// ============================================
// STARCruiser CLICKER - MAIN SCRIPT
// Version 2.1.0
// ============================================

// ============================================
// GLOBAL TOOLTIP
// ============================================
const tooltip = document.createElement('div');
tooltip.className = 'upgrade-tooltip';
document.body.appendChild(tooltip);
let tooltipAnchor = null;

function showTooltip(text, x, y, options) {
    // Chaque ligne du tooltip est insecable (nowrap) : un nombre ne peut jamais
    // etre coupe en deux par le retour a la ligne impose par max-width.
    tooltip.replaceChildren(...text.split('\n').map(line => {
        const span = document.createElement('span');
        span.className = 'tooltip-line';
        span.textContent = line;
        return span;
    }));
    tooltip.style.width = '';
    tooltip.style.maxWidth = '';
    if (options && options.width) {
        tooltip.style.width = options.width + 'px';
        tooltip.style.maxWidth = options.width + 'px';
    }
    tooltip.classList.add('visible');
    tooltip.__lastLiveContent = null;
    const rect = tooltip.getBoundingClientRect();
    const margin = 8;
    // leftEdge : bord gauche reel du tooltip une fois le centrage (-50%) applique
    const leftEdge = options && options.align === 'left' ? x : x - rect.width / 2;
    const clampedLeft = Math.max(margin, Math.min(leftEdge, window.innerWidth - rect.width - margin));
    // Clamp vertical : si le tooltip ne tient pas au-dessus (trophees proches
    // du haut d'ecran), il bascule sous l'element via options.anchorBottom.
    const anchorBottom = options && options.anchorBottom ? options.anchorBottom : y;
    const forceBelow = !!(options && options.below);
    if (!forceBelow && y - rect.height - margin >= 0) {
        tooltip.style.transform = 'translate(0, -120%)';
        tooltip.style.top = y + 'px';
    } else {
        tooltip.style.transform = 'translate(0, 0)';
        tooltip.style.top = Math.min(anchorBottom + margin, window.innerHeight - rect.height - margin) + 'px';
    }
    tooltip.style.left = clampedLeft + 'px';
    tooltipAnchor = { x, y, options: options || null };
}

function hideTooltip() {
    tooltip.classList.remove('visible');
    tooltipLiveRefresh = null;
    tooltipAnchor = null;
    tooltip.__lastLiveContent = null;
}

// Rafraichissement en continu du tooltip affiche (production qui evolue).
// Fontion qui regenere le texte; appelee periodiquement par la boucle de jeu.
let tooltipLiveRefresh = null;
function refreshLiveTooltip() {
    if (tooltipLiveRefresh && tooltip.classList.contains('visible')) {
        const nextContent = tooltipLiveRefresh();
        // Court-circuit : si le contenu est identique au dernier rendu, ni
        // le DOM ni le placement ne changent -- replaceChildren + getBoundingClientRect
        // foraient un reflow complet toutes les 500 ms pour rien.
        if (nextContent !== tooltip.__lastLiveContent) {
            tooltip.__lastLiveContent = nextContent;
            tooltip.replaceChildren(...nextContent.split('\n').map(line => {
                const span = document.createElement('span');
                span.className = 'tooltip-line';
                span.textContent = line;
                return span;
            }));
        }
        if (tooltipAnchor) {
            const rect = tooltip.getBoundingClientRect();
            const margin = 8;
            const leftEdge = tooltipAnchor.options && tooltipAnchor.options.align === 'left'
                ? tooltipAnchor.x : tooltipAnchor.x - rect.width / 2;
            const clampedLeft = Math.max(margin, Math.min(leftEdge, window.innerWidth - rect.width - margin));
            tooltip.style.left = clampedLeft + 'px';
            if (tooltipAnchor.y - rect.height - margin < 0) {
                const anchorBottom = tooltipAnchor.options && tooltipAnchor.options.anchorBottom
                    ? tooltipAnchor.options.anchorBottom : tooltipAnchor.y;
                tooltip.style.top = Math.min(anchorBottom + margin, window.innerHeight - rect.height - margin) + 'px';
            }
        }
    }
}

// Détection d'un écran tactile (mobile / tablette)
const IS_TOUCH = window.matchMedia('(hover: none) and (pointer: coarse)').matches
    || 'ontouchstart' in window
    || navigator.maxTouchPoints > 0;

// ============================================
// GLOBAL CONSTANTS
// ============================================
// Croissance du prix d'un même bâtiment à l'achat : ×1.15 par bâtiment possédé
// (identique à Cookie Clicker — le prix double tous les ~5 achats).
const BUILDING_PRICE_GROWTH_RATE = 1.15;
const GAME_LOOP_FPS = 10;
const GAME_LOOP_INTERVAL_MS = 100;
const BONUS_SPAWN_INTERVAL_MS = 30000;
const COMET_SHOWER_INTERVAL_MS = 6 * 60 * 1000;
const SAVE_INTERVAL_MS = 30000;
const DISPLAY_UPDATE_INTERVAL_MS = 100;
const SLOW_UPDATE_INTERVAL_MS = 1000;
const TOAST_DURATION_MS = 3000;

const BUILDING_UPDATE_INTERVAL_MS = 500;
const SPACE_UPDATE_INTERVAL_MS = 100; // V3.4 : 100 ms -- retour playtest, la case destination paraissait en retard
// Seuil au-dela duquel un ecart de tick n'est PLUS credite directement par la
// boucle : navigateur throttle en arriere-plan (desktop), machine endormie,
// onglet repris apres des heures. Au-dela, le temps passe par le systeme
// hors-ligne plafonne (applyOfflineEarnings) -- le meme chemin qu'une partie
// fermee puis rouverte. Sans lui, un onglet desktop oublie en arriere-plan
// produisait sans AUCUN plafond (le gel mobile ne couvre que le mobile).
const GAME_TICK_DIRECT_CREDIT_MAX_MS = 60000;

// ============================================
// GAME DATA
// ============================================

// ============================================
// ============================================
// ROCKET_PARTS avec tailles proportionnelles
// Hauteur totale: 454px (centrée verticalement)
// ============================================
// ============================================
// BÂTIMENTS DE PRODUCTION
// Achetables en masse, génèrent des Parts/s. Boucle clicker.
// ============================================
// Les noms/descriptions sont en FR (cles i18n) : affiches via t()/tf().
const PRODUCTION_BUILDINGS = [
    { id: "workshop",      name: "Atelier",                  description: "Tout commence ici", baseCost: 15,            gain: 0.1,      count: 0, image: "", imgPath: "images/buildings/workshop.webp",  unlockCondition: () => true,            totalGenerated: 0 },
    { id: "factory",       name: "Usine",                    description: "Construit les ateliers", baseCost: 100,           gain: 1,         count: 0, image: "",       imgPath: "images/buildings/factory.webp",  unlockCondition: () => score >= 50,       totalGenerated: 0 },
    { id: "mine",          name: "Mine stellaire",           description: "Nourrit les usines", baseCost: 1100,          gain: 8,        count: 0, image: "",       imgPath: "images/buildings/stellar-mine.webp", unlockCondition: () => score >= 500,      totalGenerated: 0 },
    { id: "solar",         name: "Centrale solaire",         description: "Alimente le complexe", baseCost: 12000,         gain: 47,       count: 0, image: "",       imgPath: "images/buildings/solar-central.webp", unlockCondition: () => score >= 6000,     totalGenerated: 0 },
    { id: "foundry",       name: "Autofab orbitale",        description: "Usines qui s'assemblent seules", baseCost: 130000,       gain: 260,     count: 0, image: "", imgPath: "images/buildings/orbital-autofab.webp", unlockCondition: () => score >= 65000,   totalGenerated: 0 },
    { id: "station",       name: "Essaim de sondes",         description: "Sondes auto-réplicantes", baseCost: 1400000,      gain: 1400,    count: 0, image: "", imgPath: "images/buildings/essaim-sonde.webp", unlockCondition: () => score >= 700000, totalGenerated: 0 },
    { id: "nanoforge",     name: "Nanoforge",                description: "L'atome devient matière première", baseCost: 20000000,     gain: 7800,   count: 0, image: "", imgPath: "images/buildings/nanoforge.webp", unlockCondition: () => score >= 10000000, totalGenerated: 0 },
    { id: "synth",         name: "Imprimeur quantique",  description: "La matière sur mesure", baseCost: 330000000,    gain: 44000,  count: 0, image: "", imgPath: "images/buildings/quantic-printer.webp", unlockCondition: () => score >= 150000000, totalGenerated: 0 },
    { id: "antimatter",   name: "Collecteur d'antimatière",  description: "Ressource ultime", baseCost: 5100000000,   gain: 260000, count: 0, image: "", imgPath: "images/buildings/antimatter_collector.webp", unlockCondition: () => score >= 2500000000, totalGenerated: 0 },
    { id: "voidrig",       name: "Forge de vide",           description: "Extrait l'énergie du vide quantique", baseCost: 75000000000,          gain: 1600000,      count: 0, image: "",       imgPath: "images/buildings/voidforge.webp", unlockCondition: () => score >= 35000000000,       totalGenerated: 0 },
    { id: "quasar",        name: "Moteur à quasar",           description: "Énergie de quasar", baseCost: 1000000000000,        gain: 10000000,    count: 0, image: "",       imgPath: "images/buildings/quasar-motor.webp", unlockCondition: () => score >= 500000000000,    totalGenerated: 0 },
    { id: "nebula",        name: "Fonderie stellaire",   description: "Coule des étoiles entières", baseCost: 14000000000000,          gain: 65000000,      count: 0, image: "",       imgPath: "images/buildings/stellar-fundry.webp", unlockCondition: () => score >= 7500000000000,      totalGenerated: 0 },
    { id: "pulsar",        name: "Horloger de pulsar",          description: "Règle les battements de l'univers", baseCost: 170000000000000,          gain: 430000000,      count: 0, image: "",       imgPath: "images/buildings/pulsar-clock.webp", unlockCondition: () => score >= 100000000000000,    totalGenerated: 0 },
    { id: "blackhole",     name: "Trou noir industriel",     description: "L'ultime moteur", baseCost: 2100000000000000,          gain: 2900000000,      count: 0, image: "",       imgPath: "images/buildings/black-hole-factory.webp", unlockCondition: () => score >= 1500000000000000,    totalGenerated: 0 },
];

// Bâtiments de production = liste utilisée par la boucle clicker (achat en masse, gain Parts/s)
const BUILDINGS = PRODUCTION_BUILDINGS;

// ============================================
// PIÈCES DE FUSÉE
// Achats uniques par run (payés en Parts). Compléter les 10 = lancement.
// ============================================
// V4 : la premiere piece garde son prix de base, toutes les suivantes
// sont majorees de +30% (ROCKET_PART_COST_INCREASE) pour ralentir l'assemblage.
// V4 : prix des pieces de fusee fixes, rencheris a la main
// (la 1ere piece reste a 50, les suivantes montent fort pour
// ralentir l'assemblage).
const ROCKET_PARTS = [
    { id: "nozzles",       name: "Tuyères",        description: "Propulsion", cost: 50, image: "",       imgPath: "images/rocket/nozzles.webp",       x: 50,    y: 646, width: 40,  height: 20,  order: 2,  purchased: false },
    { id: "engines",       name: "Moteurs",        description: "Moteurs principaux", cost: 210, image: "",       imgPath: "images/rocket/engines.webp",       x: 50,    y: 595, width: 40,  height: 51,  order: 3,  purchased: false },
    { id: "fuel-tank",     name: "Réservoir",     description: "Carburant", cost: 650, image: "",       imgPath: "images/rocket/fuel-tank.webp",     x: 50,    y: 537, width: 40,  height: 58,  order: 4,  purchased: false },
    { id: "rocket-body",   name: "Corps",          description: "Structure", cost: 1650, image: "",       imgPath: "images/rocket/body.webp",          x: 50,    y: 337, width: 40,  height: 200, order: 5,  purchased: false },
    { id: "boosters-left", name: "Boosters Gauche", description: "Propulsion supplémentaire", cost: 10853, image: "",       imgPath: "images/rocket/boosters-left.webp", x: 45.8,  y: 373, width: 50,  height: 300, order: 6,  purchased: false },
    { id: "boosters-right",name: "Boosters Droit",  description: "Propulsion supplémentaire", cost: 15842, image: "",       imgPath: "images/rocket/boosters-right.webp",x: 54.2,  y: 373, width: 50,  height: 300, order: 6,  purchased: false },
    { id: "cockpit",       name: "Cockpit",        description: "Poste de pilotage", cost: 50458, image: "", imgPath: "images/rocket/cockpit.webp",        x: 50,    y: 292, width: 45,  height: 45,  order: 7,  purchased: false },
    { id: "shield",        name: "Bouclier",       description: "Protection", cost: 160561, image: "",       imgPath: "images/rocket/shield.webp",        x: 50,    y: 233, width: 45,  height: 59,  order: 8,  purchased: false },
    { id: "launch-pad",    name: "Pas de tir",     description: "Lancement", cost: 550473, image: "",       imgPath: "images/rocket/launch-pad.webp",    x: 60.7,  y: 205, width: 190, height: 481, order: 9,  purchased: false },
    { id: "astronaut",     name: "Astronaute",    description: "Pilote", cost: 1000067, image: "", imgPath: "images/rocket/astronaut.webp",     x: 39.8,  y: 635, width: 25,  height: 60,  order: 10, purchased: false }
];




// Ameliorations de clic inspirees de Cookie Clicker :
// - Chacune double la valeur de base du clic (x2, comme Reinforced finger / Carpal tunnel).
// - A partir de la 2e, debloque un bonus par bâtiment possede ( Thousand Fingers).
// - Les couts suivent l'echelle ~x10 de Cookie Clicker.
const CLICK_UPGRADES = [
    // Deblocage par Parts gagnees via les clics uniquement, cumulees depuis
    // le debut du run (reset au lancement comme les upgrades). Le cout reste
    // le vrai verrou, decalant chaque achat dans le temps.
    // Echelonnement resserre : premier palier des ~50 clics (au lieu de 100
    // parts cumulees), puis progression ~x4 a x5 par palier pour lisser
    // la courbe vers les hauts multiplicateurs.
    { threshold: 50,        name: "Doigt renforcé",        cost: 50 },
    { threshold: 250,       name: "Précision laser",       cost: 250 },
    { threshold: 1200,      name: "Lancement puissant",   cost: 2500 },
    { threshold: 6000,      name: "Ingénieur expert",     cost: 15000 },
    { threshold: 30000,     name: "Scientifique spatial",  cost: 100000 },
    { threshold: 150000,    name: "Pionnier galactique",  cost: 750000 },
    { threshold: 750000,    name: "Click galactique",     cost: 5000000 },
    { threshold: 4000000,   name: "Maître cosmique",      cost: 40000000 },
    { threshold: 20000000,  name: "Puissance interstellaire", cost: 300000000 },
    { threshold: 100000000, name: "Main de l'univers",   cost: 2000000000 }
];

// Paliers de 1 a 200 batiments : personne ne depassera 200 exemplaires
const BUILDING_UPGRADE_THRESHOLDS = [1, 5, 10, 25, 50, 75, 100, 150, 200, 250, 300, 350, 400, 450, 500];

function getUpgradeTierColor(tierIndex, tierCount) {
    const n = tierCount || BUILDING_UPGRADE_THRESHOLDS.length;
    if (n <= 1) return UPGRADE_COLORS[0];
    const pos = Math.round(tierIndex * (UPGRADE_COLORS.length - 1) / (n - 1));
    return UPGRADE_COLORS[Math.min(Math.max(pos, 0), UPGRADE_COLORS.length - 1)];
}
const UPGRADE_COLORS = [
    '#88c9ee', '#66b2ff', '#4499ff', '#2288ff', '#1177ff',
    '#0066ff', '#4444ff', '#6622ff', '#8800ff', '#aa00dd',
    '#cc00bb', '#ee0099', '#ff0077', '#ff0055', '#ff2233',
    '#ff4411', '#ff6600', '#ff8800', '#ffaa00', '#ffcc00',
    '#ffee00', '#ffff00', '#ccff00', '#88ff44', '#44ff88',
    '#22ffcc', '#00ffee', '#00ffff', '#66ffee', '#aefcff',
    '#ffffff'
];

const RANDOM_BONUSES = [
    { id: "meteor", symbol: "", name: "Pluie de météores", effect: "instant", type: "meteor", colorClass: "meteor" },
    { id: "flare", symbol: "", name: "Éruption solaire", effect: "multiplier", type: "flare", multiplier: 2, duration: 15000, colorClass: "flare" }
];

const SAVE_VERSION = "2.2.0";

// ============================================
// TROPH\u0009ES
// ============================================
const TROPHY_COLORS = {
    pps: ['#88c9ee', '#4499ff', '#1177ff', '#0066ff', '#6622ff', '#aa00dd', '#ff0055'],
    planets: ['#94a3b8', '#ef4444', '#06b6d4', '#8b5cf6', '#10b981', '#3b82f6', '#f59e0b', '#fbbf24', '#ec4899', '#a78bfa'],
    launches: ['#66b2ff', '#2288ff', '#8800ff', '#ff8800'],
    stardust: ['#6622ff', '#cc00bb', '#ffcc00'],
    'building-upgrade': ['#88c9ee', '#2288ff', '#aa00dd', '#ff4411'],
    'click-upgrade': ['#1177ff', '#ffaa00'],
    building: ['#88c9ee', '#0066ff', '#ff6600', '#ffcc00', '#ffee00', '#ffff00'],
    score: ['#ffcc00', '#ff8800', '#ffee00'],
    bonus: ['#f59e0b', '#ff2233'],
    'building-types': ['#a78bfa'],
    cards: ['#94a3b8', '#a78bfa']
};
const TROPHIES = [
    // Parts par seconde (icônes: bâtiments du jeu, du plus humble au plus puissant)
    // Famille rescalee sur 15 paliers, dernier objectif 100 Qi/s (1e20).
    { id: "pps-1", name: "First Parts", description: "Atteindre 1 Parts par seconde", icon: "images/parts.webp", threshold: 1, type: "pps" },
    { id: "pps-10", name: "Liftoff", description: "Atteindre 10 Parts par seconde", icon: "images/parts.webp", threshold: 10, type: "pps" },
    { id: "pps-100", name: "Orbit Achieved", description: "Atteindre 100 Parts par seconde", icon: "images/parts.webp", threshold: 100, type: "pps" },
    { id: "pps-1000", name: "Space Speed", description: "Atteindre 1 000 Parts par seconde", icon: "images/parts.webp", threshold: 1000, type: "pps" },
    { id: "pps-10000", name: "Galactic Speed", description: "Atteindre 10 000 Parts par seconde", icon: "images/parts.webp", threshold: 10000, type: "pps" },
    { id: "pps-100000", name: "Warp Speed", description: "Atteindre 100 000 Parts par seconde", icon: "images/parts.webp", threshold: 100000, type: "pps" },
    { id: "pps-1000000", name: "Vitesse Nébulaire", description: "Atteindre 1 M Parts par seconde", icon: "images/parts.webp", threshold: 1000000, type: "pps" },
    { id: "pps-1e8", name: "Hyperdrive", description: "Atteindre 100 M Parts par seconde", icon: "images/parts.webp", threshold: 1e8, type: "pps" },
    { id: "pps-1e10", name: "Reality Bender", description: "Atteindre 10 B Parts par seconde", icon: "images/parts.webp", threshold: 1e10, type: "pps" },
    { id: "pps-1e12", name: "Cœur d'Étoile à Neutrons", description: "Atteindre 1 T Parts par seconde", icon: "images/parts.webp", threshold: 1e12, type: "pps" },
    { id: "pps-1e14", name: "Puits de Gravité", description: "Atteindre 100 T Parts par seconde", icon: "images/parts.webp", threshold: 1e14, type: "pps" },
    { id: "pps-1e15", name: "Moteur Galactique", description: "Atteindre 1 Qa Parts par seconde", icon: "images/parts.webp", threshold: 1e15, type: "pps" },
    { id: "pps-1e16", name: "Usine à Univers", description: "Atteindre 10 Qa Parts par seconde", icon: "images/parts.webp", threshold: 1e16, type: "pps" },
    { id: "pps-1e18", name: "Forgesseur de Réalités", description: "Atteindre 1 Qi Parts par seconde", icon: "images/parts.webp", threshold: 1e18, type: "pps" },
    { id: "pps-1e20", name: "Fontaine Cosmique", description: "Atteindre 100 Qi Parts par seconde", icon: "images/parts.webp", threshold: 1e20, type: "pps" },

    // Vitesse de voyage (icône: missile) — vitesse REELLE de la stat
    // "Vitesse", c'est-a-dire les km/s gagnes par la distance atteignable.
    // Famille rescalee sur 15 paliers (max famille = 15 pour l'echelle
    // de couleurs des niveaux) jusqu'a 100 Sx km/s (1e23).
    { id: "speed-100", name: "Première Accélération", description: "Atteindre 100 km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 100, type: "speed" },
    { id: "speed-1000", name: "Propulsion Ionique", description: "Atteindre 1 000 km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1000, type: "speed" },
    { id: "speed-10000", name: "Vitesse Stellaire", description: "Atteindre 10 000 km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 10000, type: "speed" },
    { id: "speed-100000", name: "Missile Interstellaire", description: "Atteindre 100 000 km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 100000, type: "speed" },
    { id: "speed-299792", name: "Plus Vite que la Lumière", description: "Dépasser la vitesse de la lumière (299 792 km/s)", icon: "images/effects/missile.webp", threshold: 299792, type: "speed" },
    { id: "speed-1000000", name: "Propulsion Warp", description: "Atteindre 1 M km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1000000, type: "speed" },
    { id: "speed-1e8", name: "Fracture Lumineuse", description: "Atteindre 100 M km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e8, type: "speed" },
    { id: "speed-1e10", name: "Nomade Interstellaire", description: "Atteindre 10 B km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e10, type: "speed" },
    { id: "speed-1e12", name: "Dieu du Voyage", description: "Atteindre 1 T km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e12, type: "speed" },
    { id: "speed-1e14", name: "Trou Noir Portatif", description: "Atteindre 100 T km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e14, type: "speed" },
    { id: "speed-1e16", name: "Saut Quantique", description: "Atteindre 10 Qa km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e16, type: "speed" },
    { id: "speed-1e18", name: "Voyageur du Multivers", description: "Atteindre 1 Qi km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e18, type: "speed" },
    { id: "speed-1e19", name: "Pli Spatial", description: "Atteindre 10 Qi km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e19, type: "speed" },
    { id: "speed-1e21", name: "Marcheur de Réalités", description: "Atteindre 1 Sx km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e21, type: "speed" },
    { id: "speed-1e23", name: "Écheveau Brisé", description: "Atteindre 100 Sx km/s de vitesse de voyage", icon: "images/effects/missile.webp", threshold: 1e23, type: "speed" },

    // Progression spatiale (icônes: images des planètes)
    { id: "planet-moon", name: "Premier Pas", description: "Atteindre la Lune", icon: "images/planets/moon.webp", threshold: 1, type: "planets" },
    { id: "planet-mars", name: "Explorateur Martien", description: "Atteindre Mars", icon: "images/planets/mars.webp", threshold: 2, type: "planets" },
    { id: "planet-neptune", name: "Lointaine Neptune", description: "Atteindre Neptune", icon: "images/planets/neptune.webp", threshold: 3, type: "planets" },
    { id: "planet-pluto", name: "Aux Confins du Système", description: "Atteindre Pluton", icon: "images/planets/pluto.webp", threshold: 4, type: "planets" },
    { id: "planet-proxima", name: "Voyageur Interstellaire", description: "Atteindre Proxima Centauri", icon: "images/planets/proxima-centauri.webp", threshold: 5, type: "planets" },
    { id: "planet-sirius", name: "Éclat de Sirius", description: "Atteindre Sirius", icon: "images/planets/sirius.webp", threshold: 6, type: "planets" },
    { id: "planet-oort", name: "Le Grand Nuage", description: "Atteindre le Nuage d'Oort", icon: "images/planets/oort-cloud.webp", threshold: 7, type: "planets" },
    { id: "planet-milky", name: "Cœur de la Galaxie", description: "Atteindre le Centre de la Voie lactée", icon: "images/planets/milky-way-center.webp", threshold: 8, type: "planets" },
    { id: "planet-andromeda", name: "Galaxie Voisine", description: "Atteindre Andromède", icon: "images/planets/andromeda.webp", threshold: 9, type: "planets" },
    { id: "planet-virgo", name: "Conquérant de l'Univers", description: "Atteindre l'Amas de Virgo", icon: "images/planets/virgo-cluster2.webp", threshold: 10, type: "planets" },

    // Lancements de fusée (icônes: pièces de fusée)
    { id: "launch-1", name: "Décollage !", description: "Réaliser votre premier lancement", icon: "images/rocket/Fusée3.webp", threshold: 1, type: "launches" },
    { id: "launch-5", name: "Pilote Confirmé", description: "Réaliser 2 lancements", icon: "images/rocket/Fusée3.webp", threshold: 2, type: "launches" },
    { id: "launch-15", name: "Escadron Spatial", description: "Réaliser 3 lancements", icon: "images/rocket/Fusée3.webp", threshold: 3, type: "launches" },
    { id: "launch-30", name: "Flotte Interstellaire", description: "Réaliser 5 lancements", icon: "images/rocket/Fusée3.webp", threshold: 5, type: "launches" },
    { id: "launch-50", name: "Vétéran des Étoiles", description: "Réaliser 7 lancements", icon: "images/rocket/Fusée3.webp", threshold: 7, type: "launches" },
    { id: "launch-100", name: "Légende Cosmique", description: "Réaliser 9 lancements", icon: "images/rocket/Fusée3.webp", threshold: 9, type: "launches" },
    { id: "launch-50real", name: "Commandant de Flotte", description: "Réaliser 12 lancements", icon: "images/rocket/Fusée3.webp", threshold: 12, type: "launches" },
    { id: "launch-100real", name: "Amiral de l'Infini", description: "Réaliser 15 lancements", icon: "images/rocket/Fusée3.webp", threshold: 15, type: "launches" },

    // Poussière d'étoiles (icônes: cartes du jeu)
    { id: "dust-1", name: "Première Poussière", description: "Gagner 1 Poussière d'Étoiles", icon: "images/Stardust.webp", threshold: 1, type: "stardust" },
    { id: "dust-100", name: "Collectionneur Cosmique", description: "Gagner 100 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 100, type: "stardust" },
    { id: "dust-1000", name: "Maître de la Poussière", description: "Gagner 1 000 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 1000, type: "stardust" },
    { id: "dust-10000", name: "Semeur d'Étoiles", description: "Gagner 10 000 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 10000, type: "stardust" },
    { id: "dust-100000", name: "Architecte Céleste", description: "Gagner 100 000 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 100000, type: "stardust" },
    { id: "dust-500000", name: "Alchimiste Stellaire", description: "Gagner 500 000 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 500000, type: "stardust" },
    { id: "dust-1000000", name: "Façonneur de Cosmos", description: "Gagner 1 000 000 Poussière d'Étoiles au total", icon: "images/Stardust.webp", threshold: 1000000, type: "stardust" },

    // Améliorations de bâtiments (icônes: bâtiments)
    { id: "first-upgrade", name: "First Upgrade", description: "Acheter votre première amélioration de bâtiment", icon: "images/buildings/factory.webp", threshold: 1, type: "building-upgrade" },
    { id: "five-upgrades", name: "Upgrade Master", description: "Avoir 5 améliorations de bâtiment", icon: "images/buildings/factory.webp", threshold: 5, type: "building-upgrade" },
    { id: "ten-upgrades", name: "Engineering Genius", description: "Avoir 10 améliorations de bâtiment", icon: "images/buildings/factory.webp", threshold: 10, type: "building-upgrade" },
    { id: "twenty-upgrades", name: "Upgrade Legend", description: "Avoir 20 améliorations de bâtiment", icon: "images/buildings/factory.webp", threshold: 20, type: "building-upgrade" },
    { id: "fifty-upgrades", name: "Génie de l'Ingénierie", description: "Avoir 50 améliorations de bâtiment", icon: "images/buildings/factory.webp", threshold: 50, type: "building-upgrade" },
    { id: "hundred-upgrades", name: "Ingénieur Cosmique", description: "Avoir 100 améliorations de bâtiment", icon: "images/buildings/factory.webp", threshold: 100, type: "building-upgrade" },

    // Améliorations de clic (icônes: pièce fusée + astronaute)
    { id: "first-click-upgrade", name: "First Launch", description: "Acheter votre première amélioration de clic", icon: "images/cursor.svg", threshold: 1, type: "click-upgrade" },
    { id: "all-click-upgrades", name: "Launch Master", description: "Débloquer toutes les améliorations de clic", icon: "images/cursor.svg", threshold: CLICK_UPGRADES.length, type: "click-upgrade" },

    // Bâtiments possédés (icônes: bâtiments)
    { id: "first-building", name: "First Component", description: "Acheter votre premier bâtiment", icon: "images/buildings/workshop.webp", threshold: 1, type: "building" },
    { id: "ten-buildings", name: "Space Builder", description: "Posséder 10 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 10, type: "building" },
    { id: "hundred-buildings", name: "Space Architect", description: "Posséder 100 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 100, type: "building" },
    { id: "thousand-buildings", name: "Galactic Builder", description: "Posséder 250 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 250, type: "building" },
    { id: "five-thousand-buildings", name: "Bâtisseur Stellaire", description: "Posséder 500 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 500, type: "building" },
    { id: "ten-thousand-buildings", name: "Empereur du Vide", description: "Posséder 1 000 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 1000, type: "building" },
    { id: "buildings-2000", name: "Souverain des Mégastructures", description: "Posséder 2 000 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 2000, type: "building" },
    { id: "buildings-4500", name: "Demiurge Orbital", description: "Posséder 4 500 bâtiments au total", icon: "images/buildings/workshop.webp", threshold: 4500, type: "building" },

    // Score total (icônes: parts et cartes)
    { id: "score-1000", name: "Small Start", description: "Atteindre 1 000 Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1000, type: "score" },
    { id: "score-1000000", name: "Millionaire", description: "Atteindre 1 M Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1000000, type: "score" },
    { id: "score-1000000000", name: "Billionaire", description: "Atteindre 1 B Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1000000000, type: "score" },
    { id: "score-1000000000000", name: "Trillionaire", description: "Atteindre 1 T Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1000000000000, type: "score" },
    { id: "score-1000000000000000", name: "Quadrillionaire", description: "Atteindre 1 Qa Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1000000000000000, type: "score" },
    { id: "score-10000000000000000", name: "Maître de l'Univers", description: "Atteindre 10 Qa Parts", icon: "images/cards/collection/earth-card.webp", threshold: 10000000000000000, type: "score" },
    { id: "score-100000000000000000", name: "Au-delà de l'Univers", description: "Atteindre 100 Qa Parts", icon: "images/cards/collection/earth-card.webp", threshold: 100000000000000000, type: "score" },
    { id: "score-1e18", name: "Forgeron de Réalités", description: "Atteindre 1 Qi Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1e18, type: "score" },
    { id: "score-1e19", name: "Bâtisseur de Multivers", description: "Atteindre 10 Qi Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1e19, type: "score" },
    { id: "score-1e20", name: "Architecte Cosmique Suprême", description: "Atteindre 100 Qi Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1e20, type: "score" },
    { id: "score-1e21", name: "Au-delà de l'Infini", description: "Atteindre 1 Sx Parts", icon: "images/cards/collection/earth-card.webp", threshold: 1e21, type: "score" },

    // Bonus cliqués (icônes: comète)
    { id: "first-bonus", name: "First Bonus", description: "Attraper votre première comète", icon: "images/effects/comete.webp", threshold: 1, type: "bonus" },
    { id: "ten-bonuses", name: "Bonus Hunter", description: "Attraper 10 comètes", icon: "images/effects/comete.webp", threshold: 10, type: "bonus" },
    { id: "fifty-bonuses", name: "Chasseur de Comètes", description: "Attraper 50 comètes", icon: "images/effects/comete.webp", threshold: 50, type: "bonus" },
    { id: "hundred-bonuses", name: "Cerveau Cosmique", description: "Attraper 100 comètes", icon: "images/effects/comete.webp", threshold: 100, type: "bonus" },
    { id: "bonuses-250", name: "As de l'Interception", description: "Attraper 250 comètes", icon: "images/effects/comete.webp", threshold: 250, type: "bonus" },
    { id: "bonuses-500", name: "Œil du Cosmos", description: "Attraper 500 comètes", icon: "images/effects/comete.webp", threshold: 500, type: "bonus" },
    { id: "bonuses-1000", name: "Surfeur de Comètes", description: "Attraper 1 000 comètes", icon: "images/effects/comete.webp", threshold: 1000, type: "bonus" },

    // Collection (icône: carte trou noir)
    { id: "all-buildings", name: "Space Collector", description: "Débloquer tous les types de bâtiments", icon: "images/cards/collection/factory-card.webp", threshold: BUILDINGS.length, type: "building-types" },
    { id: "cards-10", name: "Cartothécaire", description: "Posséder 10 cartes de collection", icon: "images/cards/collection/booster1.webp", threshold: 10, type: "cards" },
    { id: "cards-20", name: "Collection Complète", description: "Posséder toutes les cartes de collection", icon: "images/cards/collection/booster1.webp", threshold: 20, type: "cards" },
    // V3.12 : TROPHEES DES NOUVELLES MECANIQUES INFINIES
    // Doublements du record (V3.9) : paliers de +50% chacun
    { id: "record-double-1", name: "Doubler la Gageure", description: "Doubler une première fois ton record de distance (+50% de production permanente)", icon: "images/rocket/boosters-right.webp", threshold: 1, type: "record-doublings" },
    { id: "record-double-3", name: "Ascension Géométrique", description: "Doubler ton record 3 fois (+150% de production permanente cumulée)", icon: "images/rocket/boosters-right.webp", threshold: 3, type: "record-doublings" },
    { id: "record-double-5", name: "Seigneur des Exposants", description: "Doubler ton record 5 fois (+250% de production permanente cumulée)", icon: "images/rocket/boosters-right.webp", threshold: 5, type: "record-doublings" },
    { id: "record-double-10", name: "Horizon des Records", description: "Doubler ton record 10 fois (+500% de production permanente cumulée)", icon: "images/rocket/boosters-right.webp", threshold: 10, type: "record-doublings" },
    // Renforcement cosmique (V3.9, endgame) : niveaux du puits de PE
    { id: "cosmic-boost-1", name: "Premier Renforcement", description: "Acheter 1 niveau de Renforcement cosmique", icon: "images/planets/cluster4.png", threshold: 1, type: "cosmic-boost" },
    { id: "cosmic-boost-5", name: "Armure Stelloïque", description: "Acheter 5 niveaux de Renforcement cosmique (+25% de production)", icon: "images/planets/cluster4.png", threshold: 5, type: "cosmic-boost" },
    { id: "cosmic-boost-10", name: "Cœur Cosmique", description: "Acheter 10 niveaux de Renforcement cosmique (+50% de production)", icon: "images/planets/cluster4.png", threshold: 10, type: "cosmic-boost" },
    // V3.29 : contrats reussis + interception de cometes.
    { id: "contracts-5", name: "Sous-Traitant Zélé", description: "Réussir 5 contrats de fabrication", icon: "images/effects/contract.webp", threshold: 5, type: "contracts-completed" },
    { id: "contracts-15", name: "Pilote de Contrats", description: "Réussir 15 contrats de fabrication", icon: "images/effects/contract.webp", threshold: 15, type: "contracts-completed" },
    { id: "contracts-30", name: "Magnat des Contrats", description: "Réussir 30 contrats de fabrication", icon: "images/effects/contract.webp", threshold: 30, type: "contracts-completed" },
    { id: "score-1e21-treasury", name: "Trésorier du Big Bang", description: "Atteindre 1 000 Qi Parts (1e21)", icon: "images/cards/collection/earth-card.webp", threshold: 1e21, type: "score" },
    // Bâtiment favori (V3.8/V3.9) : heures de jeu cumulees
    { id: "fav-30m", name: "Fidèle Artisan", description: "Cumuler 30 minutes de jeu avec un bâtiment favori", icon: "images/cards/collection/pulsar-clock-card.webp", threshold: 1800, type: "fav-seconds" },
    { id: "fav-2h", name: "Compagnon d'Atelier", description: "Cumuler 2 heures de jeu avec des bâtiments favoris", icon: "images/cards/collection/pulsar-clock-card.webp", threshold: 7200, type: "fav-seconds" },
    { id: "fav-6h", name: "Âme d'Ingénieur", description: "Cumuler 6 heures de jeu avec des bâtiments favoris", icon: "images/cards/collection/pulsar-clock-card.webp", threshold: 21600, type: "fav-seconds" },
    // Héritage industriel (V3.9)
    // Plafond des multiplicateurs temporaires (V3.10/V3.11)
    { id: "temp-mult-16", name: "Cascade Solaire", description: "Atteindre x16 de multiplicateurs temporaires simultanés", icon: "images/planets/andromeda.webp", threshold: 16, type: "temp-mult" },
    { id: "temp-mult-64", name: "Tempête d'Éruptions", description: "Atteindre x64 de multiplicateurs temporaires simultanés", icon: "images/planets/andromeda.webp", threshold: 64, type: "temp-mult" },
    { id: "temp-mult-256", name: "Fournaise Stellaire", description: "Atteindre x256 de multiplicateurs temporaires simultanés", icon: "images/planets/andromeda.webp", threshold: 256, type: "temp-mult" },
    { id: "temp-mult-2048", name: "Rideau de Flares", description: "Atteindre le plafond x2048 de multiplicateurs temporaires simultanés -- l'exploit ultime des comètes", icon: "images/planets/andromeda.webp", threshold: 2048, type: "temp-mult" },
];

// ============================================
// GLOBAL VARIABLES
// ============================================
let score = 0;
let partsPerSecond = 0;
let partsSinceLaunch = 0;
let autoMultiplier = 1;
let clickMultiplier = 1;
let activeRandomBonuses = [];
let autoMultipliers = [1];
let clickMultipliers = [1];
let buildingUpgrades = {};
let buildingUpgradeCosts = {};
let totalPartsFromClicks = 0;
// Nombre total de clics sur la piece depuis le debut de la partie (jamais
// reset : survit aux expeditions, comme totalPartsEarnedAllTime).
let totalClicksAllTime = 0;
let activatedClickUpgrades = [];
let unlockedBuildings = new Set();
let totalGeneratedByBuilding = {};
let totalGeneratedAtLaunchStart = 0;
let totalPartsEarnedAllTime = 0;
let totalPartsEarnedThisLaunch = 0;
let naturalPartsThisLaunch = 0;
let lastSaveTime = 0;
let lastBuildingsUpdate = 0;
let lastRocketPartsUpdate = 0;
let lastSpaceProgressUpdate = 0;
let lastDisplayUpdate = 0;
let lastSlowUpdate = 0;
let gameStartTime = 0;
let expeditionStartTime = 0; // début de l'expédition en cours (reset à chaque lancement) — gameStartTime reste le début de la 1re partie
let startupBonusApplied = false;
let tutorialSeen = false;
let buyMultiplier = 1;
let clickedBonusesCount = 0;
// V3.29 : contrats REUSSIS (trophees).
let contractsCompleted = 0;
// V3.5 : comets interceptees depuis la derniere interception -- penalite
// decroissante sur la chance de spawn par clic, purgee lentement par le gameLoop.
let cometsInterceptedWindow = { count: 0, lastDecay: 0 };
let unlockedTrophies = new Set();

// ============================================
// ROCKET LAUNCH SYSTEM
// ============================================
let maxDistance = 0;
// Records de la partie : vitesse max atteinte et Parts/s max -- suivis
// en continu, sauvegardes, affiches dans les statistiques.
let maxTravelSpeed = 0;
// Anti-triche couche 1bis (WASM) : quand le module starcruiser-core est
// charge, les RECORDS de vitesse et distance vivent dans sa memoire lineaire
// (inaccessible depuis la console) -- les variables JS ci-dessus ne servent
// plus que d'affichage/cache. Voir wasm/README.md.
let wasmCoreReady = false;
// V3.12 : acces aux constantes critiques du module WASM (patcher ces
// valeurs en console est sans effet -- le module est la seule source).
function wasmConst(name, fallback) {
    const w = wasmCore();
    if (w) { try { const v = w[name](); if (isFinite(v)) return v; } catch (e) {} }
    return fallback;
}
function wasmCore() { return wasmCoreReady && window.StarcruiserCore ? window.StarcruiserCore.exports : null; }
function recordMaxTravelSpeed(candidate) {
    if (!isFinite(candidate) || candidate <= 0) return;
    if (candidate > maxTravelSpeed) maxTravelSpeed = candidate;
    const w = wasmCore(); if (w) { try { w.set_record_speed(candidate); } catch (e) {} }
}
function getRecordMaxTravelSpeed() {
    const w = wasmCore();
    if (w) { try { const v = w.get_record_speed(); if (isFinite(v) && v > 0) return v; } catch (e) {} }
    return maxTravelSpeed;
}
function recordMaxDistance(candidate) {
    if (!isFinite(candidate) || candidate <= 0) return;
    if (candidate > maxDistance) maxDistance = candidate;
    // V3.49 (retour joueur : le systeme de record double ne se debloque
    // qu'APRES l'Amas de Virgo) : avant gameFinished, le compteur de
    // doublages ne tourne PAS -- les mecaniques de la suite infinie ne
    // concernent que le mode infini, rien ne doit s'afficher avant.
    if (!gameFinished) return;
    // V3.9 : chaque palier x2 consecutif du record = +50% de prod permanente.
    if (lastRecordForDoubling <= 0) lastRecordForDoubling = candidate;
    else if (candidate >= lastRecordForDoubling * 2) {
        recordDoublings++;
        lastRecordForDoubling = candidate;
        invalidateBuildingGainsCache();
        showToast('\ud83d\udd25 ' + t('Record doubl\u00e9 ! +50% de production permanente'));
        Sounds.boosterReady();
    }
    const w = wasmCore(); if (w) { try { w.set_record_distance(candidate); } catch (e) {} }
}
function getRecordMaxDistance() {
    const w = wasmCore();
    if (w) { try { const v = w.get_record_distance(); if (isFinite(v) && v > 0) return v; } catch (e) {} }
    return maxDistance;
}
// Anti-triche : sanitisation des multiplicateurs de boost charges depuis
// une sauvegarde (import manuel ou localStorage edite a la main). Le seul
// boost de production du jeu est le flare x4 (WASM) : toute valeur
// superieure, NaN ou Infinity est necessairement falsifiee et ecretee.
function sanitizeLoadedMultipliers(arr, maxAllowed) {
    if (!Array.isArray(arr)) return [1];
    const cleaned = arr.filter(v => typeof v === 'number' && isFinite(v) && v > 0 && v <= maxAllowed);
    return cleaned.length ? cleaned : [1];
}
// Anti-triche WASM : les bonus par rarete de cartes vivent dans le module.
// Toute modification de CARD_RARITIES en console est sans effet sur la
// production (la lecture passe par le module ; fallback JS si absent).
const CARD_RARITY_INDEX = { common: 0, rare: 1, epic: 2, legendary: 3, alternative: 4 };
function wasmCardBonusMult(rarity) {
    const w = wasmCore();
    if (w) { try { return w.card_bonus_mult(CARD_RARITY_INDEX[rarity] ?? 99); } catch (e) {} }
    return (CARD_RARITIES[rarity] || {}).bonusMult || 0;
}
function wasmUpgradeEffectPerLevel(upgradeId) {
    const w = wasmCore();
    if (w) { try { return w.upgrade_effect_per_level(WASM_UPGRADE_INDEX[upgradeId] ?? 99); } catch (e) {} }
    const u = GALACTIC_UPGRADES.find(x => x.id === upgradeId);
    return u ? u.effectPerLevel : 0;
}
const WASM_UPGRADE_INDEX = { prod1: 0, prod2: 1, prod3: 2, prod4: 3, prod5: 4, prod6: 5, prod7: 6, prod8: 7, click1: 10, click2: 11, click3: 12, click4: 13, click5: 14, click6: 15, click7: 16, click8: 17, coll4: 20, 'inf-boost': 30 };
const WASM_BUILDING_INDEX = {};
PRODUCTION_BUILDINGS.forEach((b, i) => { WASM_BUILDING_INDEX[b.id] = i; });
function wasmBuildingGain(buildingId) {
    const w = wasmCore();
    if (w) { try { const g = w.building_gain(WASM_BUILDING_INDEX[buildingId] ?? 99); if (g > 0) return g; } catch (e) {} }
    const b = PRODUCTION_BUILDINGS.find(x => x.id === buildingId);
    return b ? b.gain : 0;
}
function wasmBuildingUpgradeMultiplier(nb) {
    const w = wasmCore();
    if (w) { try { return w.building_upgrade_multiplier(nb); } catch (e) {} }
    return Math.pow(2, nb);
}



let maxPartsPerSecond = 0;
let rocketsLaunched = 0;
// Multiplicateur de production FIGE au dernier reset : sert de base aux
// prix des pieces de fusee. Recalcule une seule fois par expedition (au
// reset), pour que les prix ne suivent PAS en permanence l'evolution des
// bonus temporaires ou achats en cours de partie.
let partCostMultiplier = 1;
// === BRANCHE INFINI (V3) : etat des upgrades infinies ===
let favoriteBuildingId = null; // Bâtiment favori choisi (null = aucun)
let favoriteBuildingSeconds = 0;
// V3.8 : banque par batiment -- le bonus favori est ACQUIS, il survit aux
// changements de favori (ancien comportement : remise a zero).
let favoriteBuildingSecondsByBuilding = new Map();
// V3.4 : TEMPS DE JEU REEL -- secondes avec l'ecran reellement ouvert et le
// jeu non gele (contrairement a la date de debut de partie). Compte dans
// gameLoop uniquement : hors-ligne, arriere-plan gele et pauses ne comptent
// pas. Envoye au classement en info (jamais affiche).
let activePlaytimeSeconds = 0; // Secondes de JEU ACTIF cumulées depuis le choix du favori (zéro gain hors-ligne)
// V3.99 : ANALYSE RETENTION -- nombre de SESSIONS distinctes (un
// chargement de page qui reprend une partie existante = une session).
// Permet de voir dans le classement lisible si les joueurs reviennent.
let sessionsCount = 0;
let cometRewardMode = 'neutral'; // Choix de récompense des comètes : 'parts' | 'multiplier' | 'neutral' (persisté, AVANT apparition)
// Horodatage du dernier lancement confirme (0 = jamais lance)
let lastLaunchAt = 0;
let lastLaunchDistance = 0;
let starDust = 0; // Poussière d'Étoiles : monnaie de prestige persistante
let totalStardustEarned = 0; // Cumul de toutes les Poussière d'Étoiles gagnées (trophées)
let postVirgoStardust = 0; // Suite infinie : PE gagnées au-dela de l'Amas de Virgo (+1% production chacune)
// V3.9 : DOUBLEMENTS DU RECORD -- chaque palier x2 du record credite +50%.
let recordDoublings = 0;
let lastRecordForDoubling = 0;
function getRecordDoublingBonus() {
    return 1 + wasmConst('record_doubling_percent', 0.5) * recordDoublings;
}
let gameFinished = false; // Fin vue au moins une fois (ecran de fin apres Virgo)
let lifetimeDistanceKm = 0; // V3 : distance cumulée de TOUS les vols -- base du calcul de PE cumulatif
let stardustFromFlights = 0; // V3 : PE credites par la formule de vol UNIQUEMENT (baseline du cumulatif -- les jalons de planetes et les conversions n'y entrent PAS, sinon le jalon mangerait le gain du vol suivant)


// ============================================
// ROCKET CONSTRUCTION DATA
// ============================================
const ROCKET_PART_POSITIONS = {
    'nozzles': { position: 'bottom', emoji: '', name: 'Tuyères', class: 'rocket-engine' },
    'engines': { position: 'bottom', emoji: '', name: 'Moteurs', class: 'rocket-engine' },
    'fuel-tank': { position: 'middle', emoji: '', name: 'Réservoir', class: 'rocket-body' },
    'rocket-body': { position: 'middle', emoji: '', name: 'Corps', class: 'rocket-body' },
    'wings': { position: 'sides', emoji: '', name: 'Stabilisateurs', class: 'rocket-wings' },
    'cockpit': { position: 'top', emoji: '', name: 'Cockpit', class: 'rocket-nose' },
    'shield': { position: 'top', emoji: '', name: 'Bouclier', class: 'rocket-nose' },
    'launch-pad': { position: 'bottom', emoji: '', name: 'Pas de tir', class: 'rocket-engine' },
    'astronaut': { position: 'top', emoji: '', name: 'Astronaute', class: 'rocket-nose' }
};

let isLaunching = false;
// Pause du gameplay pendant la cinematique de lancement et l'atelier post-vol :
// production, cometes, pluie de pieces et contrats sont geles jusqu'au reset.
let gameplayPaused = false;
function setGameplayPaused(paused) {
    if (paused === gameplayPaused) return;
    gameplayPaused = paused;
    if (paused) {
        pauseStartedAt = Date.now();
        // Purge immediate de tout element de jeu en cours d'ecran.
        // COMETES DE CONTRAT : marquee "collected" avant purge -- leurs
        // timeouts de fin de vol deviennent des no-ops (sinon elles etaient
        // comptees RATEES pendant la pause et faisaient echouer le contrat
        // injustement), puis comptees pour etre RE-LANCEES a la reprise.
        const bonuses = document.getElementById('random-bonuses');
        let pausedContractComets = 0;
        if (bonuses) {
            bonuses.querySelectorAll('.random-bonus').forEach(el => {
                if (el.dataset.contractComet === '1' && el.dataset.collected !== '1') {
                    el.dataset.collected = '1';
                    pausedContractComets += 1;
                }
            });
            bonuses.innerHTML = '';
        }
        const cActive = contractState.active
            && (contractState.active.typeId === 'comets' || contractState.active.typeId === 'shower');
        if (cActive && pausedContractComets > 0) {
            const c = contractState.active;
            c.showerLaunched = Math.max(0, (c.showerLaunched || 0) - pausedContractComets);
            c.showerInFlight = Math.max(0, (c.showerInFlight || 0) - pausedContractComets);
            c.pausedRelaunch = (c.pausedRelaunch || 0) + pausedContractComets;
        }
        if (typeof partsRain !== 'undefined' && partsRain) {
            partsRain.parts.length = 0;
            partsRain.spawnDebt = 0;
        }
    } else {
        // Le contrat actif ne doit pas avoir expire pendant la cinematique :
        // on decale ses echeances du temps de pause ecoule.
        const pausedMs = Date.now() - (pauseStartedAt || Date.now());
        if (pausedMs > 0) {
            if (contractState.active) contractState.active.expiresAt += pausedMs;
            if (contractState.nextRotationAt) contractState.nextRotationAt += pausedMs;
            // Bonus temporaires : leurs endTime absolus ne doivent pas
            // avoir brule pendant la pause (cinematique ou arriere-plan
            // mobile) -- le multiplicateur est preserved integralement.
            // Un bonus deja expire AVANT la pause n'est PAS decale : il
            // reste expire (expireRandomBonuses le retirera au tick).
            const prePauseNow = Date.now() - pausedMs;
            activeRandomBonuses.forEach(bonus => {
                if (bonus.endTime > prePauseNow) bonus.endTime += pausedMs;
            });
        }
        pauseStartedAt = 0;
        // Reprise : relancer les cometes de contrat purgees par la pause.
        // Leur lancement reessaie toutes les 300 ms tant que le contrat vit
        // (launchContractComet), le compte showerLaunched/showerInFlight
        // reste donc exact.
        const cNow = contractState.active;
        if (cNow && cNow.pausedRelaunch > 0) {
            const toRelaunch = cNow.pausedRelaunch;
            cNow.pausedRelaunch = 0;
            for (let k = 0; k < toRelaunch; k++) {
                launchContractComet(k * 400);
            }
        }
    }
}
let pauseStartedAt = 0;
let launchSequenceActive = false;
// V3.6 : plus haute portee AFFICHEE du run -- progression monotone, jamais
// de retour en arriere transitoire (retour playtest apres achat de contrat).
let displayedReachPeak = 0;
let nextPlanetNotified = false;

// ============================================
// SPACE MAP SYSTEM (Planets & Bonuses)
// ============================================
const PLANETS = [
    { id: 'earth', name: 'Terre', emoji: '\uD83C\uDF0D', distanceRequired: 0, bonusPercent: 0, color: '#4a90d9', imgPath: 'images/planets/earth.webp' },
    { id: 'moon', name: 'Lune', emoji: '\uD83D\uDD11', distanceRequired: 384400, bonusPercent: 35, color: '#9aa0a6', imgPath: 'images/planets/moon.webp' },
    { id: 'mars', name: 'Mars', emoji: '\u2642', distanceRequired: 4120000, bonusPercent: 40, color: '#d97b4a', imgPath: 'images/planets/mars.webp' },
    { id: 'neptune', name: 'Neptune', emoji: '\u2645', distanceRequired: 47800000, bonusPercent: 45, color: '#4878f8', imgPath: 'images/planets/neptune.webp' },
    { id: 'pluto', name: 'Pluton', emoji: '\u2646', distanceRequired: 563000000, bonusPercent: 50, color: '#c8a878', imgPath: 'images/planets/pluto.webp' },
    { id: 'oort-cloud', name: "Nuage d'Oort", emoji: '\u2728', distanceRequired: 6100000000, bonusPercent: 55, color: '#b8c4d0', imgPath: 'images/planets/oort-cloud.webp' },
    { id: 'proxima-centauri', name: 'Proxima Centauri', emoji: '\u2609', distanceRequired: 72500000000, bonusPercent: 60, color: '#f87828', imgPath: 'images/planets/proxima-centauri.webp' },
    { id: 'sirius', name: 'Sirius', emoji: '\u2609', distanceRequired: 891000000000, bonusPercent: 65, color: '#a8c8e8', imgPath: 'images/planets/sirius.webp' },
    { id: 'milky-way-center', name: 'Centre Voie lactée', emoji: '\uD83C\uDF0C', distanceRequired: 12800000000000, bonusPercent: 70, color: '#e8c898', imgPath: 'images/planets/milky-way-center.webp' },
    { id: 'andromeda', name: 'Andromède', emoji: '\uD83C\uDF0C', distanceRequired: 156000000000000, bonusPercent: 80, color: '#b89a9a', imgPath: 'images/planets/andromeda.webp' },
    { id: 'virgo-cluster', name: 'Amas de Virgo', emoji: '\u2728', distanceRequired: 2010000000000000, bonusPercent: 95, color: '#a89aa8', imgPath: 'images/planets/virgo-cluster2.webp' }
];

let unlockedPlanets = new Set(['earth']);
let planetBonuses = {}; // {planetId: bonusMultiplier}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function initLanguageSafe() { if (typeof initLanguage === 'function') initLanguage(); }
function initGlobals() {
    BUILDINGS.forEach(building => {
        totalGeneratedByBuilding[building.id] = totalGeneratedByBuilding[building.id] || 0;
        buildingUpgrades[building.id] = buildingUpgrades[building.id] || [];
    });
}

function findBuildingById(buildingId) {
    return BUILDINGS.find(b => b.id === buildingId);
}
// Cache d'accEs par id : findBuildingById est appelE dans toutes les boucles
// de rendu (plusieurs fois par tick). La liste ne change jamais apres init.
const buildingByIdCache = new Map();
function findBuildingByIdFast(buildingId) {
    let b = buildingByIdCache.get(buildingId);
    if (b === undefined) {
        b = BUILDINGS.find(x => x.id === buildingId) || null;
        buildingByIdCache.set(buildingId, b);
    }
    return b;
}


function getPlanetProductionBonus() {
    return 1 + getTotalPlanetBonus() + unlockedTrophies.size * (wasmCore() && wasmCore().trophy_production_percent ? wasmCore().trophy_production_percent() : 0.01);
}
// Suite infinie : les PE gagnees au-dela de l'Amas de Virgo donnent un
// bonus de production permanent a rendements DECROISSANTS -- le total en %
// suit une racine carree du nombre de PE converties (100 PE = +10%,
// 400 = +20%, 1 600 = +40%). L'ancienne formule lineaire (+1% par PE)
// explosait la production des centaines de PE converties d'un seul coup.
function getInfiniteProductionPercent(total) {
    // Lineaire : 1% de production permanente par PE (retour a la regle
    // d'origine, plus genereuse que l'ancienne racine carree).
    const w = wasmCore();
    return total * (w ? w.infinite_stardust_percent(1) : 1.0);
}
function getInfiniteStardustBonus() {
    return 1 + getInfiniteProductionPercent(postVirgoStardust) / 100;
}
function getRocketPartProductionBonus() {
    const w42 = wasmCore();
    return 1 + (w42 && w42.rocket_part_production_percent ? w42.rocket_part_production_percent(ROCKET_PARTS.filter(p => p.purchased).length) : 0.04 * ROCKET_PARTS.filter(p => p.purchased).length);
}
function getTotalProductionMultiplier() {
    const auto = isNaN(autoMultiplier) || autoMultiplier === undefined ? 1 : autoMultiplier;
    return auto
        * getCollectionMultiplier()
        * getProductionBonus()
        * getPlanetProductionBonus() * getRecordDoublingBonus()
        * getInfiniteStardustBonus()
        * getRocketPartProductionBonus();
}

// Multiplicateur propre du batiment : upgrades (x2 par palier).
// Exclut les bonus globaux (planets, trophees, collection, boost temporaire).
function getBuildingOwnMultiplier(building) {
    return getBuildingUpgradeMultiplier(building.id);
}
function calculateBuildingGain(building) {
    const upgradeMultiplier = getBuildingUpgradeMultiplier(building.id);
    // V3 Infini : bonus du bâtiment favori (+1%/s jouée) et héritage
    // industriel (rattrapage des anciens bâtiments) -- propres à CHAQUE
    // bâtiment, d'où leur place ici et pas dans les multiplicateurs globaux.
    const perBuildingBonus = getFavoriteBuildingBonus(building.id) * getHeritageBonus(building.id);
    return wasmBuildingGain(building.id) * building.count * autoMultiplier * upgradeMultiplier * perBuildingBonus * getCollectionMultiplier() * getProductionBonus() * getPlanetProductionBonus() * getRecordDoublingBonus() * getInfiniteStardustBonus() * getRocketPartProductionBonus();
}

function calculateUnitBuildingGain(building) {
    const upgradeMultiplier = getBuildingUpgradeMultiplier(building.id);
    const perBuildingBonus = getFavoriteBuildingBonus(building.id) * getHeritageBonus(building.id);
    return wasmBuildingGain(building.id) * autoMultiplier * upgradeMultiplier * perBuildingBonus * getCollectionMultiplier() * getProductionBonus() * getPlanetProductionBonus() * getRecordDoublingBonus() * getInfiniteStardustBonus() * getRocketPartProductionBonus();
}


// Production hors boost temporaire (autoMultiplier exclu) : base de calcul des quotas
// de contrat, pour qu'une offre generee pendant un x4 reste atteignable ensuite.
function calculateBuildingBaseGain(building) {
    const upgradeMultiplier = getBuildingUpgradeMultiplier(building.id);
    return wasmBuildingGain(building.id) * building.count * upgradeMultiplier * getCollectionMultiplier() * getProductionBonus() * getPlanetProductionBonus() * getRecordDoublingBonus() * getInfiniteStardustBonus() * getRocketPartProductionBonus();
}
// PPS total hors boost temporaire (autoMultiplier exclu) : base de calcul des
// contrats interactifs, pour qu'une offre generee pendant un x4 reste coherente.
let basePartsPerSecondCache = null;
function getBasePartsPerSecond() {
    if (basePartsPerSecondCache !== null) return basePartsPerSecondCache;
    let total = 0;
    BUILDINGS.forEach(building => { total += calculateBuildingBaseGain(building); });
    basePartsPerSecondCache = total;
    return total;
}

// Chaque upgrade de bâtiment double sa production (×2 par palier),
// comme les tiered upgrades de Cookie Clicker.
function getBuildingUpgradeMultiplier(buildingId) {
    const upgrades = buildingUpgrades[buildingId] || [];
    return wasmBuildingUpgradeMultiplier(upgrades.length);
}

function isBuildingUpgradeAvailable(buildingId, threshold) {
    const building = findBuildingById(buildingId);
    if (!building) return false;
    
    const upgrades = buildingUpgrades[buildingId] || [];
    const thresholdIndex = BUILDING_UPGRADE_THRESHOLDS.indexOf(threshold);
    
    return building.count >= threshold &&
           !upgrades.includes(threshold) &&
           (thresholdIndex === 0 || upgrades.includes(BUILDING_UPGRADE_THRESHOLDS[thresholdIndex - 1]));
}

// AUTO-ACHAT (V3, branche Infini) : tourne dans le gameLoop, throtle a une
// fois par seconde. Auto-Atelier I achete le batiment le moins cher,
// Auto-Atelier II bascule sur le meilleur ratio gain/prix. Auto-Pieces
// achete la piece de fusee suivante des que possible. On n'achete QU'UNE
// chose par tick pour laisser au joueur la main sur sa banque de Parts.
let lastAutoBuyAt = 0;
let autoBuyEnabled = true; // V3.5 : le joueur peut couper l'auto-achat (bouton)
let suppressTooltipHide = false; // V3.5 : les achats auto ne ferment pas l'infobulle
function runAutoBuy(now) {
    if (!autoBuyEnabled) return;
    if (getGalacticUpgradeLevel('inf-auto1') === 0 && getGalacticUpgradeLevel('inf-parts') === 0) return;
    if (now - lastAutoBuyAt < 1000) return;
    lastAutoBuyAt = now;
    // Pieces de fusee d'abord : sans fusee complete, rien ne part en vol
    if (getGalacticUpgradeLevel('inf-parts') > 0) {
        const nextPart = ROCKET_PARTS.find(p => !p.purchased);
        if (nextPart && score >= getRocketPartCost(nextPart)) {
            buyRocketPart(nextPart.id);
            return;
        }
    }
    if (getGalacticUpgradeLevel('inf-auto1') === 0) return;
    let target = null;
    if (getGalacticUpgradeLevel('inf-auto2') > 0) {
        // V3.5 : le PLUS GROS GAIN par unite (retour playtest -- le ratio
        // gain/prix orientait vers les batiments bon marche).
        let best = 0;
        BUILDINGS.forEach(b => {
            if (!b.unlockCondition()) return;
            const cost = calculateBuildingCost(b);
            if (cost > score) return;
            const gain = calculateUnitBuildingGain(b);
            if (gain > best) { best = gain; target = b; }
        });
    } else {
        // Le moins cher
        let cheapest = Infinity;
        BUILDINGS.forEach(b => {
            if (!b.unlockCondition()) return;
            const cost = calculateBuildingCost(b);
            if (cost <= score && cost < cheapest) { cheapest = cost; target = b; }
        });
    }
    if (target) {
        suppressTooltipHide = true;
        // V3.53 (retour joueur : 'si je mets x50 je veux que l'auto-buy
        // achete 50 s'il le peut, pareil pour x5 et Max') : l'auto-buy
        // suit desormais le MULTIPLICATEUR GLOBAL du joueur -- x1 -> 1,
        // x5 -> 5, x50 -> 50, Max -> le maximum affordable ; le garde-fou
        // de troncature dans buyBuilding protege la banque (achat partiel
        // si le score ne couvre pas la quantite demandee).
        // NB : le bug initial (l'auto-buy achetait le MAX en x50) venait du
        // calcul de CIBLE, pas du multiplicateur -- le cible choisait le
        // batiment le moins cher AVEC le multiplicateur applique au cout
        // affiche ; desormais la cible est choisie sur le cout UNITAIRE
        // et l'achat suit le multiplicateur voulu.
        try { buyBuilding(target.id); } finally { suppressTooltipHide = false; }
    }
}


function getBuildingTooltip(building) {
    const unitGain = calculateUnitBuildingGain(building);
    const totalGain = calculateBuildingGain(building);
// Total de production rEutilisE du snapshot du gameLoop (dEjA calculE
    // pour partsPerSecond) au lieu de recalculer le gain de TOUS les
    // batiments pour CHAQUE tooltip — c'Etait O(batiments^2) par tick.
    const currentTotal = cachedGainPerBuilding.get(building.id) === totalGain && buildingGainsCache !== null
        ? buildingGainsCache
        : (BUILDINGS.reduce((acc, b) => acc + (cachedGainPerBuilding.get(b.id) || calculateBuildingGain(b)), 0));
    // V3.41 (retour joueur) : espaces de milliers sur le % de production --
    // 4523.45 s'affichait '4523.45', illisible ; '4 523,45' maintenant.
    const percent = currentTotal > 0
        ? ((totalGain / currentTotal) * 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ')
        : '0';
    // V3.5 : multiplicateur COMPLET du tooltip -- upgrades x2, heritage
    // industriel ET favori (detail separe pour le favori). L'ancienne
    // version n'affichait que les upgrades : le % de production (calcule
    // sur le gain REEL, heritage compris) ne correspondait plus au x affiche.
    const favBonus = getFavoriteBuildingBonus(building.id);
    const heritBonus = getHeritageBonus(building.id);
    // V3.8 : le multiplicateur PRINCIPAL affiche n'importe les upgrades
    // (x2, x4... entiers) -- l'ancien produit upgrades*favori*heritage
    // donnait des valeurs decimales deroutantes (x1,99, x3,02...). Les
    // bonus fractionnaires restent detailles ci-dessous sur leurs lignes.
    const fullMult = getBuildingOwnMultiplier(building);
    let tooltip = tf('{flavor}: +{gain} Parts/s\nBonus de production: {mult}\n% de la production: {percent}%\nTotal g\u00e9n\u00e9r\u00e9: {total} Parts', {
        flavor: t(building.description),
        gain: formatNumber(unitGain),
        // V3.49 (retour joueur : 'garde le bonus de production en x X pas
        // en % -- juste ici') : le multiplicateur du tooltip bâtiment
        // revient a la notation x2, x4, x8 (les % restent ailleurs).
        mult: (fullMult >= 1000 ? formatNumber(fullMult) : ('x' + (Math.round(fullMult * 100) / 100).toString().replace('.', ','))),
        percent: percent,
        total: formatNumber(totalGeneratedByBuilding[building.id] || 0)
    });
    if (favBonus > 1) {
        tooltip += '\n' + tf('Favori: {mult} (+1%/s jou\u00e9e)', { mult: formatBonusPct(favBonus) });
    }
    if (heritBonus > 1) {
        // V3.41 : affichage du NOUVEL heritage -- multiplicateur d'anciennete
        // FIXE par bâtiment (x5 Atelier -> x1 dernier), plus de gain absolu
        // dependant des comptes : lisible et stable.
        // V3.49 : version COURTE (retour joueur : 'réduis la taille des
        // explications de l'héritage') -- une ligne compacte.
        // V3.50 (retour joueur : 'espaces entre milliers ou puissance de
        // 10') : format lisible du multiplicateur herite -- espaces de
        // milliers jusqu'a x10 millions, notation scientifique au-dela.
        const herMult = Math.round(heritBonus * 10) / 10;
        const herTxt = herMult >= 1e7
            ? herMult.toExponential(2).replace('.', ',').replace('e+', ' x 10^')
            : (Math.round(herMult) === herMult
                ? groupThousands(herMult)
                : groupThousands(Math.floor(herMult)) + ',' + String(Math.round((herMult % 1) * 10)));
        tooltip += '\n' + tf('Héritage: ×{mult}', { mult: herTxt });
    }
    return tooltip;
}

// Coût d'un upgrade de bâtiment au palier `threshold` : baseCost × 10^(index du palier)
// (style Cookie Clicker : chaque palier coûte ~10× le précédent, proportionnel au bâtiment).
// Déterministe : ne dépend d'aucun état de jeu, donc pas de cache figé.
// FORMULE DE BASE DU JEU RESTAURÉE : une expérimentation de coûts indexés
// sur la production (~30 s de gain par palier) a été annulée sur demande --
// retour au coût historique d'origine.
const BUILDING_UPGRADE_COST_GROWTH = 10;
function getBuildingUpgradeFixedCost(buildingId, threshold) {
    const building = findBuildingById(buildingId);
    if (!building) return 0;
    const tierIndex = BUILDING_UPGRADE_THRESHOLDS.indexOf(threshold);
    const tier = tierIndex === -1 ? 0 : tierIndex;
    return Math.floor(building.baseCost * Math.pow(BUILDING_UPGRADE_COST_GROWTH, tier));
}

// Prix du prochain bâtiment : baseCost × 1.15^(bâtiments possédés)
// (formule exacte de Cookie Clicker). Pour count=0 le multiplicateur vaut 1.
function calculateBuildingCost(building) {
    const reduction = getBuildingCostReduction();
    return Math.floor(building.baseCost * Math.pow(BUILDING_PRICE_GROWTH_RATE, building.count) * (1 - reduction));
}

// Fonction de formatage optimisée
// Multiplicateur : espaces de milliers jusqua 1 M, puis notation
// scientifique (x1.23 x 10^6) -- lisible a toutes les echelles.
// Pourcentage de la suite infinie : lisible a toute echelle --
// espaces de milliers, puis notation scientifique au-dela d'un million.
function formatInfinitePct(pct) {
    if (pct >= 1e6) {
        const exp = Math.floor(Math.log10(pct));
        const mant = pct / Math.pow(10, exp);
        return mant.toFixed(2) + ' x 10^' + exp;
    }
    return groupThousands(pct.toFixed(1));
}

// V3.33 (retour joueur : 'affiche les %, pas en xXXX') : tous les bonus et
// multiplicateurs s'affichent en POURCENTAGE. x2 -> +100%, x3,5 -> +250%,
// au-dela d'un million de % -> notation scientifique (meme regle que la
// suite infinie). Le 'x' reste pour les multiplicateurs de PUISSANCE de clic
// (Clic x2) qui ne sont pas des bonus de production.
function formatBonusPct(mult) {
    const pct = (mult - 1) * 100;
    if (pct >= 1e6) return '+' + formatInfinitePct(pct) + '%';
    if (pct >= 10) return '+' + Math.round(pct) + '%';
    return '+' + pct.toFixed(1).replace('.', ',') + '%';
}
function formatMultiplier(m) {
    if (m >= 1e6) {
        // x1e6 -> +100 000 000 % : notation scientifique lisible.
        const pct = (m - 1) * 100;
        return '+' + formatInfinitePct(pct) + '%';
    }
    return formatBonusPct(m);
}

function groupThousands(n) {
    return Math.round(n).toLocaleString('fr-FR').replace(/[\u202F\u00A0]/g, ' ');
}

function formatNumber(num, isTotalScore) {
    if (num === 0) return "0";
    
    const absNum = Math.abs(num);
    
    // Nombres < 1000
    if (absNum < 1000) {
        return num % 1 === 0 ? Math.round(num).toString() : num.toFixed(1);
    }
    
    // Nombres entre 1000 et 999999
    if (absNum < 1000000) {
        if (num % 1 === 0) return groupThousands(num);
        const intPart = Math.floor(num);
        const decPart = (num - intPart).toFixed(1).slice(2);
        return groupThousands(intPart) + ',' + decPart;
    }
    
    // Nombres >= 1M avec suffixes. Convention Conway-Wechsler complete :
    // au-dela des unites nommees usuelles, on enchaine les prefixe -illi-
    // par groupes de 3 zeros (Qad, Qid, Sxd, Spd, Ocd, Nod, Dcd, Td...).
    // La suite couvre jusqu'a 10^120 -- largement au-dela du mode infini,
    // et au-dela on bascule sur la notation scientifique, lisible a toute
    // echelle (plus de suffixe plafonne qui bouclait sur le dernier tier).
    const suffixes = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "De", "Ud", "Dd", "Td", "Qad", "Qid", "Sxd", "Spd", "Ocd", "Nod", "Vg", "Uvg", "Dvg", "Tvg", "Qavg", "Qivg", "Sxvg", "Spvg", "Ocvg", "Novg", "Tg", "Utg", "Dtg", "Qtg"];
    const tier = Math.floor(Math.log10(absNum) / 3);
    if (tier >= suffixes.length) {
        // Au-dela du dernier suffixe : notation scientifique, jamais un
        // suffixe plafonne qui bouclait et rendait deux distances differentes
        // indiscernables.
        const exp = Math.floor(Math.log10(absNum));
        return (num / Math.pow(10, exp)).toFixed(2).replace('.', ',') + ' x 10^' + exp;
    }
    const suffix = suffixes[tier];
    const scale = Math.pow(10, tier * 3);
    const scaled = num / scale;
    
    // Déterminer le nombre de décimales
    const scaledAbs = Math.abs(scaled);
    const decimals = scaledAbs >= 100 ? (isTotalScore ? 3 : 2) : (scaledAbs >= 10 ? 3 : 3);
    
    // V3.29 (retour joueur) : TRONCATURE et non arrondi -- 999,999 K doit
    // afficher '999,99 K' et pas '1,00 M' : un palier de suffixe ne peut etre
    // franchi a l'affichage QUE quand la valeur le franchit reellement.
    const sign = scaled < 0 ? '-' : '';
    const factor = Math.pow(10, decimals);
    const truncated = Math.floor(Math.abs(scaled) * factor) / factor;
    return sign + truncated.toFixed(decimals).replace('.', ',') + " " + suffix;
}

function updateAutoMultiplier() {
    autoMultiplier = autoMultipliers.reduce((a, b) => a * b, 1);
    invalidateBuildingGainsCache();
}

function updateClickMultiplier() {
    clickMultiplier = clickMultipliers.reduce((a, b) => a * b, 1);
}

function resetMultipliers() {
    autoMultipliers = [1];
    clickMultipliers = [1];
    updateAutoMultiplier();
    updateClickMultiplier();
}

let toastHideTimer = null;
const TOAST_MAX_STACK = 3;
function getToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        // V3.86 : ARBRE D'ACCESSIBILITE -- chaque mutation DOM du jeu
        // (cometes, effets de clic, toasts) marquait des noeuds AX
        // "dirty" et Chrome recalculait l accessibilite en boucle
        // (profil : 591 596 AXDirtyObject = 46% du tas mesure).
        // Le conteneur de toasts est purement visuel : hors arbre A11y.
        container.setAttribute('aria-hidden', 'true');
        document.body.appendChild(container);
    }
    return container;
}
function showToast(message, icon, durationMs, options) {
    const container = getToastContainer();
    while (container.children.length >= TOAST_MAX_STACK) {
        container.firstElementChild.remove();
    }
    const toast = document.createElement('div');
    toast.className = 'toast' + (options && options.failure ? ' failure' : '') + (options && options.trophy ? ' trophy' : '') + (options && options.subtitle ? ' has-subtitle' : '');
    toast.innerHTML = '';
    if (icon) {
        const iconEl = document.createElement('span');
        iconEl.className = 'toast-icon';
        if (icon.startsWith('images/')) {
            const img = document.createElement('img');
            img.src = icon;
            img.alt = '';
            iconEl.appendChild(img);
        } else {
            iconEl.textContent = icon;
        }
        toast.appendChild(iconEl);
    }
    const textEl = document.createElement('span');
    textEl.className = 'toast-text';
    textEl.textContent = message;
    toast.appendChild(textEl);
    // Sous-texte (ex. definition du trophee) : informe le joueur de ce
    // qu'il vient d'atteindre, pas seulement le nom du trophee.
    if (options && options.subtitle) {
        const subEl = document.createElement('span');
        subEl.className = 'toast-subtitle';
        subEl.textContent = options.subtitle;
        toast.appendChild(subEl);
    }
    container.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('active'));
    toast._hideTimer = setTimeout(() => dismissToast(toast), durationMs || TOAST_DURATION_MS);
}
function dismissToast(toast) {
    if (!toast || !toast.classList.contains('active')) return;
    if (toast._hideTimer) clearTimeout(toast._hideTimer);
    toast.classList.remove('active');
    toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    setTimeout(() => { if (toast.isConnected) toast.remove(); }, 400);
}
// Les notifications sont cliquables : le tap ferme le toast ET absorbe
// le clic (stopPropagation) pour ne JAMAIS declencher l'element situe
// derriere -- avant, un tap sur "Booster pret !" cliquait aussi le
// bouton Lancer la fusee au meme endroit.
// Le container reste pointer-events: none : seuls les toasts captent.
let toastTapCandidate = null;
document.addEventListener('pointerdown', (e) => {
    toastTapCandidate = { x: e.clientX, y: e.clientY, id: e.pointerId, toast: e.target.closest ? e.target.closest('.toast.active') : null };
}, true);
document.addEventListener('pointerup', (e) => {
    const start = toastTapCandidate;
    toastTapCandidate = null;
    if (!start || start.id !== e.pointerId) return;
    if (!start.toast || !start.toast.isConnected) return;
    if (Math.abs(e.clientX - start.x) > 10 || Math.abs(e.clientY - start.y) > 10) return;
    if (e.target.closest && e.target.closest('.toast.active')) {
        e.stopPropagation();
        dismissToast(start.toast);
    }
}, true);
// Ceinture anti-click-through : le clic genere apres le pointerup est
// annule quand il vient d'un toast (le navigateur emet click sur
// l'element le plus haut, ici le toast, mais un rest de l'ancien
// comportement pouvait laisser passer l'evenement).
document.addEventListener('click', (e) => {
    const toast = e.target.closest ? e.target.closest('.toast') : null;
    if (toast) {
        e.stopPropagation();
        e.preventDefault();
        if (toast.classList.contains('active')) dismissToast(toast);
    }
}, true);

// ============================================
// SAVE / LOAD
// ============================================

function saveGame() {
    // V3.71 : partie vierge en attente de la verification WASM -> NE PAS
    // ecraser la sauvegarde originale (elle sera relue par loadGame des
    // que le module est pret).
    if (saveLockedWaitingWasm) return;
    // V3.74 : auto-reparation silencieuse -- une save locale chargee avec
    // une signature non verifiee (mise a jour du jeu, nouveau SW) est
    // RE-SIGNEE par ce save meme : saveSign recalcule un _sig frais sur
    // l'etat actuel, le warning ne reviendra plus (retour proprietaire :
    // 'des qu ils sauvegardent, ils recreent une signature bonne').
    // MODE TRICHEUR -- verrou de sauvegarde : si une modification de code
    // est active AU MOMENT de sauvegarder, l'etat (potentiellement gonfle
    // par la triche) n'est PAS ecrit. Le tricheur qui recharge retombe sur
    // son dernier etat PROPRE (dernier autosave <= 10 s avant la triche).
    // Sans ce verrou, le scenario "tricher -> attendre l'autosave (10 s)
    // -> recharger" persisterait les gains triches sans jamais etre detecte.
    if (cheaterModeActive) return;
    const saveData = {
        score: score,
        partsPerSecond: partsPerSecond,
        partsSinceLaunch: partsSinceLaunch,
        autoMultiplier: autoMultiplier,
        clickMultiplier: clickMultiplier,
        totalPartsFromClicks: totalPartsFromClicks,
        totalClicksAllTime: totalClicksAllTime,
        totalPartsEarnedAllTime: totalPartsEarnedAllTime,
        totalPartsEarnedThisLaunch: totalPartsEarnedThisLaunch,
        activatedClickUpgrades: [...activatedClickUpgrades],
        unlockedBuildings: Array.from(unlockedBuildings),
        autoMultipliers: [...autoMultipliers],
        clickMultipliers: [...clickMultipliers],
        buildingUpgrades: {},
        buildingUpgradeCosts: {},
        totalGeneratedByBuilding: {},
        clickedBonusesCount: clickedBonusesCount,
        contractsCompleted: contractsCompleted,
        unlockedTrophies: Array.from(unlockedTrophies),
        maxDistance: maxDistance,
        maxTravelSpeed: maxTravelSpeed,
        maxPartsPerSecond: maxPartsPerSecond,
        starDust: starDust,
        totalStardustEarned: totalStardustEarned,
        lifetimeDistanceKm: lifetimeDistanceKm,
        stardustFromFlights: stardustFromFlights,
        favoriteBuildingId: favoriteBuildingId,
        favoriteBuildingSeconds: favoriteBuildingSeconds,
        favoriteBuildingSecondsByBuilding: Array.from(favoriteBuildingSecondsByBuilding.entries()),
        cometRewardMode: cometRewardMode,
        activePlaytimeSeconds: activePlaytimeSeconds,
        sessionsCount: sessionsCount,
        postVirgoStardust: postVirgoStardust,
        recordDoublings: recordDoublings,
        lastLaunchPermanentBonusPct: lastLaunchPermanentBonusPct,
        lastRecordForDoubling: lastRecordForDoubling,
        gameFinished: gameFinished,
        galacticUpgrades: {...galacticUpgrades},
        rocketsLaunched: rocketsLaunched,
        partCostMultiplier: partCostMultiplier,
        lastLaunchAt: lastLaunchAt,
        lastLaunchDistance: lastLaunchDistance,
        // Multiplicateur d'achat (x1/x5/x10/max) : confort, sinon retombe a x1.
        buyMultiplier: buyMultiplier === 'max' ? 'max' : (buyMultiplier || 1),
        unlockedPlanets: Array.from(unlockedPlanets),
        planetBonuses: {...planetBonuses},
        cardCollection: {...cardCollection},
        boosterReadyAt: {...boosterReadyAt},
        boostersOpened: {...boostersOpened},
        boosterTimersStarted: boosterTimersStarted,
        activeRandomBonuses: activeRandomBonuses.map(bonus => ({
            id: bonus.id,
            effect: bonus.effect,
            multiplier: bonus.multiplier,
            endTime: bonus.endTime
        })),
        buildings: BUILDINGS.map(building => ({
            id: building.id,
            count: building.count
        })),
        rocketParts: ROCKET_PARTS.map(part => ({            id: part.id,            purchased: part.purchased        })),
        // Pieces deja construites : evite de rejouer l'animation de chute
        // pour toute la fusee a chaque rechargement de la page.
        constructedParts: [...constructedParts],
        startupBonusApplied: startupBonusApplied,
        tutorialSeen: tutorialSeen,
        contractState: {
            offers: contractState.offers,
            active: contractState.active,
            nextRotationAt: contractState.nextRotationAt,
            unlockedSeen: contractState.unlockedSeen
        },
        // Deblocage permanent des mini-jeux : une fois acquis, les cartes
        // restent visibles meme apres un lancement (batiments retombes a 0).
        contractsEverUnlocked: contractsEverUnlocked,
        cardsEverUnlocked: cardsEverUnlocked,
        lastSave: Date.now(),
        postTravelRewardsCreditedAt: postTravelRewardsCreditedAt,
        lastLaunchDustCredited: lastLaunchDustCredited,
        atelierAfterTravel: atelierAfterTravel,
        gameStartTime: gameStartTime,
        expeditionStartTime: expeditionStartTime,
        // Le nom d'entreprise DOIT vivre dans la sauvegarde : il etait stocke
        // uniquement dans une cle localStorage separree (starcruiserCompanyName),
        // donc perdu par un export/import ou un nettoyage partiel -- le joueur
        // retrouvait sa progression mais devait rechoisir un nom (ou pire, en
        // prenait un autre et perdait son identite de classement).
        companyName: getCompanyName(),
        version: SAVE_VERSION
    };

    for (const buildingId in buildingUpgrades) {
        saveData.buildingUpgrades[buildingId] = [...buildingUpgrades[buildingId]];
    }
    for (const buildingId in totalGeneratedByBuilding) {
        saveData.totalGeneratedByBuilding[buildingId] = totalGeneratedByBuilding[buildingId];
    }
    for (const buildingId in buildingUpgradeCosts) {
        saveData.buildingUpgradeCosts[buildingId] = {...buildingUpgradeCosts[buildingId]};
    }

    // V3.15 : SIGNATURE HMAC de la sauvegarde (cle dans le module WASM).
    // Une save editee a la main ne peut pas recalculer une signature valide.
    try {
        if (window.StarcruiserCore && window.StarcruiserCore.saveSign) {
            const jsonSave = JSON.stringify(saveData);
            const sig = window.StarcruiserCore.saveSign(jsonSave);
            if (sig) saveData._sig = sig;
        }
    } catch (e) {}
    localStorage.setItem('starcruiserClickerSave', JSON.stringify(saveData));
    lastSaveTime = Date.now();
}

// V3.15 : serialisation signee -- JSON.stringify normal, le champ _sig
// fait partie de l'objet et le WASM le NEUTRALISE au calcul (strip).
function sigSaveJson(data) { return JSON.stringify(data); }
let hasSaveData = true;
function loadGame() {
    const legacySave = localStorage.getItem('starshipClickerSave');
    if (legacySave !== null && localStorage.getItem('starcruiserClickerSave') === null) {
        localStorage.setItem('starcruiserClickerSave', legacySave);
    }
    if (legacySave !== null) localStorage.removeItem('starshipClickerSave');

    const saveData = localStorage.getItem('starcruiserClickerSave');
    if (!saveData) { hasSaveData = false; return; }
    // V3.21 : RACE CONDITION corrigee -- une save SIGNEE chargee avant que
    // le module WASM soit pret etait REFUSEE (saveVerify indisponible ->
    // sigValid=false -> return) : selon la vitesse de chargement du module,
    // la meme save etait acceptee ou rejetee ('des fois', retour joueur).
    // Desormais : si _sig est present et que le module n'est PAS pret, on
    // ATTEND le module avant de verifier -- jamais de refus sur un simple
    // probleme de timing.
    var preCheckQuick = null;
    try { preCheckQuick = JSON.parse(saveData); } catch (e) {}
    if (preCheckQuick && typeof preCheckQuick._sig === 'string' && preCheckQuick._sig.length === 64 && !wasmCoreReady) {
        // Le module charge en parallele (wasm-core-loader) : on rejoue le
        // chargement quand il est pret. Le jeu demarre sur une nouvelle
        // partie en attendant, loadGame sera rappele et prendra le relais
        // AVANT toute action du joueur (le tuto gele la partie).
        if (window.StarcruiserCore && window.StarcruiserCore.loading !== undefined) {
            // V3.71 -> V3.72 : le chargement attendu -- si le module
            // NE CHARGE PAS (reseau, SW ancien, binaire absent), la save
            // signee etait ABANDONNEE : partie vierge -> autosave -> PERTE
            // DEFINITIVE (retour proprietaire : 'je ne garde TOUJOURS pas ma
            // progression'). DECISION : le catch recharge la save SANS
            // verification -- les garde-fous de clamp (records, doublages,
            // favori, boosts cap x4) restent appliques, et la protection
            // anti-edition reste ENTIEREMENT cote serveur (bornes 1re
            // soumission, croissance graduee, coherence croisee).
            saveLockedWaitingWasm = true;
            // V3.82 : REJOUER LE RENDU APRES LE CHARGEMENT ASYNCHRONE -- la
            // partie demarre VIERGE en attendant le module, init() a deja
            // rendu l'interface vide et demarre le TUTO ; quand loadGame()
            // restaure la save dans la promesse, PERSONNE ne re-rendait :
            // batiments invisibles, coach tutoriel par-dessus une vraie
            // partie (retour proprietaire : 'le tuto revient a chaque
            // rechargement et mes batiments ont disparu'). On rejoue le
            // rendu complet et on arrete le tutoriel si la save a de la
            // progression.
            const replayAfterRestore = () => {
                if (!hasSaveData) return;
                try {
                    // N'arreter le coach QUE si la save restauree a de la
                    // REELLE progression -- le meme critere que startTutorial
                    // (retour proprietaire : 'en nouvelle partie le tuto
                    // apparait et disparait directement'). Une partie qui
                    // vient de commencer doit GARDER son tutoriel.
                    const workshopB = findBuildingById('workshop');
                    const hasProgress = (workshopB && workshopB.count > 0)
                        || ROCKET_PARTS.some(p => p.purchased);
                    if (tutorialActive && hasProgress) endTutorial();
                    // V3.96 : la decision du tuto (differee par init quand
                    // on attendait le WASM) se prend MAINTENANT que la save
                    // est relue : une save avec progression n'a JAMAIS vu le
                    // coach (deja endTutorial ci-dessus) ; une save SANS
                    // progression (vraie nouvelle partie qui avait juste
                    // un autosave) DEMARRE son coach ici, et une save qui
                    // n'existe pas vraiment (nouveau navigateur) demarre
                    // intro + coach par le chemin standard.
                    if (!tutorialActive && !isTutorialSeen() && !hasProgress) {
                        if (shouldAskLanguage()) {
                            showLanguagePicker();
                        } else if (showIntroScreen()) {
                            // le coach partira a la fermeture de l intro
                        } else {
                            startTutorial(false);
                        }
                    }
                    // Lecons contextuelles : la save dit maintenant si le
                    // tuto est vu -- on peut les demarrer sans risque.
                    if (isTutorialSeen() && !tutorialActive) startFeatureLessons();
                    // Nom d entreprise : differe lui aussi pendant l attente
                    // WASM (init l a saute) -- reprendre ici si toujours absent.
                    try { ensureCompanyName(); } catch (e) {}
                    renderBuildings();
                    renderUpgrades();
                    renderRocketPartsShop();
                    updateConstructionScene();
                    checkBuildingUnlocks();
                    updateMiniGamesVisibility();
                    updateDisplay();
                    updateStardustDisplay();
                    refreshRocketNameTag();
                } catch (e) { console.warn('[Starcruiser] Rejeu du rendu apres restauration :', e); }
            };
            window.StarcruiserCore.load().then(() => {
                saveLockedWaitingWasm = false;
                try { loadGame(); } catch (e) {}
                replayAfterRestore();
            }).catch(() => {
                saveLockedWaitingWasm = false;
                // Le module echoue : charger la save SANS exigence de
                // signature (elle est legitime -- signee par le jeu).
                window.__skipSigCheck = true;
                try { loadGame(); } catch (e) {} finally { window.__skipSigCheck = false; }
                replayAfterRestore();
            });
            hasSaveData = false;
            return;
        }
    }
    // V3.15/V3.16 : VERIFICATION DE SIGNATURE -- une save produite par une
    // version signee du jeu (champ _sig present) doit presenter une signature
    // VALIDE. Une save sans _sig (premier lancement, vieilles saves, import
    // non signe) est acceptee : les garde-fous de clamp s'appliquent UNIQUEMENT
    // a ces saves non signees -- une save SIGNEE VERIFIEE est integre par
    // construction, aucun clamp ne doit la limiter (retour joueur : les bornes
    // V3.14 faisaient peur pour les gros scores honnetes).
    var saveWasSignedVerified = false;
    try {
        const preCheck = JSON.parse(saveData);
        if (window.__skipSigCheck) {
            // V3.72 : rechargement de secours (module WASM injoignable) --
            // la signature ne peut pas etre verifiee : on charge quand
            // meme, les clamps de securite s appliquent.
        } else if (preCheck && typeof preCheck._sig === 'string' && preCheck._sig.length === 64) {
            let sigValid = false;
            try {
                if (window.StarcruiserCore && window.StarcruiserCore.saveVerify) {
                    sigValid = window.StarcruiserCore.saveVerify(saveData, preCheck._sig) === 1;
                }
            } catch (e) { sigValid = false; }
            if (!sigValid) {
                // V3.74 (retour proprietaire -- il a RAISON : 'la signature
                // servait a empecher l import d une save modifiee, il ne
                // faut PAS la transformer en warning, il faut qu elle se
                // REPARE toute seule') : le REFUS ne s applique qu'aux
                // sauvegardes IMPORTERS (via importSave -- le seul chemin
                // d'entree d'une save externe editee). Le chargement LOCAL
                // (F5) continue : la save vient du jeu, elle est legitime ;
                // le prochain saveGame la RE-SIGNERA proprement (auto-
                // reparation) et le warning ne reviendra plus.
                console.warn('[Starcruiser] Signature de sauvegarde non verifiee -- save locale, re-signature au prochain save.');
                window.__sigNeedsRepair = true;
                try { localStorage.setItem('starcruiserClickerSaveRejected', saveData); } catch (e) {}
                // PAS de return : chargement local. importSave verifie LUI
                // MEME la signature de la save importee (voir importSave).
            }
            saveWasSignedVerified = true;
        }
    } catch (e) { /* JSON casse : gere par le try general ci-dessous */ }

    // V3.82 : le rejeu asynchrone (attente du module WASM) doit savoir que
    // la save a ete chargee -- hasSaveData reste sinon a false et le rendu
    // n est jamais rejoue (batiments invisibles). Il est remis ici, au
    // moment ou les donnees sont reellement lit et appliquees.
    hasSaveData = true;
    try {
        const parsed = JSON.parse(saveData);

        if (parsed.version && parsed.version !== SAVE_VERSION) {
            console.warn("Version de sauvegarde différente, migration possible");
        }

        // Charger les variables principales
        // P10 : coercion defensive de tous les champs numeriques (imports
        // manuels polluant l'economie).
        const numOr = (v, dflt) => {
            if (v === undefined || v === null) return dflt;
            const n = Number(v);
            return (typeof n === 'number' && isFinite(n)) ? n : dflt;
        };
        score = numOr(parsed.score, 0);
        partsPerSecond = numOr(parsed.partsPerSecond, numOr(parsed.autoGain, 0));
        partsSinceLaunch = numOr(parsed.partsSinceLaunch, score);
        autoMultiplier = numOr(parsed.autoMultiplier, 1);
        clickMultiplier = numOr(parsed.clickMultiplier, 1);
        totalPartsFromClicks = numOr(parsed.totalPartsFromClicks, numOr(parsed.clickPartsTotal, 0));
        totalClicksAllTime = numOr(parsed.totalClicksAllTime, 0);
        clickedBonusesCount = numOr(parsed.clickedBonusesCount, 0);
        contractsCompleted = Math.max(0, numOr(parsed.contractsCompleted, 0));
        unlockedTrophies = new Set(Array.isArray(parsed.unlockedTrophies) ? parsed.unlockedTrophies : []);
        
        maxDistance = numOr(parsed.maxDistance, 0);
        maxTravelSpeed = numOr(parsed.maxTravelSpeed, 0);
        // V3.30 (retour joueur, 2e signalement) : CLAMP DE RECORDS SUPPRIME --
        // le clamp 1e15/1e18 ne protegeait que les saves NON SIGNEES, mais une
        // save clampee une fois (WASM pas pret, import manuel) voyait son
        // record PERDANT ecrase et RESAUVEGARDE : le faux record 1 Qi devenait
        // permanent ('j affiche toujours 1 Qi et l objectif 2 Qi quand je
        // depasse de beaucoup mon record'). Depuis V3.15, TOUTES les saves du
        // jeu sont signees : un import edite a la main ne peut pas produire
        // une signature valide, le serveur valide deja la coherence -- le
        // clamp local n'a plus aucune utilite reel et son cout (records
        // legitimes detruits) est trop eleve.
        // Rejeu des records de la sauvegarde dans le module WASM (monotone) :
        // le boot WASM peut avoir lieu avant OU apres le chargement de la
        // sauvegarde, les deux ordres doivent converger.
        try { if (wasmCore()) { wasmCore().set_record_speed(maxTravelSpeed); wasmCore().set_record_distance(maxDistance); } } catch (e) {}
        maxPartsPerSecond = numOr(parsed.maxPartsPerSecond, 0);
        starDust = numOr(parsed.starDust, 0);
        totalStardustEarned = numOr(parsed.totalStardustEarned, 0);
        // V3 : migration des anciennes sauvegardes sans lifetimeDistanceKm.
        // Le cumul est inverse depuis le PE total deja gagne puis borne au
        // record de distance : le prochain lancement credite des que le
        // cumul depasse ce que represente le PE deja en banque.
        lifetimeDistanceKm = numOr(parsed.lifetimeDistanceKm, 0);
        stardustFromFlights = numOr(parsed.stardustFromFlights, 0);
        // V3.69 FIX : PROTECTION changement de formule PE -- le baseline
        // stardustFromFlights a pu etre credite sous l'ANCIENNE formule
        // (EXP=0.44, ~x92 plus genereuse que la racine cubique actuelle).
        // Sans ce cap, gain = f_1/3(cumul) - baseline_0.44 etait NEGATIF
        // (clamp 0) a tout jamais : le joueur ne gagnait PLUS AUCUNE PE
        // (retour proprietaire : 'mes gains de PE marchent pas').
        // Le baseline est desormais plafonne a ce que la formule
        // ACTUELLE represente au cumul charge : le prochain vol credite
        // immediatement la difference.
        if (parsed.lifetimeDistanceKm && stardustFromFlights > 0) {
            const capPE = stardustFromLifetimeDistance(lifetimeDistanceKm);
            if (stardustFromFlights > capPE) {
                stardustFromFlights = capPE;
            }
        }
        favoriteBuildingId = (typeof parsed.favoriteBuildingId === 'string' && BUILDINGS.some(b => b.id === parsed.favoriteBuildingId)) ? parsed.favoriteBuildingId : null;
        // Cap anti-abus (import manuel) : 100 000 secondes de favori = x1000
        // de production du favori, deja au-dela de tout playthrough legitime.
        favoriteBuildingSeconds = Math.min(numOr(parsed.favoriteBuildingSeconds, 0), 100000);
        favoriteBuildingSecondsByBuilding = new Map(
            Array.isArray(parsed.favoriteBuildingSecondsByBuilding)
                ? parsed.favoriteBuildingSecondsByBuilding.map(e => Array.isArray(e) ? [e[0], numOr(e[1], 0)] : null).filter(Boolean)
                : []);
        cometRewardMode = ['parts', 'multiplier', 'neutral'].includes(parsed.cometRewardMode) ? parsed.cometRewardMode : 'neutral';
        activePlaytimeSeconds = Math.max(0, numOr(parsed.activePlaytimeSeconds, 0));
        // V3.99 : chaque chargement d'une partie EXISTANTE est une NOUVELLE
        // SESSION -- le compteur ne s'incremente pas sur une nouvelle partie
        // (pas de save a charger). Persiste dans la save, envoye au
        // classement avec playtime : sessions/distinct = retention reelle.
        sessionsCount = Math.max(0, numOr(parsed.sessionsCount, 0)) + 1;
        if (!parsed.lifetimeDistanceKm && totalStardustEarned > 0) {
            lifetimeDistanceKm = lifetimeDistanceFromStardust(totalStardustEarned);
            stardustFromFlights = totalStardustEarned;
            const cap = numOr(parsed.maxDistance, 0);
            if (cap > 0 && lifetimeDistanceKm > cap) lifetimeDistanceKm = cap;
        }
        postVirgoStardust = numOr(parsed.postVirgoStardust, 0);
        recordDoublings = Math.max(0, numOr(parsed.recordDoublings, 0));
        lastLaunchPermanentBonusPct = Math.max(0, numOr(parsed.lastLaunchPermanentBonusPct, 0));
        lastRecordForDoubling = Math.max(0, numOr(parsed.lastRecordForDoubling, 0));
        // V3.16 : garde-fous UNIQUEMENT sur les saves NON SIGNEES (une
        // save signee-verifiee provient du jeu, elle est integre -- retour
        // joueur : les bornes faisaient peur pour les gros scores honnetes).
        if (!saveWasSignedVerified) {
            // DOUBLEMENTS : un doublage exige de JOUER, pas une edition de JSON.
            if (recordDoublings > 200) recordDoublings = 200;
            if (lastRecordForDoubling > maxDistance * 2) lastRecordForDoubling = maxDistance;
            // BANQUE FAVORI : le temps de favori cumule ne peut pas exceder
            // 1.5x le temps de jeu REEL enregistre.
            const favBankTotal = Array.from(favoriteBuildingSecondsByBuilding.values()).reduce((a, b) => a + b, 0);
            const playCeil = activePlaytimeSeconds > 0 ? activePlaytimeSeconds * 1.5 : 0;
            if (playCeil > 0 && favBankTotal > playCeil) {
                const ratio = playCeil / favBankTotal;
                const scaled = new Map();
                favoriteBuildingSecondsByBuilding.forEach((v, k) => scaled.set(k, v * ratio));
                favoriteBuildingSecondsByBuilding = scaled;
            }
            if (favoriteBuildingSeconds > Math.max(playCeil, 1e5)) {
                favoriteBuildingSeconds = Math.max(playCeil, 1e5);
            }
        }

        gameFinished = !!parsed.gameFinished;
        galacticUpgrades = parsed.galacticUpgrades || {};
        // V2.2: les upgrades galactiques sont uniques (maxLevel=1).
        // Cap les niveaux anciens pour eviter des bonus excesifs.
        Object.keys(galacticUpgrades).forEach(uid => {
            const u = GALACTIC_UPGRADES.find(x => x.id === uid);
            if (!u) {
                delete galacticUpgrades[uid];
            } else if (galacticUpgrades[uid] > u.maxLevel) {
                galacticUpgrades[uid] = u.maxLevel;
            }
        });
        rocketsLaunched = numOr(parsed.rocketsLaunched, 0);
        partCostMultiplier = Math.max(1, numOr(parsed.partCostMultiplier, 1));
        lastLaunchAt = numOr(parsed.lastLaunchAt, 0);
        lastLaunchDistance = numOr(parsed.lastLaunchDistance, 0);
        // V3.36 : FIX -- les boutons du jeu sont x1/x5/x50/Max mais la
        // validation au chargement n'acceptait que [1, 5, 10] : un joueur
        // ayant x50 actif perdait silencieusement son reglage au rechargement
        // ('les multiplicateurs d achat ne fonctionnaient plus', retour joueur).
        if (parsed.buyMultiplier === 'max' || [1, 5, 50].includes(parsed.buyMultiplier)) {
            buyMultiplier = parsed.buyMultiplier;
        }
        
        activatedClickUpgrades = Array.isArray(parsed.activatedClickUpgrades) ? parsed.activatedClickUpgrades : [];
        unlockedBuildings = new Set(Array.isArray(parsed.unlockedBuildings) ? parsed.unlockedBuildings : []);
        gameStartTime = numOr(parsed.gameStartTime, 0);
        expeditionStartTime = numOr(parsed.expeditionStartTime, 0);
        if (!expeditionStartTime && gameStartTime) expeditionStartTime = gameStartTime; // migration anciennes saves
        startupBonusApplied = !!parsed.startupBonusApplied;
        postTravelRewardsCreditedAt = numOr(parsed.postTravelRewardsCreditedAt, 0);
        lastLaunchDustCredited = numOr(parsed.lastLaunchDustCredited, 0);
        atelierAfterTravel = !!parsed.atelierAfterTravel;
        // Restaurer le nom d'entreprise depuis la sauvegarde : la cle
        // localStorage dediee (source de getCompanyName) peut avoir ete
        // perdue (nettoyage partiel, navigation privee reutilisee, autre
        // navigateur via import) alors que la progression, elle, est la.
        // La sauvegarde EST la source de verite : si elle porte un nom
        // valide, on le re-ecrit dans la cle dediee. On n'ecrase JAMAIS un
        // nom local valide par un nom vide d'une vieille sauvegarde
        // (migration : les saves pre-companyName n'ont pas le champ).
        const saveCompanyName = sanitizeCompanyName(parsed.companyName);
        if (saveCompanyName.length >= 3) {
            const currentLocalName = sanitizeCompanyName(localStorage.getItem(LEADERBOARD_COMPANY_KEY));
            if (currentLocalName.length < 3) {
                localStorage.setItem(LEADERBOARD_COMPANY_KEY, saveCompanyName);
            }
        }
        // Migration : les anciennes saves n'ont pas tutorialSeen. Un joueur qui a
        // deja progresse (score, batiments, lancements) ne doit pas voir le tuto.
        if (parsed.tutorialSeen !== undefined) {
            tutorialSeen = !!parsed.tutorialSeen;
        } else {
            const hasProgress = (parsed.score || 0) > 0
                || (parsed.rocketsLaunched || 0) > 0
                || (parsed.unlockedBuildings || []).length > 0;
            tutorialSeen = hasProgress;
        }
        if (parsed.contractState) {
            // Migration contrats interactifs : les offres/contrats de l'ancien
            // format (buildingId/quota, pas de typeId) ne sont plus valides —
            // on les jette pour regenerer des offres au nouveau format.
            const oldOffers = (parsed.contractState.offers || []).filter(o => o && o.typeId);
            contractState.offers = oldOffers.map(o => ({
                id: o.id, typeId: o.typeId, diffIdx: o.diffIdx || 1,
                target: o.target || 1, price: o.price || 0,
                rewardType: o.rewardType || 'instant', instantSec: o.instantSec || 0,
                clickMult: o.clickMult || 0, mult: o.mult || 0,
                duration: o.duration || 0, shower: o.shower || 0,
                expiresAt: o.expiresAt || 0
            }));
            const oa = parsed.contractState.active;
            contractState.active = (oa && oa.typeId && oa.target) ? oa : null;
            // Le compteur de Parts naturelles repart de zero au chargement :
            // reancrer la progression du contrat production sur la valeur
            // courante pour eviter une cible devenue inatteignable.
            if (contractState.active && contractState.active.typeId === 'production') {
                contractState.active.naturalStartTotal = 0;
            }
            // P13 : purger les offres expirees au chargement.
            const loadNow = Date.now();
            contractState.offers = contractState.offers.filter(o => !o.expiresAt || o.expiresAt > loadNow);
            contractState.nextRotationAt = parsed.contractState.nextRotationAt || 0;
            contractState.unlockedSeen = !!parsed.contractState.unlockedSeen;
            contractsEverUnlocked = !!parsed.contractsEverUnlocked;
            cardsEverUnlocked = !!parsed.cardsEverUnlocked;
            if (!contractsEverUnlocked && getUnlockedBuildingTypes() >= CONTRACT_UNLOCK_BUILDING_TYPES) contractsEverUnlocked = true;
            if (!cardsEverUnlocked && getUnlockedBuildingTypes() >= CARD_COLLECTION_UNLOCK_BUILDING_TYPES) cardsEverUnlocked = true;
        }

        if (parsed.boosterReadyAt) {
            boosterReadyAt = { standard: parsed.boosterReadyAt.standard || 0, premium: parsed.boosterReadyAt.premium || 0, legendary: parsed.boosterReadyAt.legendary || 0 };
            boostersOpened = {
                standard: numOr((parsed.boostersOpened || {}).standard, 0),
                premium: numOr((parsed.boostersOpened || {}).premium, 0),
                legendary: numOr((parsed.boostersOpened || {}).legendary, 0)
            };
            // Compat ancienne sauvegarde : des deadlines posees => timers deja demarres.
            boosterTimersStarted = !!(parsed.boosterTimersStarted !== undefined ? parsed.boosterTimersStarted : (boosterReadyAt.standard > 0 || boosterReadyAt.premium > 0 || boosterReadyAt.legendary > 0));
        }
        if (parsed.cardCollection) {
            cardCollection = {...parsed.cardCollection};
            // Migration : la carte Laboratoire n'existe plus, remplacee par Comete.
            if (cardCollection['lab-card']) {
                cardCollection['comet-card'] = (cardCollection['comet-card'] || 0) + cardCollection['lab-card'];
                delete cardCollection['lab-card'];
            }
            // Migration : la carte Nanoforge n'existe plus, remplacee par Moteur a quasar.
            if (cardCollection['nanoforge-card']) {
                cardCollection['quasar-card'] = (cardCollection['quasar-card'] || 0) + cardCollection['nanoforge-card'];
                delete cardCollection['nanoforge-card'];
            }
            // Migration : la carte Imprimeur quantique n'existe plus, remplacee par Horloger de pulsar.
            if (cardCollection['synth-card']) {
                cardCollection['pulsar-card'] = (cardCollection['pulsar-card'] || 0) + cardCollection['synth-card'];
                delete cardCollection['synth-card'];
            }
            // Migration : la carte Trou noir industriel n'existe plus, remplacee par Missile.
            if (cardCollection['blackhole-card']) {
                cardCollection['missile-card'] = (cardCollection['missile-card'] || 0) + cardCollection['blackhole-card'];
                delete cardCollection['blackhole-card'];
            }
        }

        // Charger les multiplicateurs
        autoMultipliers = sanitizeLoadedMultipliers(parsed.autoMultipliers, 4);
        clickMultipliers = sanitizeLoadedMultipliers(parsed.clickMultipliers, 4);
        updateAutoMultiplier();
        updateClickMultiplier();

        // Charger les upgrades des buildings
        if (parsed.buildingUpgrades) {
            for (const buildingId in parsed.buildingUpgrades) {
                buildingUpgrades[buildingId] = [...parsed.buildingUpgrades[buildingId]];
            }
        }

        // Charger les coûts fixes des upgrades
        if (parsed.buildingUpgradeCosts) {
            for (const buildingId in parsed.buildingUpgradeCosts) {
                buildingUpgradeCosts[buildingId] = {...parsed.buildingUpgradeCosts[buildingId]};
            }
        }

        // Charger le total généré par building
        if (parsed.totalGeneratedByBuilding) {
            for (const buildingId in parsed.totalGeneratedByBuilding) {
                totalGeneratedByBuilding[buildingId] = parsed.totalGeneratedByBuilding[buildingId] || 0;
            }
        }
        if (parsed.totalPartsEarnedAllTime !== undefined) {
            totalPartsEarnedAllTime = parsed.totalPartsEarnedAllTime || 0;
        } else {
            totalPartsEarnedAllTime = calculateTotalGenerated() + totalPartsFromClicks;
        }
        if (parsed.totalPartsEarnedThisLaunch !== undefined) {
            totalPartsEarnedThisLaunch = parsed.totalPartsEarnedThisLaunch || 0;
        } else {
            totalPartsEarnedThisLaunch = calculateTotalGenerated() + totalPartsFromClicks;
        }

        // Charger les bonus actifs (P12 : les multiplicateurs sont appliques
        // en UNE SEULE passe plus bas, APRES filtrage des bonus expires --
        // l'ancienne premiere passe etait du code mort ecrase par
        // resetMultipliers() et risquait de perdre de futurs multiplicateurs
        // persistes hors activeRandomBonuses.)
        if (Array.isArray(parsed.activeRandomBonuses)) {
            activeRandomBonuses = parsed.activeRandomBonuses.map(bonus => ({
                id: bonus.id,
                effect: bonus.effect,
                multiplier: bonus.multiplier,
                endTime: bonus.endTime
            }));
        }

        // Charger les comptes des buildings
        if (parsed.buildings) {
            parsed.buildings.forEach(savedBuilding => {
                const building = BUILDINGS.find(b => b.id === savedBuilding.id);
                if (building) {
                    building.count = savedBuilding.count || 0;
                }
            });
        } else if (parsed.eras) {
            parsed.eras.forEach(savedEra => {
                savedEra.buildings.forEach(savedBuilding => {
                    const building = BUILDINGS.find(b => b.id === savedBuilding.id);
                    if (building) {
                        building.count = savedBuilding.count || 0;
                    }
                });
            });
        }

        // Charger l'état des pièces de fusée (achats uniques)
        if (parsed.rocketParts) {
            parsed.rocketParts.forEach(savedPart => {
                const part = ROCKET_PARTS.find(p => p.id === savedPart.id);
                if (part) {
                    part.purchased = !!savedPart.purchased;
                    // Restaurer aussi l'etat construit : sans ca, toutes les
                    // pieces achetees rejouaient l'animation de chute d'un coup
                    // au chargement et paraissaient empilees n'importe comment.
                    if (savedPart.purchased) constructedParts.add(part.id);
                }
            });
        }
        // Etat construit persiste (format recent) : prioritaire sur la
        // regeneration via rocketParts, identique en pratique.
        if (parsed.constructedParts) {
            constructedParts = new Set(parsed.constructedParts.filter(id =>
                ROCKET_PARTS.some(p => p.id === id && p.purchased)));
        }

        // Restaurer les planetes atteintes et leurs bonus de production
        if (parsed.unlockedPlanets) {
            unlockedPlanets = new Set(parsed.unlockedPlanets);
            PLANETS.forEach(planet => {
                if (unlockedPlanets.has(planet.id)) {
                    planetBonuses[planet.id] = (wasmCore() ? (wasmCore().planet_bonus_percent ? wasmCore().planet_bonus_percent(PLANETS.indexOf(planet)) : planet.bonusPercent) : planet.bonusPercent) / 100;
                }
            });
        }

        // Filtrer les bonus expirés et recalculer les multiplicateurs
        const now = Date.now();
        activeRandomBonuses = activeRandomBonuses.filter(bonus => bonus.endTime >= now);
        
        resetMultipliers();
        activeRandomBonuses.forEach(bonus => {
            if (bonus.effect === "auto" || bonus.effect === "both" || bonus.effect === "multiplier") {
                if (bonus.multiplier) autoMultipliers.push(bonus.multiplier);
            }
            if (bonus.effect === "click" || bonus.effect === "both") {
                if (bonus.multiplier) clickMultipliers.push(bonus.multiplier);
            }
        });
        updateAutoMultiplier();
        updateClickMultiplier();
        
        if (autoMultipliers.length === 1) autoMultiplier = 1;
        if (clickMultipliers.length === 1) clickMultiplier = 1;

        initGlobals();
        applyOfflineEarnings(parsed.lastSave);

    } catch (e) {
        console.error("Erreur de chargement :", e);
        if (e instanceof SyntaxError) {
            localStorage.removeItem('starcruiserClickerSave');
            showToast("\u26a0\ufe0f " + t("Sauvegarde corrompue. Nouvelle partie."));
        } else {
            // Sauvegarde illisible seulement si le JSON lui-meme est casse.
            // Pour toute autre erreur (code, DOM), on conserve la sauvegarde :
            // la supprimer ferait perdre au joueur des heures de progression.
            showToast("\u26a0\ufe0f " + t("Erreur de chargement. Sauvegarde conserv\u00e9e."));
        }
    }
}

function exportSave() {
    // P11 : rafraichir la sauvegarde avant l'export (retard d'autosave).
    try { saveGame(); } catch (e) { /* export quand meme le meilleur etat connu */ }
    const saveData = localStorage.getItem('starcruiserClickerSave');
    if (!saveData) {
        showToast("\u274c " + t("Aucune sauvegarde."));
        return;
    }
    // TELECHARGEMENT PARTOUT : le joueur a demande un vrai fichier pose sur
    // l'appareil, pas un menu de partage. Le Blob + a.download + a.click()
    // telecharge sur desktop ET mobile moderne (iOS 13+, Android Chrome).
    // Fallback presse-papiers si l'appareil bloque le telechargement.
    const blob = new Blob([saveData], { type: 'text/plain' });
    try {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'starcruiser-sauvegarde.txt';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
        showToast("\u2705 " + t("Fichier de sauvegarde téléchargé !"));
    } catch (e) {
        navigator.clipboard.writeText(saveData)
            .then(() => showToast("\u2705 " + t("Sauvegarde copiée !")))
            .catch(() => showToast("\u274c " + t("Échec de la copie.")));
    }
}

let saveDisabled = false;
// V3.71 : VERROU ANTI-PERTE -- quand loadGame attend le module WASM pour
// verifier une save signee (hasSaveData=false, partie vierge en attendant),
// l autosave de la partie vierge NE DOIT PAS ecraser la save originale
// avant que le chargement rejoue (race condition : perte totale si le
// joueur reste 30 s sur la page, retour proprietaire 'j ai perdu ma
// progression au rechargement'). Le verrou est leve par loadGame lui-meme.
let saveLockedWaitingWasm = false;
// MODE TEST DEVELOPPEUR (V3.2) : panneau discret, active par l'import du
// mot-cle CHEATMODE2. Persiste via localStorage -- desactive en re-important
// CHEATMODE2. Aucune trace sans activation.
let devModeEnabled = false;
// Anti-triche : le mode test donne des Parts/distance gratuites -- tout
// score obtenu avec est invalide. Le flag est pose DES L'ACTIVATION (et a
// chaque clic du panneau) et n'est JAMAIS leve dans la session : les records
// deja falsifies restent invalides jusqu'au reload d'une partie propre.
// On coupe UNIQUEMENT la soumission au classement mondial -- pas de modale
// punitive ni de fonte des Parts : le mode test est un outil officiel.
let devModeTainted = false;
function enableDevMode() {
    devModeEnabled = true;
    devModeTainted = true;
    let panel = document.getElementById('dev-mode-panel');
    if (panel) { panel.style.display = ''; return; }
    panel = document.createElement('div');
    panel.id = 'dev-mode-panel';
    panel.innerHTML =
        '<div class="dev-panel-title">\ud83d\udd27 DEV</div>' +
        '<button data-dev="pe">+1000 PE</button>' +
        '<button data-dev="pe1m">+1M PE</button>' +
        '<button data-dev="parts">+1e9 Parts</button>' +
        '<button data-dev="virgoparts">Parts → Virgo</button>' +
        '<button data-dev="m">+1M Parts</button>' +
        '<button data-dev="t">+1T Parts</button>' +
        '<button data-dev="q">+1Q Parts</button>' +
        '<button data-dev="virgo">Virgo atteinte</button>' +
        '<button data-dev="launch">Lancement instant</button>' +
        '<button data-dev="trophies">Tous les troph\u00e9es</button>' +
        '<button data-dev="off">Quitter le mode test</button>';
    document.body.appendChild(panel);
    panel.addEventListener('click', (ev) => {
        const btn = ev.target.closest('button[data-dev]');
        if (!btn) return;
        const act = btn.dataset.dev;
        devModeTainted = true;
        if (act === 'pe') { starDust += 1000; totalStardustEarned += 1000; updateStardustDisplay(); saveGame(); }
        else if (act === 'pe1m') { starDust += 1000000; totalStardustEarned += 1000000; updateStardustDisplay(); saveGame(); }
        else if (act === 'virgoparts') {
            // Parts suffisantes pour DEPASSER l'Amas de Virgo (retour joueur :
            // 'le gain instantanne d'assez de parts pour atteindre l'amas, pas
            // simplement l'atteindre') -- le joueur achete sa fusee et lance,
            // au lieu du flag direct 'Virgo atteinte'. Distance lineaire :
            // parts = distance x 2,5e7 / 384 400, avec marge x2 pour acheter
            // les pieces de fusee par-dessus.
            const virgo = PLANETS.find(p => p.id === 'virgo-cluster');
            const partsNeeded = Math.ceil((virgo ? virgo.distanceRequired : 2.01e15) * 2.5e7 / 384400) * 2;
            score += partsNeeded;
            partsSinceLaunch += partsNeeded;
            invalidateBuildingGainsCache();
            updateDisplay();
            saveGame();
            showToast('\u2713 +' + formatNumber(partsNeeded) + ' ' + t('Parts') + ' \u2014 ' + t('Port\u00e9e actuelle') + ' : ' + formatNumber(calculateDistance()) + ' km');
        }
        else if (act === 'parts') { score += 1e9; partsSinceLaunch += 1e9; updateDisplay(); saveGame(); }
        else if (act === 'm') { score += 1e6; partsSinceLaunch += 1e6; updateDisplay(); saveGame(); }
        else if (act === 't') { score += 1e12; partsSinceLaunch += 1e12; updateDisplay(); saveGame(); }
        else if (act === 'q') { score += 1e15; partsSinceLaunch += 1e15; updateDisplay(); saveGame(); }
        else if (act === 'virgo') {
            const virgo = PLANETS.find(p => p.id === 'virgo-cluster');
            if (virgo) {
                if (lastLaunchDistance < virgo.distanceRequired) lastLaunchDistance = virgo.distanceRequired;
                if (maxDistance < virgo.distanceRequired) maxDistance = virgo.distanceRequired;
                const firstTime = !gameFinished;
                gameFinished = true;
                unlockedPlanets.add('virgo-cluster');
                saveGame();
                updateSpaceProgress();
                // Premiere fois : la celebration (ecran de fin) doit passer
                // elle aussi en mode Dev -- sinon le testeur ne la voit jamais.
                if (firstTime) showGameEnding(() => {});
            }
        }
        else if (act === 'launch') { try { launchRocket(); } catch (e) { console.warn('dev launch:', e); } }
        // V3.43 : debloque instantanement TOUS les trophees (test de l'ecran
        // de fin ultime) -- le checkTrophies du tick suivant detecte la
        // completion et declenche la modale.
        else if (act === 'trophies') {
            TROPHIES.forEach(tr => unlockedTrophies.add(tr.id));
            // V3.45 : le testeur doit VOIR la modale IMMEDIATEMENT -- l'ancien
            // chemin passait par checkTrophies dont la detection depend de
            // l'etat de jeu au moment du clic (retour joueur : 'je n'ai pas
            // eu la modale') ; appel DIRECT force, plus de dependance.
            trophiesEndingShown = false;
            showTrophiesEnding();
            trophiesEndingShown = true;
            checkTrophies();
            saveGame();
        }
        else if (act === 'off') {
            devModeEnabled = false;
            try { localStorage.removeItem('starcruiser-devMode'); } catch (e) {}
            panel.style.display = 'none';
            showToast('\ud83d\udd27 ' + t('Mode test d\u00e9sactiv\u00e9'));
        }
    });
}
function importSave() {
    let importText = document.getElementById('import-textarea').value.trim();
    if (!importText) { showToast("\u274c " + t("Rien \u00e0 importer.")); return; }
    // Nettoyage : BOM UTF-8 des fichiers exportes (Blob text/plain en
    // ajoute un), espaces invisibles -- JSON.parse echouait dessus.
    importText = importText.replace(/^\uFEFF/, '').trim();
    // MODE TEST DEVELOPPEUR (V3.2) : importer le mot-cle CHEATMODE2 (seul
    // ou en cle dans le JSON) active un panneau discret de triche -- il ne
    // remplace PAS la sauvegarde si le mot-cle est seul.
    if (importText === 'CHEATMODE2' || /"?CHEATMODE2"?\s*:/.test(importText)) {
        try { localStorage.setItem('starcruiser-devMode', '1'); } catch (e) {}
        enableDevMode();
        showToast('\ud83d\udd27 ' + t('Mode test d\u00e9veloppeur activ\u00e9'));
        document.getElementById('import-textarea').value = '';
        return;
    }
    try {
        const testParse = JSON.parse(importText);
        // V3.74 : VERIFICATION DE SIGNATURE STRICTE A L'IMPORT (retour
        // proprietaire : c'est ICI que la signature doit mordre -- une
        // save exportee puis MODIFIEE ne peut plus etre reimportee).
        // Une save sans _sig (vieilles saves, premier export) reste
        // acceptee -- la signature date de la V3.15.
        if (typeof testParse._sig === 'string' && testParse._sig.length === 64
            && window.StarcruiserCore && window.StarcruiserCore.saveVerify) {
            let importSigValid = false;
            try {
                importSigValid = window.StarcruiserCore.saveVerify(importText, testParse._sig) === 1;
            } catch (e) { importSigValid = false; }
            if (!importSigValid) {
                showToast('\u274c ' + t('Sauvegarde modifi\u00e9e \u2014 signature invalide. Import refus\u00e9.'));
                console.warn('[Starcruiser] Import refuse : signature invalide.');
                return;
            }
        }
        // Version ABSENTE : acceptee aussi -- les vieilles sauvegardes
        // n'avaient pas le champ, et loadGame migre par defaut. En mode
        // infini, buildings est un tableau (vide apres reset mais
        // present) : on accepte egalement un score seul.
        const hasGameData = !!(testParse.buildings || testParse.buildingUpgrades
            || typeof testParse.score === 'number' || testParse.totalPartsEarnedAllTime);
        if (hasGameData) {
            // P9 : backup de la sauvegarde actuelle avant ecrasement.
            const previous = localStorage.getItem('starcruiserClickerSave');
            if (previous) {
                try { localStorage.setItem('starcruiserClickerSaveBackup', previous); }
                catch (e) { /* quota plein : on importe quand meme */ }
            }
            // NOM D'ENTREPRISE : la save EST la cle. Priorite --
            // 1. La save importee PORTE un nom (exports recents) : il gagne.
            //    On restaure aussi la cle dediee des maintenant -- si le
            //    joueur importe PENDANT la modale non fermable, le nom doit
            //    etre la des le reload, sans nouvelle demande.
            // 2. Sinon, un nom local existe deja : on l'INJECTE dans la
            //    save avant ecriture -- l'import ne retire jamais
            //    l'identite du joueur.
            // 3. Sinon, le champ de la modale nom-requis est REMPLI (le
            //    joueur tapait son nom quand il a ouvert les Parametres
            //    pour importer) : on capture cette saisie comme nom --
            //    sinon le reload redemandait le nom et la saisie etait
            //    perdue (le flux semblait "casse").
            // 4. Rien : la modale nom-requis s'affichera au reload,
            //    comportement normal d'une premiere partie.
            let saveToWrite = importText;
            const importedName = sanitizeCompanyName(testParse.companyName);
            const localName = sanitizeCompanyName(localStorage.getItem(LEADERBOARD_COMPANY_KEY));
            let nameToUse = '';
            if (importedName.length >= 3) {
                nameToUse = importedName;
            } else if (localName.length >= 3) {
                nameToUse = localName;
            } else {
                const pendingInput = document.getElementById('company-required-input');
                const pendingName = sanitizeCompanyName(pendingInput ? pendingInput.value : '');
                if (pendingName.length >= 3) nameToUse = pendingName;
            }
            if (nameToUse) {
                try {
                    const enriched = JSON.parse(importText);
                    enriched.companyName = nameToUse;
                    saveToWrite = JSON.stringify(enriched);
                    try { localStorage.setItem(LEADERBOARD_COMPANY_KEY, nameToUse); } catch (e) {}
                } catch (e) { /* save deja valide en JSON : n'arrive pas */ }
            }
            localStorage.setItem('starcruiserClickerSave', saveToWrite);
            // FIX import : neutraliser les hooks de sauvegarde au reload
            // (beforeunload ecrasait la save importee par l'etat en cours).
            saveDisabled = true;
            showToast("\u2705 " + t("Import\u00e9 ! Red\u00e9marrage..."));
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showToast("\u274c " + t("Format invalide."));
        }    } catch (e) {
        // DIAGNOSTIC : l'erreur exacte dans la console + le toast precise
        // (fini le 'Format invalide' generique qui masquait la cause).
        console.error('Erreur import sauvegarde :', e);
        showToast("\u274c " + t("Format invalide.") + " (" + String(e.message || e).slice(0, 40) + ")");
    }
}

// Import direct d'un fichier texte de sauvegarde (exporte via exportSave) :
// le fichier est lu et importe sans passer par le copier-coller.
document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('import-file-input');
    if (!fileInput) return;
    fileInput.addEventListener('change', () => {
        const file = fileInput.files && fileInput.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            let text = String(e.target.result || '').trim();
            // Extraction du JSON : si le fichier contient du texte
            // autour (logs, en-tetes), on isole le premier '{' au
            // dernier '}'.
            const first = text.indexOf('{');
            const last = text.lastIndexOf('}');
            if (first > 0 && last > first) text = text.slice(first, last + 1);
            const textarea = document.getElementById('import-textarea');
            if (textarea) textarea.value = text;
            importSave();
        };
        reader.onerror = () => showToast("\u274c " + t("Échec de la lecture du fichier."));
        reader.readAsText(file);
        fileInput.value = '';
    });
});


function confirmDeleteSave() {
    // V3.79 (retour proprietaire : 'le bouton supprimer ne fonctionne pas')
    // : confirm() NATIF remplace par une modale maison -- le natif peut etre
    // ignore/masque (bloqueur de dialogues, reglages navigateur), sans
    // diagnostic possible. Modale .modal existante + verification reelle
    // de la suppression dans deleteSave.
    const existing = document.getElementById('delete-confirm-modal');
    if (existing) { existing.classList.add('active'); return; }
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'delete-confirm-modal';
    modal.style.cssText = 'width:92%;max-width:460px;top:50%;left:50%;transform:translate(-50%,-50%);height:auto;max-height:80dvh;z-index:16000;';
    modal.innerHTML =
        '<div class="modal-body" style="display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:28px 24px;gap:6px;overflow-y:auto;">' +
        '<div style="font-size:52px;line-height:1;margin-bottom:10px;">\u26a0\ufe0f</div>' +
        '<h3 style="color:#ef4444;font-size:1.35rem;margin:0 0 10px;">' + t('Supprimer la sauvegarde ?') + '</h3>' +
        '<p style="font-size:1rem;line-height:1.5;max-width:360px;margin:0 0 20px;">' + t('Tous vos progr\u00e8s seront PERDUS ! Cette action est irr\u00e9versible.') + '</p>' +
        '<div style="display:flex;flex-direction:column;gap:10px;width:100%;max-width:300px;">' +
        '<button class="modal-button delete" data-act="confirm" style="margin:0;background:#dc2626;">\ud83d\uddd1\ufe0f ' + t('Supprimer d\u00e9finitivement') + '</button>' +
        '<button class="modal-button" data-act="cancel" style="margin:0;background:var(--secondary-light);">\u2716 ' + t('Annuler') + '</button>' +
        '</div></div>';
    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('active'));
    modal.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-act]');
        if (btn) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 250);
            if (btn.dataset.act === 'confirm') deleteSave();
        } else if (e.target === modal) {
            modal.classList.remove('active');
            setTimeout(() => modal.remove(), 250);
        }
    });
}

function deleteSave() {
    // Neutraliser la sauvegarde avant suppression : le hook beforeunload
    // re-sauvegardait la partie au moment du reload et ressuscitait la
    // sauvegarde juste effacee.
    saveDisabled = true;
    clearTimeout(bonusSpawnTimer);
    bonusSpawnTimer = null;
    // RESET COMPLET : l'entree du classement MONDIAL part aussi -- le nom
    // local est supprime ci-dessous mais le serveur garderait sinon
    // l'ancienne progression indefiniment (records monotones). Fire-and-
    // forget : le reload ne l'attend pas.
    try {
        const name = getCompanyName();
        if (name.length >= 3) deleteRemoteScore(name);
    } catch (e) {}
    localStorage.removeItem('starcruiserClickerSave');
    localStorage.removeItem('starcruiserClickerSaveBackup');
    localStorage.removeItem(LEADERBOARD_COMPANY_KEY);
    localStorage.removeItem(LEADERBOARD_LOCAL_KEY);
    // RESET COMPLET : les lecons vues, le tuto et l'ecran d'intro survivaient
    // a la suppression -- apres un "reset", le joueur ne revoyait NI le tuto
    // NI l'intro NI les lecons contextuelles : la partie semblait non
    // supprimee. Tout l'etat de progression pedagogique repart de zero.
    // Seuls la langue et les reglages audio sont conserves (confort).
    localStorage.removeItem('starcruiser-lessons-seen');
    localStorage.removeItem('starcruiser-intro-seen');
    // V3.79 : purge COMPLETE -- l'archive des saves refusees (V3.71) et
    // le backup d'import disparaissent aussi : un reset complet est un
    // reset complet.
    localStorage.removeItem('starcruiserClickerSaveRejected');
    localStorage.removeItem('starcruiserClickerSaveBackup');
    // VERIFICATION : relire la cle principale apres effacement. Si elle
    // est encore la (stockage navigateur refusant, quota corrompu), on
    // PREVIENT au lieu de recharger en silence (retour proprietaire :
    // 'le bouton ne fonctionne pas' -- la cause sera au moins visible).
    const stillThere = localStorage.getItem('starcruiserClickerSave');
    if (stillThere !== null) {
        showToast('\u274c ' + t('Echec de suppression (stockage navigateur)'));
        saveDisabled = false;
        return;
    }
    showToast('\ud83d\uddd1\ufe0f ' + t('Supprimé !'));
    // RELOAD IMMEDIAT : l'ancien delai de 1 s laissait le jeu tourner ;
    // replace() evite en plus de polluer l'historique de navigation.
    window.location.replace(window.location.pathname);
}

// ============================================
// BUILDINGS MANAGEMENT
// ============================================

function setBuyMultiplier(multiplier) {
    buyMultiplier = multiplier;
    
    document.querySelectorAll('.multiplier-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    if (multiplier === 'max') {
        document.getElementById('multiplier-max').classList.add('active');
    } else {
        document.getElementById(`multiplier-x${multiplier}`).classList.add('active');
    }
    
    updateAllBuildingButtons();
}

// Reveal "Nouveau batiment" : popup plein ecran avec l'image en grand,
// la description et les caracteristiques. Se declenche uniquement au
// premier achat d'un type de batiment (count 0 -> 1).
function showNewBuildingModal(building) {
    const modal = document.getElementById('new-building-modal');
    if (!modal) return;
    const img = document.getElementById('nb-image');
    if (img) {
        img.src = building.imgPath || '';
        img.alt = building.name;
        // relance l'animation de pop a chaque ouverture
        img.style.animation = 'none';
        void img.offsetWidth;
        img.style.animation = '';
    }
    document.getElementById('nb-name').textContent = t(building.name);
    document.getElementById('nb-description').textContent = t(building.description);
    document.getElementById('nb-gain').textContent = '+' + formatNumber(building.gain) + ' ' + t('Parts') + '/s';
    document.getElementById('nb-cost').textContent = formatNumber(building.baseCost) + ' ' + t('Parts');
    modal.classList.add('active');
}

function closeNewBuildingModal() {
    const modal = document.getElementById('new-building-modal');
    if (modal) modal.classList.remove('active');
}

function buyBuilding(buildingId, qty) {
    const building = findBuildingById(buildingId);
    if (!building) return;

    // V3.5 GARDE-FOU ABSOLU : plus jamais d'achat a credit. Le bug du score
    // negatif venait d'ici -- aucun controle totalCost <= score : un
    // double-clic rapide (le score n'a pas encore ete debite) ou l'auto-achat
    // (decision sur un score stale) achetaient au-dela de la banque.
    // On RECALCULE ici, a l'instant de l'achat, et on TRONQUE la quantite.
    // V3.52 : parametre qty optionnel -- l'AUTO-BUY passe 1 : il achetait
    // via le MULTIPLICATEUR GLOBAL du joueur (x50 ou Max, retour joueur :
    // 'mon auto achat achete le maximum quand je passe en x50') et vidait
    // la banque en une passe, rendant ensuite les boutons manuels
    // inabordables ('les multiplicateurs ne sont plus effectifs').
    // Sans qty : comportement inchange (multiplicateur du joueur).
    let buildingsToBuy = qty !== undefined
        ? Math.max(1, Math.floor(qty))
        : (buyMultiplier === 'max' ? calculateMaxAffordable(building) : buyMultiplier);
    let totalCost = 0;
    const computeCost = () => {
        let c = 0;
        for (let i = 0; i < buildingsToBuy; i++) {
            c += calculateBuildingCost({...building, count: building.count + i});
        }
        return c;
    };
    totalCost = computeCost();
    // Troncature : si la banque ne couvre pas la quantite demandee, on
    // rachete seulement ce qui est couvrable (jamais de credit).
    while (buildingsToBuy > 0 && totalCost > score) {
        buildingsToBuy--;
        totalCost = computeCost();
    }
    if (buildingsToBuy > 0 && totalCost > score + 1e-9) {
        buildingsToBuy = 0;
    }
    if (buildingsToBuy > 0 && score >= totalCost) {
        const isNewType = building.count === 0;
        const gainedPps = calculateUnitBuildingGain(building) * buildingsToBuy;
        score -= totalCost;
        building.count += buildingsToBuy;
        unlockedBuildings.add(building.id);
        invalidateBuildingGainsCache();
        updateMiniGamesVisibility();
        Sounds.buy();
        showBuyFeedback(document.getElementById('building-' + building.id), '-' + formatNumber(totalCost) + ' ' + t('Parts'), '+' + formatNumber(gainedPps) + '/s');
        if (isNewType) { showNewBuildingModal(building); Sounds.unlock(); }
        updateDisplay();
        updateConstructionScene();
        // UI D'ABORD (retour joueur : le compteur Possédés semblait mettre
        // plusieurs centaines de ms a reagir) : updateAllBuildingButtons est
        // synchrone et leger, il repose sur le cache invalide juste au-dessus.
        // saveGame (JSON.stringify x2 + signature HMAC WASM depuis V3.15)
        // est le cout lourd : DIFFERE apres le rendu, la frame n'attend plus.
        updateAllBuildingButtons();
        renderUpgrades();
        checkBuildingUnlocks();
        // V3.36 : ROBUSTESSE anti-perte -- le save differe (setTimeout 0,
        // optimisation de reactivite V3.22) ne s'executait JAMAIS si l'onglet
        // gelait juste apres une rafale d'achats : au rechargement, TOUS les
        // achats depuis le dernier autosave etaient perdus (retour joueur :
        // 'j ai perdu la liste des batiments'). Garde-fou : si le save differe
        // precedent n'a pas encore tourne, on SAUVE GARDE IMMEDIATEMENT le
        // 1er achat ( synchrone), puis on differe -- une rafale ne peut plus
        // perdre que son dernier achat, jamais tout le lot.
        if (buyBuilding.__savePending) {
            try { saveGame(); } catch (e) {}
        } else {
            buyBuilding.__savePending = true;
            setTimeout(() => { buyBuilding.__savePending = false; saveGame(); }, 0);
        }
        // V3.5 : hideTooltip seulement pour un achat MANUEL -- l'auto-achat
        // rafraichissant les cases toutes les secondes tuait l'infobulle du
        // batiment survole (retour playtest : "relou").
        if (!suppressTooltipHide) hideTooltip();
        checkTrophies();
    } else {
        hideTooltip();
        Sounds.lose();
        showToast("\u274c " + t("Pas assez de Parts"));
    }
}

function calculateMaxAffordable(building) {
    // Formule fermee (somme geometrique) au lieu d'une boucle couteuse :
    // cost(i) = floor(base * r^i * (1 - red)), i = 0..n-1.
    // La boucle precedente etait O(n) par batement et par frame, avec un
    // score eleve n pouvait atteindre des dizaines de milliers d'unites.
    if (score < calculateBuildingCost(building)) return 0;
    const reduction = getBuildingCostReduction();
    const unit = Math.floor(building.baseCost * (1 - reduction));
    if (unit <= 0) return 0;
    const r = BUILDING_PRICE_GROWTH_RATE;
    let n = Math.floor(Math.log(1 + (score * (r - 1)) / (unit * Math.pow(r, building.count))) / Math.log(r));
    if (!(n > 0)) return 0;
    // Ajustement fin : l'arrondi floor() par unite rend les couts reels
    // legerement differents de la somme geometrique continue. On corrige de
    // part et d'autre avec le cout exact (quelques iterations seulement).
    while (n > 0 && calculateTotalBuildingCost(building, n) > score) n--;
    let guard = 0;
    while (guard++ < 1000 && calculateTotalBuildingCost(building, n + 1) <= score) n++;
    return n;
}
let buildingCostMemo = null;
function calculateTotalBuildingCost(building, count) {
    // Somme geometrique des couts des `count` prochaines unites.
    // Memoisation : updateAllBuildingButtons recalcule le cout d'achat pour
    // TOUS les batiments toutes les 500 ms -- a haut score avec x/max, chaque
    // passe bouclait sur des milliers d'unites. La memo n'est valide que pour
    // un meme (buildingId, count achete, count possede), purgee a chaque
    // achat via invalidateBuildingGainsCache.
    const key = building.id + ':' + count + ':' + building.count;
    if (buildingCostMemo && buildingCostMemo.key === key) return buildingCostMemo.value;
    let totalCost = 0;
    for (let i = 0; i < count; i++) {
        totalCost += calculateBuildingCost({...building, count: building.count + i});
    }
    buildingCostMemo = { key, value: totalCost };
    return totalCost;
}

// Feedback d'achat : pop flottant "\u00d72" au-dessus de la case amelioration
// concernee, aux couleurs de la case, pour confirmer visuellement le gain.
function showUpgradeBoughtFeedback(hostEl, color, buildingId) {
    // Mobile : le pop x2 n'est pas visible (ancres viewport au-dessus de
    // zones masquees par la vue une-page-a-la-fois) -- on ne l'affiche pas,
    // le toast confirme deja l'achat.
    if (typeof isMobileLayout === 'function' && isMobileLayout()) return;
    const container = document.getElementById('upgrades-container');
    let host = hostEl || (container ? container.querySelector('.upgrade-icon') : null);
    // Amelioration de BATIMENT : le pop ×2 s'affiche a cote de la case du
    // batiment concernee dans le panneau droit (demande explicite), pas
    // sur la case d'amelioration de la barre du haut.
    if (buildingId) {
        const buildingCard = document.getElementById('building-' + buildingId);
        if (buildingCard) host = buildingCard;
    }
    if (!host) return;
    // Position capturee AVANT le re-render (renderUpgrades vide le conteneur :
    // un pop attache a la case etait detruit instantanement, d'ou l'absence
    // totale de feedback). Le pop vit dans le body, hors de tout re-render.
    const rect = host.getBoundingClientRect();
    const pop = document.createElement('span');
    pop.className = 'upgrade-bought-pop';
    // V3.47bis (retour joueur : 'remets le x2 a GAUCHE de la case') :
    // retour a l'ancrage GAUCHE, mais CLAMPE au viewport -- la version
    // precedente translatlee a -100% partait hors ecran quand la case
    // est proche du bord gauche. On mesure le pop et on le colle au bord
    // minimum : toujours a gauche de la case quand il y a la place,
    // jamais invisible.
    if (buildingId) pop.classList.add('upgrade-bought-pop-xl');
    pop.textContent = '\u00d72';
    if (color) { pop.style.color = color; pop.style.borderColor = color; }
    pop.style.top = (rect.top + rect.height / 2) + 'px';
    document.body.appendChild(pop);
    const popW = pop.offsetWidth || 60;
    pop.style.left = Math.max(4, rect.left - popW - 8) + 'px';
    return;
    setTimeout(() => pop.remove(), 900);
}
function buyClickUpgrade(threshold, sourceEl) {
    const upgrade = CLICK_UPGRADES.find(u => u.threshold === threshold);
    if (!upgrade) return;
    
    if (activatedClickUpgrades.includes(threshold)) {
        showToast("\u2705 " + t("Already activated!"));
        return;
    }
    
    if (score < upgrade.cost) {
        Sounds.lose();
        showToast("\u274c " + t("Pas assez de Parts"));
        return;
    }
    
    score -= upgrade.cost;
    activatedClickUpgrades.push(threshold);
    Sounds.upgrade();
    showUpgradeBoughtFeedback(sourceEl, UPGRADE_COLORS[CLICK_UPGRADES.indexOf(upgrade) % UPGRADE_COLORS.length]);
    updateDisplay();
    saveGame();
    hideTooltip();
    renderUpgrades();
    updateAllBuildingButtons();
    showToast(`\u2705 ${t(upgrade.name)} ${t("activated")}`);
}

function buyBuildingUpgrade(buildingId, threshold, sourceEl) {
    const building = findBuildingById(buildingId);
    if (!building || !isBuildingUpgradeAvailable(buildingId, threshold)) return;
    
    const cost = getBuildingUpgradeFixedCost(buildingId, threshold);
    
    if (score < cost) {
        Sounds.lose();
        showToast("\u274c " + t("Pas assez de Parts"));
        return;
    }
    
    score -= cost;
    
    if (!buildingUpgrades[buildingId]) {
        buildingUpgrades[buildingId] = [];
    }
    
    buildingUpgrades[buildingId].push(threshold);
    Sounds.upgrade();
    showUpgradeBoughtFeedback(sourceEl, getUpgradeTierColor(BUILDING_UPGRADE_THRESHOLDS.indexOf(threshold)), buildingId);
    invalidateBuildingGainsCache();
    updateDisplay();
    saveGame();
    hideTooltip();
    renderUpgrades();
    updateAllBuildingButtons();
    checkTrophies();
    showToast('+ ' + t(building.name) + ' ' + t('am\u00e9lior\u00e9 x2') + ' (-' + formatNumber(cost) + ' Parts)');
}

// Bâtiments déjà signalés comme abordables : le son ne joue qu'au passage
// inabordable -> abordable, pas en continu ni au chargement initial.
const affordableNotifiedBuildings = new Set();
let affordableSoundReady = false;

function updateBuildingButton(buildingId, pulseTarget) {
    const element = document.getElementById(`building-${buildingId}`);
    if (!element) return;

    const building = findBuildingById(buildingId);
    if (!building) return;

    const buildingsToShow = buyMultiplier === 'max' ? calculateMaxAffordable(building) : buyMultiplier;
    const totalCost = calculateTotalBuildingCost(building, buildingsToShow);
    
    const totalGain = calculateBuildingGain(building);
    const isAffordable = score >= totalCost;
    
    const displayCost = formatNumber(totalCost);

    const notPurchased = building.count === 0;
    if (element.classList.contains('not-purchased') !== notPurchased) {
        element.classList.toggle('not-purchased', notPurchased);
    }

    const button = element.querySelector('button');
    const productionSpan = element.querySelector('.building-production');
    const ownershipDiv = element.querySelector('.building-ownership');

    if (button) {
        const btnText = `${displayCost} ${t("Parts")}`;
        const btnDisabled = !isAffordable || buildingsToShow === 0;
        if (button.textContent !== btnText) button.textContent = btnText;
        if (button.disabled !== btnDisabled) button.disabled = btnDisabled;
    }
    if (productionSpan) {
        const prodText = `${formatNumber(totalGain)}/s`;
        if (productionSpan.textContent !== prodText) productionSpan.textContent = prodText;
    }
    if (ownershipDiv) {
        const ownText = `${t("Possédés:")} ${building.count}`;
        if (ownershipDiv.textContent !== ownText) ownershipDiv.textContent = ownText;
    }

    const newTooltip = getBuildingTooltip(building);
    if (element.getAttribute('data-tooltip') !== newTooltip) element.setAttribute('data-tooltip', newTooltip);
    // Pulse d'attention : le premier batiment debloquE non possEdE dont le
    // prix est abordable (la cible est pre-calcullEe par updateAllBuildingButtons).
    if (pulseTarget !== undefined && building.id === pulseTarget && isAffordable) {
        pulseHint(element);
    } else if (!notPurchased) {
        clearPulseHint(element);
    }
    // V3.9 : le carillon ne joue QUE pour le DERNIER batiment debloque
    // (retour playtest : un son a chaque batiment abordable = pollution).
    // affordableNotifiedBuildings garde la memoire par batiment, le son
    // n'est emis que si c'est le plus haut batiment du jeu.
    const isLastBuilding = BUILDINGS[BUILDINGS.length - 1].id === building.id;
    if (isAffordable) {
        if (!affordableNotifiedBuildings.has(building.id)) {
            affordableNotifiedBuildings.add(building.id);
            // Pas de son au tout premier passage (chargement de partie) :
            // on ne carillonne que les transitions ultérieures.
            if (affordableSoundReady && isLastBuilding) Sounds.affordable();
        }
    } else {
        affordableNotifiedBuildings.delete(building.id);
    }
}

function updateAllBuildingButtons() {
    // Cible du pulse calculEe UNE fois (et non par batiment) : le premier
    // batiment debloquE non possEdE. Chaque bouton testait avant avec un
    // BUILDINGS.some() — O(batiments^2) a chaque tick de 500 ms.
    let pulseTarget = null;
    for (const b of BUILDINGS) {
        if (isBuildingUnlocked(b) && b.count === 0) { pulseTarget = b.id; break; }
    }
    document.querySelectorAll('.building-item').forEach(element => {
        const buildingId = element.id.replace('building-', '');
        updateBuildingButton(buildingId, pulseTarget);
    });
    affordableSoundReady = true;
}

// Pulse d'attention : allume un element pendant 10 s maxi, puis s'eteint
// tout seul si le joueur n'a pas agi. Reallumer un element deja allume
// ne reinitialise PAS son chrono (pas de pulse infini sur un element).
const pulseHintTimers = new WeakMap();
function pulseHint(el) {
    if (!el || pulseHintTimers.has(el)) return;
    el.classList.add('pulse-hint');
    const timer = setTimeout(() => {
        el.classList.remove('pulse-hint');
        pulseHintTimers.delete(el);
    }, 10000);
    pulseHintTimers.set(el, timer);
}
function clearPulseHint(el) {
    if (!el || !pulseHintTimers.has(el)) return;
    clearTimeout(pulseHintTimers.get(el));
    pulseHintTimers.delete(el);
    el.classList.remove('pulse-hint');
}

function isBuildingUnlocked(building) {
    return building.unlockCondition ? building.unlockCondition() : true;
}

function checkBuildingUnlocks() {
    let needsRerender = false;
    BUILDINGS.forEach((building) => {
        if (isBuildingUnlocked(building) && !unlockedBuildings.has(building.id)) {
            unlockedBuildings.add(building.id);
            needsRerender = true;
        }
    });
    if (needsRerender) {
        renderBuildings();
    }
    renderCollectionCardStatus();
    renderContractsCardStatus();
}

function renderBuildings() {
    const container = document.getElementById('buildings-list');
    // Preserver la position de scroll : un rerendu (ex. deblocage d'un
    // batiment pendant que le score monte) ne doit jamais remonter la liste.
    // La liste elle-meme est le conteneur scrollable (header fige au-dessus).
    const scrollPanel = container.classList.contains('buildings-list') ? container : container.closest('.right-panel');
    const savedScroll = scrollPanel ? scrollPanel.scrollTop : 0;
    container.innerHTML = '';

    BUILDINGS.forEach((building) => {
        if (isBuildingUnlocked(building) || unlockedBuildings.has(building.id)) {
            renderBuilding(building);
        }
    });
    // V3.76 : le transfert des .building-production (mobile<->desktop) est
    // DEFERE hors boucle -- renderBuilding l'appelait a CHAQUE case (14
    // appendChild de deplacement au boot = 14 invalidations de layout en
    // rafale, retour : reflow 87 ms au chargement). Un seul passage apres
    // le rendu complet suffit : les noeux sont tous presents.
    relocateBuildingProductions();
    // Restauration ASYNCHRONE du scroll (double rAF). La restauration
    // synchrone etait mangee sur mobile : le rerendu VIDE le conteneur ->
    // le navigateur reclamp scrollTop sur la hauteur reduite -> les
    // batiments sont re-ajoutes -> scrollTop restaure, MAIS le clamp
    // posterieur (mesure de la NOUVELLE hauteur, notamment en bas de
    // liste quand l'achat debloque un batiment suivant plus haut)
    // remontait la liste de quelques pixels. En double rAF, la
    // restauration n'arrive qu'APRES le reflow de la nouvelle hauteur :
    // le clamp ne peut plus la remanger.
    if (scrollPanel && savedScroll > 0) {
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                if (scrollPanel.isConnected) scrollPanel.scrollTop = savedScroll;
            });
        });
    }
}

function renderBuilding(building) {
    const container = document.getElementById('buildings-list');
    const currentCost = calculateBuildingCost(building);
    const totalGain = calculateBuildingGain(building);
    const isAffordable = score >= currentCost;

    const buildingElement = document.createElement('div');
    buildingElement.className = 'building-item ' + building.id + (building.count === 0 ? ' not-purchased' : '');
    buildingElement.id = `building-${building.id}`;
    buildingElement.setAttribute('data-tooltip', getBuildingTooltip(building));

    // Créer la structure avec l'image ou l'emoji du bâtiment
    const imageUrl = building.imgPath || '';
    const imageHtml = imageUrl
        ? `<img src="${imageUrl}" class="building-image" alt="${building.name}" width="${building.width || 84}" height="${building.height || 84}">`
        : `<span class="building-emoji">${building.image || ''}</span>`;

    buildingElement.innerHTML = `
        <div class="building-left">
            <div class="building-name-icon">
                <span class="building-name">${t(building.name)}</span>
            </div>
            <div class="building-ownership">
                ${t("Possédés:")} ${building.count}
            </div>
            <div class="building-production">${formatNumber(totalGain)}/s</div>
        </div>
        <div class="building-center">
            ${imageHtml}
        </div>
        <div class="building-right">
            <button onclick="buyBuilding('${building.id}')" ${!isAffordable ? 'disabled' : ''}>
                ${formatNumber(currentCost)} ${t("Parts")}
            </button>
        </div>
    `;

    if (!IS_TOUCH) {
        buildingElement.addEventListener('mouseenter', (e) => {
            if (building.count === 0) return;
            const rect = buildingElement.getBoundingClientRect();
            showTooltip(getBuildingTooltip(building), rect.left, rect.top, {
                align: 'left',
                // 90 % de la largeur de la case : texte aise sans deborder
                // sur les elements voisins.
                width: Math.round(rect.width * 0.9)
            });
            tooltipLiveRefresh = () => getBuildingTooltip(building);
        });
        buildingElement.addEventListener('mouseleave', hideTooltip);
    }
    if (IS_TOUCH) {
        buildingElement.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;
            if (building.count === 0) return;
            showTouchTooltip(buildingElement, getBuildingTooltip(building));
            tooltipLiveRefresh = () => getBuildingTooltip(building);
        });
    }

    container.appendChild(buildingElement);
}


function relocateBuildingProductions() {
    document.querySelectorAll('.building-item').forEach(item => {
        const prod = item.querySelector('.building-production');
        const left = item.querySelector('.building-left');
        const right = item.querySelector('.building-right');
        if (!prod || !left || !right) return;
        if (isMobileLayout() && prod.parentElement !== left) {
            left.appendChild(prod);
        } else if (!isMobileLayout() && prod.parentElement !== right) {
            right.appendChild(prod);
        }
    });
}

// V3.47 : indicateurs de SCROLL de la liste des batiments -- les
// scrollbars sont masquees globalement (scrollbar-width: none), avec 14
// batiments debloques le Trou noir restait SOUS LA FOLD sans aucun
// signal que la liste continuait (retour joueur : 'je ne vois pas les
// batiments apres l'Horloger du pulsar'). Deux voiles de fondu sur le
// right-panel, pilotes par ces classes, visibles seulement quand il y a
// du contenu cache dans la direction.
function updateBuildingsScrollHints() {
    const panel = document.querySelector('.right-panel');
    const list = document.getElementById('buildings-list');
    if (!panel || !list) return;
    const canUp = list.scrollTop > 4;
    const canDown = list.scrollTop + list.clientHeight < list.scrollHeight - 4;
    panel.classList.toggle('can-scroll-up', canUp);
    panel.classList.toggle('can-scroll-down', canDown);
}
(function attachBuildingsScrollHints() {
    const list = document.getElementById('buildings-list');
    if (list) list.addEventListener('scroll', updateBuildingsScrollHints, { passive: true });
    window.addEventListener('resize', updateBuildingsScrollHints);
})();

// ============================================
// ROCKET LAUNCH SYSTEM
// ============================================

function checkRocketReady() {
    // Vérifier si toutes les pièces de fusée sont achetées
    return ROCKET_PARTS.every(part => part.purchased);
}
// Visibilite du bouton Lancer la fusee : il n'apparait QUE quand la fusee
// est complete. Avant, la case d'achat des pieces occupe le bas du panneau
// central a sa place -- plus de bouton inutilisable des le debut du jeu.
// Le bouton "Site officiel" n'a de sens que dans une iframe embarquée (itch.io...).
// Sur le site officiel il est caché (display:none par défaut dans le HTML) ; on
// l'affiche uniquement si le domaine courant est une plateforme d'hébergement.
(function () {
    var h = location.hostname;
    var embedded = /itch\.zone$/.test(h) || /(^|\.)itch\.io$/.test(h)
        || /(^|\.)crazygames\.com$/.test(h) || /(^|\.)poki\.(com|games)$/.test(h)
        || /(^|\.)gamejolt\.com$/.test(h) || /(^|\.)newgrounds\.com$/.test(h);
    var btn = document.getElementById('official-site-btn');
    if (btn && embedded) btn.style.display = '';
})();

function updateLaunchButtonVisibility() {
    const btn = document.getElementById('launch-button');
    const shop = document.getElementById('rocket-parts-shop');
    const ready = checkRocketReady();
    if (btn && btn.classList.contains('ready') !== ready) {
        btn.classList.toggle('ready', ready);
    }
    // Fusee complete : le bouton LANCER reprend le bas du panneau, la carte
    // de la boutique laisse sa place (elle etait informative seulement).
    if (shop && shop.classList.contains('shop-done') !== ready) {
        shop.classList.toggle('shop-done', ready);
    }
}

const PIECE_DISTANCE_MULT = 1.0;
const MOON_DISTANCE = 384400;
// Parts cumulees produites lors du premier lancement d'une nouvelle partie.
// Ce point d'ancrage calibre le debut de la courbe de distance.
// 35M parts pour la Lune: premier objectif reel du jeu (baisse depuis 50M,
// juge trop long ; 35M vise ~25-30 min de jeu actif).
const DISTANCE_MOON_PARTS = 2.5e7;
// Distance lineaire : exposant 1.0, la vitesse km/s ne diminue jamais quand
// les parts croissent. La difficulte vient uniquement du prix des batiments
// et de l'ancre de la Lune, pas d'un ralentissement de la distance.
const DISTANCE_SCORE_EXP = 1.0;
// Gain de Poussière d'Étoiles -- système CUMULATIF (V3, style Cookie Clicker):
// le PE potentiel depend de la distance TOTALE parcourue depuis le debut
// de la partie (tous vols confondus), pas du dernier vol seul.
//
// UNE SEULE FORMULE, aucune seuil, exactement comme les Heavenly Chips :
//   PE(D) = (D / Lune)^(1/3)   avec D = distance cumulee en km
// Le PREMIER vol Lune donne toujours 1 PE. La racine cubique rend les
// Quindecillions atteignables : x1000 de distance = x10 de PE.
//
// V3.3 : l'arbre de base a ete RECALIBRE (couts 1 a 50 PE, total ~800)
// pour etre achetable au fil de l'eau par la formule SEULE -- pas de
// jalons de planetes, une seule regle simple pour le joueur : chaque
// vol rapporte f(distance cumulee). Arbre complet ~800 PE < Virgo
// (~1 736 PE), la branche Infinie prend le relais au-dela.
//
// Chaque lancement credite la DIFFERENCE entre le PE cumul actuel et le PE
// deja credite : attendre plus longtemps avant de lancer rapporte plus.
const STARDUST_DISTANCE_EXP = 1 / 3;
const STARDUST_MILESTONE_START_KM = 891000000000; // Nuage d'Oort : bascule racine cubique

// Croissance du coût des pièces de fusée entre les lancements.
// Croissance calibrée sur le multiplicateur de production permanent MOYEN
// gagné par cycle de lancement. Estimation fixe (constante, pas variable) :
// - planète débloquée (~1/cycle) : +30 à 50% additif -> ~×1,1-1,2 effectif
// - Poussière d'Étoiles dépensée en production : +25 à 45% additif -> ~×1,1
// Cumul moyen ~×1,3 par lancement (×1,5 en début de partie, ×1,2 en fin).
// La fusée reste reconstruisible en début de cycle (le joueur produit ~30%
// plus vite qu'au cycle précédent) sans devenir gratuite en fin de partie.
// V3.26 : croissance des pieces de fusee RENCHERIE -- l'ancien 1.3 plat
// rendait les dernieres pieces (astronaute 638k de base) trop faciles des
// que la production explosait. Facteur de base 1.4, +0.04 par lancement
// AU-DELA du 10e, plafonne a 1.8 : modere en debut de partie (x1.3 au 5e
// lancement vs x1.0 avant), mordant en end-game (x460 au 20e vs x146).
const ROCKET_PART_COST_GROWTH_BASE = 1.4;
const ROCKET_PART_COST_GROWTH_MAX = 1.8;
function rocketPartCostGrowth(launches) {
    return Math.min(ROCKET_PART_COST_GROWTH_MAX, ROCKET_PART_COST_GROWTH_BASE + 0.04 * Math.max(0, launches - 10));
}

function calculateDistance() {
    const partsUnlocked = ROCKET_PARTS.filter(part => part.purchased).length;
    const totalParts = Math.max(partsSinceLaunch, 0);
    const partsMult = Math.pow(PIECE_DISTANCE_MULT, partsUnlocked);
    const scoreFactor = totalParts > 0
        ? (totalParts <= DISTANCE_MOON_PARTS
            ? MOON_DISTANCE * (totalParts / DISTANCE_MOON_PARTS)
            : MOON_DISTANCE * Math.pow(totalParts / DISTANCE_MOON_PARTS, DISTANCE_SCORE_EXP))
        : 0;
    const baseDistance = partsMult * scoreFactor;

    return baseDistance * getDistanceBonus();
}

function getCurrentDistance() {
// Retourne la dernière distance calculée au lancement
    return lastLaunchDistance;
}
// Vitesse du prochain voyage : distance atteignable / durée de l'animation.
// Chaque tronçon dure TRAVEL_ANIM_LEG_MS ; le nombre de tronçons suit le
// nombre de planètes jusqu'ê la destination atteignable (même logique
// que l'animation : la vitesse en km/s s'adapte ê chaque tronçon).
function calculateTravelSpeedKmS() {
    // Vitesse REELLE : combien de km la stat "Distance atteignable" gagne
    // par seconde. Distance = f(partsSinceLaunch) et partsSinceLaunch croit
    // de partsPerSecond chaque seconde -> vitesse = f'(parts) * pps.
    // On derive exactement la meme formule que calculateDistance().
    const parts = Math.max(partsSinceLaunch, 0);
    if (parts <= 0 || partsPerSecond <= 0) return 0;
    return travelSpeedFromPps(parts, partsPerSecond);
}
// Vitesse hors boost temporaire de production (x4 etc.) : base des trophees
// de vitesse, pour qu'un multiplicateur ephemere ne debloque pas un trophee.
function calculateTravelSpeedKmSBase() {
    const parts = Math.max(partsSinceLaunch, 0);
    const basePps = getBasePartsPerSecond();
    if (parts <= 0 || basePps <= 0) return 0;
    return travelSpeedFromPps(parts, basePps);
}
function travelSpeedFromPps(parts, pps) {
    const partsUnlocked = ROCKET_PARTS.filter(part => part.purchased).length;
    const partsMult = Math.pow(PIECE_DISTANCE_MULT, partsUnlocked);
    let dFactor;
    if (parts <= DISTANCE_MOON_PARTS) {
        // scoreFactor lineaire : MOON_DISTANCE * (parts / DISTANCE_MOON_PARTS)
        dFactor = MOON_DISTANCE / DISTANCE_MOON_PARTS;
    } else {
        // scoreFactor puissance : derivee de MOON_DISTANCE * x^EXP avec x = parts/DISTANCE_MOON_PARTS
        dFactor = MOON_DISTANCE * DISTANCE_SCORE_EXP * Math.pow(parts / DISTANCE_MOON_PARTS, DISTANCE_SCORE_EXP - 1) / DISTANCE_MOON_PARTS;
    }
    return pps * partsMult * dFactor * getDistanceBonus();
}
function formatTravelSpeed(kmS) {
    if (kmS <= 0) return '0 km/s';
    if (kmS >= 1000) return formatNumber(kmS) + ' km/s';
    const v = Math.round(kmS * 10) / 10;
    return (v % 1 === 0 ? v.toString() : v.toFixed(1)) + ' km/s';
}

// Glow radial de plongee galactique : voile de lumiere plein ecran qui
// grandit a l'approche d'une galaxie (rel = distance camera).
let travelGalaxyGlow = null;
function createTravelGalaxyGlow(hostEl) {
    const scene = hostEl ? hostEl.parentElement : null;
    if (!scene) return null;
    const glow = document.createElement('div');
    glow.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:40;opacity:0;' +
        'background:radial-gradient(circle at 50% 55%, rgba(200,210,255,0.85) 0%, rgba(150,160,255,0.4) 22%, rgba(90,100,200,0.18) 40%, transparent 68%);' +
        'transition:opacity 0.25s linear;';
    scene.appendChild(glow);
    return glow;
}
function updateTravelGalaxyGlow(rel) {
    if (!travelGalaxyGlow) return;
    // rel grand = loin (invisible) ; rel petit = plongee (plein ecran).
    const closeness = Math.max(0, Math.min(1, 1 - (rel - 1.2) / 3.2));
    travelGalaxyGlow.style.opacity = (closeness * closeness).toFixed(2);
}
function clearTravelGalaxyGlow() {
    if (travelGalaxyGlow) { travelGalaxyGlow.remove(); travelGalaxyGlow = null; }
}

// Confirmation de lancement : le gros bouton rouge est facile a cliquer
// par erreur (comme accidentellement au doigt) -- un clic ouvre la modale
// de confirmation avec la distance estimee, un SECOND clic lance vraiment.
// V5.1 : anti-dégoût du 1er lancement — tant que la Lune n'a jamais été atteinte,
// on n'autorise le lancement que si la fusée peut L'atteindre (portée >= Lune).
// Après la 1re Lune atteinte, plus aucune restriction.
function canLaunchNow() {
    if (!checkRocketReady()) return { ok: false, reason: 'incomplete' };
    if (unlockedPlanets.has('moon')) return { ok: true };
    if (calculateDistance() >= MOON_DISTANCE) return { ok: true };
    return { ok: false, reason: 'moon' };
}

function openLaunchConfirm() {
    if (!checkRocketReady()) {
        showToast(t("Fusée pas encore prête ! Il manque des pièces."));
        return;
    }
    const gate = canLaunchNow();
    if (!gate.ok && gate.reason === 'moon') {
        showToast(t("Tu pourras lancer ta fusée une fois que tu pourras atteindre la Lune car sinon tu ne gagneras pas de bonus permanents !"));
        return;
    }
    if (isLaunching) {
        showToast("⏳ " + t("Lancement en cours..."));
        return;
    }
    const distEl = document.getElementById('launch-confirm-distance');
    if (distEl) distEl.textContent = formatNumber(calculateDistance()) + ' ' + t('km');
    document.getElementById('launch-confirm-modal').classList.add('active');
}
function closeLaunchConfirm() {
    document.getElementById('launch-confirm-modal').classList.remove('active');
}
function confirmLaunchRocket() {
    closeLaunchConfirm();
    launchRocket();
}
function launchRocket() {
    // Tuto etape fusête prête : le joueur a cliqué LANCER -> valider.
    try { markLessonSeen('tutorial-launch-clicked'); } catch (e) {}
    if (!checkRocketReady()) {
        showToast(t("Fusée pas encore prête ! Il manque des pièces."));
        return;
    }
    const gate = canLaunchNow();
    if (!gate.ok && gate.reason === 'moon') {
        showToast(t("Tu pourras lancer ta fusée une fois que tu pourras atteindre la Lune car sinon tu ne gagneras pas de bonus permanents !"));
        return;
    }
    
    if (isLaunching) {
        showToast("⏳ " + t("Lancement en cours..."));
        return;
    }
    
    isLaunching = true;
    setGameplayPaused(true);
    try { window.UMI && window.UMI.track('rocket_launch', { }); } catch (e) {}
    try { playLaunchTheme(); } catch (e) {}
    launchSoundSequence();
    
    // Nouveau lancement : invalider le marqueur d'idempotence du vol
    // PRECEDENT. Sans lui, postTravelRewardsCreditedAt === lastLaunchAt
    // restait vrai au 2e lancement (aucune des deux valeurs n'etait remise
    // a zero entre les vols) et showPostTravelShop croyait que les
    // recompenses du vol avaient deja ete creditees : ni Poussiere
    // d'Etoiles, ni record de distance, ni compteur de fusees au 2e voyage.
    // L'invalidation ici preserve le cas reel du garde-fou : un F5 PENDANT
    // l'atelier recharge une sauvegarde ou les deux horodatages sont egaux
    // (credit deja fait) et ne credite pas deux fois.
    postTravelRewardsCreditedAt = 0;
    
    // Calculer la distance
    const distance = calculateDistance();
    
    playLaunchSequence(() => {
        lastLaunchDistance = distance;
        // Animation de voyage Terre -> Lune, puis carte de l'espace
        playTravelAnimation(distance, () => {
            // Fin du voyage : l'atelier galactique s'ouvre en plein ecran,
            // non fermable -- on en sort uniquement par le bouton Continuer
            // (qui applique le reset). Plus d'ecran de space map intermediaire.
            Sounds.launchFanfare();
            showLaunchReward(distance);
            // Premiere arrivee a l'Amas de Virgo : l'ecran de fin celebre
            // la completion de la route, puis l'atelier s'ouvre normalement.
            const virgo = PLANETS.find(p => p.id === 'virgo-cluster');
            if (virgo && distance >= virgo.distanceRequired && !gameFinished) {
                gameFinished = true;
                saveGame();
                showGameEnding(() => {
                    transitionToPostTravelShop(distance);
                    showToast(`${t("Fus\u00e9e lanc\u00e9e ! Distance atteinte:")} ${formatNumber(distance)} ${t("km")}`);
                });
                return;
            }
            transitionToPostTravelShop(distance);
            showToast(`${t("Fusée lancée ! Distance atteinte:")} ${formatNumber(distance)} ${t("km")}`);
        });
    });
}

// Séquence cinématique de lancement : compte à rebours avec tremblement,
// allumage des moteurs avec flammes et fumée, puis décollage accéléré
// de la fusée complète au centre du panneau. `onDone` est appelé quand la
// fusée a quitté l'écran.
function playLaunchSequence(onDone) {
    const scene = document.getElementById('construction-scene');
    const container = document.getElementById('rocket-parts-container');
    if (!scene || !container) { onDone(); return; }

    // Bloquer le clic et le recalcul d'échelle pendant la séquence
    const medal = document.getElementById('medal');
    if (medal) medal.style.pointerEvents = 'none';
    launchSequenceActive = true;

    // Gel du transform d'échelle de base pour composer proprement l'animation
    const baseTransform = container.style.transform || '';
    const baseOrigin = container.style.transformOrigin || '';

    const overlay = document.createElement('div');
    overlay.className = 'launch-overlay';
    const countdown = document.createElement('div');
    countdown.className = 'launch-countdown';
    overlay.appendChild(countdown);
    scene.appendChild(overlay);

    // Wrapper d'animation : la fusée vole dedans. Le pas de tir et l'astronaute
    // restent au sol (pièces « ground ») : ils ne décollent pas.
    const GROUND_PARTS = ['launch-pad', 'astronaut'];
    const rocketWrap = document.createElement('div');
    rocketWrap.className = 'launch-rocket-wrap';
    rocketWrap.style.transform = baseTransform;
    if (baseOrigin) rocketWrap.style.transformOrigin = baseOrigin;
    // P2 : conserver le style.transform du conteneur (echelle scene)
    // en plus du wrapper -- eviter le double scaling.
    // pendant le vol. On neutralise celui du conteneur le temps de la
    // sequence ; il est restaure dans finish().
    container.style.transform = 'none';
    const groundPieces = [];
    Array.from(container.children).forEach(child => {
        const isGround = GROUND_PARTS.some(id => child.classList && child.classList.contains(id));
        if (isGround) groundPieces.push(child);
        else rocketWrap.appendChild(child);
    });
    container.appendChild(rocketWrap);

    const finish = () => {
        overlay.remove();
        // P1 : re-inserer les pieces dans l'ordre canonique de ROCKET_PARTS
        // (l'ordre de peinture changeait selon l'historique).
        ROCKET_PARTS.forEach(part => {
            const piece = rocketWrap.querySelector('.rocket-piece.' + part.id);
            if (piece) container.appendChild(piece);
        });
        Array.from(rocketWrap.children).forEach(child => {
            if (child.classList && child.classList.contains('rocket-piece')) container.appendChild(child);
        });
        rocketWrap.remove();
        container.style.transform = baseTransform;
        const smoke = scene.querySelector('.launch-smoke');
        if (smoke) smoke.remove();
        const astronaut = container.querySelector('.rocket-piece.astronaut');
        if (astronaut) {
            astronaut.classList.remove('astronaut-jumping');
            astronaut.style.opacity = '';
        }
        if (medal) medal.style.pointerEvents = '';
        launchSequenceActive = false;
        clearTravelGalaxyGlow();
        onDone();
    };

    // Étape 1 : compte à rebours 3..2..1. Seule la fusée tremble ;
    // l'astronaute, lui, saute dans le cockpit dès le clic.
    const steps = ['3', '2', '1'];
    let stepIndex = 0;
    // P4 : prefers-reduced-motion -> pas de tremblement ni de saut.
    const reducedMotion = window.matchMedia
        && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const stepMs = reducedMotion ? 350 : 700;
    if (!reducedMotion) rocketWrap.classList.add('launch-shaking');
    const astronaut = container.querySelector('.rocket-piece.astronaut');
    if (astronaut && !reducedMotion) astronaut.classList.add('astronaut-jumping');
    countdown.textContent = steps[0];
    countdown.classList.add('pulsing');
    const stepTimer = setInterval(() => {
        stepIndex++;
        if (stepIndex < steps.length) {
            countdown.textContent = steps[stepIndex];
        } else {
            clearInterval(stepTimer);
            // Étape 2 : allumage moteurs
            countdown.textContent = t('Décollage !');
            rocketWrap.classList.remove('launch-shaking');
            igniteLaunchFlames(rocketWrap, scene);
            setTimeout(() => {
                // Étape 3 : décollage — la fusée s'envole (l'astronaute court déjà)
                countdown.classList.add('fading');
                rocketWrap.classList.add('lift-off');
                setTimeout(finish, reducedMotion ? 500 : 1900);
            }, reducedMotion ? 200 : 700);
        }
    }, stepMs);
}

// Flammes + fumée sous la fusée pendant le décollage
function igniteLaunchFlames(rocketWrap, sceneEl) {
    // Flammes dans le repere de la fusee : elles suivent le vol.
    // Positionnement calcule depuis ROCKET_PARTS (plus de valeurs CSS en
    // dur) : un jet sous chaque tuyere de booster + le jet central sous
    // les moteurs. Tolerie de proximite pour relier tuyere et jet.
    const flames = document.createElement('div');
    flames.className = 'launch-flames';
    rocketWrap.appendChild(flames);
    const nozzles = ROCKET_PARTS.filter(p => p.id === 'nozzles');
    const boosters = ROCKET_PARTS.filter(p => p.id.startsWith('boosters-'));
    const centerX = 50; // axe central de la fusee en %
    // Decalage du centre VISUEL des tuyeres dans chaque image de booster :
    // le contenu PNG n'est pas centre dans le canevas (boosters-left a du
    // remplissage transparent a droite, boosters-right a gauche).
    const BOOSTER_JET_OFFSET_PX = { 'boosters-left': -5, 'boosters-right': 4 };
    const jets = [];
    nozzles.forEach(n => jets.push({ cx: n.x, off: 0 }));
    boosters.forEach(b => jets.push({ cx: b.x, off: BOOSTER_JET_OFFSET_PX[b.id] || 0 }));
    if (jets.length === 0) {
        jets.push({ cx: centerX, off: 0 }, { cx: centerX, off: 0 }, { cx: centerX, off: 0 });
    }
    jets.forEach((j, i) => {
        const jet = document.createElement('div');
        jet.className = 'launch-flame-jet';
        jet.style.left = 'calc(' + j.cx + '% + ' + (j.off || 0) + 'px - 13px)'; // 13px = demi-largeur du jet
        jet.style.animationDelay = (i * 0.12) + 's';
        flames.appendChild(jet);
    });
    // Fumée au sol sur le pas de tir : elle ne décolle pas.
    // Ajoutée dans le monde scene-world pour suivre la meme echelle que la fusée.
    const world = document.getElementById('scene-world');
    if (world) {
        const smoke = document.createElement('div');
        smoke.className = 'launch-smoke';
        world.appendChild(smoke);
    }
}

function showLaunchResults(distance) {
    const modal = document.getElementById('launch-results-modal');
    const distanceElement = document.getElementById('launch-results-distance');
    const multiplierElement = document.getElementById('launch-results-multiplier');
    const rocketsElement = document.getElementById('launch-results-rockets');
    const destinationElement = document.getElementById('launch-results-destination');
    
    // Protéger contre NaN et undefined
    const safeDistance = isNaN(distance) || distance === undefined ? 0 : distance;
    const safeRockets = rocketsLaunched === undefined ? 0 : rocketsLaunched;
    
    distanceElement.textContent = formatNumber(safeDistance) + ' km';
    // Vrai bonus total de production, identique a la ligne "Multiplicateur de production" des statistiques.
    multiplierElement.textContent = formatBonusPct(getTotalProductionMultiplier());
    rocketsElement.textContent = safeRockets;
    // Destination la plus lointaine reellement atteinte par ce vol :
    // la fusee retombe sur la planete atteinte par sa distance parcourue.
    if (destinationElement) {
        const destProgress = calculatePlanetProgress(safeDistance);
        const destPlanet = destProgress && destProgress.currentPlanet ? destProgress.currentPlanet : null;
        destinationElement.textContent = destPlanet ? t(destPlanet.name) : t('Terre');
    }
    const stardustEl = document.getElementById('launch-results-stardust');
    if (stardustEl) {
        // Valeur REELLEMENT creditee au moment du vol (lastLaunchDustCredited)
        // -- le recalcul produisait un ecart avec le resume de l'atelier si
        // un upgrade de gain etait achete entre-temps, et inversait la
        // coherence des deux ecrans.
        stardustEl.textContent = '+' + formatNumber(lastLaunchDustCredited) + '  (total: ' + formatNumber(starDust) + ')';
    }
    
    modal.classList.add('active');
}

function closeLaunchResults() {
    document.getElementById('launch-results-modal').classList.remove('active');
}

// Bouton NOUVELLE EXPEDITION de la modale de resultats : meme action que
// la croix, formulee positivement (le reset a deja eu lieu, on lance la
// suite de la progression globale).
function startNewExpedition() {
    closeLaunchResults();
}
document.addEventListener('DOMContentLoaded', () => {
    // Mode test developpeur : restaure le panneau si le mot-cle a deja ete
    // importe sur cet appareil.
    try { if (localStorage.getItem('starcruiser-devMode') === '1') enableDevMode(); } catch (e) {}
    // V3.5 : etat du toggle d'auto-achat.
    try { autoBuyEnabled = localStorage.getItem('starcruiser-autoBuy') !== '0'; } catch (e) {}
    // Mode basse config persistant : reapplique la classe body au demarrage.
    try { applyLowConfig(); } catch (e) {}
    const btn = document.getElementById('launch-new-expedition-btn');
    if (btn) btn.addEventListener('click', startNewExpedition);
});

// ============================================
// ANIMATION DE VOYAGE (apres decollage, avant la carte de l'espace)
// Plein ecran, verticale, pensee mobile : la fusee monte de la Terre
// (bas de l'ecran) vers la Lune (haut). Le compteur de km defile de 0
// jusqu'a la distance reellement atteinte par le lancer.
// ============================================
// Troncon STANDARD : 5 s pile entre chaque passage d'objectif.
// Les troncons pesees (Nuage d'Oort x3.2, arrivee Virgo x3.5) durent
// proportionnellement plus -- la linearite du timing reste exacte.
const TRAVEL_ANIM_LEG_MS = 5000;    // duree par troncon (Terre -> Lune = 1 troncon)
let travelAnimFrame = 0;
let travelStarsData = [];

// ============================================
// MOTEUR DE PROJECTION PERSPECTIVE (voyage spatial pseudo-3D)
// Axe de voyage : vertical, la fusee vise le HAUT de l'ecran. La
// profondeur z croit vers le haut. La camera (chase cam) est legerement
// AU-DESSUS et DERRIERE la fusee : la fusee est rendue au tiers inferieur,
// les astres proches apparaissent bas et gros, les astres lointains
// remontent vers l'horizon en rapetissant (parallaxe reelle).
// Unite de profondeur : 1 = distance camera->fusee (REL_ROCKET).
// ============================================

// Construit la fusee COMPLETE dans le holder, a l'echelle cible.
function buildTravelRocketInto(holder, targetH) {
    // Fusee du voyage : image dediee (Fusee-travel.webp, 768x1376),
    // verticale et droite. Largeur deduite du ratio de l'image.
    const ROCKET_TRAVEL_IMG = 'images/rocket/Fusee-travel.webp';
    const ROCKET_TRAVEL_RATIO = 768 / 1376;
    holder.innerHTML = '';
    const h = Math.max(1, targetH);
    const w = h * ROCKET_TRAVEL_RATIO;
    holder.style.width = w + 'px';
    holder.style.height = h + 'px';
    const img = document.createElement('img');
    img.src = ROCKET_TRAVEL_IMG;
    img.alt = '';
    img.style.position = 'absolute';
    img.style.inset = '0';
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'contain';
    holder.appendChild(img);
    // Flammes des TROIS moteurs : structure dediee proportionnelle a la
    // fusee. Positions mesurees sur Fusee-travel.webp (tuyeres a 20.8%,
    // 50.3% et 79.8% de la largeur, sortie a ~86% de la hauteur). Chaque
    // jet = lueur externe + flamme principale (coeur blanc-jaune, colonne
    // orange) + base bleue + pointe fumeuse, animees independamment.
    const JETS = [
        { left: 20.8, scale: 0.9 },   // booster gauche
        { left: 50.3, scale: 1.0 },   // moteur central
        { left: 79.8, scale: 0.9 }    // booster droit
    ];
    const flames = document.createElement('div');
    flames.className = 'travel-flames';
    JETS.forEach((j, idx) => {
        const jet = document.createElement('div');
        jet.className = 'travel-jet';
        jet.style.left = j.left + '%';
        jet.style.setProperty('--jet-scale', String(j.scale));
        jet.style.setProperty('--jet-delay', (idx * 0.06) + 's');
        const glow = document.createElement('div');
        glow.className = 'travel-flame-glow';
        const core = document.createElement('div');
        core.className = 'travel-flame-core';
        const blue = document.createElement('div');
        blue.className = 'travel-flame-blue';
        const tip = document.createElement('div');
        tip.className = 'travel-flame-tip';
        core.appendChild(blue);
        core.appendChild(tip);
        jet.appendChild(glow);
        jet.appendChild(core);
        flames.appendChild(jet);
    });
    holder.appendChild(flames);
}

// Projection d'un astre (decalage lateral lat, profondeur z) sur
// l'ecran pour une camera a la profondeur cameraZ. Tous les astres
// restent proches de l'axe central (composition mobile).
function travelProject(lat, z, cameraZ, W, horizonY, pitchK, baseSize) {
    const rel = z - cameraZ;                 // profondeur relative
    if (rel <= 0.08) return { visible: false };
    const inv = 1 / rel;                     // 1 = profondeur de la fusee
    return {
        x: W / 2 + lat * 0.5 * W * inv,      // parallaxe laterale
        y: horizonY + pitchK * inv,          // proche = bas, loin = horizon
        size: baseSize * inv,                 // echelle perspective
        inv: inv,
        visible: true
    };
}

function playTravelAnimation(distance, onDone) {
    const overlay = document.getElementById('travel-overlay');
    if (!overlay || typeof distance !== 'number' || isNaN(distance)) {
        if (onDone) onDone();
        return;
    }
    travelSoundStart();
    cancelAnimationFrame(travelAnimFrame);
    const deepEl = document.getElementById('travel-deep');
    const rocketEl = document.getElementById('travel-rocket');
    const throughVeil = document.getElementById('travel-through-veil');
    if (throughVeil) throughVeil.style.opacity = '0';
    const distanceEl = document.getElementById('travel-distance-value');
    const skipBtn = document.getElementById('travel-skip');
    const safeDistance = Math.max(0, distance);

    const H = window.innerHeight || 800;
    const W = window.innerWidth || 400;

    // --- Chase cam legerement au-dessus et derriere la fusee ---
    // La fusee est le point focal : fixe au tiers inferieur, inclinee
    // dans son axe de voyage (nez vers la destination), avec un leger
    // abaissement d'arriere (vue surelevee, pas un sprite 2D plat).
    const rocketX = W * 0.5;
    // Cam plus HAUTE au-dessus de l'axe : la fusee est rendue plus bas,
    // l'horizon descend, la pente fusee->horizon s'accentue (vue plongeante
    // plus marquee sur la ligne de planetes).
    const rocketY = H * 0.70;
    const horizonY = H * 0.20;
    // pitchK : ecart vertical fusee->horizon pour un astre a la profondeur
    // de la fusee (rel=1) -> l'astre affleure la fusee.
    const pitchK = (rocketY - horizonY);
    // Facteur global d'echelle des planetes : -20% (vue un peu plus
    // reculee, comme si la camera etait plus loin de l'axe).
    const PLANET_SCALE = 0.8;
    // Adaptation mobile : sur un ecran portrait, W est petit et H grand --
    // baser la taille des planetes sur la seule largeur les rend minuscules.
    // On ancre l'echelle sur une diagonale normalisee : equivalente a W sur
    // un ecran large (desktop), proche de 73% de la hauteur en 9:16.
    const isPortrait = H > W * 1.15;
    const sizeRef = isPortrait ? Math.min(W * 1.95, H * 0.92) : W;
    const baseSize = sizeRef * 0.52 * PLANET_SCALE;
    // Fusee VERTICALE et DROITE (image dediee, aucune inclinaison).

    if (rocketEl) buildTravelRocketInto(rocketEl, H * 0.288);

    // --- Itineraire : planetes de PLANETS jusqu'a la destination atteinte
    // (structure du jeu inchangee : Terre -> Lune -> Mars -> ...).
    const reached = PLANETS.filter(p => safeDistance >= p.distanceRequired);
    const target = reached[reached.length - 1] || PLANETS[0];
    const itinerary = PLANETS.slice(0, PLANETS.indexOf(target) + 1);
    // Etapes espacees : 5 unites de profondeur par planete -> la
    // destination demarre tres loin (point minuscule a l'horizon), les
    // intermediaires demandent un vrai trajet. zMax = profondeur de la cible.
    const DEPTH_STEP = 5;
    // Fenetre de visibilite : au plus deux planetes devant la camera
    // (la suivante en micro-point a l'horizon), rien au-dela.
    const TRAVEL_LOOKAHEAD = 2 * DEPTH_STEP + 1.15;
    const zMax = (itinerary.length - 1) * DEPTH_STEP;

    // Trajet de la camera : demarre PRES de la Terre (gros bout de
    // planet en bas d'ecran, comme juste apres le decollage), accelere
    // puis maintient sa vitesse de croisiere jusqu'a la cible (aucune
    // deceleration, meme a l'arrivee).
    // GALAXIES : quand la destination est le Centre Voie lactee, Andromede
    // ou l'Amas de Virgo, la camera ne s'arrete pas devant -- elle PLONGE
    // au centre du corps (CAM_END = zMax, rel -> 0 : la galaxie grossit
    // jusqu'a remplir l'ecran, comme si on la traversait).
    const GALAXY_IDS = ['milky-way-center', 'andromeda', 'virgo-cluster'];
    // Le Centre Voie lactee est rendu par le calque PROCEDURAL : son
    // sprite est masque (il resterait une image plate au milieu de la
    // scene animee). Andromede et Virgo gardent leurs sprites.
    const isProceduralGalaxy = target.id === 'milky-way-center';
    const isGalaxyTarget = GALAXY_IDS.includes(target.id);
    // Les galaxies sont des objets IMMENSES vus de tres loin : sans
    // correction, la perspective (size = baseSize / rel) les rend meme
    // pas plus grosses qu'une planete. Facteur d'echelle dedie pour
    // qu'elles dominent l'horizon des leur apparition.
    // Galaxies DISCRETES a l'horizon : scale 3 (mysterieuses, pas de
    // grossissement moche) -- la plongee finale est portee par le glow.
    const GALAXY_SCALE = 3.0;
    const CAM_START = -0.85;                 // Terre a rel ~0.85 au depart
    const CAM_END = isGalaxyTarget ? zMax : zMax - 1.15;
    // Temps EQUIVALENT par troncon : Terre -> Lune garde sa duree, chaque
    // planete supplementaire ajoute un troncon de meme duree (Mars = deux
    // fois Terre -> Lune).
    const legs = itinerary.length - 1;
    // Traversee du Nuage d'Oort plus longue : les troncons qui y arrivent
    // et qui en repartent durent OORT_LEG_WEIGHT fois la duree standard.
    const oortLegIdx = itinerary.findIndex(p => p.id === 'oort-cloud');
    // Traversee du Nuage d'Oort encore plus longue : le poids par troncon
    // etire la duree de ces segments (poids total -> animMs).
    // Poids 2.0 : la traversEE du nuage dure 10 s (2 troncons standard),
    // le troncon SORTIE (nuage -> Proxima) redevient 5 s standard.
    const OORT_LEG_WEIGHT = 2.0;
    const legWeights = [];
    // Traversee de l'Amas de Virgo : le dernier troncon (arrivee dans
    // l'amas) dure VIRGO_LEG_WEIGHT fois la duree standard -- la
    // population galactique dense se deguste.
    const virgoLegIdx = itinerary.findIndex(p => p.id === 'virgo-cluster');
    const VIRGO_LEG_WEIGHT = 3.5;
    for (let i = 0; i < legs; i++) {
        let w = 1;
        // Seul le troncon d'ENTREE dans le nuage est pese (avant : les
        // deux troncons alentour, temps double).
        if (oortLegIdx > 0 && i === oortLegIdx - 1) w = OORT_LEG_WEIGHT;
        if (virgoLegIdx > 0 && i === virgoLegIdx - 1) w = VIRGO_LEG_WEIGHT;
        legWeights.push(w);
    }
    const totalWeight = legWeights.reduce((a, b) => a + b, 0);
    const animMs = Math.max(1, legs) * TRAVEL_ANIM_LEG_MS * (totalWeight / Math.max(1, legs));
    // progressions cumulees des poids : t (0..1) -> troncon + avancement
    const legAt = (t) => {
        let scaled = Math.max(0, Math.min(1, t)) * totalWeight;
        for (let k = 0; k < legs; k++) {
            if (scaled <= legWeights[k] || k === legs - 1) return { k, f: Math.min(1, scaled / legWeights[k]) };
            scaled -= legWeights[k];
        }
        return { k: legs - 1, f: 1 };
    };

    // Corps celestes generes dynamiquement (calque de profondeur)
    // Le Nuage d'Oort n'a PAS de sprite : il est remplace par le champ
    // volumetrique procedural (oortField) -- troncon, timing et km
    // inchanges, uniquement la representation visuelle.
    deepEl.innerHTML = '';
    // CENTRE VOIE LACTEE : retour au sprite image fixe (webp), identique
    // aux autres galaxies (Andromede, Amas de Virgo) -- la representation
    // procedurale a ete retiree sur demande.
    // Index du Nuage d'Oort dans l'itineraire (calcule AVANT bodies :
    // sert a rendre la planete suivante plus discrete en sortie de nuage).
    const oortIdx = itinerary.findIndex(p => p.id === 'oort-cloud');
    const virgoClusterIdx = itinerary.findIndex(p => p.id === 'virgo-cluster');
    // Proxima Centauri : position rapprochée de la fin du Nuage
    // d'Oort (z réduit de 2 unités) pour un enchainement plus fluide.
    const PROXIMA_Z_SHIFT = -2;
    const bodies = itinerary.map((p, i) => {
        if (p.id === 'oort-cloud') {
            return { el: null, z: i * DEPTH_STEP, lat: 0, scale: 1, hidden: true };
        }
        const el = document.createElement('div');
        el.className = 'travel-body';
        const img = document.createElement('img');
        img.src = p.imgPath;
        img.alt = '';
        el.appendChild(img);
        deepEl.appendChild(el);
        // Composition : toutes les planetes sur l'axe central, sans
        // decalage laterale (meme la Terre).
        const lat = 0;
        // La Terre un peu plus petite que l'echelle globale des planetes.
        let scale = (i === 0) ? 0.75 : 1;
        // La planete qui suit le Nuage d'Oort est plus discrete : elle
        // se reveille en tout petit seulement apres la traversee, pour
        // ne pas gacher l'immersion dans le nuage.
        const afterOort = i === oortIdx + 1;
        // Galaxies (Centre Voie lactee, Andromede, Amas de Virgo) :
        // echelle dediee pour qu'elles occupent l'ecran des leur
        // apparition a l'horizon et remplissent tout lors de la plongee.
        const isGalaxy = GALAXY_IDS.includes(p.id);
        if (isGalaxy && !(isProceduralGalaxy && p.id === 'milky-way-center')) scale = GALAXY_SCALE;
        // Seule la cible Amas de Virgo garde son sprite masque a
        // l'arrivee (plongee dans le champ de galaxies).
        const hidden = !!(target.id === 'virgo-cluster' && p.id === target.id);
        const z = (p.id === 'proxima-centauri') ? i * DEPTH_STEP + PROXIMA_Z_SHIFT : i * DEPTH_STEP;
        return { el, z, lat, scale, distant: afterOort, isGalaxy, hidden };
    });

    // Helpers aleatoires PARTAGES par le Nuage d'Oort et l'Amas de
    // Virgo (avant : definis dans le bloc Oort seulement, le champ
    // Virgo levait ReferenceError quand l'itineraire n'a pas de nuage).
    const rand = (a, b) => a + Math.random() * (b - a);
    const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

    // --- Nuage d'Oort : champ volumetrique de debris glaces ---
    // La camera traverse un VOLUME 3D d'objets : les 5 images dediees
    // de l'utilisateur (images/effects/) remplacee les modeles proceduraux.
    // Trois couches de profondeur, densite progressive (aucune apparition
    // brutale), projection et z-index identiques aux planetes. Aucune
    // logique de voyage modifiee -- uniquement la representation visuelle.
    let oortDensity = () => 0;
    const oortField = [];
    const smooth01 = (x) => { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); };
    if (oortIdx >= 0) {
        const oortZ = oortIdx * DEPTH_STEP;
        // Champ elargi et montee plus douce : les premiers cailloux
        // apparaissent PLUS TOT (des le passage de Pluton), la densite
        // monte progressivement vers le plein regime au milieu du
        // nuage, puis redescent doucement -- jamais de mur de rochers.
        // Champ confine a la region du nuage : la traversee commence
        // avant la position Oort (premiers cailloux anticipes) mais
        // s'ARRETE pile a la position du nuage -- au-dela on en ressort
        // et l'espace redevient vide.
        // Champ RESSERRE : 5 unites au lieu de 8 -- la densite par
        // unite de distance monte, les objets filent plus vite.
        const FIELD_Z0 = oortZ - 4.5;
        const FIELD_Z1 = oortZ + 0.5;
        oortDensity = (cam) => {
            if (cam <= FIELD_Z0 || cam >= FIELD_Z1) return 0;
            return Math.min(smooth01((cam - FIELD_Z0) / 3.0), smooth01((FIELD_Z1 - cam) / 1.2));
        };
        // Les 5 modeles d'objets du nuage (images dediees, tailles
        // natives heterogenes -- les tailles ecran sont fixees par couche).
        const OORT_MODELS = [
            { cls: 'oort-ice', img: 'images/effects/Small irregular icy nucleus.webp', ar: 197 / 184 },
            { cls: 'oort-comet', img: 'images/effects/Small comet nucleus.webp', ar: 182 / 165 },
            { cls: 'oort-fragment', img: 'images/effects/Ice-rock fragment.webp', ar: 218 / 244 },
            { cls: 'oort-asteroid', img: 'images/effects/Dark rocky asteroid.webp', ar: 159 / 156 },
            { cls: 'oort-large', img: 'images/effects/Large rare Oort Cloud body.webp', ar: 289 / 281 }
        ];
        const addObj = (layer, model, size, op, ox, oy, z) => {
            const el = document.createElement('div');
            el.className = 'travel-oort ' + model.cls;
            const img = document.createElement('img');
            img.src = model.img;
            img.alt = '';
            img.draggable = false;
            el.appendChild(img);
            el.style.width = '100px';
            el.style.height = (100 / model.ar).toFixed(2) + 'px';
            el.style.display = 'none';
            deepEl.appendChild(el);
            oortField.push({
                el, layer, z, ox, oy, size, op, on: false, ar: model.ar,
                gate: layer === 0 ? 0.02 : (layer === 1 ? 0.14 : 0.30),
                stag: Math.random(),
                rot: rand(0, 360),
                spin: rand(-40, 40)
            });
        };
        // Petits modeles (4) pour les couches lointaine et moyenne.
        const SMALLS = OORT_MODELS.slice(0, 4);
        // Couche 1 -- tres loin : minuscules points glaces (immensite,
        // quasi immobiles, ils habillent la profondeur).
        for (let i = 0; i < 140; i++) {
            addObj(0, pick(SMALLS),
                rand(5, 11), rand(0.25, 0.55),
                rand(-1.15, 1.15) * W, rand(-0.85, 0.85) * H,
                rand(FIELD_Z0, FIELD_Z1));
        }
        // Couche 2 -- distance moyenne : fragments et asteroides
        // visibles, tailles variees, parallaxe marquee -- repartis sur
        // TOUT l'ecran, pas seulement l'axe central.
        for (let i = 0; i < 110; i++) {
            addObj(1, pick(SMALLS),
                rand(16, 44), rand(0.5, 0.85),
                rand(-1.05, 1.05) * W, rand(-0.75, 0.75) * H,
                rand(FIELD_Z0 + 0.5, FIELD_Z1 - 0.5));
        }
        // Couche 3 -- fly-by proches : gros blocs rares qui traversent
        // vite le champ de vision, avec streak radial (motion blur).
        for (let i = 0; i < 36; i++) {
            addObj(2, pick(OORT_MODELS),
                rand(45, 110), rand(0.75, 0.95),
                (Math.random() < 0.5 ? -1 : 1) * rand(0.16, 0.46) * W,
                rand(-0.26, 0.26) * H,
                rand(FIELD_Z0 + 1.5, FIELD_Z1 - 1.5));
        }
        // Couche 4 -- AUTOUR DE LA CAMERA : gros blocs derives sur les
        // bords de l'ecran, au niveau de la camera elle-meme (rel tres
        // faible). La camera est DANS le nuage : des cailloux l'entourent,
        // passent devant la fusee et derriere elle.
        for (let i = 0; i < 24; i++) {
            addObj(2, pick(OORT_MODELS),
                rand(50, 130), rand(0.6, 0.9),
                (Math.random() < 0.5 ? -1 : 1) * rand(0.55, 1.15) * W,
                rand(-0.7, 0.7) * H,
                rand(FIELD_Z0 + 0.3, FIELD_Z1 - 0.3));
        }
    }

    // --- AMAS DE VIRGO : champ volumetrique de galaxies ---
    // Meme architecture que le Nuage d'Oort mais avec les 6 galaxies
    // de l'utilisateur : la camera traverse une POPULATION galactique
    // (pas un seul sprite) avant d'atteindre la cible. Densite
    // croissante vers la cible : on entre dans l'amas, il s'epaissit,
    // puis la plongee finale (glow) prend le relais.
    let virgoDensity = () => 0;
    const virgoField = [];
    if (virgoClusterIdx >= 0) {
        const vz = virgoClusterIdx * DEPTH_STEP;
        const VZ0 = vz - 7.5;      // premiers galaxies en approche
        const VZ1 = vz + 0.5;      // la population s'arrete a la cible
        virgoDensity = (cam) => {
            if (cam <= VZ0 || cam >= VZ1) return 0;
            return Math.min(smooth01((cam - VZ0) / 5.5), smooth01((VZ1 - cam) / 1.6));
        };
        // Les 6 galaxies de l'utilisateur (PNG, ratios varies).
        const VIRGO_MODELS = [
            { cls: 'virgo-g1', img: 'images/planets/cluster1.png', ar: 1 },
            { cls: 'virgo-g2', img: 'images/planets/cluster2.png', ar: 1 },
            { cls: 'virgo-g3', img: 'images/planets/cluster3.png', ar: 1 },
            { cls: 'virgo-g4', img: 'images/planets/cluster4.png', ar: 1 },
            { cls: 'virgo-g5', img: 'images/planets/cluster5.png', ar: 1 },
            { cls: 'virgo-g6', img: 'images/planets/cluster6.png', ar: 1 }
        ];
        const addVirgoObj = (layer, model, size, op, ox, oy, z) => {
            const el = document.createElement('div');
            el.className = 'travel-oort ' + model.cls;
            const img = document.createElement('img');
            img.src = model.img;
            img.alt = '';
            img.draggable = false;
            el.appendChild(img);
            el.style.width = '100px';
            el.style.height = '100px';
            el.style.display = 'none';
            deepEl.appendChild(el);
            virgoField.push({
                el, layer, z, ox, oy, size, op, on: false, ar: model.ar,
                gate: layer === 0 ? 0.02 : (layer === 1 ? 0.14 : 0.30),
                stag: Math.random(),
                rot: rand(0, 360),
                spin: rand(-12, 12)   // les galaxies tournent doucement
            });
        };
        // Couche 1 -- tres loin : galaxies-points, l'immensite de l'amas
        // (densifiee, tailles encore agrandies).
        for (let i = 0; i < 220; i++) {
            addVirgoObj(0, pick(VIRGO_MODELS),
                rand(7, 18), rand(0.25, 0.55),
                rand(-1.15, 1.15) * W, rand(-0.85, 0.85) * H,
                rand(VZ0, VZ1));
        }
        // Couche 2 -- distance moyenne : galaxies discibles, elles
        // habillent la profondeur de l'amas (tailles x1.4 encore).
        for (let i = 0; i < 140; i++) {
            addVirgoObj(1, pick(VIRGO_MODELS),
                rand(30, 85), rand(0.45, 0.85),
                rand(-1.05, 1.05) * W, rand(-0.75, 0.75) * H,
                rand(VZ0 + 0.5, VZ1 - 0.5));
        }
        // Couche 3 -- fly-by proches : galaxies entieres qui traversent
        // le champ, enormes a cette echelle (tailles x1.4 encore).
        for (let i = 0; i < 55; i++) {
            addVirgoObj(2, pick(VIRGO_MODELS),
                rand(70, 200), rand(0.6, 0.92),
                (Math.random() < 0.5 ? -1 : 1) * rand(0.16, 0.46) * W,
                rand(-0.26, 0.26) * H,
                rand(VZ0 + 1.5, VZ1 - 1.5));
        }
        // Couche 4 -- autour de la camera : galaxies geantes derivees
        // sur les bords, la camera est AU COEUR de l'amas (tailles x1.4).
        for (let i = 0; i < 36; i++) {
            addVirgoObj(2, pick(VIRGO_MODELS),
                rand(75, 220), rand(0.5, 0.88),
                (Math.random() < 0.5 ? -1 : 1) * rand(0.55, 1.15) * W,
                rand(-0.7, 0.7) * H,
                rand(VZ0 + 0.3, VZ1 - 0.3));
        }
    }

    // --- Couche vitesse : trainees de vitesse radiales 3D ---
    // Chaque trainee vit dans le volume devant la camera (comme les
    // etoiles et le nuage d'Oort) : elle coule depuis le point de fuite
    // vers les bords de l'ecran, alignee sur l'axe camera -> trainee,
    // et s'allonge avec la vitesse et la proximite.
    const streaksEl = document.createElement('div');
    streaksEl.className = 'travel-streaks';
    const oldStreaks = overlay.querySelectorAll('.travel-streaks');
    for (let i = 0; i < oldStreaks.length; i++) oldStreaks[i].remove();
    overlay.appendChild(streaksEl);
    const streaks = [];
    const streakCount = 120;
    for (let i = 0; i < streakCount; i++) {
        const s = document.createElement('div');
        s.className = 'travel-streak';
        s.style.opacity = '0';
        streaksEl.appendChild(s);
        streaks.push({
            el: s,
            ox: (Math.random() * 2 - 1) * 1.6,
            oy: (Math.random() * 2 - 1) * 1.25,
            rel: 0.3 + Math.random() * 3.2,
            depth: 0.35 + Math.random() * 0.75
        });
    }

    const startTime = performance.now();
    let lastNow = startTime;
    let finished = false;

    const cleanup = () => {
        cancelAnimationFrame(travelAnimFrame);
        overlay.classList.remove('active');
        if (throughVeil) throughVeil.style.opacity = '0';
        if (skipBtn) skipBtn.removeEventListener('click', skipHandler);
        // P5 : purge des calques volumineux du voyage -- des centaines de
        // noeuds morts (nuage d'Oort ~250) s'accumulaient sinon.
        // s'accumulaient sur une session multi-lancements.
        const streaks = overlay.querySelectorAll('.travel-streaks');
        for (let i = 0; i < streaks.length; i++) streaks[i].remove();
        if (deepEl) deepEl.innerHTML = '';
        if (finished) {
            if (onDone) onDone();
        }
    };
    const skipHandler = () => finish();

    function finish() {
        if (finished) return;
        finished = true;
        travelSoundStop();
        if (distanceEl) rollCounterText(distanceEl, formatNumber(safeDistance));
        setTimeout(cleanup, 240);
    }

    const lerp = (a, b, t) => a + (b - a) * t;
    const easeInOut = (x) => (x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2);
    // Profil de vitesse : ACCELERATION CONSTANTE du depart a la cible.
    // Vitesse calibree sur la route GLOBALE Terre -> Virgo : la vitesse
    // finale d'un voyage depend de sa position sur la route complete
    // (Lune = lente, Virgo = vitesse MAX). Chaque nouveau record va donc
    // plus vite que le precedent -- la vitesse max n'est atteinte QUE
    // lors de l'arrivee a Virgo.
    const totalLegs = PLANETS.length - 1; // Terre -> Virgo (route complete)
    // Multiplicateur de vitesse du fond : LINEAIRE sur la position absolue
    // de la fusee sur la route Terre -> Virgo (pas sur le voyage en cours).
    // Passer Mars dans un voyage long montre exactement les memes effets
    // que l'arrivee a Mars d'un voyage court : coherent partout.
    // Plafond volontairement INSENSE : la vitesse finale (Virgo) est
    // abstraitement enorme -- le fond doit donner l'impression d'un
    // trou de ver, quitte a defier la realite. Reste lineaire et ancre
    // a la position absolue : Terre = 1, Virgo = 8.
    // Vitesse visuelle UNIFORME sur tout le voyage : chaque troncon a la
    // meme vitesse de defilement -> avec 5 s par objectif, le rythme est
    // parfaitement lineaire du depart a l'arrivee.
    const VIRGO_SPEED_MAX = 1;
    // Vitesse camera CONSTANTE PAR TRONCON : chaque troncon dure
    // exactement TRAVEL_ANIM_LEG_MS (5s), de l'echapement de la planete
    // au passage de la suivante. La fusee croise chaque planete pile a
    // la frontiere 5s/5s -- la sensation d'acceleration vient du fond,
    // du compteur km (distances reelles croissantes) et des trainees.
    const camAt = (t) => {
        if (legs <= 0) return CAM_START;
        const { k, f } = legAt(t);
        // Le premier troncon part de CAM_START (derriere la Terre, bien
        // visible au depart) ; les suivants de la planete k a la k+1.
        const from = (k === 0) ? CAM_START : k * DEPTH_STEP;
        const to = (k === legs - 1) ? CAM_END : (k + 1) * DEPTH_STEP;
        return lerp(from, to, f);
    };
    // Position absolue normalisee sur la route COMPLETE (0 Terre, 1 Virgo) :
    // troncons deja franchis + avancement dans le troncon courant.
    const posAt = (t) => {
        if (legs <= 0) return 0;
        const { k, f } = legAt(t);
        return Math.min(1, (k + f) / totalLegs);
    };
    // Compteur km : interpolation REELLE entre planetes. Quand la camera
    // croise la Lune, le compteur lit exactement 384 400 km, quel que soit
    // le voyage ; la vitesse en km/s s'adapte donc a chaque troncon. Le
    // troncon final se termine sur la distance reellement atteinte.
    const kmAt = (cam) => {
        if (cam <= CAM_START) return 0;
        const last = itinerary.length - 1;
        const bounds = [];
        for (let i = 1; i <= last - 1; i++) bounds.push(i * DEPTH_STEP);
        bounds.push(CAM_END);
        for (let i = 0; i < bounds.length; i++) {
            // Le premier troncon part de CAM_START : le compteur monte
            // des la premiere image, fini le 0 km fige alors qu'on avance.
            const z0 = (i === 0) ? CAM_START : bounds[i - 1];
            const z1 = bounds[i];
            if (cam < z1 || i === bounds.length - 1) {
                const d0 = itinerary[i].distanceRequired;
                const d1 = (i === last - 1) ? safeDistance : itinerary[i + 1].distanceRequired;
                const f = Math.max(0, Math.min(1, (cam - z0) / (z1 - z0)));
                return d0 + (d1 - d0) * f;
            }
        }
        return itinerary[last].distanceRequired;
    };

    const tick = (now) => {
        if (finished) return;
        const linear = Math.min(1, (now - startTime) / animMs);
        const cameraZ = camAt(linear);
        // Vitesse visuelle du fond : LINEAIRE, ancree a la position absolue
        // sur la route (troncon courant + avancement dedans). Quasi
        // immobile pres de la Terre, plein regime uniquement a Virgo --
        // et identique a toute passe precedente, quel que soit le voyage.
        const dt = Math.min(0.05, (now - lastNow) / 1000);
        lastNow = now;
        const posNow = Math.min(1, posAt(linear));
        const speedNorm = posNow;                      // 0 Terre -> 1 Virgo
        const speed = 1 + speedNorm * (VIRGO_SPEED_MAX - 1);

        // ---- Fusee : point focal ----
        // Leger balancement organique : derive latérale douce + avance/
        // recul dans l'axe de voyage (fleche verticale + tres legere
        // variation d'echelle pour la profondeur). Fusée toujours
        // verticale et droite, aucun tangage -- juste assez de vie pour
        // que la scene ne soit pas statique.
        if (rocketEl) {
            const ph = (now - startTime) / 1000;
            const swayX = Math.sin(ph * 0.9 + 0.4) * 28 + Math.sin(ph * 1.7) * 12;
            const swayY = Math.sin(ph * 0.6) * 20;
            const breathe = 1 + Math.sin(ph * 0.6 + 1.2) * 0.024;
            rocketEl.style.transform = 'translate3d(' + (rocketX + swayX).toFixed(1) + 'px, ' + (rocketY + swayY).toFixed(1) + 'px, 0) translate(-50%, -50%) scale(' + breathe.toFixed(4) + ')';
        }

        // ---- Compteur de km : distances reelles, synchronisees au
        // passage effectif de chaque planete ----
        if (distanceEl) rollCounterText(distanceEl, formatNumber(Math.floor(legs > 0 ? kmAt(cameraZ) : safeDistance * easeInOut(linear))));

        // ---- Fond en parallaxe RADIALE 3D : chaque etoile vit dans le
        // volume devant la camera. Elle s'approche a une vitesse
        // proportionnelle a la vitesse reelle (les proches filent plus
        // vite que les lointaines) et coule depuis le point de fuite
        // (horizon) vers les bords -- coherent avec la vue chase-cam
        // et la projection des planetes / du nuage d'Oort.
        travelStarsData.forEach(st => {
            st.rel -= speed * st.depth * 0.7 * dt;
            if (st.rel < 0.12) {
                // Recyclage : l'etoile a depasse la camera, on la renvoie
                // au fond du volume avec un nouvel angle.
                st.rel = 2.6 + Math.random() * 0.9;
                st.ox = (Math.random() * 2 - 1) * 1.6;
                st.oy = (Math.random() * 2 - 1) * 1.25;
            }
            const inv = 1 / st.rel;
            const x = W / 2 + st.ox * 0.5 * W * inv;
            const y = horizonY + pitchK * inv + st.oy * H * 0.85 * inv;
            // Grossit en s'approche : scale sur une base 1px, compositE GPU.
            const sz = Math.min(5, st.size * (0.6 + inv * 0.55));
            st.el.style.transform = 'translate3d(' + x.toFixed(1) + 'px, ' + y.toFixed(1) + 'px, 0) translate(-50%, -50%) scale(' + sz.toFixed(2) + ')';
            // Sorties d'ecran masquees (l'etoile reapparaitra au recyclage).
            if (x < -6 || x > W + 6 || y < -6 || y > H + 6) {
                st.el.style.opacity = '0';
            } else {
                st.el.style.opacity = '';
            }
        });
        // ---- Trainees de vitesse RADIALES : chaque trainee vit dans le
        // volume devant la camera. Elle coule depuis le point de fuite,
        // alignee sur son propre axe camera -> trainee, et s'allonge
        // avec la vitesse et la proximite -- meme physique que les
        // etoiles et le nuage d'Oort.
        streaks.forEach(s => {
            s.rel -= speed * s.depth * 0.8 * dt;
            if (s.rel < 0.15) {
                s.rel = 2.6 + Math.random() * 0.9;
                s.ox = (Math.random() * 2 - 1) * 1.6;
                s.oy = (Math.random() * 2 - 1) * 1.25;
            }
            const inv = 1 / s.rel;
            const x = W / 2 + s.ox * 0.5 * W * inv;
            const y = horizonY + pitchK * inv + s.oy * H * 0.85 * inv;
            // Direction du flot au point projete : vecteur point de
            // fuite -> trainee, normalise.
            const dx = x - W / 2;
            const dy = y - horizonY;
            const len = Math.max(1, Math.hypot(dx, dy));
            const ang = Math.atan2(dy, dx) * 180 / Math.PI + 90;
            // V3.43 (retour joueur) : la longueur de DEPART etait trop
            // grande (46 px des le lancement) -- base divisee par 5 (9 px),
            // la croissance jusqu'a Virgo est PRESERVEE (meme maximum 240 px
            // a speedNorm=1) : les trainees demarrent courtes et s'allongent
            // avec la VITESSE REELLE, pas avec la duree du voyage.
            const streakLen = (9 + speedNorm * 231) * (0.35 + inv * 0.5);
            // V3.43 : FENETRE CENTRALE masquee -- pres du point de fuite
            // (horizon), toutes les trainees convergent au meme endroit :
            // la densite y etait bizarre ('ca fait trop bizarre au point
            // centrale de convergence, plus sur les cotes'). On eteint
            // progressivement les trainees dans un rayon central (fondu
            // smoothstep sur 18% de la largeur) : le centre reste degage,
            // les bords gardent le plein effet de vitesse.
            const centerDist = Math.hypot(x - W / 2, (y - horizonY) * (W / H));
            const centerFade = Math.min(1, Math.max(0, (centerDist / (W * 0.18) - 0.35) / 0.65));
            s.el.style.transform = 'translate3d(' + x.toFixed(1) + 'px, ' + y.toFixed(1) + 'px, 0) translate(-50%, -50%) rotate(' + ang.toFixed(1) + 'deg) scaleY(' + streakLen.toFixed(1) + ')';
            // V3.30 : opacite PLANCHER 62% -- visible partout, croissante.
            const op = Math.min(1, 0.62 + 0.38 * speedNorm) * (0.3 + s.depth * 0.7) * Math.min(1, inv * 0.9);
            if (x < -20 || x > W + 20 || y < -20 || y > H + 20) {
                s.el.style.opacity = '0';
            } else {
                s.el.style.opacity = (op * centerFade).toFixed(2);
            }
        });

        // ---- Astres : projection perspective + fondu de depassement ----
        bodies.forEach(b => {
            if (b.hidden) {
                if (b.el) b.el.style.display = 'none';
                return;
            }
            // Fenetre de visibilite : on ne montre pas toute la ligne de
            // planetes, seulement les deux prochaines (la 2e en micro-point).
            // La planete qui suit le Nuage d'Oort apparait PLUS TARD et
            // PLUS PETITE (fenetre resserree).
            // TOUTES les planetes apparaissent en DOUCEUR : meme fondu
            // d'entree que Proxima (smoothstep sur l'opacite des
            // premieres unites de profondeur apres l'entree en fenetre),
            // puis croissance perspective purement monotone.
            // Proxima post-Oort : fenetre resserree -- elle n'apparait
            // qu'a la fin du Nuage d'Oort (mystere preserve), mais se
            // rapproche ensuite NORMALEMENT, taille pleine.
            const lookahead = b.distant ? 9 : TRAVEL_LOOKAHEAD;
            if (b.z - cameraZ > lookahead) {
                b.el.style.display = 'none';
                return;
            }
            b.el.style.display = '';
            const pr = travelProject(b.lat, b.z, cameraZ, W, horizonY, pitchK, baseSize);
            if (!pr.visible) {
                b.el.style.opacity = '0';
                return;
            }
            // Entree en douceur generalisee : fondu d'opacite au moment
            // ou la planete entre dans sa fenetre de visibilite, taille
            // de depart reduite pour la planete post-Oort.
            const rel = b.z - cameraZ;
            const fadeIn = Math.max(0, Math.min(1, (lookahead - rel) / 2.5));
            b.el.style.opacity = (fadeIn * fadeIn * (3 - 2 * fadeIn)).toFixed(2);
            // Perspective par scale compositE : la planete a une largeur de
            // base 100px posee une fois, on ne fait plus que la scaler.
            const px = Math.max(0.02, pr.size * (b.scale || 1) / 300);
            b.el.style.transform = 'translate3d(' + pr.x.toFixed(1) + 'px, ' + pr.y.toFixed(1) + 'px, 0) translate(-50%, -50%) scale(' + px.toFixed(3) + ')';
            // PLONGEE CINEMATIQUE (galaxies) : un glow radial croissant
            // enveloppe l'ecran quand la camera s'approche -- on TRAVERSE
            // la galaxie dans un voile de lumiere au lieu de regarder une
            // image s'etirer. Le glow est cree une fois, anime ici.
            if (b.isGalaxy) {
                if (!travelGalaxyGlow) travelGalaxyGlow = createTravelGalaxyGlow(b.el);
                updateTravelGalaxyGlow(rel);
            }
            // Ordre de peinture par profondeur : plus un astre est proche,
            // plus il est peint au-dessus (z eleve). Les astres passes
            // derriere la camera gardent leur ordre naturel.
            b.el.style.zIndex = String(Math.max(1, Math.round(pr.inv * 10) + 1));
            // A la sortie : l'astre depasse la camera en grossissant et
            // sort naturellement de l'ecran par le bas, plein echelle.
        });

        // ---- Plongee galactique : voile lumineux de traversée ----
        // Quand la destination est une galaxie, la camera finit DANS le
        // corps : au-dela du demi-tour de perspective (rel < 1.6), un
        // voile teinte aux couleurs de la galaxie monte en opacite et
        // enveloppe l'ecran -- immersion de traverse, pas un flash brut.
        if (throughVeil && isGalaxyTarget) {
            const relT = zMax - cameraZ;
            const veilOp = relT <= 0.08 ? 1 : Math.max(0, Math.min(1, (1.6 - relT) / 1.35));
            throughVeil.style.opacity = (veilOp * 0.92).toFixed(2);
        }

        // ---- Nuage d'Oort : traverssee volumetrique ----
        // Densite progressive : vide -> premiers objets -> immersion.
        // Chaque objet n'apparait que si la densite locale depasse son
        // seuil (reparti par couche + alea de staging) -> montee douce,
        // jamais un mur de rochers d'un coup.
        if (virgoField.length > 0) {
            const vDensity = virgoDensity(cameraZ);
            virgoField.forEach(o => {
                const rel = o.z - cameraZ;
                if (vDensity <= 0 || rel <= 0.05 || rel > TRAVEL_LOOKAHEAD * 1.6) {
                    if (o.on) { o.el.style.display = 'none'; o.on = false; }
                    return;
                }
                const local = Math.max(0, Math.min(1, (vDensity - o.gate * 0.55) / (1 - o.gate * 0.55)));
                const appear = smooth01(local - o.stag * 0.85);
                if (appear <= 0.01) {
                    if (o.on) { o.el.style.display = 'none'; o.on = false; }
                    return;
                }
                const inv = 1 / Math.max(0.12, rel);
                const sx = W / 2 + o.ox * inv;
                const sy = horizonY + pitchK * inv + o.oy * inv;
                const size = Math.max(1.5, o.size * inv);
                const op = o.op * appear * Math.min(1, rel * 2.2);
                if (!o.on) { o.el.style.display = ''; o.on = true; }
                o.el.style.opacity = op.toFixed(2);
                // Les galaxies tournent DOUCEMENT (spin reduit), pas comme
                // les cailloux du nuage : ce sont des objets massifs lointains.
                o.el.style.transform = 'translate3d(' + sx.toFixed(1) + 'px, ' + sy.toFixed(1) + 'px, 0) translate(-50%, -50%) rotate(' + (o.rot + o.spin * (o.layer === 2 ? 0.8 : 0.2)) + 'deg) scale(' + (size / 100).toFixed(3) + ')';
                o.el.style.zIndex = String(Math.min(30, Math.round(inv * 10) + 1));
            });
        }
        if (oortField.length > 0) {
            const density = oortDensity(cameraZ);
            oortField.forEach(o => {
                const rel = o.z - cameraZ;
                // Un objet depasse par la camera (rel <= 0) n'est PLUS
                // rendu : le rendu miroir le faisait retr ecir apres le
                // passage, comme s'il filait dans le meme sens que la
                // fusee. Il grossit, croise la camera, disparait --
                // exactement comme les planetes.
                if (density <= 0 || rel <= 0.05 || rel > TRAVEL_LOOKAHEAD * 1.6) {
                    if (o.on) { o.el.style.display = 'none'; o.on = false; }
                    return;
                }
                const local = Math.max(0, Math.min(1, (density - o.gate * 0.55) / (1 - o.gate * 0.55)));
                const appear = smooth01(local - o.stag * 0.85);
                if (appear <= 0.01) {
                    if (o.on) { o.el.style.display = 'none'; o.on = false; }
                    return;
                }
                const inv = 1 / Math.max(0.12, rel);
                const sx = W / 2 + o.ox * inv;
                const sy = horizonY + pitchK * inv + o.oy * inv;
                const size = Math.max(1.5, o.size * inv);
                const op = o.op * appear * Math.min(1, rel * 2.2);
                if (!o.on) { o.el.style.display = ''; o.on = true; }
                o.el.style.opacity = op.toFixed(2);
                o.el.style.transform = 'translate3d(' + sx.toFixed(1) + 'px, ' + sy.toFixed(1) + 'px, 0) translate(-50%, -50%) rotate(' + (o.rot + o.spin * (o.layer === 2 ? 2.2 : 0.5)) + 'deg) scale(' + (size / 100).toFixed(3) + ')';
                // Ordre de peinture identique aux planetes : plus c'est
                // proche, plus c'est peint au-dessus. Les fly-by proches
                // passent devant la fusee (z-index 12+).
                // Ordre de peinture identique aux planetes : plus c'est
                // proche, plus c'est peint au-dessus.
                o.el.style.zIndex = String(Math.min(30, Math.round(inv * 10) + 1));
                // Streak de motion blur sur les objets proches : le halo
                // s'allonge avec la proximite (sensation de vitesse).
                if (o.layer === 2) {
                    o.el.style.setProperty('--streak', Math.min(1, (inv - 1) / 1.6).toFixed(2));
                }
            });
        }

        if (linear >= 1) {
            finish();
            return;
        }
        travelAnimFrame = requestAnimationFrame(tick);
    };

    // Initialisation
    if (rocketEl) {
        rocketEl.style.left = '0px';
        rocketEl.style.top = '0px';
        rocketEl.style.transform = 'translate3d(' + rocketX + 'px, ' + rocketY + 'px, 0) translate(-50%, -50%)';
    }
    if (distanceEl) rollCounterText(distanceEl, '0');
    fillTravelStars(overlay);
    overlay.classList.add('active');
    if (skipBtn) skipBtn.addEventListener('click', skipHandler);
    travelAnimFrame = requestAnimationFrame(tick);
}

function fillTravelStars(overlay) {
    // Etoiles reconstruites a chaque voyage : positions pilotees en JS
    // (parallaxe selon la profondeur propre a chaque etoile).
    const deepFieldEl = overlay.querySelector('.travel-deepfield');
    if (deepFieldEl) {
        // Fond lointain riche : 2 halos de nebuleuse + poussiere d'etoiles
        // statique + micro-etoiles scintillantes, toutes en CSS pur (aucune
        // image chargee) -- la profondeur lointaine que le voyage manquait.
        deepFieldEl.innerHTML = '';
        const nebA = document.createElement('div');
        nebA.className = 'travel-nebula';
        nebA.style.left = (Math.random() * 50 + 8) + '%';
        nebA.style.top = (Math.random() * 35 + 5) + '%';
        deepFieldEl.appendChild(nebA);
        const nebB = document.createElement('div');
        nebB.className = 'travel-nebula nebula-b';
        nebB.style.left = (Math.random() * 40 + 45) + '%';
        nebB.style.top = (Math.random() * 40 + 40) + '%';
        deepFieldEl.appendChild(nebB);
        const dustCount = 90;
        for (let i = 0; i < dustCount; i++) {
            const d = document.createElement('div');
            d.className = 'travel-dust';
            d.style.left = (Math.random() * 100) + '%';
            d.style.top = (Math.random() * 100) + '%';
            d.style.width = (Math.random() * 1.6 + 0.6) + 'px';
            d.style.height = d.style.width;
            d.style.animationDelay = (Math.random() * 2.4) + 's';
            deepFieldEl.appendChild(d);
        }
    }
    const starsEl = overlay.querySelector('.travel-stars');
    if (!starsEl) return;
    starsEl.innerHTML = '';
    travelStarsData = [];
    const count = 320;
    for (let i = 0; i < count; i++) {
        const star = document.createElement('div');
        star.className = 'travel-star';
        if (Math.random() < 0.5) star.classList.add('twinkle');
        const size = Math.random() * 2.2 + 1;
        star.style.width = '1px';
        star.style.height = '1px';
        star.style.animationDelay = (Math.random() * 1.6) + 's';
        starsEl.appendChild(star);
        // Champ 3D radial : chaque etoile vit dans le volume devant la
        // camera (decalage ox/oy + profondeur rel). Projettee depuis le
        // point de fuite (horizon) comme les planetes et le nuage d'Oort,
        // elle coule vers la camera -- coherent avec la chase-cam.
        travelStarsData.push({
            el: star,
            ox: (Math.random() * 2 - 1) * 1.6,
            oy: (Math.random() * 2 - 1) * 1.25,
            rel: 0.25 + Math.random() * 3.25,
            depth: 0.35 + Math.random() * 0.75,
            size: size
        });
    }
}

// ============================================
// SPACE MAP FUNCTIONS
// ============================================

function calculatePlanetProgress(distance) {
    // Trouver quelle planète on atteint et le pourcentage entre les planètes
    let currentPlanetIndex = -1;
    let nextPlanetIndex = -1;
    let progressPercent = 0;

    for (let i = PLANETS.length - 1; i >= 0; i--) {
        if (distance >= PLANETS[i].distanceRequired) {
            currentPlanetIndex = i;
            break;
        }
    }

    // Earth (index 0) est le point de départ, pas un objectif.
    // On la traite comme si on n'avait pas encore atteint de planète.
    if (currentPlanetIndex <= 0) {
        return {
            currentPlanet: null,
            nextPlanet: PLANETS[1],
            progressPercent: (distance / PLANETS[1].distanceRequired) * 100
        };
    }

    if (currentPlanetIndex === PLANETS.length - 1) {
        // Amas de la Vierge atteint (max)
        return {
            currentPlanet: PLANETS[currentPlanetIndex],
            nextPlanet: null,
            progressPercent: 100
        };
    }

    // Calculer le progrès vers la prochaine planète
    const currentPlanet = PLANETS[currentPlanetIndex];
    const nextPlanet = PLANETS[currentPlanetIndex + 1];
    const distanceBetween = nextPlanet.distanceRequired - currentPlanet.distanceRequired;
    const distanceFromCurrent = distance - currentPlanet.distanceRequired;
    progressPercent = (distanceFromCurrent / distanceBetween) * 100;

    return {
        currentPlanet: currentPlanet,
        nextPlanet: nextPlanet,
        progressPercent: progressPercent
    };
}

function getNextTwoPlanets(distance) {
    // Retourne uniquement les 2 prochaines planètes à atteindre
    const progress = calculatePlanetProgress(distance);
    const currentIndex = progress.currentPlanet ? PLANETS.findIndex(p => p.id === progress.currentPlanet.id) : -1;
    
    let nextPlanets = [];
    
    if (currentIndex === -1) {
        // Pas encore atteint la Lune, afficher Lune et Mars
        nextPlanets = [PLANETS[1], PLANETS[2]];
    } else if (currentIndex >= PLANETS.length - 2) {
        // A atteint ou dépassé l'avant-dernière planète
        nextPlanets = [PLANETS[PLANETS.length - 2], PLANETS[PLANETS.length - 1]];
    } else {
        // Afficher la planète actuelle et la prochaine
        nextPlanets = [PLANETS[currentIndex], PLANETS[currentIndex + 1]];
    }
    
    return nextPlanets;
}

function checkNewPlanetsUnlocked(distance) {
    const newlyUnlocked = [];
    
    PLANETS.forEach(planet => {
        if (planet.id === 'earth') return;
        if (distance >= planet.distanceRequired && !unlockedPlanets.has(planet.id)) {
            newlyUnlocked.push(planet);
        }
    });
    
    return newlyUnlocked;
}

// V3.3 : JALONS DE PLANETES SUPPRIMES -- retour playtest, le bonus one-time
// etait deroutant. Tout l'atelier est desormais finance par la formule
// racine cubique seule (les couts de l'arbre de base ont ete recalibres
// entre 1 et 50 PE : arbre complet ~800 PE, atteignable avant Virgo).
// NARRATIF DES DECOUVERTES (V3.4) : chaque premiere planete atteinte
// raconte SA decouverte -- rend les bonus concrets et memorables. Cles i18n.
const PLANET_DISCOVERY_LORE = {
    'moon': "Sur la Lune, vous trouvez un parchemin d'ingénieurs lunaires : leurs astuces de fabrication boostent votre production !",
    'mars': "Sur Mars, un minier martien vous offre un matériau révolutionnaire : vos machines tournent plus vite !",
    'neptune': "Dans les vents de Neptune, vos sondes captent une source d'énergie inconnue : production renforcée !",
    'pluto': "Sur Pluton, des cristaux antédiluviens amplifient vos chaînes de production !",
    'oort-cloud': "Dans le Nuage d'Oort, une comète porteuse de poussière d'étoile accélère vos usines !",
    'proxima-centauri': "Autour de Proxima, une civilisation disparue a laissé des plans de construction parfaits !",
    'sirius': "La lumière de Sirius recharge vos raffineries d'une énergie stellaire pure !",
    'milky-way-center': "Au cœur de la Voie lactée, la matière première est abondante : production renforcée !",
    'andromeda': "Andromède partage ses secrets intergalactiques : vos machines dépassent l'impossible !",
    'virgo-cluster': "L'Amas de Virgo couronne votre voyage : l'énergie de mille galaxies alimente vos usines !"
};

function applyNewPlanets(newlyUnlocked) {
    newlyUnlocked.forEach(planet => {
        unlockedPlanets.add(planet.id);
        planetBonuses[planet.id] = (wasmCore() ? (wasmCore().planet_bonus_percent ? wasmCore().planet_bonus_percent(PLANETS.indexOf(planet)) : planet.bonusPercent) : planet.bonusPercent) / 100;
        invalidateBuildingGainsCache();
    });
}

function getTotalPlanetBonus() {
    let total = 0;
    Object.values(planetBonuses).forEach(bonus => {
        total += bonus;
    });
    return total;
}

// Fin de voyage : ouvre l'atelier galactique en PLEIN ECRAN, non fermable.
// Le joueur y depense sa Poussiere d'Etoiles, puis clique sur Continuer
// pour appliquer le reset et reprendre la partie. Le bouton de la sidebar
// ouvre la meme modal en consultation (fermable librement).
let postTravelLock = false;
// P8 : idempotence du credit des recompenses post-voyage + reouverture de
// l'atelier apres un rechargement pendant la modale (le reset doit etre
// confirme, il ne peut pas etre saute par un F5).
let postTravelRewardsCreditedAt = 0;
// V3.71 : PE de suite infinie avant le vol en cours -- sert a afficher le
// gain DU vol dans la case PE de l'atelier (et non le cumul complet).
let postVirgoStardustBeforeFlight = 0;
// Bonus de production permanent gagnee lors du DERNIER vol (en %) :
// suite infinie du vol + doublages de record du vol + nouvelles planetes
// du vol. Persiste dans la save : un rechargement pendant l'atelier
// conserve l'affichage du gain du vol.
let lastLaunchPermanentBonusPct = 0;
// Poussiere reellement creditee pour le dernier vol : le resume de
// l'atelier et la modale de resultats REUTILISENT cette valeur au lieu
// de recalculer calculateStardustGain() -- le recalcul apres achat
// d'upgrades ou a un autre moment produisait des ecarts affiches
// (le joueur voyait un gain different de celui credite).
let lastLaunchDustCredited = 0;
let atelierAfterTravel = false;

// Ecran de fin : premiere arrivee a l'Amas de Virgo. La route complete
// Terre -> Virgo est terminee : on celebre la completion, on annonce la
// suite infinie (+1% production par Poussiere d'Etoiles), puis on rend la
// main via onDone (ouverture de l'atelier galactique).
function showGameEnding(onDone) {
    const overlay = document.getElementById('game-ending-overlay');
    if (!overlay) { if (onDone) onDone(); return; }
    const distEl = document.getElementById('game-ending-distance');
    if (distEl && typeof lastLaunchDistance === 'number') distEl.textContent = formatNumber(lastLaunchDistance);
    try { Sounds.launchFanfare(); } catch (e) {}
    try { spawnEndingFireworks(); } catch (e) {}
    overlay.classList.add('active');
    const btn = document.getElementById('game-ending-continue');
    const handler = () => {
        btn.removeEventListener('click', handler);
        overlay.classList.remove('active');
        if (onDone) onDone();
    };
    if (btn) btn.addEventListener('click', handler);
}

// Petites etoiles filantes / eclats decoratifs derriere l'ecran de fin.
// V3.43 : ecran de fin ULTIME -- le joueur a debloque TOUS les trophees.
// Modale plein ecran, champ d'etoiles scintillantes (points + grandes
// etoiles a 5 branches en clip-path), couronne flottante, titre dore.
// Affichee UNE SEULE fois par sauvegarde (trophiesEndingShown persiste).
let trophiesEndingShown = false;
function showTrophiesEnding() {
    const overlay = document.getElementById('trophies-ending-overlay');
    if (!overlay) return;
    const starsEl = document.getElementById('trophies-ending-stars');
    if (starsEl) {
        starsEl.innerHTML = '';
        // 90 petits points scintillants + 12 grandes etoiles a 5 branches
        for (let i = 0; i < 90; i++) {
            const st = document.createElement('div');
            st.className = 'trophies-star';
            const sz = 1.5 + Math.random() * 2.5;
            st.style.width = sz + 'px';
            st.style.height = sz + 'px';
            st.style.left = (Math.random() * 100) + '%';
            st.style.top = (Math.random() * 100) + '%';
            st.style.setProperty('--ts-dur', (1.2 + Math.random() * 2.2).toFixed(2) + 's');
            st.style.setProperty('--ts-delay', (Math.random() * 2.5).toFixed(2) + 's');
            st.style.setProperty('--ts-drift-dur', (4 + Math.random() * 5).toFixed(2) + 's');
            st.style.setProperty('--ts-dx', ((Math.random() - 0.5) * 30).toFixed(1) + 'px');
            st.style.setProperty('--ts-dy', ((Math.random() - 0.5) * 30).toFixed(1) + 'px');
            starsEl.appendChild(st);
        }
        for (let i = 0; i < 12; i++) {
            const st = document.createElement('div');
            st.className = 'trophies-star trophies-star-big';
            const sz = 18 + Math.random() * 26;
            st.style.width = sz + 'px';
            st.style.height = sz + 'px';
            st.style.left = (4 + Math.random() * 92) + '%';
            st.style.top = (4 + Math.random() * 92) + '%';
            st.style.setProperty('--ts-dur', (1.8 + Math.random() * 2.4).toFixed(2) + 's');
            st.style.setProperty('--ts-delay', (Math.random() * 2.5).toFixed(2) + 's');
            st.style.setProperty('--ts-drift-dur', (5 + Math.random() * 6).toFixed(2) + 's');
            st.style.setProperty('--ts-dx', ((Math.random() - 0.5) * 44).toFixed(1) + 'px');
            st.style.setProperty('--ts-dy', ((Math.random() - 0.5) * 44).toFixed(1) + 'px');
            starsEl.appendChild(st);
        }
    }
    const numEl = document.getElementById('trophies-ending-count-num');
    if (numEl) numEl.textContent = String(unlockedTrophies.size);
    const totalEl = document.getElementById('trophies-ending-count-total');
    if (totalEl) totalEl.textContent = String(TROPHIES.length);
    try { Sounds.launchFanfare(); } catch (e) {}
    overlay.classList.add('active');
    const btn = document.getElementById('trophies-ending-continue');
    if (btn) {
        const handler = () => {
            btn.removeEventListener('click', handler);
            overlay.classList.remove('active');
        };
        btn.addEventListener('click', handler);
    }
}

function spawnEndingFireworks() {
    const fw = document.getElementById('game-ending-fireworks');
    if (!fw) return;
    fw.innerHTML = '';
    for (let i = 0; i < 26; i++) {
        const s = document.createElement('span');
        s.textContent = '\u2726';
        s.style.left = (Math.random() * 100).toFixed(1) + '%';
        s.style.top = (Math.random() * 100).toFixed(1) + '%';
        s.style.fontSize = (10 + Math.random() * 26).toFixed(0) + 'px';
        s.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
        s.style.animationDuration = (2 + Math.random() * 3).toFixed(2) + 's';
        fw.appendChild(s);
    }
}

function showPostTravelShop(distance) {
    const modal = document.getElementById('galactic-shop-modal');
    if (!modal) return;
    const wasCredited = postTravelRewardsCreditedAt > 0
        && postTravelRewardsCreditedAt === lastLaunchAt;
    postTravelLock = true;
    atelierAfterTravel = true;
    modal.classList.add('post-travel');
    // Recompenses creditees DES L'OUVERTURE de l'atelier (pas au reset) :
    // le joueur voit deja sa Poussiere d'Etoiles et peut la depenser avant
    // de cliquer sur Continuer. Sauvegarde immediate : un rafraichissement
    // pendant l'atelier ne fait pas perdre le gain du vol. Idempotence via
    // postTravelRewardsCreditedAt : un rechargement pendant l'atelier ne
    // credite PAS deux fois les recompenses du meme vol.
    if (!wasCredited) {
        // V3.71 : PE de suite infinie AVANT le credit -- la ligne 'Suite
        // infinie' de la case PE affichera le gain de CE vol uniquement
        // (retour : 'montre les gains de bonus grace aux PE gagnes via
        // ce voyage la uniquement').
        postVirgoStardustBeforeFlight = postVirgoStardust;
        const doublingsBeforeFlight = recordDoublings;
        recordMaxDistance(lastLaunchDistance);
        rocketsLaunched++;
        lastLaunchAt = Date.now();
        postTravelRewardsCreditedAt = lastLaunchAt;
        updateMiniGamesVisibility();
        // V3 cumulatif : le gain credite est la difference entre le PE que
        // represente le NOUVEAU cumul (ancien cumul + distance du vol) et le
        // PE deja credite. La distance est ajoutee au cumul APRES le calcul
        // (calculateStardustGainExact projette deja cumul + distance du vol).
        const dustGained = calculateStardustGain(isNaN(lastLaunchDistance) ? 0 : lastLaunchDistance);
        lifetimeDistanceKm += Math.max(isNaN(lastLaunchDistance) ? 0 : lastLaunchDistance, 0);
        // Valeur de reference : TOUT l'affichage ulterieur (resume atelier,
        // modale resultats) reutilise ce chiffre reellement credite.
        lastLaunchDustCredited = dustGained;
        if (dustGained > 0) {
            starDust += dustGained;
            totalStardustEarned += dustGained;
            stardustFromFlights += dustGained;
            const virgoDist = (PLANETS.find(p => p.id === 'virgo-cluster') || {}).distanceRequired || Infinity;
            if (!isNaN(lastLaunchDistance) && lastLaunchDistance > virgoDist) {
                postVirgoStardust += dustGained;
                invalidateBuildingGainsCache();
            }
        }
        // Bonus permanent GAGNEE ce vol : suite infinie portee par les PE du
        // vol + doublages de record du vol + nouvelles planetes du vol.
        const doublingsPct = (recordDoublings - doublingsBeforeFlight) * wasmConst('record_doubling_percent', 0.5) * 100;
        const newlyUnlockedForBonus = checkNewPlanetsUnlocked(isNaN(lastLaunchDistance) ? 0 : lastLaunchDistance);
        const newPlanetsPct = newlyUnlockedForBonus.reduce((sum, planet) => {
            const pct = wasmCore() ? (wasmCore().planet_bonus_percent ? wasmCore().planet_bonus_percent(PLANETS.indexOf(planet)) : planet.bonusPercent) : planet.bonusPercent;
            return sum + pct;
        }, 0);
        lastLaunchPermanentBonusPct = getInfiniteProductionPercent(Math.max(0, postVirgoStardust - postVirgoStardustBeforeFlight)) + doublingsPct + newPlanetsPct;
    }
    // visible pendant l'atelier post-lancement (position absolute, il ne
    // recouvre ni le titre ni la Poussiere d'Etoiles). Pose APRES le
    // credit du record ci-dessus pour afficher la valeur a jour.
    updatePostTravelRecordBadge(modal);
    const summaryEl = document.getElementById('post-travel-summary');
    if (summaryEl) {
        const newlyUnlocked = checkNewPlanetsUnlocked(distance);
        // RESUME V3.4 : TROIS CASES CARREES cote a cote (Expédition, PE,
        // Bonus) + narratif des decouvertes + message de relance. Le joueur
        // doit comprendre ce qu'il gagne ET pourquoi recommencer.
        const reached = PLANETS.filter(p => p.id !== 'earth' && distance >= p.distanceRequired);
        // V3.51 : newBonusTotal plus utilise au CHIFFRE principal (somme
        // permanente a la place) -- les planetes du vol restent en lores.
        // Lignes bonus PLANETE (une par planete, nom colore) : elles vivent
        // dans la case Bonus Permanents (retour joueur) -- plus de bloc
        // pts-lores separe en dessous du resume.
        let planetLinesHtml = newlyUnlocked.map(planet => {
            const lore = PLANET_DISCOVERY_LORE[planet.id] || '';
            return '<div class="pts-lore">' +
                '<span class="pts-lore-planet" style="color:' + planet.color + ';">' + t(planet.name) + ' +' + planet.bonusPercent + '%</span>' +
                (lore ? '<span class="pts-lore-text">' + t(lore) + '</span>' : '') +
            '</div>';
        }).join('');
        // V3.29 : la ligne 'Suite infinie' est RETIREE de la case Bonus
        // Permanents (retour joueur) -- elle vit desormais dans la case
        // Poussière d'Étoiles (emplacement fixe V3.25).
        // V4.0ter (retour proprietaire : 'dans la case Bonus Permanents il
        // est ecrit +0% production pour toujours alors que j ai gagne +50%')
        // : la case affiche desormais le bonus permanent GAGNEE AVEC CE
        // VOYAGE (lastLaunchPermanentBonusPct : suite infinie du vol +
        // doublages de record du vol + nouvelles planetes du vol) et non
        // plus le cumul complet ; les lignes de lore gardent le detail des
        // nouvelles planetes du vol.
        const permTotalPct = lastLaunchPermanentBonusPct;
        // V3.26 : VISIBILITE du bonus de doublage de record (retour joueur 'ou
        // est-ce que c'est ecrit ?') -- ligne dediee dans la case Bonus
        // Permanents des que le premier doublage a eu lieu.
        if (gameFinished && recordDoublings > 0) planetLinesHtml +=
            '<div class="pts-lore"><span class="pts-lore-planet" style="color:#fbbf24;">🔥 ' + tf('Records doublés : {count} (+{pct}% de production)', { count: recordDoublings, pct: formatInfinitePct(recordDoublings * 50) }) + '</span></div>';
        // « production pour toujours » : a DROITE du % global, sur la MEME
        // LIGNE (retour joueur : il etait retombe en bas de la case quand
        // les lores ont ete deplaces dedans).
        const foreverLabel = t('production pour toujours');
        const planetsHtml =
              '<div class="pts-case pts-case-bonus">' +
                '<div class="pts-case-icon"><img src="images/planets/earth.webp" alt="" class="pts-case-img"></div>' +
                '<div class="pts-case-title">' + t('Bonus permanent gagné') + '</div>' +
                '<div class="pts-case-big pts-case-big-line">+' + formatInfinitePct(permTotalPct) + '% <span class="pts-case-forever">' + foreverLabel + '</span></div>' +
                (planetLinesHtml ? '<div class="pts-case-lores">' + planetLinesHtml + '</div>' : '') +
              '</div>';
        summaryEl.innerHTML =
            '<div class="pts-cases">' +
                '<div class="pts-case">' +
                    '<div class="pts-case-icon"><img src="images/rocket/Fusee-travel.webp" alt="" class="pts-case-img"></div>' +
                    '<div class="pts-case-title">' + t('Expédition') + '</div>' +
                    '<div class="pts-case-big">' + formatNumber(isNaN(distance) ? 0 : distance) + ' <span class="pts-case-unit">' + t('km parcourus') + '</span></div>' +
                    (reached.length > 0
                        ? '<div class="pts-case-planets"><span class="pts-case-planets-label">' + t('Vous avez atteints :') + '</span>' + reached.map(p => '<span style="color:' + p.color + ';">' + t(p.name) + '</span>').join('<span class="pts-case-dot"> · </span>') + '</div>'
                        : '') +
                    // V3.38bis : nombre de records doubles (retour joueur 'ca
                    // peut etre sympa pour le joueur') -- meme ligne que les
                    // planetes atteintes, separee par un point.
                    (gameFinished
                        ? '<div class="pts-case-planets"><span class="pts-case-planets-label">' + tf('Nombre de records doublés : {count}', { count: recordDoublings }) + '</span></div>'
                        : '') +
                '</div>' +
                '<div class="pts-case pts-case-dust">' +
                    '<div class="pts-case-icon"><img src="images/Stardust.webp" alt="" class="control-icon-stardust"></div>' +
                    '<div class="pts-case-title">' + t('Poussière d’Étoiles') + '</div>' +
                    '<div class="pts-case-big">+' + formatNumber(lastLaunchDustCredited) + '</div>' +
                    '<div class="pts-case-note">' + t('S’obtiennent en parcourant des km — de plus en plus dur · À dépenser dans l’atelier') + '</div>' +
                    // V3.25 : emplacement FIXE (retour a chaque lancement post-Virgo)
                    // -- le gain de la suite infinie porte par les PE de CE vol.
                    // V3.71 (retour proprietaire : 'le BONUS INFINIE doit
                    // montrer les gains grace aux PE gagnes via CE voyage
                    // uniquement') : delta de PE post-Virgo du vol courant,
                    // converti en % de production (1% par PE).
                    (postVirgoStardust > postVirgoStardustBeforeFlight
                        ? '<div class="pts-case-infinite-gain"><span class="pts-case-ig-label">' + t('Suite infinie') + '</span> +' + formatInfinitePct(getInfiniteProductionPercent(postVirgoStardust - postVirgoStardustBeforeFlight)) + '% ' + t('prod gr\u00e2ce aux PE') + '</div>'
                        : '') +
                '</div>' +
                planetsHtml +
            '</div>' +
            '<div class="pts-reset-note">' +
                t('En cliquant sur Nouvelle Expédition, tu recommences à zéro — mais avec tous tes bonus permanents ! C’est la clé pour aller toujours plus loin.') +
            '</div>';
        summaryEl.style.display = '';y = '';y = '';
    }
    const actionsEl = document.getElementById('post-travel-actions');
    if (actionsEl) actionsEl.style.display = '';
    renderGalacticShop();
    updateStardustDisplay();
    modal.classList.add('active');
}

// Consultation libre depuis la sidebar : pas de blocage, pas de resume.
function openGalacticShopBrowse() {
    const modal = document.getElementById('galactic-shop-modal');
    if (!modal) return;
    postTravelLock = false;
    modal.classList.remove('post-travel');
    const oldBadge = modal.querySelector('.post-travel-record');
    if (oldBadge) oldBadge.remove();
    const summaryEl = document.getElementById('post-travel-summary');
    if (summaryEl) summaryEl.style.display = 'none';
    const actionsEl = document.getElementById('post-travel-actions');
    if (actionsEl) actionsEl.style.display = 'none';
    renderGalacticShop();
    updateStardustDisplay();
    modal.classList.add('active');
}

// Sortie de la modal atelier : bloquee si on vient de finir un voyage
// (seul le bouton Continuer -> confirmPostTravelReset peut la fermer).
function tryCloseGalacticShop() {
    if (postTravelLock) return;
    document.getElementById('galactic-shop-modal').classList.remove('active');
}

// V3.13 (audit) : la modale de confirmation "Nouvelle expedition ?" --
// confirmNewExpedition/closeNewExpeditionConfirm avaient ete perdus lors
// de l'incident de troncature de script.js : les boutons de la modale
// n'appelaient RIEN et le joueur restait bloque. Rebranches ici.
function closeNewExpeditionConfirm() {
    document.getElementById('new-expedition-confirm-modal').classList.remove('active');
}
function confirmNewExpedition() {
    closeNewExpeditionConfirm();
    confirmPostTravelReset();
}
// Bouton Continuer : ferme la modal, applique le reset avec les bonus,
// puis affiche les resultats de la mission.
function confirmPostTravelReset() {
    try { window.UMI && window.UMI.track('expedition_complete', { }); } catch (e) {}
    setGameplayPaused(false);
    document.getElementById('galactic-shop-modal').classList.remove('active');
    postTravelLock = false;
    atelierAfterTravel = false;
    const summaryEl = document.getElementById('post-travel-summary');
    if (summaryEl) summaryEl.style.display = 'none';
    const actionsEl = document.getElementById('post-travel-actions');
    if (actionsEl) actionsEl.style.display = 'none';
    // Les recompenses (record, prestige, Poussiere d'Etoiles) ont deja ete
    // creditees a l'ouverture de l'atelier : ici, seul le reset reste a faire.
    // Debloquer les planetes atteintes uniquement a la confirmation du reset
    applyNewPlanets(checkNewPlanetsUnlocked(lastLaunchDistance));
    // Reset du score, des batiments et des pieces de fusee (garde les bonus/prestige)
    score = 0;
    // Le chronometre "depuis le dernier lancement" repart de zero avec la
    // nouvelle expedition : sans lui, il continuait de courir depuis
    // l'ancien lancement (lastLaunchAt) ou le debut de la partie (gameStartTime).
    lastLaunchAt = 0;
    postTravelRewardsCreditedAt = 0;
    expeditionStartTime = Date.now(); // le chrono d'expédition repart, PAS "Partie commencée"
    // Les cooldowns des boosters ne sont PAS remis a zero au reset :
    // ils continuent de courir entre les parties (timers absolus).
    BUILDINGS.forEach(b => b.count = 0);
    ROCKET_PARTS.forEach(p => p.purchased = false);
    constructedParts = new Set();
    nextPlanetNotified = false;
    // Le pop-up "tu peux voyager vers X" d'une expedition precedente ne
    // doit PAS survivre au reset : sinon le joueur voit "Mars" alors que
    // la portee de sa nouvelle expedition vaut bien moins (pop-up perime
    // = fausse promesse, 2 calculs contradictoires a l'ecran).
    closeNextPlanetNotification();
    const scene = document.getElementById('rocket-parts-container');
    if (scene) scene.innerHTML = '';
    unlockedBuildings = new Set();
    startupBonusApplied = false;
    applyStartupBonus();
    totalPartsFromClicks = 0;
    activatedClickUpgrades = [];
    buildingUpgrades = {};
    buildingUpgradeCosts = {};
    totalGeneratedAtLaunchStart = calculateTotalGenerated();
    totalGeneratedByBuilding = {};
    partsSinceLaunch = 0;
    totalPartsEarnedThisLaunch = 0;
    naturalPartsThisLaunch = 0;
    displayedReachPeak = 0;
    activeRandomBonuses = [];
    // Prix des pieces de fusee : capture du multiplicateur de production
    // UNE fois ici, au moment du reset (les batiments sont deja retombes a
    // zero mais tous les bonus permanents -- prestige, planetes, collection,
    // suite infinie -- sont deja credites). Il restera fige toute l'expedition.
    partCostMultiplier = Math.max(1, getTotalProductionMultiplier());
    rebuildAutoMultipliers();
    updateBonusTimer();
    resetContractState();
    // Les batiments retombent a zero au lancement, mais le deblocage des
    // mini-jeux est permanent : les cartes restent affichees.
    updateMiniGamesVisibility();
    updateDisplay();
    saveGame();
    checkBuildingUnlocks();
    renderBuildings();
    renderUpgrades();
    renderRocketPartsShop();
    // V3.2 : la modale "Expedition terminee" est SUPPRIMEE -- le resume de
    // l'atelier post-voyage explique deja la distance, la Poussoire et les
    // bonus; une deuxieme fenetre repetait l'information sans valeur.
    isLaunching = false;
    updateSpaceProgress();
    updateConstructionScene();
}


// ============================================
// ATELIER GALACTIQUE (upgrades permanents)
// ============================================

function getGalacticUpgradeLevel(upgradeId) {
    return galacticUpgrades[upgradeId] || 0;
}

function getGalacticUpgradeCost(upgrade) {
    const level = getGalacticUpgradeLevel(upgrade.id);
    return Math.floor(upgrade.baseCost * Math.pow(upgrade.costMult, level));
}

// V3.9 : le Renforcement cosmique ne se debloque qu'avec TOUTES les autres
// upgrades infinies au max -- sinon il n'y a plus rien a acheter et les PE
// s'accumulent a l'infini (retour playtest).
function isInfiniteTreeComplete() {
    return GALACTIC_UPGRADES
        .filter(u => u.branch === 'infinite' && u.id !== 'inf-boost')
        .every(u => getGalacticUpgradeLevel(u.id) >= u.maxLevel);
}
function isGalacticUpgradeLocked(upgrade) {
    // V3.23 (retour joueur) : le Renforcement cosmique est debloque DES LE
    // MODE INFINI -- plus de condition d'arbre complet, il revient dans la
    // liste triee par prix, a sa place naturelle.
    if (upgrade.id === 'inf-boost') return false;
    if (!upgrade.requires) return false;
    return upgrade.requires.some(req => getGalacticUpgradeLevel(req) === 0);
}

function buyGalacticUpgrade(upgradeId) {
    const upgrade = GALACTIC_UPGRADES.find(u => u.id === upgradeId);
    if (!upgrade) return;
    const level = getGalacticUpgradeLevel(upgradeId);
    if (level >= upgrade.maxLevel) return;
    if (isGalacticUpgradeLocked(upgrade)) {
        showToast("\u274c " + t("Prérequis non rempli"));
        return;
    }
    const cost = getGalacticUpgradeCost(upgrade);
    if (starDust < cost) {
        showToast("\u274c " + t("Pas assez de Poussière d'Étoiles"));
        return;
    }
    starDust -= cost;
    galacticUpgrades[upgradeId] = level + 1;
    // V3.2 : son d'achat dedie aux ameliorations galactiques.
    try { Sounds.buy(); } catch (e) {}
    updateStardustDisplay();
    renderGalacticShop();
    // Reduction du temps d'attente des boosters (coll1/coll3/coll5) :
    // appliquer IMMEDIATEMENT aux cooldowns en cours, pas seulement au
    // prochain cycle. Le facteur est recalcule et le nouveau deadline
    // garde la proportion deja ecoulee de l'ancien cycle.
    if (upgradeId === 'coll1' || upgradeId === 'coll3' || upgradeId === 'coll5') {
        // Ratio entre le facteur apres achat et le facteur avant achat :
        // le reste du cooldown en cours est recale au meme ratio.
        const now = Date.now();
        galacticUpgrades[upgradeId] = level;
        const prevFactor = getBoosterCooldownFactor();
        galacticUpgrades[upgradeId] = level + 1;
        const newFactor = getBoosterCooldownFactor();
        const ratio = newFactor / prevFactor;
        for (const key in BOOSTERS) {
            const deadline = boosterReadyAt[key] || 0;
            if (deadline > now) {
                boosterReadyAt[key] = now + (deadline - now) * ratio;
            }
        }
        updateBoosterTimers();
    }

    // Upgrades de la branche Batiment : le batiment offert est credite
    // immediatement en cours de run (pas seulement au prochain demarrage).
    const boughtUpgrade = GALACTIC_UPGRADES.find(u => u.id === upgradeId);
    if (boughtUpgrade && boughtUpgrade.branch === 'rocket' && boughtUpgrade.effectBuilding) {
        const b = BUILDINGS.find(x => x.id === boughtUpgrade.effectBuilding);
        if (b) {
            b.count += boughtUpgrade.effectPerLevel;
            unlockedBuildings.add(b.id);
            invalidateBuildingGainsCache();
            startupBonusApplied = true;
            renderBuildings();
            updateDisplay();
        }
    }

    saveGame();
    showToast(t(upgrade.name) + " " + t("niveau") + " " + (level + 1), "images/Stardust.webp");
}

// Getters d'effets (utilisés par la boucle de jeu)
// ============================================
// PRODUCTION HORS-LIGNE (atelier galactique, branche Hors-ligne)
// Credit la production accumulée pendant l'absence, plafonnée au palier débloqué.
// ============================================

// Plafond hors-ligne de base, gratuit des le debut du jeu (10 minutes).
// Les ameliorations galactiques de la branche hors-ligne augmentent ce plafond.
const BASE_OFFLINE_CAP_HOURS = 5 / 60;
function getOfflineCapHours() {
    let hours = BASE_OFFLINE_CAP_HOURS;
    for (const up of GALACTIC_UPGRADES) {
        if (up.branch === 'offline' && getGalacticUpgradeLevel(up.id) > 0) {
            hours = Math.max(hours, up.effectPerLevel);
        }
    }
    return hours;
}

function applyOfflineEarnings(lastSave) {
    if (!lastSave) return;
    const capHours = getOfflineCapHours();
    if (capHours <= 0) return;
    const elapsedSec = (Date.now() - lastSave) / 1000;
    // Seuil abaisse de 60 s a 2 s : le pop-up "Bon retour" doit s'afficher
    // des le moindre passage en arriere-plan mobile (la production en
    // direct y est FIGEE -- chaque seconde d'absence passe par ce credit)
    // ou a la reouverture d'une partie. Avant, une absence < 60 s ne
    // creditait RIEN pendant que la boucle etait gelee : production
    // silencieusement perdue.
    if (elapsedSec < 2) return;
    const cappedSec = Math.min(elapsedSec, capHours * 3600);
    let totalGain = 0;
    BUILDINGS.forEach(building => {
        if (building.count > 0) {
            // Gain de BASE (hors boost temporaire autoMultiplier) : le credit
            // hors-ligne est un rattrapage de production normale, pas un
            // moyen d'etendre un x4 temporaire au-dela de sa duree. Avant,
            // calculateBuildingGain incluait le boost actif au moment de la
            // fermeture -> un boost x4 eternise sur tout le plafond horaire.
            const g = calculateBuildingBaseGain(building) * cappedSec;
            totalGeneratedByBuilding[building.id] = (totalGeneratedByBuilding[building.id] || 0) + g;
            totalGain += g;
        }
    });
    if (totalGain <= 0) return;
    score += totalGain;
    partsSinceLaunch += totalGain;
    trackPartsEarned(totalGain);
    const capped = cappedSec < elapsedSec;
    showWelcomeBackModal(totalGain, cappedSec, capped);
    updateDisplay();
}

// Pop-up de reconnexion : resume les Parts gagnees pendant l'absence.
// Reutilise le style de la modale Nouveau batiment.
function showWelcomeBackModal(gain, seconds, capped) {
    const modal = document.getElementById('welcome-back-modal');
    if (!modal) return;
    const img = document.getElementById('wb-image');
    if (img) {
        // relance l'animation de pop a chaque ouverture
        img.style.animation = 'none';
        void img.offsetWidth;
        img.style.animation = '';
    }
    document.getElementById('wb-gain').textContent = '+' + formatNumber(gain) + ' ' + t('Parts');
    document.getElementById('wb-duration').textContent = formatDurationHMS(seconds * 1000);
    const cappedEl = document.getElementById('wb-capped');
    if (cappedEl) {
        cappedEl.style.display = capped ? '' : 'none';
        if (capped) cappedEl.textContent = t("Plafonné aux capacités de production hors-ligne. Améliore-les dans l'atelier galactique !");
    }
    modal.classList.add('active');
    // Plein ecran BLOQUANT : focus sur Continuer, Entree/Espace valide ;
    // rien d'autre n'est cliquable tant que le joueur n'a pas accepte.
    const wbBtn = document.getElementById('wb-continue-btn');
    if (wbBtn) setTimeout(() => wbBtn.focus(), 50);
}

function closeWelcomeBackModal() {
    const modal = document.getElementById('welcome-back-modal');
    if (modal) modal.classList.remove('active');
}

function getUpgradeEffect(upgradeId) {
    return getGalacticUpgradeLevel(upgradeId) * wasmUpgradeEffectPerLevel(upgradeId);
}

function getProductionBonus() {
    return 1
        + getUpgradeEffect('prod1')
        + getUpgradeEffect('prod2')
        + getUpgradeEffect('prod3')
        + getUpgradeEffect('prod4')
        + getUpgradeEffect('prod5')
        + getUpgradeEffect('prod6')
        + getUpgradeEffect('prod7')
        + getUpgradeEffect('prod8')
        + getUpgradeEffect('inf-boost');
}
function getBuildingCostReduction() {
    return 0;
}
function getRocketPartDiscount() {
    return 0;
}
// Batiments gratuits au demarrage : un par upgrade de la branche Batiment,
// chacun cible un batiment DIFFERENT de la chaine de production.
function getStartupFreeBuildings() {
    const free = [];
    GALACTIC_UPGRADES.forEach(u => {
        if (u.branch === 'rocket' && u.effectBuilding) {
            const lvl = getGalacticUpgradeLevel(u.id);
            for (let i = 0; i < lvl * u.effectPerLevel; i++) {
                free.push(u.effectBuilding);
            }
        }
    });
    return free;
}
function getCometFrequencyBonus() {
    // Eclipse totale (V3.5, inf-eclip) : +25% de frequence des cometes
    // isolees (retour playtest : x2 etait trop fort).
    return getGalacticUpgradeLevel('inf-eclip') > 0 ? 0.25 : 0;
}
function getStardustGainBonus() {
    return 1;
}
// PE total que representerait une distance cumulee donnee (formule brute).
// Racine cubique pure, sans aucun seuil -- les jalons de planetes se
// chargent du pacing du milieu de partie.
function stardustFromLifetimeDistance(lifetimeKm) {
    const safe = (isNaN(lifetimeKm) || lifetimeKm < 0) ? 0 : lifetimeKm;
    return Math.pow(safe / MOON_DISTANCE, STARDUST_DISTANCE_EXP) * getStardustGainBonus();
}

// V3 cumulatif : PE potentiel ACTUEL -- ce que le joueur obtiendrait s'il
// lancait maintenant = f(distance cumulee + distance du vol) - PE deja credite.
function calculateStardustGainExact(distanceKm) {
    const flightDistance = (isNaN(distanceKm) || distanceKm < 0) ? 0 : distanceKm;
    const projectedLifetime = lifetimeDistanceKm + Math.max(flightDistance, 0);
    return Math.max(0, stardustFromLifetimeDistance(projectedLifetime) - stardustFromFlights);
}

// PE fractionnaires (V3) : plus de floor -- un vol Lune ratant le seuil
// affiche 0,4 PE au lieu de 0. Les decimales s'accumulent avec les vols.
function calculateStardustGain(distanceKm) {
    return calculateStardustGainExact(distanceKm);
}

// Inverse de la formule PE : quelle distance cumulee represente un montant
// de PE donne ? Utilise par la migration des anciennes sauvegardes (V3).
function lifetimeDistanceFromStardust(stardust) {
    const safe = (isNaN(stardust) || stardust < 0) ? 0 : stardust;
    const adjusted = Math.max(0, safe / Math.max(getStardustGainBonus(), 1e-9));
    return MOON_DISTANCE * Math.pow(adjusted, 1 / STARDUST_DISTANCE_EXP);
}
function getDistanceBonus() {
    return 1;
}
function getClickPowerBonus() {
    let mult = 1;
    if (getGalacticUpgradeLevel('click1') > 0) mult *= 1.5;
    if (getGalacticUpgradeLevel('click3') > 0) mult *= 1.75;
    if (getGalacticUpgradeLevel('click5') > 0) mult *= 2;
    if (getGalacticUpgradeLevel('click7') > 0) mult *= 2.5;
    return mult;
}
function getCritChance() {
    const wCr = wasmCore();
    return Math.min(wCr && wCr.crit_chance_cap ? wCr.crit_chance_cap() : 0.50, getUpgradeEffect('click2') + getUpgradeEffect('click4'));
}
function getBoosterTimeDiscount() {
    let discount = 1;
    if (getGalacticUpgradeLevel('coll1') > 0) discount *= 0.90;
    if (getGalacticUpgradeLevel('coll3') > 0) discount *= 0.90;
    if (getGalacticUpgradeLevel('coll5') > 0) discount *= 0.85;
    return 1 - discount;
}
function getCollectionUpgradeBonus() {
    return getUpgradeEffect('coll4');
}
function getRarityBoost() {
    return Math.min(0.50, getUpgradeEffect('coll2'));
}

function applyStartupBonus() {
    const freeBuildings = getStartupFreeBuildings();
    if (startupBonusApplied || freeBuildings.length === 0) return;
    freeBuildings.forEach(bId => {
        const b = BUILDINGS.find(x => x.id === bId);
        if (b) {
            b.count += 1;
            unlockedBuildings.add(b.id);
        }
    });
    startupBonusApplied = true;
    invalidateBuildingGainsCache();
}

// Selecteurs de la branche Infinie (V3) : favori + recompense comete.
function setFavoriteBuilding(buildingId) {
    if (getGalacticUpgradeLevel('inf-fav') === 0) return;
    if (!BUILDINGS.some(b => b.id === buildingId)) return;
    if (favoriteBuildingId === buildingId) return;
    favoriteBuildingId = buildingId;
    // V3.8 : le bonus gagne est ACQUIS -- chaque batiment garde ses
    // secondes accumulees (banque par batiment). Le nouveau favori repart
    // de SA banque (0 si jamais favori avant) et continue de cumuler.
    favoriteBuildingSeconds = favoriteBuildingSecondsByBuilding.get(buildingId) || 0;
    invalidateBuildingGainsCache();
    saveGame();
    showToast('\u2b50 ' + t('B\u00e2timent favori') + ' : ' + t(findBuildingById(buildingId).name));
}
// Tirage pondere du choix de recompense (V3.5) : a l'interception d'une
// comete meteor, 40% de chances de la convertir en x4 si le mode est
// 'multiplier' (20% de base + 20% de l'upgrade), 0% si 'parts', 20% de
// base si 'neutral'. Jamais binaire -- moins fort qu'avant.
// V3.10 : NEUTRE = 50/50 entre Parts et x4. Le choix oriente de +/-15% :
// 'multiplier' -> 65% de x4, 'parts' -> 65% de Parts (donc 35% de x4).
// Le hasard reste TOUJOURS present, aucun mode ne garantit 100%.
function shouldCometGiveMultiplier() {
    const neutral = wasmConst('comet_reward_neutral_chance', 0.50);
    const bonus = wasmConst('comet_reward_choice_bonus', 0.15);
    const x4Chance = cometRewardMode === 'multiplier' ? neutral + bonus
        : cometRewardMode === 'parts' ? neutral - bonus
        : neutral;
    return Math.random() < x4Chance;
}

function setCometRewardMode(mode) {
    if (getGalacticUpgradeLevel('inf-choice') === 0) return;
    cometRewardMode = ['parts', 'multiplier', 'neutral'].includes(mode) ? mode : 'neutral';
    saveGame();
}
// V3.5 : bouton on/off de l'auto-achat (persiste, ne s'affiche qu'avec l'upgrade).
function setAutoBuyEnabled(v) {
    autoBuyEnabled = v !== 'off';
    try { localStorage.setItem('starcruiser-autoBuy', autoBuyEnabled ? '1' : '0'); } catch (e) {}
}
function updateInfiniteControls() {
    const wrap = document.getElementById('infinite-controls');
    if (!wrap) return;
    const show = gameFinished && (getGalacticUpgradeLevel('inf-fav') > 0 || getGalacticUpgradeLevel('inf-choice') > 0
        || getGalacticUpgradeLevel('inf-auto1') > 0 || getGalacticUpgradeLevel('inf-auto2') > 0 || getGalacticUpgradeLevel('inf-parts') > 0);
    wrap.style.display = show ? '' : 'none';
    if (!show) return;
    const favSel = document.getElementById('favorite-building-select');
    if (favSel && getGalacticUpgradeLevel('inf-fav') > 0) {
        const current = favSel.value;
        favSel.innerHTML = '<option value="">' + t('Aucun') + '</option>' +
            BUILDINGS.map(b => '<option value="' + b.id + '">' + t(b.name) + '</option>').join('');
        favSel.value = favoriteBuildingId || '';
        if (favSel.value !== (favoriteBuildingId || '') && current === (favoriteBuildingId || '')) favSel.value = current;
        favSel.parentElement.style.display = '';
    } else if (favSel) {
        favSel.parentElement.style.display = 'none';
    }
    const cometSel = document.getElementById('comet-reward-select');
    if (cometSel && getGalacticUpgradeLevel('inf-choice') > 0) {
        cometSel.value = cometRewardMode;
        cometSel.parentElement.style.display = '';
    } else if (cometSel) {
        cometSel.parentElement.style.display = 'none';
    }
    const autoSel = document.getElementById('autobuy-select');
    if (autoSel) {
        const hasAuto = getGalacticUpgradeLevel('inf-auto1') > 0 || getGalacticUpgradeLevel('inf-auto2') > 0 || getGalacticUpgradeLevel('inf-parts') > 0;
        autoSel.parentElement.style.display = (hasAuto) ? '' : 'none';
        if (hasAuto) autoSel.value = autoBuyEnabled ? 'on' : 'off';
    }
}

function renderGalacticShop() {
    const container = document.getElementById('galactic-shop-list');
    if (!container) return;
    container.innerHTML = '';
    // V3.24 (retour joueur) : la case affiche UNIQUEMENT les bonus gagnes
    // avec les PE -- la branche production de l'atelier (prod1-8 + Renforcement
    // cosmique) et la suite infinie (+1%/PE post-Virgo). Les planetes, trophees,
    // cartes et doublages n'ont rien a faire la : le joueur doit lire CE QUE
    // SES PE LUI ONT RAPPORTE.
    // V3.31 : le badge 'Bonus PE Infini' est CACHE avant le mode infini
    // (retour joueur) -- il ne parle que de la suite infinie et des PE
    // post-Virgo, il n'a rien a faire a l'ecran tant que Virgo n'est pas
    // atteint. En mode infini : visible, meme calcul.
    const bonusBadge = document.getElementById('shop-bonus-badge');
    if (bonusBadge) {
        if (!gameFinished) {
            bonusBadge.style.display = 'none';
        } else {
            bonusBadge.style.display = '';
            const peMult = getProductionBonus() * getInfiniteStardustBonus();
            const permPct = Math.round((peMult - 1) * 100);
            bonusBadge.innerHTML = '<span class="sbb-label">' + t('Bonus PE Infini') + '</span><span class="sbb-value">+' + formatInfinitePct(permPct) + '%</span>';
            bonusBadge.title = t('Bonus PE Infini gagné avec les PE');
        }
    }
    // V3.4 : la branche Infinie debloquee passe en PREMIER -- elle est la
    // suite du jeu, le joueur post-Virgo la voit immediatement.
    const orderedBranches = gameFinished
        ? [GALACTIC_BRANCHES.find(b => b.id === 'infinite'), ...GALACTIC_BRANCHES.filter(b => b.id !== 'infinite')].filter(Boolean)
        : GALACTIC_BRANCHES;
    orderedBranches.forEach(branch => {
        // Branche Infini : visible seulement apres l'Amas de Virgo -- le
        // joueur decouvre les upgrades infinies en finissant l'arbre de base.
        if (branch.id === 'infinite' && !gameFinished) return;
        const branchEl = document.createElement('div');
        branchEl.className = 'galactic-branch';
        branchEl.style.setProperty('--branch-color', branch.color);

        const header = document.createElement('div');
        header.className = 'galactic-branch-header';
        // V3.89 : icone IMAGE des branches (chemin de fichier) avec fallback
        // emoji/symbole (l infini reste un caractere).
        const branchIconHtml = (branch.icon && branch.icon.indexOf('/') !== -1)
            ? '<img src="' + branch.icon + '" alt="" class="galactic-branch-icon-img">'
            : branch.icon;
        header.innerHTML = '<span class="galactic-branch-icon">' + branchIconHtml + '</span><span class="galactic-branch-name">' + t(branch.name) + '</span>';
        branchEl.appendChild(header);

        const treeEl = document.createElement('div');
        treeEl.className = 'galactic-tree';

        let upgrades = GALACTIC_UPGRADES.filter(u => u.branch === branch.id);
        // Branche infinie : tri par PRIX CROISSANT (retour joueur) -- les
        // outils accessibles d'abord. V3.29 : le RENFORCEMENT COSMIQUE est
        // EXCLU de la liste (retour joueur) -- il a SA case dediee EN DESSOUS,
        // largeur de 4 cases. Debloque des le mode infini.
        let cosmicUpgrade = null;
        if (branch.id === 'infinite') {
            cosmicUpgrade = upgrades.find(u => u.id === 'inf-boost');
            // V3.41 (choix joueur) : ordre d'affichage EXPLICITE via le champ
            // `order` -- le tri par prix croissant mele les outils et les
            // upgrades massives sans logique de progression. Les PRIX de
            // chaque item sont inchanges, seul l'ordre de la liste bouge.
            upgrades = upgrades.filter(u => u.id !== 'inf-boost')
                .slice().sort((a, b) => (a.order || 99) - (b.order || 99));
        }
        upgrades.forEach(upgrade => {
            const level = getGalacticUpgradeLevel(upgrade.id);
            const maxed = level >= upgrade.maxLevel; // Infinity : jamais maxed
            const locked = isGalacticUpgradeLocked(upgrade);
            const cost = getGalacticUpgradeCost(upgrade);
            const affordable = starDust >= cost && !locked;
            const el = document.createElement('div');
            el.className = 'galactic-node' + (maxed ? ' maxed' : '') + (locked ? ' locked' : '') + (!affordable && !maxed && !locked ? ' too-expensive' : '');

            let reqHtml = '';
            if (upgrade.requires) {
                const reqNames = upgrade.requires.map(r => {
                    const ru = GALACTIC_UPGRADES.find(u => u.id === r);
                    return ru ? ru.name : r;
                });
                reqHtml = '<span class="galactic-req">' + t('Prérequis:') + ' ' + reqNames.map(r => t(r)).join(', ') + '</span>';
            }

            el.innerHTML =
                '<div class="galactic-node-top">' +
                    '<span class="galactic-node-name">' + t(upgrade.name) + '</span>' +
                    // V3.50 : PLUS de badge MAX ici (retour joueur : 'tu
                    // as laisse le MAX en haut a gauche') -- le MAX vit
                    // desormais UNIQUEMENT en bas de la case, a la place du
                    // bouton (placeholder V3.49), la case ne resise pas.

                '</div>' +
                '<span class="galactic-node-desc">' + t(upgrade.desc) + '</span>' +
                '<div class="galactic-node-bottom">' +
                    '<span class="galactic-node-level">' + t('Niv.') + ' ' + level + (upgrade.maxLevel === Infinity ? '' : '/' + upgrade.maxLevel) + '</span>' +
                    // V3.49 (retour joueur : 'je ne veux AUCUN resize de
                    // la case') : le MAX prend la PLACE du bouton dans la
                    // meme zone -- avant, maxed retirait le bouton et la
                    // case changeait de hauteur d'un coup.
                    (maxed
                        ? '<span class="galactic-node-maxed-placeholder">' + t('MAX') + '</span>'
                        : locked
                            ? reqHtml
                            : '<button class="galactic-btn" onclick="buyGalacticUpgrade(\'' + upgrade.id + '\')"' + (!affordable ? ' disabled' : '') + '>' + formatNumber(cost) + ' <img src="images/Stardust.webp" alt="" class="control-icon-stardust"></button>') +
                '</div>';
            treeEl.appendChild(el);
        });

        // V3.29 : RENFORCEMENT COSMIQUE -- case dediee EN DESSOUS de la liste,
        // LARGEUR DE 4 CASES (grid-column span 4, centre). Le puits de PE de
        // l'endgame se voit comme un monument, pas comme une ligne de plus.
        if (cosmicUpgrade) {
            // V3.31 : FIX NaN -- getGalacticUpgradeCost attend l'OBJET upgrade,
            // on lui passait l'ID (cosmicUpgrade.id) : upgrade.baseCost = undefined
            // -> cout NaN affiche au joueur ('pourquoi le cout est NaN ?').
            const level = getGalacticUpgradeLevel(cosmicUpgrade.id);
            const cost = getGalacticUpgradeCost(cosmicUpgrade);
            const affordable = starDust >= cost;
            const cosmicEl = document.createElement('div');
            cosmicEl.className = 'galactic-node galactic-node-cosmic' + (!affordable ? ' too-expensive' : '');
            cosmicEl.innerHTML =
                '<div class="galactic-node-top">' +
                    '<span class="galactic-node-name">' + t(cosmicUpgrade.name) + '</span>' +
                    '<span class="galactic-node-level">' + t('Niv.') + ' ' + level + '</span>' +
                '</div>' +
                '<span class="galactic-node-desc">' + t(cosmicUpgrade.desc) + '</span>' +
                '<div class="galactic-node-bottom">' +
                    '<button class="galactic-btn" onclick="buyGalacticUpgrade(\'' + cosmicUpgrade.id + '\')"' + (!affordable ? ' disabled' : '') + '>' + formatNumber(cost) + ' <img src="images/Stardust.webp" alt="" class="control-icon-stardust"></button>' +
                '</div>';
            treeEl.appendChild(cosmicEl);
        }

        branchEl.appendChild(treeEl);
        container.appendChild(branchEl);
    });
    updateInfiniteControls();
}

// V3.38 (P1 nettoyage) : updateInfiniteBuyButton SUPPRIME -- code mort V3.4
// (le bouton d'echange PE n'existe plus dans le DOM, la fonction ne faisait
// qu'un display:none sur un element absent ; l'element infinite-buy-button-wrap
// n'apparait nulle part dans le HTML). Le +1%/PE est credite automatiquement
// a chaque lancement post-Virgo (postVirgoStardust).
function toggleGalacticShop() {
    const modal = document.getElementById('galactic-shop-modal');
    if (modal && modal.classList.contains('active') && !postTravelLock) {
        modal.classList.remove('active');
        return;
    }
    openGalacticShopBrowse();
}

// ============================================
// SPACE PROGRESS SIDEBAR UPDATE
// ============================================

// ============================================
// INFOS CLIC SUR LA PROGRESSION SPATIALE
// ============================================
// Chaque case de la colonne Progression Spatiale est cliquable :
// une petite bulle d'information explique ce que represente la valeur,
// avec des donnees dynamiques (record, bonus, vitesse...).
// Chronomètre stellaire / Radar de pilote (V3) : mises en forme des ETA.
// ETA = distance restante / vitesse de portèe (km/s) -> secondes.
function formatEta(seconds) {
    if (!isFinite(seconds) || seconds <= 0) return t('Imminent');
    if (seconds < 60) return Math.ceil(seconds) + ' ' + t('s');
    if (seconds < 3600) return Math.floor(seconds / 60) + ' ' + t('min') + ' ' + Math.ceil(seconds % 60) + ' ' + t('s');
    if (seconds < 86400) return Math.floor(seconds / 3600) + ' ' + t('h') + ' ' + Math.floor((seconds % 3600) / 60) + ' ' + t('min');
    return Math.floor(seconds / 86400) + ' ' + t('j') + ' ' + Math.floor((seconds % 86400) / 3600) + ' ' + t('h');
}
function getChronoEtaLines(remainingKm) {
    if (getGalacticUpgradeLevel('inf-chrono') === 0) return '';
    const kmS = calculateTravelSpeedKmS();
    if (kmS <= 0 || remainingKm <= 0) return '';
    return '\n' + t('Temps restant actuellement') + ' : ~' + formatEta(remainingKm / kmS);
}

// Radar de pilote (V3, inf-radar) : pilote juste au-dessus au classement
// (distance record) + temps estimé pour le dépasser. Leaderboard via la lib
// partagee, cache 60 s, asynchrone et silencieux.
let pilotRadarCache = null;
// V3.17 : le radar UTILISAIT lbSharedFetchLeaderboard (leaderboard-shared.js)
// qui n'est PAS charge dans game.html -- typeof check en echec, le radar
// restait vide a l'ecran. On passe par fetchRemoteLeaderboard DU JEU
// (script.js, Supabase configure via leaderboard-config.js) : format array
// normalise. Fallback classement local si le reseau echoue.
function fetchPilotRadarEntries() {
    // V3.36 (retour joueur : 'ca me mettait zizi de l espace alors qu il y
    // avait d autres joueurs entre lui et moi') : FIX -- l'ancien fetch
    // reutilisait le classement de la MODALE : les 50 premiers en VITESSE.
    // Le radar cherche le voisin en DISTANCE dans ce sous-ensemble : les
    // joueurs ayant une DISTANCE record superieure mais une vitesse plus
    // faible (hors top 50 vitesse) etaient INVISIBLES -- le radar sautait
    // des joueurs reels. Requete DEDIEE triee par DISTANCE : le premier
    // au-dessus est bien le VRAI voisin de classement distance.
    return supabaseFetch('/rest/v1/leaderboard?select=name,speed,distance,rockets,clicks,at&order=distance.desc&limit=' + LEADERBOARD_MAX_ENTRIES, { cache: 'no-store' })
        .then(res => {
            if (!res || !res.ok) return getLocalLeaderboard();
            return res.json().then(rows => {
                if (!Array.isArray(rows)) return getLocalLeaderboard();
                return rows
                    .filter(e => e && typeof e.name === 'string' && isFinite(e.speed))
                    .map(e => ({
                        name: String(e.name).slice(0, 20),
                        speed: Number(e.speed) || 0,
                        distance: Number(e.distance) || 0,
                        rockets: Number(e.rockets) || 0,
                        clicks: Number(e.clicks) || 0,
                        at: Number(e.at) || 0
                    }));
            }).catch(() => getLocalLeaderboard());
        })
        .catch(() => getLocalLeaderboard());
}
let pilotRadarFetchedAt = 0;
function getPilotRadarLines() {
    if (getGalacticUpgradeLevel('inf-radar') === 0) return '';
    // V3.50 : MAX(record, portee actuelle) -- cf updatePilotRadarTile.
    const me = Math.max(maxDistance || 0, calculateDistance() || 0);
    if (me <= 0) return '';
    const now = Date.now();
    if (pilotRadarCache && now - pilotRadarFetchedAt < 60000) {
        return formatPilotRadar(pilotRadarCache, me);
    }
    fetchPilotRadarEntries().then(entries => {
        pilotRadarCache = entries;
        pilotRadarFetchedAt = Date.now();
    }).catch(() => {});
    return t('Radar : analyse du classement...');
}
function formatPilotRadar(entries, me) {
    // V3.88 (retour proprietaire : 'quand je recommence une exploration le
    // radar m affiche MON PROPRE nom et record a ~1 seconde') : le filtre
    // strict (distance > me) laissait passer SA PROPRE LIGNE du classement
    // -- apres un reset d expedition, la portee retombe a 0 et meNow vaut
    // le record ; si la ligne en base porte un record ne serait-ce que
    // microscopiquement superieur (aller-retour d arrondi a l envoi), la
    // propre ligne du joueur passait le filtre et le radar se verrouillait
    // sur lui-meme avec un ecart minuscule (~1 s). EXCLUSION par le nom
    // d entreprise : le radar ne considere que les AUTRES pilotes.
    const myName = (typeof getCompanyName === 'function' ? getCompanyName() : '').toLowerCase();
    const above = entries
        .filter(e => (e.distance || 0) > me && e.name.toLowerCase() !== myName)
        .sort((a, b) => (a.distance || 0) - (b.distance || 0))[0];
    if (!above) return '\n' + t('Radar') + ' : ' + t('tu es le numéro 1 de la distance !');
    const gap = (above.distance || 0) - me;
    const kmS = calculateTravelSpeedKmS();
    const eta = kmS > 0 ? formatEta(gap / kmS) : '?';
    return '\n' + t('Pilote à dépasser') + ' : ' + above.name + '\n' +
        t('Son record') + ' : ' + formatNumber(above.distance || 0) + ' ' + t('km') + '\n' +
        t('Ecart') + ' : ' + formatNumber(gap) + ' ' + t('km') + '\n' +
        t('Temps estimé') + ' : ~' + eta;
}

function statTileInfoText(tileId) {
    const progress = calculatePlanetProgress(calculateDistance());
    const target = progress.nextPlanet ? progress.nextPlanet : progress.currentPlanet;
    switch (tileId) {
        case 'sidebar-distance':
            return t('Portée actuelle') + '\n' +
                t('Distance maximale que votre fusée actuelle pourrait parcourir si vous la lanciez maintenant.') + '\n' +
                t('Elle augmente avec chaque Part gagnée.');
        case 'sidebar-distance-needed': {
            // Suite infinie : objectif = doubler le record, la case compte
            // la distance restante jusqu'a cet objectif.
            if (postVirgoStardust > 0) {
                const goalKm = maxDistance > 0 ? maxDistance * 2 : calculateDistance() * 2;
                const remaining = Math.max(0, goalKm - calculateDistance());
                return t('Distance à parcourir') + '\n' +
                    t('Suite infinie : objectif = doubler ton record.') + '\n' +
                    t('Record actuel') + ' : ' + formatNumber(maxDistance) + ' ' + t('km') + '\n' +
                    t('Objectif') + ' : ' + formatNumber(goalKm) + ' ' + t('km') + '\n' +
                    t('Restant') + ' : ' + formatNumber(remaining) + ' ' + t('km') +
                    getChronoEtaLines(remaining);
            }
            const needed = target ? Math.max(0, target.distanceRequired - calculateDistance()) : 0;
            return t('Distance à parcourir') + '\n' +
                t('Distance restante pour atteindre') + ' ' + (target ? t(target.name) : '?') + ' : ' + formatNumber(needed) + ' ' + t('km') + '.\n' +
                t('Une fois atteinte, votre fusée pourra voyager jusqu\'à cette destination.') +
                getChronoEtaLines(needed);
        }
        case 'sidebar-speed': {
            const kmS = calculateTravelSpeedKmS();
            return t('Vitesse') + '\n' +
                t('Nombre de kilomètres de portée que votre fusée gagne chaque seconde.') + '\n' +
                t('Actuellement') + ' : +' + formatTravelSpeed(kmS).replace(' km/s', ' ' + t('km')) + ' ' + t('de portée par seconde') + '.';
        }
        case 'sidebar-distance-max':
            return t('Distance record') + '\n' +
                t('Plus grande distance réellement parcourue lors d\'une expédition précédente.') + '\n' +
                t('Cette valeur est permanente : elle survit aux nouvelles expéditions.') + '\n' +
                t('Record actuel') + ' : ' + formatNumber(maxDistance) + ' ' + t('km') +
                getPilotRadarLines();
        case 'sidebar-bonus': {
            const totalBonus = 1 + getTotalPlanetBonus();
            return t('Bonus planètes') + '\n' +
                t('Bonus de production cumulé des planètes atteintes lors de vos expéditions.') + '\n' +
                t('Chaque nouvelle destination débloquée augmente ce bonus de façon permanente.') + '\n' +
                t('Bonus actuel') + ' : ' + formatBonusPct(totalBonus);
        }
        default:
            return '';
    }
}

// Bulle d'info partagee pour les cases de la sidebar : un seul popup a la
// fois, fermé par un clic a l'exterieur ou sur la croix.
let statTileInfoBubble = null;
// V3.32 : rafraichissement PERIODIQUE (1x/s) des bulles d'explication de la
// progression spatiale -- les textes contiennent des valeurs dynamiques
// (record, ETA radar, temps restant chrono...) qui figeaient depuis l'ouverture.
let statTileInfoRefreshTimer = null;
function refreshStatTileInfo() {
    if (!statTileInfoBubble) return;
    const tileId = statTileInfoBubble.dataset.forTile;
    if (!tileId) return;
    const text = statTileInfoText(tileId);
    if (!text) return;
    // Rebuild des lignes SANS toucher au bouton de fermeture.
    statTileInfoBubble.querySelectorAll('.sti-title, .sti-line').forEach(el => el.remove());
    const lines = text.split('\n');
    const closeBtn = statTileInfoBubble.querySelector('.sti-close');
    lines.forEach((line, idx) => {
        const div = document.createElement('div');
        div.className = idx === 0 ? 'sti-title' : 'sti-line';
        div.textContent = line;
        if (closeBtn) statTileInfoBubble.insertBefore(div, closeBtn);
        else statTileInfoBubble.appendChild(div);
    });
}
function startStatTileInfoRefresh() {
    if (statTileInfoRefreshTimer) return;
    statTileInfoRefreshTimer = setInterval(() => {
        if (!statTileInfoBubble) { stopStatTileInfoRefresh(); return; }
        refreshStatTileInfo();
    }, 1000);
}
function stopStatTileInfoRefresh() {
    if (statTileInfoRefreshTimer) { clearInterval(statTileInfoRefreshTimer); statTileInfoRefreshTimer = null; }
}
function toggleStatTileInfo(tile) {
    if (!tile) return;
    // Les IDs (sidebar-speed...) sont sur les spans internes, pas sur la tile.
    const valueSpan = tile.querySelector('.stat-value');
    const tileId = valueSpan ? valueSpan.id : tile.id;
    if (statTileInfoBubble && statTileInfoBubble.dataset.forTile === tileId) {
        closeStatTileInfo();
        return;
    }
    closeStatTileInfo();
    const text = statTileInfoText(tileId);
    if (!text) return;
    const bubble = document.createElement('div');
    bubble.className = 'stat-tile-info';
    bubble.dataset.forTile = tileId;
    const closeBtn = document.createElement('span');
    closeBtn.className = 'sti-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.addEventListener('click', (e) => { e.stopPropagation(); closeStatTileInfo(); });
    const lines = text.split('\n');
    lines.forEach((line, idx) => {
        const p = document.createElement(idx === 0 ? 'div' : 'div');
        p.className = idx === 0 ? 'sti-title' : 'sti-line';
        p.textContent = line;
        bubble.appendChild(p);
    });
    bubble.appendChild(closeBtn);
    // La bulle vit dans le body (position fixed) : elle n'est clippee ni par
    // .left-panel (overflow hidden) ni par un parent quelconque. Centree
    // sous la tuile, puis clampee aux bords de l'ecran.
    document.body.appendChild(bubble);
    statTileInfoBubble = bubble;
    const positionStatBubble = () => {
        if (!statTileInfoBubble) return;
        const tileRect = tile.getBoundingClientRect();
        statTileInfoBubble.style.top = (tileRect.bottom + 6) + 'px';
        // Centre la bulle sur le milieu de la COLONNE (la tuile), puis la
        // recale dans le viewport si elle deborde a gauche ou a droite.
        const r = statTileInfoBubble.getBoundingClientRect();
        let left = tileRect.left + tileRect.width / 2 - r.width / 2;
        left = Math.max(8, Math.min(left, window.innerWidth - r.width - 8));
        statTileInfoBubble.style.left = left + 'px';
    };
    requestAnimationFrame(positionStatBubble);
    window.addEventListener('resize', positionStatBubble);
    startStatTileInfoRefresh();
}
function closeStatTileInfo() {
    if (statTileInfoBubble) {
        statTileInfoBubble.remove();
        statTileInfoBubble = null;
    }
    stopStatTileInfoRefresh();
}
document.addEventListener('click', (e) => {
    if (statTileInfoBubble && !e.target.closest('.stat-tile-info') && !e.target.closest('.stat-tile')) {
        closeStatTileInfo();
    }
});

// V3.8 : case RADAR DE PILOTE dediee (sous la case Distance record) --
// l'info vivait seulement dans le tooltip de cette derniere. Mise a jour
// avec le meme cache 60 s que getPilotRadarLines, rendu compact une ligne.
// V3.20 : case BONUS DE PRODUCTION TOTAL (mode infini uniquement) sous
// l'atelier galactique. Compose TOUT les multiplicateurs PERMANENTS de la
// chaine de production (ceux qui survivent aux expeditions) :
// atelier (prod + renforcement cosmique), planetes + trophees, doublages du
// record, PE post-Virgo, pieces de fusee, cartes de collection.
function getTotalPermanentProductionBonus() {
    return getProductionBonus()
        * getPlanetProductionBonus()
        * getRecordDoublingBonus()
        * getInfiniteStardustBonus()
        * getRocketPartProductionBonus()
        * getCollectionMultiplier();
}
function updateInfiniteBonusTile() {
    const tile = document.getElementById('infinite-bonus-tile');
    const value = document.getElementById('infinite-bonus-value');
    if (!tile || !value) return;
    // Visible uniquement en mode infini (suite debloquee).
    if (!gameFinished) { tile.style.display = 'none'; return; }
    tile.style.display = '';
    const total = getTotalPermanentProductionBonus();
    // Format : x1,23 en decouvert, notation scientifique au-dela d'un million
    // (meme regle que la suite infinie).
    value.textContent = formatBonusPct(total);
}
function updatePilotRadarTile() {
    const tile = document.getElementById('sidebar-pilot-radar-tile');
    const value = document.getElementById('sidebar-pilot-radar');
    if (!tile || !value) return;
    const owned = getGalacticUpgradeLevel('inf-radar') > 0;
    if (!owned || maxDistance <= 0) { tile.style.display = 'none'; return; }
    tile.style.display = '';
    const now = Date.now();
    const render = () => {
        // V3.50 (retour joueur) : le radar compare les pilotes au MAX de
        // (record atteint, portee ACTUELLE) -- avant, un joueur qui
        // depassait un pilote en portee courante (boost x2048) voyait le
        // radar fige sur l'ancien voisin : le record ne bouge qu'au
        // lancement suivant, la portee actuelle avance en continu. Avec le
        // max des deux, le voisin suit la progression reelle et les pilotes
        // deja depasses ne reviennent jamais au reset de la portee.
        const meNow = Math.max(maxDistance || 0, calculateDistance() || 0);
        // V3.88 : EXCLUSION DE SA PROPRE LIGNE -- cf formatPilotRadar (le
        // radar visait le joueur lui-meme apres un reset d expedition).
        const myName = (typeof getCompanyName === 'function' ? getCompanyName() : '').toLowerCase();
        const above = (pilotRadarCache || [])
            .filter(e => (e.distance || 0) > meNow && e.name.toLowerCase() !== myName)
            // V3.41 : FIX COMPARATEUR -- l'ancien tri comparait (a.distance -
            // a.distance), toujours 0 : le tri ne faisait RIEN et la case
            // affichait le PREMIER element du fetch (le top 1 du classement
            // distance) au lieu du voisin reel -- meme avec la requete triee
            // par distance descendante, le premier au-dessus du joueur dans
            // l'ordre du fetch est le numero 1, pas le plus proche (retour
            // joueur : 'il affiche le top 1 alors qu il y a 4 joueurs entre
            // lui et moi').
            .sort((a, b) => (a.distance || 0) - (b.distance || 0))[0];
        if (!above) { value.textContent = t('tu es le num\u00e9ro 1 de la distance !'); return; }
        // V3.36 (retour joueur) : affichage CLAIR -- distance RECORD du
        // pilote juste au-dessus, ecart a combler, et TEMPS estime pour le
        // rejoindre a la vitesse actuelle.
        const gap = (above.distance || 0) - meNow;
        const kmS = calculateTravelSpeedKmS();
        const eta = kmS > 0 ? formatEta(gap / kmS) : '?';
        // V3.37 : 'encore +X' RETIRE (retour joueur) -- nom, distance record, temps estime.
        value.textContent = above.name + ' \u00b7 ' + formatNumber(above.distance) + ' km \u00b7 ~' + eta;
    };
    if (pilotRadarCache && now - pilotRadarFetchedAt < 60000) { render(); return; }
    value.textContent = t('Radar : analyse du classement...');
    fetchPilotRadarEntries().then(entries => {
        pilotRadarCache = entries;
        pilotRadarFetchedAt = Date.now();
        render();
    }).catch(() => { render(); });
}
function updateSpaceProgress() {
    // Distance atteignable ecretee au plus haut affiche du run : monotone.
    let reachableDistance = calculateDistance();
    if (reachableDistance >= displayedReachPeak) displayedReachPeak = reachableDistance;
    else reachableDistance = displayedReachPeak;
    // Distance reellement parcourue (ne change qu'au lancement)
    const traveledDistance = maxDistance;
    let progress = calculatePlanetProgress(reachableDistance);
    // Destination a AFFICHER : la premiere planete pas encore debloquee.
    // Apres une nouvelle expedition, la portee retombe a 0 et le calcul brut
    // designe la planete suivante de la portee (ex. la Lune deja atteinte) :
    // on avance alors jusqu'a la premiere destination verrouillee, avec le %
    // de la portee actuelle vers cette destination (pur affichage, les
    // mecaniques continuent d'utiliser calculatePlanetProgress tel quel).
    while (progress.nextPlanet && unlockedPlanets.has(progress.nextPlanet.id)
        && PLANETS.findIndex(p => p.id === progress.nextPlanet.id) < PLANETS.length - 1) {
        const nextIdx = PLANETS.findIndex(p => p.id === progress.nextPlanet.id);
        const target = PLANETS[nextIdx + 1];
        // La nouvelle fusee repart de la TERRE : meme si les planetes
        // precedentes sont deja debloquees, la portee actuelle se construit
        // depuis la Terre. Le % est donc calcule sur la distance TOTAL
        // Terre -> destination, pas depuis la derniere planete debloquee
        // (sinon, au retour de la Terre, le % restait fige ou sautait).
        const pct = Math.min(100, Math.max(0,
            reachableDistance / target.distanceRequired * 100));
        progress = { currentPlanet: PLANETS[0], nextPlanet: target, progressPercent: pct };
    }

    // Afficher la progression vers la PROCHAINE planète : en temps reel sur la
    // distance ACTUELLEMENT atteignable (elle croit a chaque Part gagnee),
    // pas sur la distance parcourue qui ne bouge qu'au lancement.
    // V4.5 (retour proprietaire : 'je suis a 1.4 % de Sirius alors que j'ai
    // une portee de 85 B sur 891 B') : le % affiche etait la progression
    // DEPUIS LA DERNIERE PLANETE ATTEINTE (85-72,5)/(891-72,5) = 1,5 % --
    // incoherent avec le while ci-dessus qui affiche, lui, la portee totale
    // depuis la Terre. Le joueur comprend '% de la destination' comme la
    // progression du voyage complet Terre -> destination : on affiche
    // desormais TOUJOURS reachableDistance / destination.
    // (calculatePlanetProgress reste inchange : il pilote aussi l'animation
    // de voyage qui, elle, interpole bien entre les deux dernieres planetes.)
    if (progress.nextPlanet) {
        progress.progressPercent = Math.min(100, Math.max(0,
            reachableDistance / progress.nextPlanet.distanceRequired * 100));
    }
    const planetDisplay = document.getElementById('current-planet-display');
    const planetText = document.getElementById('current-planet-text');
    const planetBarFill = document.getElementById('header-planet-fill');
    const pct = Math.min(100, Math.max(0, progress.progressPercent));
    const pctText = pct.toFixed(1);
    // Pourcentage effectif de la barre : celui du mode infini quand actif,
    // sinon celui de la planete visee. Sans lui, la barre restait figee a
    // 100 % en suite infinie (pct venait du dernier objectif planetaire).
    let barPct = pct;
    if (planetText) {
        if (progress.nextPlanet) {
            planetText.textContent = `${t('Prochaine destination')} : ${t(progress.nextPlanet.name)} — ${pctText}%`;
        } else if (postVirgoStardust > 0) {
            // Suite infinie (Amas de Virgo depasse) : plus de planete
            // connue devant -- objectif genere = le DOUBLE du record de
            // distance. La case reste vivante : un vrai km a viser, qui
            // recule a chaque nouveau record.
            // V3.25 : la barre utilise reachableDistance ECRETE (displayedReachPeak)
            // -- l'ancien calculateDistance() BRUT faisait RECULER la barre a la
            // fin d'un bonus temporaire (le pic du bonus etait memorise par
            // l'ecrete, mais pctInf le recalculait sans ecrete : chute visible).
            const goalKm = maxDistance > 0 ? maxDistance * 2 : reachableDistance * 2;
            const pctInf = maxDistance > 0 ? Math.min(100, (reachableDistance / goalKm) * 100) : 0;
            barPct = pctInf;
            planetText.textContent = `${t('Double ton record !')} ${formatNumber(goalKm)} km — ${pctInf.toFixed(1)}%`;
        } else {
            planetText.textContent = `${t('Prochaine destination')} : ${t(progress.currentPlanet.name)} — 100%`;
        }
        // Texte trop long pour la case (ex. Nuage d'Oort) : on reduit la
        // police par paliers jusqu'a ce que tout rentre sans ellipsis.
        // Estimation proportionnelle en UNE mesure de layout (1 reflow au
        // lieu d'un par palier de 0.05 rem), puis correction exacte en 1-2
        // passes seulement -- la boucle mesure+ecrivait forcait un reflow
        // a chaque palier toutes les 500 ms.
        const display = planetDisplay || planetText.parentElement;
        if (display) {
            const maxWidth = display.clientWidth - 20;
            if (planetText.__fitWidth !== maxWidth || planetText.__fitText !== planetText.textContent) {
                planetText.__fitWidth = maxWidth;
                planetText.__fitText = planetText.textContent;
                planetText.style.fontSize = '';
                const startFs = 0.95;
                planetText.style.fontSize = startFs + 'rem';
                const w = planetText.getBoundingClientRect().width;
                if (w > maxWidth && w > 0) {
                    let fs = Math.max(0.55, Math.floor((startFs * maxWidth / w) * 20) / 20);
                    planetText.style.fontSize = fs + 'rem';
                    let guard = 0;
                    while (fs > 0.55 && planetText.getBoundingClientRect().width > maxWidth && guard++ < 2) {
                        fs = Math.max(0.55, fs - 0.05);
                        planetText.style.fontSize = fs + 'rem';
                    }
                }
            }
        }
    }
    if (planetDisplay && planetText) planetDisplay.title = planetText.textContent;
    if (planetBarFill) {
        planetBarFill.style.width = barPct + '%';
        // Teinte de la planete visee en RGB pour le fond translucide
        // (ne masque jamais le texte, contrairement a la couleur pleine).
        const tint = (progress.nextPlanet && progress.nextPlanet.color) || '#f59e0b';
        const m = /^#([0-9a-f]{6})$/i.exec(tint);
        const rgb = m
            ? [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16)].join(', ')
            : '245, 158, 11';
        planetBarFill.style.setProperty('--planet-tint', rgb);
    }
    // Mettre a jour la mini-carte : elle montre le RECORD (la plus grande
    // distance reellement parcourue), pas l'avancement de la fusee en
    // construction -- le joueur voit ou ses expeditions passees sont allees.
    updateMiniSpaceMap(traveledDistance);

    // Mettre à jour les stats
    const sidebarDistance = document.getElementById('sidebar-distance');
    const sidebarDistanceMax = document.getElementById('sidebar-distance-max');
    const sidebarDistanceNeeded = document.getElementById('sidebar-distance-needed');
    const sidebarSpeed = document.getElementById('sidebar-speed');
    const sidebarBonus = document.getElementById('sidebar-bonus');
    // Distance encore necessaire pour la prochaine destination : la
    // difference entre la distance exigee par la planete visee et la portee
    // de la fusee en construction (jamais negative).
    if (sidebarDistanceNeeded) {
        // Suite infinie debloquee : plus de destination finale -- la valeur
        // de la case est remplacee par le sigle infini, comme les autres
        // valeurs elle est centree par le CSS existant (.stat-value).
        if (gameFinished) {
            // Suite infinie : l'objectif est de DOUBLER le record -- la case
            // affiche la distance RESTANTE jusqu'a cet objectif (objectif
            // moins la portee actuelle), pas le sigle infini : un vrai
            // compte a rebours de km, vivant a chaque Part gagnee.
            const goalKm = maxDistance > 0 ? maxDistance * 2 : reachableDistance * 2;
            const remaining = Math.max(0, goalKm - reachableDistance);
            sidebarDistanceNeeded.classList.remove('stat-value-infinite');
            rollCounterText(sidebarDistanceNeeded, formatNumber(remaining) + ' ' + t('km'));
        } else {
            sidebarDistanceNeeded.classList.remove('stat-value-infinite');
            const target = progress.nextPlanet ? progress.nextPlanet : progress.currentPlanet;
            const needed = target ? Math.max(0, target.distanceRequired - reachableDistance) : 0;
            rollCounterText(sidebarDistanceNeeded, formatNumber(needed) + ' ' + t('km'));
        }
    }

        if (sidebarDistance) {
        rollCounterText(sidebarDistance, formatNumber(reachableDistance) + ' ' + t('km'));
    }
    if (sidebarDistanceMax) {
        rollCounterText(sidebarDistanceMax, formatNumber(traveledDistance) + ' ' + t('km'));
    }
    if (sidebarSpeed) {
        const curSpeed = calculateTravelSpeedKmS();
        rollCounterText(sidebarSpeed, formatTravelSpeed(curSpeed));
        // Record de vitesse : boosts temporaires RETABLIS (decision du
        // 2024-10 : les records AVEC boost comptent -- le joueur qui
        // combine flare x4 + multiplicateur a le merite de son setup).
        recordMaxTravelSpeed(curSpeed);
    }
    if (sidebarBonus) {
        const totalBonus = 1 + getTotalPlanetBonus();
        sidebarBonus.textContent = formatBonusPct(totalBonus);
    }
    updatePilotRadarTile();
    updateInfiniteBonusTile();
    // V3.5 : indicateur chrono/radar -- le joueur ne savait pas qu'il faut
    // CLIQUER les tuiles pour voir l'ETA/radar. Badge discret sur les tuiles
    // dont l'info est enrichie par une upgrade infinie.
    try {
        const chronoOwned = getGalacticUpgradeLevel('inf-chrono') > 0;
        const radarOwned = getGalacticUpgradeLevel('inf-radar') > 0;
        const markTile = (spanId, show) => {
            const span = document.getElementById(spanId);
            const tile = span ? span.closest('.stat-tile') : null;
            if (!tile) return;
            let badge = tile.querySelector('.sti-hint-badge');
            if (show) {
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'sti-hint-badge';
                    badge.textContent = '\u2139';
                    tile.appendChild(badge);
                }
            } else if (badge) badge.remove();
        };
        markTile('sidebar-distance-needed', chronoOwned);
        // Le badge du Radar de pilote sur la case Distance record est
        // RETIRE (retour joueur) : le radar a desormais SA propre case
        // dediee sous la grille -- plus besoin d'indiquer ou cliquer.
        markTile('sidebar-distance-max', false);
    } catch (e) {}

    // Infos au clic : brancher une seule fois sur chaque tile existante.
    const allTiles = document.querySelectorAll('#space-stats-sidebar .stat-tile, #space-stats-bottom .stat-tile');
    allTiles.forEach(tileEl => {
        if (!tileEl.dataset.infoBound) {
            tileEl.dataset.infoBound = '1';
            tileEl.addEventListener('click', () => toggleStatTileInfo(tileEl));
        }
    });
    checkNextPlanetNotification();
}

// Minimap MODE INFINI : fusée au centre, étoiles scintillantes, logo ∞.
// Le DOM n'est construit qu'une fois (clef dataset), seule l'animation CSS vit.
function renderInfiniteMiniMap(container) {
    if (container.dataset.planetsKey === 'infinite') return;
    container.dataset.planetsKey = 'infinite';
    container.innerHTML = '';
    container.classList.add('infinite');
    // Champ d'etoiles : 70 points de tailles/delais varies, twinkle CSS pur.
    for (let i = 0; i < 70; i++) {
        const star = document.createElement('div');
        star.className = 'inf-star';
        star.style.left = (Math.random() * 100).toFixed(1) + '%';
        star.style.top = (Math.random() * 100).toFixed(1) + '%';
        const size = (1 + Math.random() * 2.2).toFixed(1);
        star.style.width = size + 'px';
        star.style.height = size + 'px';
        star.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
        star.style.animationDuration = (1.8 + Math.random() * 2.4).toFixed(2) + 's';
        container.appendChild(star);
    }
    // Fusée centrale, plus grosse que le vaisseau de la route planetaire.
    const ship = document.createElement('div');
    ship.className = 'spaceship infinite-ship';
    ship.innerHTML = '<img src="images/rocket/Fusée3.webp" alt="Fusée" class="spaceship-img">';
    ship.style.left = '46%';
    container.appendChild(ship);
    // Logo infini a droite.
    const logo = document.createElement('div');
    logo.className = 'inf-logo';
    logo.textContent = '\u221e';
    logo.title = t('Suite infinie');
    container.appendChild(logo);
}

function updateMiniSpaceMap(distance) {
    const container = document.getElementById('mini-space-map');
    if (!container) return;
    // MODE INFINI (Amas de Virgo depasse) : representation dediee -- plus de
    // fenetre de planetes, la route est terminee. Fusée plus grosse au centre,
    // champ d'etoiles scintillantes autour, logo infini a droite.
    if (postVirgoStardust > 0) {
        renderInfiniteMiniMap(container);
        return;
    }
    let spaceship = container.querySelector('.spaceship');
    // Sortie de secours du mode infini (clef posee par renderInfiniteMiniMap)
    if (container.dataset.planetsKey === 'infinite') {
        container.dataset.planetsKey = '';
        container.classList.remove('infinite');
        container.innerHTML = '';
        spaceship = null;
    }
    const progress = calculatePlanetProgress(distance);
    
    // Position des planètes dans la mini-map
    const planetPositions = [18, 50, 82];
    
    // Déterminer les planètes à afficher
    const planetsToShow = [];
    if (progress.currentPlanet) {
        const currentIndex = PLANETS.findIndex(p => p.id === progress.currentPlanet.id);
        if (currentIndex !== -1) {
            planetsToShow.push(PLANETS[currentIndex]);
            if (currentIndex + 1 < PLANETS.length) planetsToShow.push(PLANETS[currentIndex + 1]);
            if (currentIndex + 2 < PLANETS.length) planetsToShow.push(PLANETS[currentIndex + 2]);
        }
    } else {
        // Avant la Lune : afficher Terre (départ), Lune, Mars
        planetsToShow.push(PLANETS[0]);
        if (PLANETS.length > 1) planetsToShow.push(PLANETS[1]);
        if (PLANETS.length > 2) planetsToShow.push(PLANETS[2]);
    }
    
    // Clé pour détecter si les planètes affichées ont changé
    const planetsKey = planetsToShow.map(p => p.id).join(',');
    
    // Ne recréer le DOM (planètes + connexions) que si les planètes changent.
    // Sinon, mettre à jour uniquement la position du vaisseau pour éviter
    // que l'animation CSS ne redémarre toutes les 500ms.
    if (container.dataset.planetsKey !== planetsKey) {
        container.dataset.planetsKey = planetsKey;
        container.innerHTML = '';
        // Changement de fenetre de planetes : le vaisseau est recree
        // (innerHTML = ''), pas de transition de position a animer.
        spaceship = null;

        // Fond stelle : etoiles scintillantes derriere les planetes
        // (meme esprit que le mode infini, plus discret ici : 32 points).
        for (let i = 0; i < 32; i++) {
            const star = document.createElement('div');
            star.className = 'inf-star';
            star.style.left = (Math.random() * 100).toFixed(1) + '%';
            star.style.top = (Math.random() * 100).toFixed(1) + '%';
            const size = (1 + Math.random() * 1.8).toFixed(1);
            star.style.width = size + 'px';
            star.style.height = size + 'px';
            star.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
            star.style.animationDuration = (1.8 + Math.random() * 2.4).toFixed(2) + 's';
            container.appendChild(star);
        }

        // Dessiner les planètes
        planetsToShow.forEach((planet, index) => {
            const planetElement = document.createElement('div');
            planetElement.className = 'space-planet';
            
            const isUnlocked = unlockedPlanets.has(planet.id) || distance >= planet.distanceRequired;
            const isCurrent = progress.currentPlanet && progress.currentPlanet.id === planet.id;
            
            if (isUnlocked) planetElement.classList.add('unlocked');
            if (isCurrent) planetElement.classList.add('current');
            if (planet.id === 'earth') planetElement.classList.add('origin');
            
            let planetHtml = '';
            if (planet.imgPath) {
                planetHtml = `<img src="${planet.imgPath}" class="planet-image" alt="${planet.name}">`;
            } else {
                planetHtml = `<span class="planet-emoji">${planet.emoji}</span>`;
            }
            planetHtml += `<div class="planet-name">${t(planet.name)}</div>`;
            const planetDist = planet.distanceRequired;
            const distLabel = planet.id === 'earth' ? t('Départ') : `${formatNumber(planetDist)} ${t('km')}`;
            planetHtml += `<div class="planet-distance">${distLabel}</div>`;
            
            planetElement.innerHTML = planetHtml;
            planetElement.style.setProperty('--planet-color', planet.color);
            
            const position = planetPositions[index] || (index * 40 + 15);
            planetElement.style.left = `${position}%`;
            planetElement.style.transform = 'translateX(-50%)';
            planetElement.style.textAlign = 'center';
            
            container.appendChild(planetElement);
        });
        
        // Ajouter les lignes de connexion entre les planètes
        for (let i = 0; i < planetsToShow.length - 1; i++) {
            const currentPlanet = planetsToShow[i];
            const nextPlanet = planetsToShow[i + 1];
            
            const isCurrentUnlocked = unlockedPlanets.has(currentPlanet.id) || distance >= currentPlanet.distanceRequired;
            const isNextUnlocked = unlockedPlanets.has(nextPlanet.id) || distance >= nextPlanet.distanceRequired;
            
            const line = document.createElement('div');
            line.className = 'space-connection';
            if (isCurrentUnlocked && isNextUnlocked) {
                line.classList.add('active');
            }
            
            const startPos = planetPositions[i] || (i * 40 + 15);
            const endPos = planetPositions[i + 1] || ((i + 1) * 40 + 15);
            line.style.left = `${startPos}%`;
            line.style.width = `${endPos - startPos}%`;
            container.appendChild(line);
        }
    }
    
    const shouldShowShip = true;
    
    if (shouldShowShip) {
        // Calculer la position du vaisseau
        let shipPosition = 15;
        
        if (progress.currentPlanet) {
            const currentIndex = PLANETS.findIndex(p => p.id === progress.currentPlanet.id);
            
            if (currentIndex > 0 && progress.nextPlanet) {
                const nextIndex = PLANETS.findIndex(p => p.id === progress.nextPlanet.id);
                
                if (nextIndex > currentIndex && nextIndex < currentIndex + 3) {
                    const startPos = planetPositions[0] || 15;
                    const endPos = planetPositions[1] || 50;
                    shipPosition = startPos + (endPos - startPos) * (progress.progressPercent / 100);
                } else {
                    shipPosition = planetPositions[Math.min(currentIndex, 2)] || 50;
                }
            } else if (currentIndex === 0) {
                shipPosition = 15;
            } else {
                shipPosition = planetPositions[Math.min(currentIndex, 2)] || 85;
            }
        } else {
            const firstPlanetPos = planetPositions[0] || 15;
            const secondPlanetPos = planetPositions[1] || 50;
            shipPosition = firstPlanetPos + (secondPlanetPos - firstPlanetPos) * (progress.progressPercent / 100);
        }
        
        if (!spaceship) {
            spaceship = document.createElement('div');
            spaceship.className = 'spaceship';
            spaceship.innerHTML = '<img src="images/rocket/Fusée3.webp" alt="Fusée" class="spaceship-img">';
            container.appendChild(spaceship);
        }
        spaceship.style.left = `${shipPosition}%`;
    } else if (spaceship) {
        spaceship.remove();
    }
}





// ============================================
// UPGRADES MANAGEMENT
// ============================================

// Affiche les nouveaux upgrades des qu'un seuil de production est franchi,
// sans reconstruire la barre a chaque tick (seulement si du nouveau apparait).
function checkNewUpgrades() {
    const container = document.getElementById('upgrades-container');
    if (!container) return;
    const newClickUps = CLICK_UPGRADES.filter(u => totalPartsFromClicks >= u.threshold && !activatedClickUpgrades.includes(u.threshold)).length;
    const newBuildingUps = BUILDING_UPGRADE_THRESHOLDS.reduce((acc, threshold) =>
        acc + BUILDINGS.filter(b => isBuildingUpgradeAvailable(b.id, threshold)).length, 0);
    if (container.childElementCount !== newClickUps + newBuildingUps) {
        renderUpgrades();
    }
    // Rafraichir l'etat actif/grise du bouton "Tout acheter" selon le score
    const btn = document.getElementById('buy-all-upgrades');
    if (btn) {
        const affordable = [score].length && (newClickUps + newBuildingUps) > 0;
        btn.disabled = !canBuyAllUpgrades() || !affordable || !isAnyUpgradeAffordable();
        btn.classList.toggle('affordable', !btn.disabled);
    }
}
function isAnyUpgradeAffordable() {
    const cheapest = getCheapestAvailableUpgradeCost();
    return cheapest !== null && cheapest <= score;
}
function getCheapestAvailableUpgradeCost() {
    let cheapest = null;
    CLICK_UPGRADES.forEach(upgrade => {
        if (totalPartsFromClicks >= upgrade.threshold && !activatedClickUpgrades.includes(upgrade.threshold)) {
            if (cheapest === null || upgrade.cost < cheapest) cheapest = upgrade.cost;
        }
    });
    BUILDING_UPGRADE_THRESHOLDS.forEach(threshold => {
        BUILDINGS.forEach(building => {
            if (isBuildingUpgradeAvailable(building.id, threshold)) {
                const cost = getBuildingUpgradeFixedCost(building.id, threshold);
                if (cheapest === null || cost < cheapest) cheapest = cost;
            }
        });
    });
    return cheapest;
}

function renderUpgrades() {
    const container = document.getElementById('upgrades-container');

    const available = [];

    // Upgrades de clic
    // Deblocage par les Parts gagnees uniquement en cliquant, cumulees depuis
    // le debut du run. Le cout reste le vrai verrou.
    CLICK_UPGRADES.forEach(upgrade => {
        if (totalPartsFromClicks >= upgrade.threshold && !activatedClickUpgrades.includes(upgrade.threshold)) {
            const upgradeIndex = CLICK_UPGRADES.indexOf(upgrade);
            const color = UPGRADE_COLORS[upgradeIndex % UPGRADE_COLORS.length];
            available.push({
                cost: upgrade.cost,
                renderKey: 'click-' + upgrade.threshold,
                render: () => {
                    const newNb = CLICK_UPGRADES.indexOf(upgrade) + 1;
                    const el = createUpgradeElement(color, 'images/cursor.svg', upgrade.name, newNb);
                    const lines = [
                        t(upgrade.name) + ' — ' + t('niveau') + ' ' + newNb,
                        t('+1% de production par clic') + '\n' + formatNumber(upgrade.cost) + ' ' + t('Parts')
                    ];
                    attachTooltip(el, lines.join('\n'));
                    el.onclick = () => buyClickUpgrade(upgrade.threshold, el);
                    return el;
                }
            });
        }
    });

    // Upgrades de buildings
    BUILDING_UPGRADE_THRESHOLDS.forEach(threshold => {
        BUILDINGS.forEach(building => {
            if (isBuildingUpgradeAvailable(building.id, threshold)) {
                const thresholdIndex = BUILDING_UPGRADE_THRESHOLDS.indexOf(threshold);
                const color = getUpgradeTierColor(thresholdIndex);
                const cost = getBuildingUpgradeFixedCost(building.id, threshold);
                available.push({
                    cost,
                    renderKey: 'bup-' + building.id + '-' + threshold,
                    render: () => {
                        const el = createUpgradeElement(color, building.imgPath || '', building.name, thresholdIndex + 1);
                        attachTooltip(el, `${t(building.name)} — ${t('niveau')} ${thresholdIndex + 1} — ×2 ${t('production')} — ${formatNumber(cost)} ${t('Parts')}`);
                        el.onclick = () => buyBuildingUpgrade(building.id, threshold, el);
                        return el;
                    }
                });
            }
        });
    });

    // Tri du moins chere au plus chere
    available.sort((a, b) => a.cost - b.cost);
    // Anti-flicker : chaque clic appelait renderUpgrades qui vidait puis
    // reconstruisait toute la barre -- les <img> des icones etaient recreees
    // et re-chargees a CHAQUE clic sur la piece (tres visible sur mobile).
    // La liste ne change que sur achat/deblocage/changement de langue : on
    // genere une signature et on ne retouche le DOM QUE si elle change.
    const signature = available.map(item =>
        item.cost + '|' + (item.renderKey || '')).join(';') + '|' + gameLanguage;
    if (signature === renderUpgrades.lastSignature) {
        renderBuyAllUpgradesButton(container, available);
        return;
    }
    renderUpgrades.lastSignature = signature;
    container.innerHTML = '';
    available.forEach(item => container.appendChild(item.render()));
    renderBuyAllUpgradesButton(container, available);
}

// Bouton "Tout acheter" : achete en un clic toutes les ameliorations
// abordables, de la moins chere a la plus chere (le score baisse au fur
// et a mesure, donc l'ordre est important). Debloque au 3e lancement.
const BUY_ALL_UNLOCK_LAUNCHES = 3;
function canBuyAllUpgrades() {
    return rocketsLaunched >= BUY_ALL_UNLOCK_LAUNCHES;
}
function renderBuyAllUpgradesButton(container, available) {
    let btn = document.getElementById('buy-all-upgrades');
    if (!canBuyAllUpgrades()) {
        if (btn) btn.remove();
        return;
    }
    const affordable = available.filter(item => item.cost <= score).length;
    if (!btn) {
        btn = document.createElement('button');
        btn.id = 'buy-all-upgrades';
        btn.className = 'buy-all-upgrades-btn';
        btn.textContent = t('Tout acheter');
        btn.onclick = buyAllUpgrades;
        container.parentNode.insertBefore(btn, container.nextSibling);
    }
    btn.disabled = affordable === 0;
    btn.classList.toggle('affordable', affordable > 0);
}
function buyAllUpgrades() {
    if (!canBuyAllUpgrades()) return;
    // Reconstituer la liste complete des ameliorations disponibles
    const available = [];
    CLICK_UPGRADES.forEach(upgrade => {
        if (totalPartsFromClicks >= upgrade.threshold && !activatedClickUpgrades.includes(upgrade.threshold)) {
            available.push({ kind: 'click', threshold: upgrade.threshold, cost: upgrade.cost });
        }
    });
    BUILDING_UPGRADE_THRESHOLDS.forEach(threshold => {
        BUILDINGS.forEach(building => {
            if (isBuildingUpgradeAvailable(building.id, threshold)) {
                available.push({ kind: 'building', buildingId: building.id, threshold, cost: getBuildingUpgradeFixedCost(building.id, threshold) });
            }
        });
    });
    available.sort((a, b) => a.cost - b.cost);
    let bought = 0;
    // Achat successif du moins cher : a chaque achat le score baisse, ce
    // qui peut rendre les suivantes inabordables. On s'arrete des que le
    // prochain n'est plus payable.
    while (available.length && available[0].cost <= score) {
        const item = available.shift();
        if (item.kind === 'click') {
            if (!activatedClickUpgrades.includes(item.threshold) && score >= item.cost) {
                score -= item.cost;
                activatedClickUpgrades.push(item.threshold);
                bought++;
            }
        } else if (isBuildingUpgradeAvailable(item.buildingId, item.threshold) && score >= item.cost) {
            score -= item.cost;
            if (!buildingUpgrades[item.buildingId]) buildingUpgrades[item.buildingId] = [];
            buildingUpgrades[item.buildingId].push(item.threshold);
            bought++;
            // Feedback visuel identique a l'achat unitaire : pop x2 XXL a
            // gauche de la case du batiment (les cases existent encore ici,
            // le re-render vient plus tard).
            showUpgradeBoughtFeedback(
                null,
                getUpgradeTierColor(BUILDING_UPGRADE_THRESHOLDS.indexOf(item.threshold)),
                item.buildingId
            );
        }
    }
    if (bought === 0) {
        Sounds.lose();
        showToast("\u274c " + t("Pas assez de Parts"));
        return;
    }
    invalidateBuildingGainsCache();
    updateDisplay();
    saveGame();
    hideTooltip();
    renderUpgrades();
    updateAllBuildingButtons();
    checkTrophies();
    showToast("\u2705 " + bought + " " + t("ameliorations achetees"));
}

function createUpgradeElement(color, imgSrc, altText, levelBadgeText) {
    const el = document.createElement('div');
    el.className = 'upgrade-icon';
    el.style.borderColor = color;
    el.style.boxShadow = `var(--shadow), 0 0 6px ${color}`;

    const img = document.createElement('img');
    img.className = 'upgrade-img';
    img.src = imgSrc;
    img.alt = altText;
    el.appendChild(img);

    const levelBadge = document.createElement('span');
    levelBadge.className = 'upgrade-level';
    levelBadge.textContent = levelBadgeText;
    levelBadge.style.background = color;
    el.appendChild(levelBadge);

    return el;
}

function attachTooltip(element, text) {
    if (!IS_TOUCH) {
        element.addEventListener('mouseenter', (e) => {
            const rect = e.target.getBoundingClientRect();
            // Tooltip des upgrades AU-DESSUS de la case (regle par defaut) :
            // le clamp interne le rabat sous la case seulement s'il ne tient
            // pas entre la case et le haut de l'ecran.
            showTooltip(text, rect.left + rect.width / 2, rect.top, { anchorBottom: rect.bottom });
        });
        element.addEventListener('mouseleave', hideTooltip);
    }
    if (IS_TOUCH) {
        element.addEventListener('click', (e) => {
            if (touchTooltipElement !== element) {
                // 1er tap : afficher l'info, bloquer l'achat
                showTouchTooltip(element, text);
                e.stopImmediatePropagation();
                e.preventDefault();
            } else {
                // 2e tap : acheter (laisser passer le onclick)
                touchTooltipElement = null;
            }
        });
    }
}

// Tooltip tactile : sur mobile, le 1er tap affiche l'info, le 2e achète.
let touchTooltipElement = null;
function showTouchTooltip(element, text) {
    const rect = element.getBoundingClientRect();
    showTooltip(text, rect.left + rect.width / 2, rect.top, { anchorBottom: rect.bottom });
    touchTooltipElement = element;
}
document.addEventListener('touchstart', (e) => {
    if (!e.target.closest('.upgrade-icon') && !e.target.closest('.building-item')) {
        hideTooltip();
        touchTooltipElement = null;
    }
}, { passive: true });

// ============================================
// BONUSES MANAGEMENT
// ============================================

// V3.11 : PLAFOND DOUX x2048 -- uniquement sur la partie COMETES du
// produit. Les bonus de CONTRATS (contract-mult / contract-click)
// comptent TOUJOURS integralement, plafond ou pas (retour playtest).
// Atteindre 2048 par les cometes seules reste possible mais
// extremement difficile : la penalite de chance de spawn cumulee
// (cometsInterceptedWindow) auto-limite la cascade de x4.
const TEMP_MULT_CAP = () => wasmConst('temp_mult_cap', 2048);
function isContractBonus(b) { return b.id === 'contract-mult' || b.id === 'contract-click'; }
function rebuildAutoMultipliers() {
    resetMultipliers();
    let prodAccum = 1;
    let clickAccum = 1;
    activeRandomBonuses.forEach(bonus => {
        if ((bonus.effect === 'auto' || bonus.effect === 'both' || bonus.effect === 'multiplier') && bonus.multiplier) {
            // Les contrats ne comptent pas dans prodAccum : ils sont hors plafond.
            if (isContractBonus(bonus) || prodAccum * bonus.multiplier <= TEMP_MULT_CAP()) {
                autoMultipliers.push(bonus.multiplier);
                if (!isContractBonus(bonus)) prodAccum *= bonus.multiplier;
            }
        }
        if ((bonus.effect === 'click' || bonus.effect === 'both') && bonus.multiplier) {
            if (isContractBonus(bonus) || clickAccum * bonus.multiplier <= TEMP_MULT_CAP()) {
                clickMultipliers.push(bonus.multiplier);
                if (!isContractBonus(bonus)) clickAccum *= bonus.multiplier;
            }
        }
    });
    updateAutoMultiplier();
    updateClickMultiplier();
}

let __cometTopOffsetCache = null;
function cometContainerTopOffset() {
    if (__cometTopOffsetCache === null) {
        const el = document.getElementById('random-bonuses');
        __cometTopOffsetCache = el ? el.getBoundingClientRect().top : 0;
    }
    return __cometTopOffsetCache;
}
window.addEventListener('resize', () => { __cometTopOffsetCache = null; });
function spawnRandomBonus(shower, isContract) {
    // Pendant la cinematique de lancement, aucun bonus ne spawn.
    if (gameplayPaused) return;
    // MODELE D'ORIGINE : les cometes de contrat sont des cometes de pluie
    // standard -- pas de ref, pas de comportement special. (L'ancien code
    // pre-V1 n'avait qu'un argument.) On garde isContract uniquement pour
    // le marquage dataset (pas de gain de parts) -- comportement identique.
    // Pluie de comètes : bonus instantané uniquement (pas de flare, pas de
    // cumul de multiplicateurs), look distinct, récompense généreuse.
    let bonus = shower
        ? { id: "meteor", symbol: "\ud83c\udf20", name: "Pluie de météores", effect: "instant", type: "meteor", colorClass: "meteor" }
        : RANDOM_BONUSES[Math.floor(Math.random() * RANDOM_BONUSES.length)];
    // Les bonus temporaires se cumulent : un flare peut apparaitre meme si
    // un autre est deja actif (multiplicateurs multiplies entre eux).

    // La comète traverse l'écran en diagonale de haut en bas
    // La traînée part du haut et descend jusqu'en bas
    // V3.81 (perf, retour proprietaire : 'setTimeout handler took 120ms a
    // chaque comete') : getBoundingClientRect().top a CHAQUE spawn forcait
    // un reflow complet -- le conteneur etant position:fixed top:var(--top-height),
    // sa valeur ne change qu'au RESIZE. Cache statique + invalidation.
    const containerHeight = window.innerHeight - cometContainerTopOffset();
    // GEOMETRIE D'ORIGINE (pre-V1) : entree par le TOUT HAUT, sortie tout
    // en bas, diagonale 60 deg, depart dans la moitie du cote de depart.
    // Pas de bande centrale, pas de detection mobile -- c'est cette
    // geometrie simple qui marchait sur tous les ecrans.
    // -330 (et non -180) : la plus grande comete fait desormais 300px
    // (contrats) -- a -180, le conteneur DEPASSAIT sous le bord haut et la
    // comete etait visible "en train d'apparaitre" des le spawn. -330 cache
    // entierement le plus grand conteneur (300px + marge) avant l'entree.
    const startY = -330;
    const endY = containerHeight + 330;
    const verticalTravel = endY - startY;
    // Diagonale ~70 deg (+10 deg vers le bas, demande mobile) : la comete
    // descend plus verticalement, reste plus longtemps dans la zone jouable
    // -- sur petit ecran la diagonale 60 deg sortait trop vite par les cotes.
    // V3.87 (retour proprietaire : 'en mobile fais attention aux positions
    // d apparition des cometes, pas en dehors de l ecran') : le trajet
    // horizontal etait PROPORTIONNEL au trajet vertical -- sur un ecran
    // etroit et haut (mobile), il depassait la LARGEUR de l ecran (ex :
    // 512 px de traversee sur un 400 px) et la comete volait majoritairement
    // HORS ECRAN. PLAFOND : la traverssee horizontale ne peut pas exceder
    // 75% de la largeur -- la diagonale se resserre sur petit ecran et
    // TOUT le vol reste visible.
    const horizontalTravel = Math.min(verticalTravel * 0.364, Math.max(60, window.innerWidth * 0.75));
    let goRight = Math.random() < 0.5;
    let startX, endX;
    // Bornes GARANTIES : la trajectoire COMPLETE tient dans l ecran --
    // startX >= marge et endX <= largeur - marge (aller a droite),
    // symetrique a gauche. Les anciennes formules (innerWidth*0.5 etc.)
    // ne bornaient pas le trajet et laissaient la sortie hors cadre.
    const xMargin = 30;
    const usableW = Math.max(0, window.innerWidth - horizontalTravel - xMargin * 2);
    if (shower) {
        // PLUIES (naturelles et contrats) : diversite maximale -- le depart
        // balaie TOUTE la largeur exploitable dans le sens du vol (retour
        // joueur : les cometes de contrat tombaient quasiment toutes au
        // meme endroit).
        if (goRight) {
            startX = xMargin + Math.random() * usableW;
            endX = startX + horizontalTravel;
        } else {
            startX = xMargin + horizontalTravel + Math.random() * usableW;
            endX = startX - horizontalTravel;
        }
    } else if (goRight) {
        startX = xMargin + Math.random() * usableW;
        endX = startX + horizontalTravel;
    } else {
        startX = xMargin + horizontalTravel + Math.random() * usableW;
        endX = startX - horizontalTravel;
    }
    // V3.6 : cometes SIMULTANEES decalees -- quand une comete est deja a
    // l'ecran (Ciel frequente, 2 isolees), la nouvelle demarre a l'OPPOSE
    // horizontal de la premiere : plus de superposition au spawn, chacune
    // reste cliquable dans sa moitie d'ecran.
    try {
        // Le decalage OPPOSE ne concerne que les cometes ISOLEES simultanees
        // (Ciel frequente : 2 cometes isolees a l'ecran). Les PLUIES ne
        // passent PAS ici : chaque comete de pluie a deja sa propre trajectoire
        // diversifiee ci-dessus -- l'ancien bloc les repondait toutes au
        // meme couloir etroit "oppose-vers-centre" des qu'une comete
        // precedent etait encore en vol (dans une pluie : presque toujours).
        const existing = !shower ? document.querySelector('#random-bonuses .random-bonus:not(.shower)') : null;
        if (existing) {
            // V3.84 : ZERO lecture de layout -- le conteneur est
            // position:fixed left:0 right:0 (largeur = innerWidth) et la
            // position de naissance de la comete existante est RELUE depuis
            // son dataset (notre propre valeur de spawn, pas une mesure).
            const contW = window.innerWidth;
            const exStart = parseFloat(existing.dataset.startX);
            const exMid = isFinite(exStart) ? exStart : contW / 2;
            const contMid = contW / 2;
            const firstIsLeft = exMid < contMid;
            // V3.17 (retour joueur) : la comete supplementaire DOIT rester
            // attrapable. Avant, elle heritait de la direction aleatoire :
            // nee dans la moitie gauche en allant a gauche (ou inversement),
            // elle traversait le bord et disparaissait. Desormais elle part
            // de sa moitie et VOLE VERS LE CENTRE -- et le depart est
            // recale pour que TOUTE la trajectoire tienne dans l'ecran
            // (horizontalTravel de marge du cote du bord de sortie).
            const half = Math.max(0, contW / 2 - 100);
            if (firstIsLeft) {
                // la 2e nait a DROITE et vole vers la gauche (centre)
                goRight = false;
                startX = Math.min(
                    contW - horizontalTravel - 60,
                    contW / 2 + 60 + Math.random() * Math.max(0, half - 60));
                endX = startX - horizontalTravel;
            } else {
                // la 2e nait a GAUCHE et vole vers la droite (centre)
                goRight = true;
                startX = Math.max(
                    horizontalTravel + 60,
                    Math.random() * Math.max(0, half - 60));
                endX = startX + horizontalTravel;
            }
        }
    } catch (e) {}
    let travelX = endX - startX;

    // Angle de vol REEL (la bande peut resserrer la diagonale) : le sprite
    // et les queues sont orientes via --comet-rot, et le noyau (a ~86% de
    // la largeur du sprite horizontal) est recalcule via --nx/--ny pour
    // que coma, queues et trainee suivent exactement la trajectoire.
    const travelY0 = endY - startY;
    const flightDeg = Math.atan2(travelY0, Math.abs(travelX)) * 180 / Math.PI;
    const cometRot = goRight ? flightDeg : 180 - flightDeg;
    const nucFrac = 0.358;
    const nucX = 0.5 + (goRight ? 1 : -1) * nucFrac * Math.cos(flightDeg * Math.PI / 180);
    const nucY = 0.5 + nucFrac * Math.sin(flightDeg * Math.PI / 180);
    // V4.3 (retour proprietaire : 'les cometes doivent toujours etre
    // visibles dans l ecran apres leur point de depart') : le NOYAU est
    // decale par rapport au coin du conteneur (nucX ~ +0.358 en vol vers la
    // droite) -- selon la taille du conteneur, un depart trop pres du bord
    // gauche (goRight) ou droit (goLeft) naittait avec son noyau HORS de
    // l ecran. On RECALE le depart horizontal pour que le noyau du sprite
    // soit DANS le viewport des la premiere frame : marge = decalage du
    // noyau, appliquee du cote d ou vient la comete.
    const contW = 240; // largeur conteneur comete (reference desktop; mobile plus petit => marge conservee)
    const nucleusOffset = (goRight ? 1 : -1) * (nucX - 0.5) * contW;
    const nucleusSafeMargin = Math.abs(nucleusOffset) + 15;
    if (goRight) {
        startX = Math.max(nucleusSafeMargin, startX);
        endX = startX + horizontalTravel;
    } else {
        startX = Math.min(window.innerWidth - nucleusSafeMargin, startX);
        endX = startX - horizontalTravel;
    }
    travelX = endX - startX;
    // V4.4 (retour proprietaire : cometes hors ecran sur mobile) : sur un
    // ecran tactile etroit, la marge "noyau" (V4.3) etait calculee avec une
    // largeur de conteneur fixe de 240px -- sur mobile le conteneur est
    // bien plus petit, la marge etait donc surestimee et ne couvrait pas
    // le vrai decalage du noyau : la comete naissait encore partiellement
    // hors ecran. De plus, si horizontalTravel >= innerWidth - 2*marge, le
    // reclamp pouvait inverser la trajectoire (startX > endX). Garde-fou
    // mobile : on borne startX/endX pour que le CONTENEUR ENTIER (et donc
    // le noyau) reste dans le viewport pendant tout le vol.
    if (IS_TOUCH || window.innerWidth <= 768) {
        const contWReal = Math.min(240, window.innerWidth * 0.5);
        const m = Math.abs((goRight ? 1 : -1) * (nucX - 0.5) * contWReal) + 15;
        const minX = m, maxX = window.innerWidth - contWReal + m - contWReal; // borne droite du conteneur
        const rightBound = window.innerWidth - m - contWReal;
        if (goRight) {
            startX = Math.min(Math.max(startX, minX), Math.max(minX, rightBound - horizontalTravel));
            endX = startX + horizontalTravel;
        } else {
            startX = Math.max(Math.min(startX, rightBound), minX + horizontalTravel);
            endX = startX - horizontalTravel;
        }
        travelX = endX - startX;
    }
    // Cometes de contrat : plus rapides (4 s au lieu de 6 s sur un vol
    // PC de reference), plus dures a intercepter -- le contrat doit se
    // mEriter.
    // DUREE PROPORTIONNELLE A LA DISTANCE REELLE : sur mobile la diagonale
    // de traverse est ~2x plus courte que sur PC (ecran petit) -- a duree
    // fixe, la comete paraissait 2x plus LENTE que la reference. On cale
    // la duree sur une vitesse constante (px/s de reference PC ~ 800 px/s
    // de vol, moins pour les cometes de contrat, plus rapides).
    // DUREE D'ORIGINE (pre-V1) : FIXE -- 4 s pour les cometes de contrat,
    // 6 s pour les cometes naturelles. La duree calculee selon la
    // geometrie de l'ecran rendait les cometes invisibles ou figees sur
    // certains PC portables ; la duree fixe marchait sur tous les ecrans.
    const isContractComet = shower && contractState.active
        && (contractState.active.typeId === 'comets' || contractState.active.typeId === 'shower');
    // Cometes de contrat MOBILE : 5.5 s (au lieu de 4 s) -- sur petit
    // ecran le vol est ~2x plus court, la duree fixe 4 s les rendait trop
    // rapides a intercepter au doigt. Desktop garde 4 s.
    const isMobileView = typeof isMobileLayout === 'function' && isMobileLayout();
    const duration = isContractComet ? (isMobileView ? 5500 : 4000) : 6000;


    const bonusElement = document.createElement('div');
    bonusElement.className = `random-bonus comet ${bonus.colorClass}` + (shower ? ' shower' : '');
    if (isContract) {
        bonusElement.dataset.contractComet = '1';
        // Classe dediee : les cometes de CONTRAT sont plus grandes (300px)
        // que les naturelles (240px) -- contrat = mini-jeu de precision,
        // la taille compense la vitesse (4 s de vol).
        bonusElement.classList.add('contract-comet');
    }
    if (!goRight) bonusElement.classList.add('reverse');
    bonusElement.style.setProperty('--comet-rot', cometRot.toFixed(2) + 'deg');
    bonusElement.style.setProperty('--nx', (nucX * 100).toFixed(2) + '%');
    bonusElement.style.setProperty('--ny', (nucY * 100).toFixed(2) + '%');
    // Structure detaillee inspiree des vraies cometes :
    // - chevelure (coma) : halo diffus autour du noyau
    // - queue de plasma continue attachee derriere le noyau, orientee
    //   dans l'axe oppose au vol
    // - queue de poussiere : particules qui derivent vers l'arriere
    bonusElement.innerHTML = '<img src="images/effects/comete.webp" class="comet-img" alt="Comete">'
        + '<div class="comet-coma"></div>'
        + '<div class="comet-tail-plasma"></div>'
        + '<div class="comet-tail-dust"></div>';
    bonusElement.style.left = `${startX}px`;
    bonusElement.style.top = `${startY}px`;
    // V3.84 : geometrie persistee -- le bloc des cometes simultanees
    // relisait getBoundingClientRect de la comete existante pour savoir
    // dans quelle moitié elle est nee ; cette lecture de layout au
    // milieu d un handler qui vient d ecrire le DOM forcait un reflow
    // (retour proprietaire : 'il m en reste un quand la comete apparait').
    // startX est NOTRE valeur : on la stocke, pas besoin de la re-mesurer.
    bonusElement.dataset.startX = String(startX);

    document.getElementById('random-bonuses').appendChild(bonusElement);

    // Animation de traversée en diagonale en transform (compositee GPU,
    // comme le missile) : animer left/top forcerait le layout a chaque
    // frame, la comete saccaderait et le point de rendez-vous du missile
    // serait rate des que le thread principal charge (pluie, trainee).
    const travelY = endY - startY;
    // FIX race condition : la transition etait installee puis le transform
    // applique DANS LE MEME callback rAF que l'ajout au DOM. Sous charge
    // (PC portable pendant les pluies, frames coalesces), le navigateur
    // recalcule le style UNE SEULE FOIS : la transition etait SUPPRIMEE
    // et la comete sautait directement a sa position finale (hors ecran)
    // -- "des cometes n'apparaissent pas". Les etapes doivent etre
    // separees par un reflow EXPLICITE (void offsetWidth) entre
    // l'installation de la transition et l'application du transform :
    // le navigateur ne peut plus fusionner les deux etats.
    bonusElement.style.transition = `transform ${duration}ms linear`;
    void bonusElement.offsetWidth;
    bonusElement.style.transform = `translate(${travelX}px, ${travelY}px)`;
    // V3.90 (perf, retour proprietaire : reflows ~30ms en serie a chaque
    // comete) : le trail lisait bonusElement.getBoundingClientRect() TOUTES
    // LES 60 MS pendant toute la vie de la comete -- pendant une pluie,
    // jusqu a 12 cometes simultanees = ~120 lectures de layout/seconde,
    // chacune forcant un reflow (les particules du trail ecrivent le DOM
    // entre deux lectures = layout thrashing). Or la position de la comete
    // est DETERMINISTE : transition transform lineaire de duree connue
    // demarree a un instant connu. On stocke les parametres de vol et le
    // trail CALCULE la position au lieu de la MESURER : zero lecture de
    // layout, plus un seul reflow explicite (celui de l installation de la
    // transition, necessaire).
    bonusElement.dataset.flightStart = String(Date.now());
    bonusElement.dataset.flightDur = String(duration);
    bonusElement.dataset.baseLeft = String(startX);
    bonusElement.dataset.baseTop = String(startY);
    bonusElement.dataset.flightDx = String(travelX);
    bonusElement.dataset.flightDy = String(travelY);

    // Queue de poussiere : particules frequentes a vie longue, qui
    // DERIVENT vers l'arriere du noyau (rejetees dans l'axe oppose au
    // vol) et s'ecartent legerement sur les cotes -- comme la queue
    // reelle d'une comete, courbee et diffuse, pas un chapelet de
    // cercles fixes.
    // Performance : la traIne etait LE goulot d'etranglement de la pluie
    // (12 cometes x 2 particules / 16 ms ~ 1500 nodes DOM/s, chacune avec son
    // rAF + setTimeout). Nouvelle approche : un intervalle serre en absolute
    // (60 ms), UNE particule par tick, et un POOL de particules recyclees —
    // zero allocation en regime etabli, le navigateur ne gere plus que
    // ~20 elements persistants au lieu de creer/detruire 1500 par seconde.
    const TRAIL_LIFE_MS = 900;
    // Direction REELLE du vol (normalisee) : la derive de la trainee doit
    // etre colineaire a la trajectoire, pas a un angle 60 deg fixe -- la
    // bande centrale resserree la diagonale et les cometes de contrat
    // volent plus vite, si bien que la trainee derivait HORS de l'axe.
    const flightLen = Math.hypot(travelX, travelY0) || 1;
    // travelX est SIGNE : dirVX en derive directement, PAS de facteur
    // (goRight ? 1 : -1) -- ce facteur datait de la version ou travelX
    // etait un absolu ; melange aux deux systemes, la trainee derivait
    // vers l'AVANT du vol en sens droite->gauche.
    const dirVX = travelX / flightLen;
    const dirVY = travelY0 / flightLen;
    // Fraction du noyau dans le conteneur (identique aux variables CSS --nx/--ny)

    const trailPool = [];
    const trailInUse = [];
    // V3.90 : TAILLE LUE UNE SEULE FOIS -- elle ne change pas pendant le
    // vol (le sprite est fixe, seul le transform bouge). L ancien code
    // re-mesurait rect.width a CHAQUE tick de 60 ms.
    const spriteRect0 = bonusElement.getBoundingClientRect();
    const spriteW = spriteRect0.width;
    const spriteH = spriteRect0.height;
    // Les particules du trail sont position: FIXED (coordonnees VIEWPORT)
    // mais baseLeft/baseTop sont relatives au CONTENEUR des cometes : on
    // convertit UNE FOIS (l ecart conteneur->viewport ne change pas pendant
    // le vol, le conteneur est position:fixe).
    const contOffsetX = spriteRect0.left - (parseFloat(bonusElement.dataset.baseLeft) || 0);
    const contOffsetY = spriteRect0.top - (parseFloat(bonusElement.dataset.baseTop) || 0);
    const flightStart = parseFloat(bonusElement.dataset.flightStart) || 0;
    const flightDur = Math.max(1, parseFloat(bonusElement.dataset.flightDur) || 1);
    const baseLeft = (parseFloat(bonusElement.dataset.baseLeft) || 0) + contOffsetX;
    const baseTop = (parseFloat(bonusElement.dataset.baseTop) || 0) + contOffsetY;
    const flightDx = parseFloat(bonusElement.dataset.flightDx) || 0;
    const flightDy = parseFloat(bonusElement.dataset.flightDy) || 0;
    // V4.1 (retour proprietaire : 'les cometes laguent un poil / pas a
    // 60 fps') : le trail tournait sur setInterval(60 ms) -- 16 ticks/s,
    // NON synchronise au vsync, qui derive sous charge -- la trainee
    // paraissait saccadee. Boucle requestAnimationFrame : CHAQUE frame
    // du navigateur calcule la position exacte de la comete (transition
    // CSS lineaire = position deterministe), et des particules sont
    // spawnes avec un ESPACEMENT TEMPOREL (TRAIL_SPAWN_MS) pour garder
    // la meme densite qu avant. TRAIL_LIFE_MS est conserve.
    const TRAIL_SPAWN_MS = 55;   // densite de spawn (~1 generation/55 ms)
    let lastSpawnAt = 0;
    let trailRafId = 0;
    const trailTick = () => {
        trailRafId = requestAnimationFrame(trailTick);
        // Mode degrade : pas de trainee du tout -- la comete garde son
        // propre halo CSS, la lecture du mini-jeu reste intacte.
        if (typeof PerfMonitor !== 'undefined' && PerfMonitor.lowPerf) return;
        // Espacement des spawns : la boucle tourne a 60 fps mais les
        // particules naissent au rythme TRAIL_SPAWN_MS (meme densite
        // visuelle qu avec l ancien setInterval 60 ms, sans la derive).
        const spawnNow = performance.now();
        const doSpawn = (spawnNow - lastSpawnAt) >= TRAIL_SPAWN_MS;
        if (doSpawn) lastSpawnAt = spawnNow;
        // V3.90 : POSITION CALCULEE, plus MESUREE -- la transition CSS est
        // lineaire : position = base + progression * distance. Aucun
        // getBoundingClientRect dans cette boucle (l ancien en faisait un
        // toutes les 60 ms par comete = layout thrashing pendant les
        // pluies, jusqu a 120 lectures de layout/seconde).
        const prog = Math.min(1, (Date.now() - flightStart) / flightDur);
        // V4.1bis (retour proprietaire : 'les poussieres de trainee sont
        // trop sur l AVANT de la comete') : les particules naissaient
        // PILE sur le noyau -- pendant leurs premieres frames elles
        // apparaissaient par-dessus le point brillant (l'avant visuel de
        // la comete) avant de derriere en arriere. Naissance en RETRAIT :
        // chaque particule nait deja ~45px DERRIERE le noyau dans l'axe
        // oppose au vol, et continue de derriere en arriere -- la trainee
        // reste entierement dans le sillage, jamais sur l avant.
        const RETRY_OFFSET = 45;
        const cx = baseLeft + flightDx * prog + spriteW * nucX - dirVX * RETRY_OFFSET;
        const cy = baseTop + flightDy * prog + spriteH * nucY - dirVY * RETRY_OFFSET;
        // Reference 240px (taille desktop actuelle des cometes) : les
        // particules grandissent avec la comete au lieu d'etre plafonnees.
        const tsc = Math.max(0.6, Math.min(1.33, spriteW / 240));
        // Deux particules par spawn (coeur + poussiere) : la trainee reste
        // dense sur toute la trajectoire. Le pool recycle, le cout DOM est
        // borne (~2 particules x TRAIL_LIFE_MS / TRAIL_SPAWN_MS).
        if (doSpawn) for (let pi = 0; pi < 2; pi++) {
        const isCore = (pi === 0);
        let trail = trailPool.pop();
        if (!trail) {
            trail = document.createElement('div');
        }
        // Une particule recyclee a ete DETACHEE du DOM au moment de son
        // recyclage (old.remove()) : sans reattachement ici, elle restait
        // invisible pour toujours -- la trainee ne restait visible que
        // pendant la premiere generation (~TRAIL_LIFE_MS), puis plus rien.
        if (!trail.isConnected) document.body.appendChild(trail);
        trail.className = 'comet-trail' + (isCore ? ' core' : ' dust');
        trail.style.width = ((isCore ? 20 : 11) * tsc).toFixed(1) + 'px';
        trail.style.height = ((isCore ? 20 : 11) * tsc).toFixed(1) + 'px';
        const drift = (40 + Math.random() * 70) * tsc;
        const spread = ((Math.random() * 2 - 1) * 26) * tsc;
        // Reset de l'etat ANIM du pool : repositionner puis reactiver la
        // transition dans le frame suivant (forcage du reflow via offsetWidth).
        trail.style.transition = 'none';
        trail.style.opacity = '1';
        trail.style.left = `${cx}px`;
        trail.style.top = `${cy}px`;
        trail.style.transform = 'translate(-50%, -50%)';
        // V4.1 : PLUS DE REFLOW FORCE -- l ancien 'void offsetWidth'
        // forcait le layout 2x par tick (2 particules) = la cause
        // principale du micro-lag du trail. Le double-rAF produit le
        // meme reset de transition sans toucher au layout.
        trail.style.transition = '';
        requestAnimationFrame(() => { requestAnimationFrame(() => {
            trail.style.opacity = '0';
            trail.style.transform = `translate(-50%, -50%) translate(${(-dirVX * drift + -dirVY * spread * 0.55).toFixed(1)}px, ${(-dirVY * drift + dirVX * spread * 0.55).toFixed(1)}px) scale(0.2)`;
        }); });
        trailInUse.push(trail);
        // Recyclage par AGE REEL : l'ancien test sur style.opacity === '0'
        // etait vrai DES le lancement de la transition (la cible etant 0),
        // si bien que chaque particule etait recyclee au tick suivant --
        // la trainee ne faisait jamais plus de 1-2 particules de long et
        // les "particules derriere la comete" n'apparaissaient que tres
        // brievement. Une particule vit TRAIL_LIFE_MS, point.
        const now = performance.now();
        trail.dataset.born = String(now);
        while (trailInUse.length > 0) {
            const old = trailInUse[0];
            const born = parseFloat(old.dataset.born || '0');
            if (now - born < TRAIL_LIFE_MS) break;
            if (old.isConnected) old.remove();
            trailPool.push(trailInUse.shift());
        }
        }
    };
    trailRafId = requestAnimationFrame(trailTick);

    const timeout = setTimeout(() => {
        cancelAnimationFrame(trailRafId);
        bonusElement.remove();
        trailInUse.forEach(t => { t.remove(); });
        trailInUse.length = 0;
        // Contrat "Protection de la fusee" : une comete qui traverse sans
        // etre interceptee frappe la fusee — defaut PARFAIT, le contrat echoue
        // immediatement. C'est ce qui le distingue de la "Survie a la pluie"
        // ou rater des cometes ne fait perdre que la recolte.
        // La comete n'agit que sur le contrat qui l'a planifiee, et
        // seulement s'il est toujours l'actif (sinon contrat suivant fausse).
        const c = contractState.active;
        if (shower && bonusElement.dataset.collected !== '1') {
            // Cometes ratees HORS defense parfaite (pluie naturelle, contrat
            // shower) : petit son de perte pour signaler le manque a gagner.
            if (!c || c.typeId !== 'comets') Sounds.lose();
        }
        if (shower && c && c.typeId === 'comets' && bonusElement.dataset.collected !== '1') {
            c.progress = -Infinity; // marque l'echec pour updateContractProgress
            c.failed = true;
            failContract();
        }
        // Contrat "Survie a la pluie" : cette comete vient de finir sa course
        // sans etre attrapee. Des que la cible n'est plus atteignable --
        // progression + cometes encore rattrapables (en vol + a venir) --
        // le contrat est perdu : on n'attend PAS la fin des 30 secondes du
        // chrono, on arrete net des la premiere comete decisive ratee.
        if (shower && c && c.typeId === 'shower') {
            c.showerInFlight = Math.max(0, (c.showerInFlight || 0) - 1);
            const stillCatchable = c.showerInFlight
                + Math.max(0, (c.showerTotal || 0) - (c.showerLaunched || 0));
            if (c.progress + stillCatchable < c.target) {
                c.failed = true;
                failContract();
            }
        }
    }, duration);

    bonusElement.onclick = () => {
        if (bonusElement.dataset.collected === '1') return;
        bonusElement.dataset.collected = '1';
        // Hitbox DESACTIVEE immediatement : apres le clic, la comete reste
        // ~800 ms a l'ecran (vol du missile + explosion + fade) et son
        // onclick interceptait les clics destines aux cometes VOISINES qui
        // passent derriere elle -- pendant une pluie de contrat, des
        // interceptions etaient perdues pour rien. pointer-events: none
        // rend la zone cliquable a travers.
        bonusElement.style.pointerEvents = 'none';
        // Le timeout de fin de course est coupe des le clic : il ne doit pas
        // retirer la comete pendant que le missile est en vol.
        clearTimeout(timeout);
        // Interception en vol : la comete NE S'ARRETE PAS, elle continue sa
        // transition. Le missile calcule un point de rendez-vous sur sa
        // trajectoire future et la detruit en plein vol.
        interceptCometWithMissile(bonusElement, () => {
            // Impact : la comete disparait pile au point de rendez-vous, remplacee
            // par l'explosion. On fige sa position ACQUISE (pas de teleportation,
            // la transition est coupee sur place), puis fondu de sortie.
            cancelAnimationFrame(trailRafId);
            // Le vol est porte par transform. On fige la comete a sa position
            // ACQUISE sans reparser left/top (le parse px->NaN donnait un
            // transform invalide : sprite teleporte a sa position de DEPART,
            // fige ~1 s dans un coin avant le remove). Methode sure : left/top
            // redefinis a la position viewport - coin conteneur, transform remis
            // a zero : la comete reste exactement ou l'explosion a eu lieu.
            const impactRect = bonusElement.getBoundingClientRect();
            const contRect = document.getElementById('random-bonuses').getBoundingClientRect();
            bonusElement.style.transition = 'none';
            bonusElement.style.left = (impactRect.left - contRect.left) + 'px';
            bonusElement.style.top = (impactRect.top - contRect.top) + 'px';
            bonusElement.style.transform = 'scale(0.5)';
            bonusElement.classList.add('clicked');
            clickedBonusesCount++;
            // V3.23 : tirage UNIQUE de la conversion meteor -> x2 -- une
            // interception, une decision, appliquee partout pareil (credit,
            // penalite, reset). DECLARE EN TETE du callback : la version
            // precedente le declarait plus bas, APRES ses usages
            // (wasGrantingMult/grantsMultiplier) -- ReferenceError TDZ au
            // premier clic : le callback plantait AVANT notifyContractComet,
            // les cometes cliquees n'etaient JAMAIS comptees (retour joueur).
            // V3.43 (retour joueur : 'les cometes des contrats ne rapportent
            // AUCUN gain, que ce soit un x2 ou des parts -- seule la
            // recompense du contrat compte') : la comete de CONTRAT ne
            // declenche PLUS la conversion en x2 -- le test inf-choice est
            // coupe pour elles (isConvertedToMult force false).
            const isContractCometEl = bonusElement.dataset.contractComet === '1';
            const isConvertedToMult = !isContractCometEl
                && bonus.id === "meteor"
                && getGalacticUpgradeLevel('inf-choice') > 0
                && shouldCometGiveMultiplier();
// V3.11 : la penalite de chance de spawn ne s'accumule que sur les
// cometes qui OCTROIENT un x4 -- la cascade vers le plafond 2048 devient
// auto-limitante : plus tu enchaines de x4, moins la prochaine comete a
// de chances d'apparaitre (jusqu'a -10% cumules par x4, remontee lente).
// V3.23 : meme tirage unique isConvertedToMult -- penalite et reset ne
// peuvent plus diverger du credit reellement octroye.
const wasGrantingMult = bonus.id === "flare" || isConvertedToMult;
if (wasGrantingMult) {
    cometsInterceptedWindow.count++;
    cometsInterceptedWindow.lastDecay = Date.now();
}
            // V3.5 : intercepter une comete RESET le timer du multiplicateur
            // temporaire actif a 15 s -- recompenser l'interception active.
            // V3.10 : le reset du timer n'a lieu QUE si cette interception
            // octroie un x4 (flare, ou meteor converti par le choix) --
            // sinon intercepter une comete a Parts prolongerait un x4
            // en cours pour rien.
            const grantsMultiplier = bonus.id === "flare" || isConvertedToMult;
            if (grantsMultiplier) {
                const nowMs = Date.now();
                // V3.21 : le reset du timer DOIT respecter la duree AUGMENTEE
                // par les Sursauts prolonges I/II -- l'ancien reset utilisait
                // flare_duration_ms() brut (15 s) : avec les sursauts, le
                // premier bonus durait 21 s mais une interception RACCOURCISSAIT
                // le timer a 15 s au lieu de le repartir sur la duree augmentee.
                // Meme multiplicateur que la pose initiale du bonus (spawn).
                const sursautMult = 1 + getUpgradeEffect('inf-surs1') + getUpgradeEffect('inf-surs2');
                let resetAny = false;
                activeRandomBonuses.forEach(b => {
                    if ((b.effect === 'multiplier' || b.effect === 'both' || b.id === 'flare') && b.endTime > nowMs) {
                        b.endTime = nowMs + (wasmCore() ? wasmCore().flare_duration_ms() : 15000) * sursautMult;
                        resetAny = true;
                    }
                });
                if (resetAny) { rebuildAutoMultipliers(); updateDisplay(); }
            }
            // Contrat interactif en cours : la comete interceptee compte --
            // uniquement si elle appartient au contrat toujours actif.
            notifyContractComet();
            // La comete n'atteindra jamais son timeout de fin de course
            // (clearTimeout ci-dessus) : decrementer le compteur de vol ici.
            const cc = contractState.active;
            if (shower && cc && cc.typeId === 'shower') {
                cc.showerInFlight = Math.max(0, (cc.showerInFlight || 0) - 1);
            }
            if (bonus.id === "meteor" && !isConvertedToMult) {
                // Cometes de CONTRAT uniquement : aucun bonus direct, elles ne
                // servent qu'a remplir l'objectif. Les pluies naturelles (shower)
                // donnent bien leurs parts, comme les cometes isolees.
                const isContractComet = bonusElement.dataset.contractComet === '1';
                if (!isContractComet) {
                    // V3.49 : FIX Comete doree (inf-comet) -- l'upgrade
                    // 'x2 sur les gains instantanes des cometes interceptees'
                    // n'etait JAMAIS appliquee : le credit lisait les
                    // constantes brutes sans le facteur. Double des gains
                    // instantanes quand l'upgrade est possedee.
                    const cometGoldMult = getGalacticUpgradeLevel('inf-comet') > 0 ? 2 : 1;
                    const instantProduction = partsPerSecond * cometGoldMult * (shower ? (wasmCore() ? wasmCore().meteor_gain_shower() : 30) : (wasmCore() ? wasmCore().meteor_gain_solo() : 10));
                    score += instantProduction;
                    partsSinceLaunch += instantProduction;
                    trackPartsEarned(instantProduction);
                    showBonusPopup('+' + formatNumber(instantProduction) + ' ' + t("Parts"), 'instant');
                }
            }
            // Choix de recompense (V3.5) : PROBABILISTE, pas binaire -- le mode
            // 'multiplier' donne +20% de chances de convertir un meteor en x4,
            // 'parts' ne convertit jamais, 'neutral' garde le hasard d'origine.
            else if (bonus.id === "flare" || isConvertedToMult) {
                // Chaque flare porte un endTime unique : le timer d'expiration
                // retire uniquement CE bonus. Filtrer par id retirerait tous les
                // flares actifs du meme type d'un seul coup.
                // PAS de setTimeout d'expiration : expireRandomBonuses
                // (gameLoop) est l'unique source de verite -- les setTimeout
                // n'etaient pas decales pendant les pauses (cinematique, gel
                // mobile) alors que endTime l'etait, ce desynchronisait les
                // deux mecanismes et laissait des multiplicateurs fantomes.
                // Sursaut prolongé I/II (V3) : +20% / +25% de durée sur
                // les bonus temporaires (cumulés ~+50% avec les deux).
                // V3.5 : bonus de duree des sursauts REDUITS (retour playtest :
                // le reset 15 s par interception les rendait deja bien plus forts).
                const sursautMult = 1 + getUpgradeEffect('inf-surs1') + getUpgradeEffect('inf-surs2');
                // V3.31 : fallback numerique -- un meteor converti n'a PAS de
                // champ multiplier (effect 'instant') : le fallback bonus.multiplier
                // etait undefined -> 'Production xundefined' au popup et un
                // multiplicateur fantome (NaN) dans la chaine de production.
                activeRandomBonuses.push({
                    id: bonus.id,
                    effect: 'multiplier',
                    multiplier: (wasmCore() ? wasmCore().flare_multiplier() : (bonus.multiplier || 2)),
                    endTime: Date.now() + (wasmCore() ? wasmCore().flare_duration_ms() : (bonus.duration || 15000)) * sursautMult
                });
                rebuildAutoMultipliers();
                showBonusPopup(t('Production') + ' \u00d7' + (wasmCore() ? wasmCore().flare_multiplier() : (bonus.multiplier || 2)), 'multiplier');
            }
            setTimeout(() => bonusElement.remove(), 500);
            checkTrophies();
        }, { startX, startY, endX, endY, duration });
    };
}
// Missile d'interception : quand le joueur clique sur une comète, un missile
// part du bord de l'écran et la percute en trajectoire perpendiculaire à la
// sienne. Vol très rapide (180-320 ms), puis explosion et destruction.
// Interception en vol : la comete NE S'ARRETE PAS. Le missile calcule
// un point de rendez-vous sur la trajectoire future de la comete et
// s'y crash pile au moment ou elle y passe.
// Gros popup de bonus au centre de l'ecran : "+X Parts" ou "Production x4",
// position et angle aleatoires, comme un gain dans un jeu video. Vit dans
// .click-effects (calque fixe au-dessus du jeu, sous les cometes).
function showBonusPopup(text, kind) {
    const container = document.getElementById('click-effects');
    if (!container) return;
    const cRect = container.getBoundingClientRect();
    const cx = cRect.width / 2;
    const cy = cRect.height / 2;
    const rx = (Math.random() - 0.5) * Math.min(240, cRect.width * 0.3);
    const ry = (Math.random() - 0.5) * Math.min(160, cRect.height * 0.3);
    const angle = (Math.random() - 0.5) * 24;
    const el = document.createElement('div');
    el.className = 'bonus-pop ' + (kind === 'multiplier' ? 'bonus-pop-mult' : 'bonus-pop-instant');
    el.textContent = text;
    el.style.left = (cx + rx) + 'px';
    el.style.top = (cy + ry) + 'px';
    el.style.setProperty('--bpop-rot', angle.toFixed(1) + 'deg');
    container.appendChild(el);
    setTimeout(() => el.remove(), 1900);
}

function interceptCometWithMissile(cometEl, onDestroy, opts) {
    Sounds.missile();
    const cometRect = cometEl.getBoundingClientRect();
    // Vecteur vitesse de la comete (px/ms) -- calcule en PREMIER : le point
    // de rendez-vous (le NEZ) en depend.
    const vTotal0 = opts ? opts.duration : 6000;
    const vcx0 = opts ? (opts.endX - opts.startX) / vTotal0 : 0;
    const vcy0 = opts ? (opts.endY - opts.startY) / vTotal0 : 0;
    // Nucleau reel de la comete via les variables CSS --nx/--ny (le sprite est
    // horizontal avec queue integree, le noyau n'est PAS au centre du canvas).
    // Les variables sont en POURCENTAGE du conteneur : convertir en px selon
    // la taille reelle, pour que le point de rendez-vous reste exact quelle
    // que soit la taille de la comete (desktop 180px, mobile 130px, pluie 120px).
    const cs = getComputedStyle(cometEl);
    const nxRaw = parseFloat(cs.getPropertyValue('--nx')) || 74.44;
    const nyRaw = parseFloat(cs.getPropertyValue('--ny')) || 75;
    const nx = cometRect.width * nxRaw / 100;
    const ny = cometRect.height * nyRaw / 100;
    let cx = cometRect.left + nx;
    let cy = cometRect.top + ny;
    // V3.4 : viser le NEZ de la comete -- le point AVANT dans la direction
    // de vol, pas le centre du noyau. Le missile frappe la pointe.
    {
        const vLen0 = Math.hypot(vcx0 || 0, vcy0 || 0);
        if (vLen0 > 0) {
            // V3.24 : 0.22 (retour joueur : 0.28 etait un peu trop en
            // avant du nez -- le missile paraissait decolle de la comete).
            cx += (vcx0 / vLen0) * cometRect.width * 0.22;
            cy += (vcy0 / vLen0) * cometRect.height * 0.22;
        }
    }
    // Facteur d'echelle des effets (missile, explosion) : 1 pour une comete
    // de 180px, proportionnellement plus petit pour les cometes reduites.
    const scale = Math.max(0.6, Math.min(1, cometRect.width / 180));
    const goRight = !cometEl.classList.contains('reverse');
    // Vecteur vitesse de la comete (px/ms) sur sa trajectoire lineaire.
    const vTotal = opts ? opts.duration : 6000;
    const vcx = opts ? (opts.endX - opts.startX) / vTotal : 0;
    const vcy = opts ? (opts.endY - opts.startY) / vTotal : 0;
    // Depart du missile : PERPENDICULAIRE a la trajectoire de la comete.
    // La comete vole en diagonale ; le missile arrive dans l'axe
    // perpendiculaire, depuis hors de l'ecran, et la percute de plein
    // fouet dans une direction orthogonale a son vol.
    const vLen = Math.hypot(vcx, vcy) || 1;
    let pvx = -vcy / vLen;
    let pvy = vcx / vLen;
    // Cote du tir : partir du BAS de la comete (le missile monte vers elle)
    if (pvy < 0) { pvx = -pvx; pvy = -pvy; }
    const reach = Math.hypot(window.innerWidth, window.innerHeight) * 0.6;
    // Convergence du point de rendez-vous : la comete avance pendant le vol
    // du missile, donc on reitere (temps de vol <-> position future) jusqu'a
    // ce que le missile arrive au point pile au moment ou elle y passe.
    // Convergence du point de rendez-vous (V3.2 fix) : la comete avance
    // pendant le vol du missile. On reitere (position future <-> temps de
    // vol) jusqu'a stabilisation ; a la FIN, on RECALCULE tx/ty avec le
    // flightMs final -- avant, le dernier tx/ty utilisait l'ancien flightMs
    // et le missile explosait DERIERE la comete.
    let flightMs = 320;
    let tx = cx, ty = cy;
    let launchXadj = cx, launchY = cy;
    for (let i = 0; i < 6; i++) {
        tx = cx + vcx * flightMs;
        ty = cy + vcy * flightMs;
        launchXadj = tx + pvx * reach;
        launchY = ty + pvy * reach;
        const d = Math.hypot(tx - launchXadj, ty - launchY);
        const next = Math.max(240, Math.min(600, d / 2.2));
        if (Math.abs(next - flightMs) < 2) { flightMs = next; break; }
        flightMs = next;
    }
    // Point final COHERENT avec le temps de vol final : le missile et la
    // comete arrivent au meme point au meme instant.
    tx = cx + vcx * flightMs;
    ty = cy + vcy * flightMs;
    launchXadj = tx + pvx * reach;
    launchY = ty + pvy * reach;
    const angle = Math.atan2(ty - launchY, tx - launchXadj);
    const missile = document.createElement('div');
    missile.className = 'comet-missile';
    missile.innerHTML = '<img src="images/effects/missile.webp" alt="">';
    document.body.appendChild(missile);
    const mRect = missile.getBoundingClientRect();
    const mW = mRect.width || 46;
    const mH = mRect.height || 14;
    missile.style.left = (launchXadj - mW / 2) + 'px';
    missile.style.top = (launchY - mH / 2) + 'px';
    missile.style.transform = `translate(0px, 0px) rotate(${angle}rad) scale(${scale})`;
    // Forcer le commit de l'orientation initiale AVANT de poser la
    // transition : sinon le navigateur n'a jamais calcule le style de depart
    // et interpole la rotation depuis 0 rad, le missile tourne sur lui-meme
    // pendant tout le vol.
    void missile.getBoundingClientRect();
    // Vol rapide mais lisible : borné entre 240 et 600 ms selon la distance.
    // Animation en transform (compositee GPU) : left/top forcerait le layout
    // a chaque frame et ferait saccader le vol.
    const dx = tx - launchXadj;
    const dy = ty - launchY;
    requestAnimationFrame(() => {
        missile.style.transition = `transform ${flightMs}ms linear`;
        missile.style.transform = `translate(${dx}px, ${dy}px) rotate(${angle}rad) scale(${scale})`;
    });
    // V3.4 : le missile disparait PILE a l'impact -- avant, +20 ms le
    // laissaient visible un instant SUR la comete apres la fin du vol.
    setTimeout(() => {
        if (!missile.isConnected) return;
        missile.remove();
        spawnCometExplosion(tx, ty, scale);
        onDestroy();
    }, flightMs);
}
// Explosion de la comète à l'impact : lueur, flash blanc, boule de feu,
// ondes de choc, gerbe d'étincelles et fumée. Chaque couche est un div
// positionné au point d'impact, animée en CSS puis nettoyée.
function spawnCometExplosion(cx, cy, scale) {
    Sounds.explosion();
    // Echelle des effets : proportionnelle a la taille de la comete detruite
    const sc = Math.max(0.5, Math.min(1, scale || 1));
    const explosion = document.createElement('div');
    explosion.className = 'comet-explosion';
    explosion.style.left = cx + 'px';
    explosion.style.top = cy + 'px';
    explosion.style.setProperty('--es', sc);
    document.body.appendChild(explosion);

    const layer = (cls) => {
        const el = document.createElement('div');
        el.className = cls;
        explosion.appendChild(el);
        return el;
    };

    layer('exp-light');
    layer('exp-core');
    layer('exp-fireball');

    // Deux ondes de choc, la seconde légèrement en retard
    layer('exp-ring');
    const ring2 = layer('exp-ring');
    ring2.style.animationDelay = '0.12s';
    ring2.style.animationDuration = '0.7s';

    // Gerbe d'étincelles : directions et portées variées
    const SPARKS = 16;
    for (let i = 0; i < SPARKS; i++) {
        const spark = layer('exp-spark');
        const theta = (i / SPARKS) * Math.PI * 2 + Math.random() * 0.35;
        const dist = (50 + Math.random() * 110) * sc;
        const sx = Math.cos(theta) * dist;
        const sy = Math.sin(theta) * dist;
        spark.style.setProperty('--sx', sx.toFixed(1) + 'px');
        spark.style.setProperty('--sy', sy.toFixed(1) + 'px');
        spark.style.setProperty('--sr', (Math.random() * 220 - 110).toFixed(0) + 'deg');
        spark.style.setProperty('--ssize', ((3 + Math.random() * 3.5) * sc).toFixed(1) + 'px');
        spark.style.setProperty('--sd', (0.5 + Math.random() * 0.35).toFixed(2) + 's');
    }

    // Fumée : bouffées décalées, majoritairement vers le haut
    for (let i = 0; i < 6; i++) {
        const smoke = layer('exp-smoke');
        const theta = -Math.PI / 2 + (Math.random() - 0.5) * 1.9;
        const dist = (26 + Math.random() * 60) * sc;
        smoke.style.setProperty('--sx', (Math.cos(theta) * dist).toFixed(1) + 'px');
        smoke.style.setProperty('--sy', (Math.sin(theta) * dist).toFixed(1) + 'px');
        smoke.style.setProperty('--sscale', (0.7 + Math.random() * 0.9).toFixed(2));
        smoke.style.setProperty('--sdelay', (0.05 + Math.random() * 0.2).toFixed(2) + 's');
    }

    setTimeout(() => explosion.remove(), 1400);
}

// ============================================
// VISUAL EFFECTS
// ============================================
// V3.43 (retour joueur : 'la pluie ralentit quand je clique sur la piece') :
// CACHE des rectangles des conteneurs d'effets -- chaque clic lisait 3 a 4
// fois getBoundingClientRect (medal + click-effects), ce qui FORCE un reflow
// synchrone du main thread : les frames rAF de la pluie de pieces sautaient
// par paquets au moment du clic (le reste du jeu, en CSS compile GPU, ne
// montrait rien). Rects caches, invalides au resize/scroll.
const clickRectCache = new Map();
function getCachedRect(id) {
    if (clickRectCache.has(id)) return clickRectCache.get(id);
    const el = document.getElementById(id);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    clickRectCache.set(id, r);
    return r;
}
function invalidateClickRectCache() { clickRectCache.clear(); }
window.addEventListener('resize', invalidateClickRectCache);
window.addEventListener('scroll', invalidateClickRectCache, true);

// Parts par clic "naturelles" : base + bonus batiments + bonus production de base,
// sans aucun multiplicateur (temporaire, galactique ou critique). Sert de base
// de calcul pour les cibles et la progression des contrats clickParts.
function getNaturalClickParts() {
    const nbUpgrades = activatedClickUpgrades.length;
    const { baseCpC, buildingBonus } = getClickComponents();
    const naturalCpsBonus = nbUpgrades * 0.01 * getBasePartsPerSecond();
    return baseCpC + buildingBonus + naturalCpsBonus;
}

function getClickComponents() {
    const nbUpgrades = activatedClickUpgrades.length;
    // Base qui double a chaque upgrade de clic (comme Reinforced finger / Carpal tunnel).
    const wCl = wasmCore();
    const baseCpC = wCl && wCl.click_base_power ? wCl.click_base_power(nbUpgrades) : Math.pow(2, nbUpgrades);
    // Bonus par bâtiment possede (equivalent Thousand Fingers) : +0.1 par bâtiment,
    // multiplie par un facteur croissant avec les upgrades (Million/Billion Fingers).
    const wFg = wasmCore();
    const fingerMult = wFg && wFg.click_finger_multiplier ? wFg.click_finger_multiplier(nbUpgrades) : (nbUpgrades >= 2 ? (1 + (nbUpgrades - 1) * 0.5) : 0);
    const buildingBonus = fingerMult * 0.1 * getTotalBuildingsOwned();
    // Bonus lie a la production (1% des Parts/s par upgrade).
    const cpsBonus = nbUpgrades * 0.01 * partsPerSecond;
    return { baseCpC, buildingBonus, cpsBonus };
}

// Raccourci clavier : ESPACE = clic sur la piece (accessibilite clavier +
// confort joueurs PC). Ignore si une modale/edition est ouverte ou si le
// focus est dans un champ.
document.addEventListener('keydown', function (e) {
    if (e.key !== ' ' && e.code !== 'Space') return;
    if (e.repeat) return;
    const ae = document.activeElement;
    if (ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.isContentEditable)) return;
    if (document.querySelector('.modal.active')) return;
    if (e.target && (e.target.tagName === 'BUTTON' || e.target.tagName === 'A')) return;
    e.preventDefault();
    addScore(1, null);
});

function addScore(points, event) {
    trackClickRhythm();
    Sounds.click();
    // Bande-son : lancee au premier clic, mais JAMAIS au prix du jeu --
    // toute erreur audio est absorbee silencieusement.
    if (Sound.enabled && !Music.playing) { try { startMusic(); } catch (e) {} }
    const { baseCpC, buildingBonus, cpsBonus } = getClickComponents();
    const basePoints = baseCpC + buildingBonus + cpsBonus;
    const isCrit = Math.random() < getCritChance();
    // Main céleste (V3, inf-crit) : les critiques passent a x5 -- cumule avec
    // click8 (Cœur de supernova) qui donnait deja x5.
    const critBase = (getGalacticUpgradeLevel('click8') > 0 || getGalacticUpgradeLevel('inf-crit') > 0) ? 5 : 3;
    const critMult = isCrit ? critBase : 1;
    if (isCrit) Sounds.critical();
    // clickMultiplier : multiplicateurs temporaires de CLIC (contrats,
    // flares). Il etait calcule et sauvegarde mais jamais applique ici —
    // les rewards "Clic x2/3/5" des contrats n'avaient donc AUCUN effet.
    const totalPoints = basePoints * clickMultiplier * getClickPowerBonus() * critMult;
    // Appel cosmique II (V3, inf-call) : 10% de chance de comete par clic.
    // V3.5 : chaque comete interceptee reduit cette chance (chances decroissantes) --
    // le reset du timer de multiplicateur par interception ne doit pas
    // permettre une boucle infinie comete -> clic -> comete. La chance remonte
    // progressivement quand le joueur arrete d'intercepter (decroissance du
    // compteur dans le gameLoop).
    const hasCall2 = getGalacticUpgradeLevel('inf-call') > 0;
    const baseCometChance = hasCall2
        ? wasmConst('click_comet_chance_upgraded', 0.10)
        : wasmConst('click_comet_chance_base', 0.05);
    // V3.47bis (choix joueur : 'augmente la penalite de 5%') : penalite
    // DEGRESSIVE MULTIPLICATIVE -- chaque x2 octroye retire desormais 15%
    // de la chance RESTANTE (x0.85 par x2 : 5% -> 4,25 -> 3,61 -> 3,07%...,
    // 10% -> 8,5 -> 7,23 -> 6,14%...), etouffement plus mordant, sans
    // plancher artificiel. Uniforme du debut a la fin du jeu.
    const cometChance = baseCometChance * Math.pow(1 - wasmConst('comet_chance_penalty_per_intercept', 0.15), cometsInterceptedWindow.count);
    if (getGalacticUpgradeLevel('click6') > 0 && Math.random() < cometChance) {
        spawnRandomBonus();
    }

    score += totalPoints;
    partsSinceLaunch += totalPoints;
    totalPartsFromClicks += totalPoints;
    totalClicksAllTime += 1;
    trackPartsEarned(totalPoints);
    trackNaturalParts(basePoints);
    // V3.34 : le contrat clickParts compte le gain REEL du clic (totalPoints :
    // multiplicateurs permanents, puissance de clic, crit) -- coherent avec
    // la cible (clic complet moyen) et avec ce que le joueur voit s'afficher.
    notifyContractClick(contractState.active && contractState.active.typeId === 'clickParts' ? totalPoints : basePoints);

    showClickEffect(Math.round(totalPoints), event, isCrit);
    spawnShockwave(event);
    spawnFallingCoin(event);

    const medal = document.getElementById('medal');
    // Direction du clic par rapport au centre de la piece (normalisee), pour
    // tordre l'animation vers l'endroit clique. Fallback: centre.
    if (medal && event && event.clientX !== undefined) {
        const rect = medal.getBoundingClientRect();
        const halfW = rect.width / 2;
        const halfH = rect.height / 2;
        const dx = event.clientX - (rect.left + halfW);
        const dy = event.clientY - (rect.top + halfH);
        const dist = Math.min(1, Math.hypot(dx, dy) / halfW);
        const nx = (dx / halfW) * dist;
        const ny = (dy / halfH) * dist;
        medal.style.setProperty('--click-nx', nx.toFixed(3));
        medal.style.setProperty('--click-ny', ny.toFixed(3));
    }
    medal.classList.remove('bounce');
    void medal.offsetWidth;
    medal.classList.add('bounce');

    updateDisplay();
    saveGame();
    updateAllBuildingButtons();
    renderUpgrades();
    checkBuildingUnlocks();
    checkTrophies();
}

// Ondes de choc : 2 anneaux emis au point EXACT du clic (le 2e plus petit,
// 60 ms plus tard), qui s'etendent en s'estompant : sensation de frappe.
function spawnShockwave(event) {
    const container = document.getElementById('click-effects');
    if (!container) return;
    let x, y;
    if (event && event.clientX !== undefined) {
        x = event.clientX; y = event.clientY;
    } else {
        const r = getCachedRect('medal');
        if (!r) return;
        x = r.left + r.width / 2; y = r.top + r.height / 2;
    }
    const rect = getCachedRect('click-effects');
    if (!rect) return;
    const cx = x - rect.left, cy = y - rect.top;
    // Taille ADAPTATIVE : proportionnelle au diametre reel de la piece
    // (~22%), elle-meme adaptee a l'ecran (21cqh min/max). L'onde suit
    // donc la piece sur mobile comme sur PC, sans media query.
    const medalRect = getCachedRect('medal');
    if (!medalRect) return;
    const base = Math.max(20, Math.round(medalRect.width * 0.22));
    const half = -(base / 2);
    const w1 = document.createElement('div');
    w1.className = 'shockwave';
    w1.style.left = cx + 'px';
    w1.style.top = cy + 'px';
    w1.style.width = base + 'px';
    w1.style.height = base + 'px';
    w1.style.margin = half + 'px 0 0 ' + half + 'px';
    const w2 = document.createElement('div');
    w2.className = 'shockwave small';
    w2.style.left = cx + 'px';
    w2.style.top = cy + 'px';
    w2.style.width = base + 'px';
    w2.style.height = base + 'px';
    w2.style.margin = half + 'px 0 0 ' + half + 'px';
    container.appendChild(w1);
    container.appendChild(w2);
    setTimeout(() => { w1.remove(); w2.remove(); }, 700);
}

// Feedback d'achat : deux popups flottants (cout rouge, gain vert) ancre au-dessus
// de l'element acheteur. Position absolue dans l'element : aucun decalage de mise
// en page. Auto-suppression apres l'animation.
function showBuyFeedback(targetEl, costText, gainText) {
    if (!targetEl) return;
    // V3.88 (retour proprietaire : 'je ne vois plus le feedback visuel
    // d achat de batiment sur mobile') : le feedback etait purement et
    // simplement COUPE en mobile ('hors zone visible') au lieu d etre
    // repare. Desormais il s affiche partout, avec un ANCRAGE RECALCULE
    // en mobile : au-DESSUS de la carte (elle-meme dans le panneau bas,
    // un popup ancre au top debordait sous la liste), taille reduite,
    // et CLAMP horizontal dans le viewport pour que le texte (parfois
    // large) ne sorte jamais de l ecran.
    const isMobile = typeof isMobileLayout === 'function' && isMobileLayout();
    // V3.89 (retour proprietaire : 'le feedback ne doit etre visible QUE
    // sur la page des batiments -- sinon il s affiche en haut a gauche') :
    // sur mobile, l auto-achat tourne en arriere-plan pendant que le
    // joueur est sur une AUTRE vue (Espace/Fusee) -- la carte achetee
    // n est pas affichee, son rect vaut 0x0 et le popup s ancrait en
    // haut a gauche de l ecran. On ne montre le feedback que si la vue
    // BATIMENTS est active.
    if (isMobile && mobileActiveView !== 'right') return;
    const rect = targetEl.getBoundingClientRect();
    let anchorX = rect.left + rect.width / 2;
    let anchorY = isMobile ? Math.max(70, rect.top - 10) : rect.top;
    // Clamp horizontal : le popup est centre sur anchorX mais le texte
    // peut deborder -- on le maintient dans [60px, innerWidth-60px].
    anchorX = Math.min(Math.max(anchorX, 60), Math.max(60, window.innerWidth - 60));
    [{ cls: 'buy-feedback-cost', text: costText }, { cls: 'buy-feedback-gain', text: gainText }].forEach(cfg => {
        const el = document.createElement('div');
        el.className = 'buy-feedback ' + cfg.cls + (isMobile ? ' buy-feedback-mobile' : '');
        el.textContent = cfg.text;
        el.style.left = anchorX + 'px';
        el.style.top = anchorY + 'px';
        document.body.appendChild(el);
        setTimeout(() => el.remove(), cfg.cls === 'buy-feedback-gain' ? 2900 : 2500);
    });
}
// Badge record affiche en haut a gauche de l'atelier post-lancement :
// la plus grande distance jamais atteinte, mise a jour au moment de
// l'ouverture (maxDistance vient d'etre credite juste avant).
function updatePostTravelRecordBadge(modal) {
    // Case harmonisee du header (flex, entre le titre et les autres cases) :
    // plus de badge absolute qui forcait un padding-left sur le titre.
    let badge = modal.querySelector('.post-travel-record');
    if (!badge) {
        badge = document.createElement('div');
        badge.className = 'post-travel-record ptr-case';
        const header = modal.querySelector('.modal-header');
        const shopBadge = header ? header.querySelector('.shop-bonus-badge') : null;
        if (header && shopBadge) header.insertBefore(badge, shopBadge);
        else if (header) header.appendChild(badge);
    }
    badge.innerHTML =
        '<span class="ptr-label">' + t('Distance record') + '</span>' +
        '<span class="ptr-value">' + formatNumber(maxDistance) + ' ' + t('km') + '</span>';
}
// Recompense audiovisuelle de fin de lancement : gros popup central avec la
// distance atteinte en caracteres geants, fanfare majesteuse en parallele.
function showLaunchReward(distance) {
    const el = document.createElement('div');
    el.className = 'launch-reward';
    el.innerHTML = '<img src="images/rocket/Fusée3.webp" alt="Fusée" class="launch-reward-emoji-img">' +
        '<span class="launch-reward-distance">' + formatNumber(distance) + ' ' + t('km') + '</span>' +
        '<span class="launch-reward-label">' + t('Fusée lancée ! Distance atteinte:') + '</span>';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2900);
}
// Fondu de transition vers l'atelier galactique apres un lancement :
// un voile noir s'opacifie en fin de cinematique, l'atelier s'ouvre
// DESSUS puis le voile se dissipe -- plus de decoupe seche.
function transitionToPostTravelShop(distance) {
    const veil = document.createElement('div');
    veil.className = 'post-travel-veil';
    document.body.appendChild(veil);
    requestAnimationFrame(() => veil.classList.add('visible'));
    setTimeout(() => {
        showPostTravelShop(distance);
        updateSpaceProgress();
        updateConstructionScene();
        isLaunching = false;
        setTimeout(() => {
            veil.classList.remove('visible');
            setTimeout(() => veil.remove(), 450);
        }, 120);
    }, 420);
}
function showClickEffect(value, event, isCrit) {
    const container = document.getElementById('click-effects');
    if (!container) return;
    const containerRect = getCachedRect('click-effects');
    if (!containerRect) return;
    let x, y;
    if (event && event.clientX !== undefined) {
        x = event.clientX;
        y = event.clientY;
    } else {
        const medalRect = getCachedRect('medal');
        if (!medalRect) return;
        x = medalRect.left + medalRect.width / 2;
        y = medalRect.top + medalRect.height / 2;
    }
    x -= containerRect.left;
    y = y - containerRect.top - 10;

    const effect = document.createElement('div');
    effect.className = 'click-effect' + (isCrit ? ' crit' : '');
    effect.textContent = `+${formatNumber(value)}`;
    const dir = Math.random() * Math.PI * 2;
    const dist = 55 + Math.random() * 45;
    effect.style.left = `${x}px`;
    effect.style.top = `${y}px`;
    effect.style.setProperty('--ce-dx', (Math.cos(dir) * dist).toFixed(1) + 'px');
    effect.style.setProperty('--ce-dy', (Math.sin(dir) * dist).toFixed(1) + 'px');
    effect.style.setProperty('--ce-rot', ((Math.random() - 0.5) * 22).toFixed(1) + 'deg');
    container.appendChild(effect);
    setTimeout(() => effect.remove(), 1200);
}

// Piece qui tombe depuis le point clique : apparait sur place (pop),
// saute de quelques pixels au-dessus du clic (vitesse initiale vers le haut
// qui s'amortit), puis retombe tout doucement avec une acceleration
// gravitationnelle, en tournoyant lentement. Disparait hors ecran en bas.
// Gravite faible (~3x plus lente qu'avant en duree de chute).
const FALL_GRAVITY = 260; // px/s^2
const HOP_MIN = 18; // px
const HOP_MAX = 40; // px

function spawnFallingCoin(event) {
    const container = document.getElementById('falling-coins');
    if (!container) return;

    let x, y;
    if (event && event.clientX !== undefined) {
        x = event.clientX;
        y = event.clientY;
    } else {
        const medalRect = getCachedRect('medal');
        if (!medalRect) return;
        x = medalRect.left + medalRect.width / 2;
        y = medalRect.top + medalRect.height / 2;
    }

    const coin = document.createElement('div');
    coin.className = 'falling-coin';

    const img = document.createElement('img');
    img.src = 'images/parts.webp';
    img.alt = '';
    img.draggable = false;
    coin.appendChild(img);

    const size = 24 + Math.random() * 32;
    const drift = (Math.random() - 0.5) * 440;
    const spinDir = Math.random() < 0.5 ? 1 : -1;

    // Petit saut vers le haut depuis le point clique, puis chute douce
    const hop = HOP_MIN + Math.random() * (HOP_MAX - HOP_MIN);
    const fallDist = window.innerHeight - y + size + 20;
    const tUp = Math.sqrt(2 * hop / FALL_GRAVITY);
    const tDown = Math.sqrt(2 * (fallDist + hop) / FALL_GRAVITY);
    const total = tUp + tDown;
    const startDelay = 0.05 + Math.random() * 0.07;
    // Rotation reguliere : exactement 1 tour toutes les 12 secondes sur
    // toute la duree de vie de la piece (chute ~2-4s -> ~0.2-0.3 tour)
    const SPIN_PERIOD = 12;
    const spinDeg = spinDir * 360 * (total / SPIN_PERIOD);

    coin.style.width = size + 'px';
    coin.style.height = size + 'px';
    coin.style.left = x + 'px';
    coin.style.top = y + 'px';
    coin.style.setProperty('--fall-drift', drift + 'px');
    coin.style.setProperty('--fall-spin', spinDeg + 'deg');
    coin.style.setProperty('--fall-duration', total + 's');
    coin.style.setProperty('--fall-delay', startDelay + 's');

    container.appendChild(coin);

    // Trajectoire balistique en 2 phases : montee amortie (ease-out) puis
    // chute accelerante (ease-in). Les durees decoulent de la physique.
    if (coin.animate) {
        const anim = coin.animate([
            { transform: 'translate(-50%, -50%)', easing: 'cubic-bezier(0.25, 0.6, 0.4, 1)' },
            { transform: `translate(-50%, calc(-50% - ${hop.toFixed(1)}px))`, easing: 'cubic-bezier(0.5, 0, 0.85, 0.45)', offset: tUp / total },
            { transform: `translate(calc(-50% + ${drift.toFixed(1)}px), calc(-50% + ${fallDist.toFixed(1)}px))`, offset: 1 }
        ], { duration: total * 1000, delay: startDelay * 1000, fill: 'forwards' });
        anim.onfinish = () => coin.remove();
    } else {
        setTimeout(() => coin.remove(), (startDelay + total) * 1000);
    }
}

// ============================================
// SOUND DESIGN — moteur Web Audio 100% synthétisé
// Aucun fichier audio : chaque son est généré par oscillateurs.
// Muert par défaut jusqu'à la première interaction (politique navigateurs),
// réglage sauvegardé, coupé quand l'onglet est masqué.
// ============================================
// Son du clic sur la piece : activable/desactivable separement des SFX
// (parametres) -- le "coin" repete peut agacer sur les longues sessions.
const ClickSound = { enabled: (localStorage.getItem('starcruiserClickSound') !== '0') };

function toggleClickSound() {
    ClickSound.enabled = !ClickSound.enabled;
    localStorage.setItem('starcruiserClickSound', ClickSound.enabled ? '1' : '0');
    const btn = document.getElementById('clicksound-toggle-btn');
    const btnLbl = btn ? btn.querySelector('span') : null;
    if (btnLbl) btnLbl.textContent = ClickSound.enabled ? t('Désactiver le son du clic') : t('Activer le son du clic');
}

const Sound = {
    ctx: null,
    master: null,
    enabled: (localStorage.getItem('starcruiserSound') !== '0'),
    _lastClick: 0
};
function soundInit() {
    if (Sound.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    Sound.ctx = new AC();
    Sound.master = Sound.ctx.createGain();
    Sound.master.gain.value = 0.3;
    Sound.master.connect(Sound.ctx.destination);
}
function soundResume() {
    // V3.91 (retour proprietaire : 'des fois j entends le son du jeu
    // pendant qu il est en arriere-plan') : le visibilitychange SUSPEND
    // l AudioContext quand la page est cachee, mais chaque appel de son
    // passait ICI et REVEILLAIT le contexte (ctx.resume()) -- un simple
    // timer de jeu (rotation de contrat, booster pret) jouait son bip
    // depuis l onglet cache. Garde : ne JAMAIS reactivir l audio tant
    // que la page est cachEe -- le visibilitychange est le SEUL endroit
    // autorise a redemarrer le son (au retour sur la page).
    if (typeof document !== 'undefined' && document.hidden) return;
    if (!Sound.ctx) soundInit();
    if (Sound.ctx && Sound.ctx.state === 'suspended') Sound.ctx.resume();
}
// Bip générique : fréquence de départ, fréquence de fin, durée, type d'onde, volume
function soundTone(freq, freqEnd, dur, type, vol, delay) {
    if (!Sound.enabled) return;
    soundResume();
    if (!Sound.ctx) return;
    const t0 = Sound.ctx.currentTime + (delay || 0);
    const osc = Sound.ctx.createOscillator();
    const g = Sound.ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    if (freqEnd && freqEnd !== freq) osc.frequency.exponentialRampToValueAtTime(Math.max(1, freqEnd), t0 + dur);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(vol || 0.5, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(g); g.connect(Sound.master);
    osc.start(t0); osc.stop(t0 + dur + 0.02);
    osc.onended = () => { try { osc.disconnect(); } catch (e) {} };
    // V3.49 : memoire audio -- les noms connectes jamais deconnectes
    // s'accumulaient dans le graphe Web Audio (retour joueur : >1 Go).
    osc.onended = () => { try { osc.disconnect(); g.disconnect(); } catch (e) {} };
}
// Bruit filtré (explosions, whoosh)
function soundNoise(dur, vol, freqStart, freqEnd) {
    if (!Sound.enabled) return;
    soundResume();
    if (!Sound.ctx) return;
    const t0 = Sound.ctx.currentTime;
    const len = Math.max(1, Math.floor(Sound.ctx.sampleRate * dur));
    const buf = Sound.ctx.createBuffer(1, len, Sound.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = Sound.ctx.createBufferSource();
    src.buffer = buf;
    const filt = Sound.ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(freqStart || 1800, t0);
    filt.frequency.exponentialRampToValueAtTime(Math.max(40, freqEnd || 120), t0 + dur);
    const g = Sound.ctx.createGain();
    g.gain.setValueAtTime(vol || 0.4, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    src.connect(filt); filt.connect(g); g.connect(Sound.master);
    src.start(t0); src.stop(t0 + dur);
}
// ============================================
// MOTEUR MUSICAL v3 -- "OH JOY" style (Todd Terje disco mix)
// House-disco chaleureux : 122 BPM, swing leger sur les 16e, kick doux
// quatre-quarts, clap sur 2 et 4, basse ronde syncop\u00e9e, stabs d'accords
// disco sur les offbeats, arp\u00e8ge cristallin en croches, et de VRAIES
// m\u00e9lodies lead compos\u00e9es en call & response (phrases A/B qui se
// r\u00e9pondent) au-dessus d'une progression joyeuse en R\u00e9 majeur 7e.
// Boucle : 8 accords x 2 mesures, 4 sections de 32 mesures ~ 5 min.
// 100% WebAudio : bus + compresseur + reverb spatiale + echo.
// ============================================
// ============================================================
// V3.95 : RETOUR A LA MUSIQUE ORIGINALE (retour proprietaire : 'remet
// celle d avant du debut a 120 BPM, de toute facon la plupart des
// gens ne la mettront pas') -- moteur disco joyeux en D majeur
// restaure depuis la V3.90 (avant les experiences arcade/piano/
// generatif), tempo ramene de 122 a 120 BPM.
// ============================================================
const Music = {
    enabled: (localStorage.getItem('starcruiserMusic') !== '0'),
    playing: false,
    timer: null,
    step: 0,          // 16e dans la mesure (0-15)
    bar: 0,           // mesure globale
    bpm: 120,
    // Progression joyeuse en D majeur (Dmaj7 - Bm7 - Gmaj7 - A7 /
    // Em7 - Bm7 - Gmaj7 - A7) : couleur disco euphorique.
    chords: [
        { root: 146.83, notes: [146.83, 185.00, 220.00, 277.18] },  // Dmaj7 : D F# A C#
        { root: 123.47, notes: [123.47, 146.83, 185.00, 220.00] },  // Bm7  : B D F# A
        { root: 98.00,  notes: [98.00, 123.47, 146.83, 185.00] },  // Gmaj7: G B D F#
        { root: 110.00, notes: [110.00, 138.59, 164.81, 196.00] }, // A7   : A C# E G
        { root: 82.41,  notes: [82.41, 98.00, 123.47, 146.83] },   // Em7  : E G B D
        { root: 123.47, notes: [123.47, 146.83, 185.00, 220.00] },  // Bm7
        { root: 98.00,  notes: [98.00, 123.47, 146.83, 185.00] },  // Gmaj7
        { root: 110.00, notes: [110.00, 138.59, 164.81, 196.00] }  // A7
    ],
    // M\u00e9lodies lead COMPOS\u00c9ES (demi-tons depuis D5 = 587.33 Hz),
    // en croches, une phrase par mesure : A (question) / B (r\u00e9ponse),
    // puis A' (variance) / C (r\u00e9solution descendante). Joyeux et
    // chantant, facon Oh Joy.
    // Gamme D majeur ETENDUE en demi-tons depuis D4 : indices 0-14.
    // idx: 0=D 1=E 2=F# 3=G 4=A 5=B 6=C# 7=D5 8=E5 9=F#5 10=G5 11=A5 12=B5 13=C#6 14=D6
    dMajorScale: [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 23, 24],
    // Phrases lead COMPOSEES par accord (0-7) : 8 notes chacune, en
    // INDICES DIRECTS de dMajorScale. Chaque phrase demarre sur la
    // fondamentale de son accord (Dmaj7->0, Bm7->5, Gmaj7->3, A7->4,
    // Em7->1) et y retourne : diatonique a D majeur ET harmonique,
    // verifie note par note. Call & response : question/reponse.
    leadPhrases: [
        [0, 2, 4, 2, 5, 4, 2, 0],      // Dmaj7 : D-F#-A... montee riante
        [5, 4, 2, 4, 7, 6, 4, 5],      // Bm7 : B-A-F#... reponse sombre-claire
        [3, 5, 7, 5, 4, 2, 0, 3],      // Gmaj7 : G-B-D... pont lumineux
        [4, 2, 0, 2, 4, 6, 4, 4],      // A7 : A-F#-D... tension de dominante
        [1, 2, 4, 5, 4, 2, 1, 1],      // Em7 : E-F#-A... berceuse
        [5, 7, 6, 4, 2, 4, 5, 5],      // Bm7 : reponse elevee
        [3, 2, 0, 2, 3, 5, 3, 3],      // Gmaj7 : retour paisible
        [4, 6, 7, 6, 4, 2, 0, 4]       // A7 : culmine puis resolution vers D
    ],
    bus: null,
    delaySend: null,
    spaceSend: null,
    drumBus: null,
    sectionLen: 32,
    chordForBar(bar) { return this.chords[Math.floor(bar / 2) % 8]; },
    chordIndexForBar(bar) { return Math.floor(bar / 2) % 8; },
    section() { return Math.floor(this.bar / this.sectionLen) % 4; },
    isFill() { return (this.bar % this.sectionLen) >= this.sectionLen - 2; }
};

function musicInit() {
    if (Music.bus) return;
    soundResume();
    if (!Sound.ctx) return;
    Music.bus = Sound.ctx.createGain();
    Music.bus.gain.value = 0.85;
    // Compresseur doux : le mix respire, rien n'\u00e9crase rien.
    const comp = Sound.ctx.createDynamicsCompressor();
    comp.threshold.value = -22;
    comp.knee.value = 16;
    comp.ratio.value = 4;
    comp.attack.value = 0.006;
    comp.release.value = 0.22;
    // Echo d\u00e9di\u00e9 (croche point\u00e9e) : la patine disco.
    const delay = Sound.ctx.createDelay(1.0);
    delay.delayTime.value = (60 / Music.bpm) * 0.75;
    const fb = Sound.ctx.createGain();
    fb.gain.value = 0.30;
    const wet = Sound.ctx.createGain();
    wet.gain.value = 0.20;
    const wetFilter = Sound.ctx.createBiquadFilter();
    wetFilter.type = 'lowpass';
    wetFilter.frequency.value = 3400;
    Music.delaySend = Sound.ctx.createGain();
    Music.delaySend.gain.value = 1;
    Music.delaySend.connect(delay);
    delay.connect(fb); fb.connect(delay);
    delay.connect(wetFilter); wetFilter.connect(wet); wet.connect(comp);
    Music.bus.connect(comp);
    comp.connect(Sound.master);
    // Reverb spatiale (IR de bruit d\u00e9croissant 1.8 s).
    try {
        const irLen = Math.floor(Sound.ctx.sampleRate * 1.8);
        const ir = Sound.ctx.createBuffer(2, irLen, Sound.ctx.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
            const d = ir.getChannelData(ch);
            for (let i = 0; i < irLen; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / irLen, 2.5);
        }
        Music.space = Sound.ctx.createConvolver();
        Music.space.buffer = ir;
        const spaceOut = Sound.ctx.createGain();
        spaceOut.gain.value = 0.30;
        Music.spaceSend = Sound.ctx.createGain();
        Music.spaceSend.connect(Music.space);
        Music.space.connect(spaceOut);
        spaceOut.connect(comp);
    } catch (e) { Music.spaceSend = null; }
    // Sous-mix batterie : nets, assis sous les m\u00e9lodies.
    try {
        Music.drumBus = Sound.ctx.createGain();
        Music.drumBus.gain.value = 0.72;
        Music.drumBus.connect(Music.bus);
        if (Music.spaceSend) {
            const dr = Sound.ctx.createGain();
            dr.gain.value = 0.10;
            Music.drumBus.connect(dr);
            dr.connect(Music.spaceSend);
        }
    } catch (e) { Music.drumBus = null; }
}

// Oscillateur musical : glide, filtre r\u00e9sonant, enveloppe, echo/reverb.
function musicTone(freq, freqEnd, dur, type, vol, filter, opts) {
    if (!Sound.ctx || !Music.bus) return;
    opts = opts || {};
    const t0 = opts.at !== undefined ? opts.at + (opts.delay || 0) : Sound.ctx.currentTime + (opts.delay || 0);
    let t = t0;
    if (t < Sound.ctx.currentTime) t = Sound.ctx.currentTime;
    const atk = opts.attack !== undefined ? opts.attack : 0.008;
    const osc = Sound.ctx.createOscillator();
    const g = Sound.ctx.createGain();
    osc.type = type || 'sawtooth';
    osc.frequency.value = Math.max(20, freq);
    if (opts.detune) osc.detune.value = opts.detune;
    if (freqEnd && freqEnd !== freq) {
        osc.frequency.setValueAtTime(Math.max(20, freq), t);
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + dur);
    }
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let node = osc;
    if (filter) {
        const f = Sound.ctx.createBiquadFilter();
        f.type = filter.type || 'lowpass';
        f.frequency.setValueAtTime(filter.freq || 1200, t);
        if (filter.freqEnd) f.frequency.exponentialRampToValueAtTime(filter.freqEnd, t + dur);
        f.Q.value = filter.q || 1;
        osc.connect(f);
        node = f;
    }
    node.connect(g);
    g.connect(Music.bus);
    if (opts.echo && Music.delaySend) {
        const send = Sound.ctx.createGain();
        send.gain.value = opts.echo;
        g.connect(send);
        send.connect(Music.delaySend);
    }
    if (opts.space && Music.spaceSend) {
        const send = Sound.ctx.createGain();
        send.gain.value = opts.space;
        g.connect(send);
        send.connect(Music.spaceSend);
    }
    osc.start(t);
    osc.stop(t + dur + 0.05);
}

// Note tenue avec vibrato LFO -- les notes m\u00e8re du lead.
function musicVibrato(freq, dur, type, vol, filter, opts) {
    if (!Sound.ctx || !Music.bus) return;
    opts = opts || {};
    const t0 = opts.at !== undefined ? opts.at + (opts.delay || 0) : Sound.ctx.currentTime + (opts.delay || 0);
    let t = t0;
    if (t < Sound.ctx.currentTime) t = Sound.ctx.currentTime;
    const osc = Sound.ctx.createOscillator();
    const g = Sound.ctx.createGain();
    const lfo = Sound.ctx.createOscillator();
    const lfoGain = Sound.ctx.createGain();
    osc.type = type || 'sawtooth';
    osc.frequency.value = freq;
    lfo.frequency.value = opts.vibRate || 5.2;
    lfoGain.gain.value = freq * 0.005;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + (opts.attack || 0.05));
    g.gain.setValueAtTime(vol, t + dur * 0.7);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let node = osc;
    if (filter) {
        const f = Sound.ctx.createBiquadFilter();
        f.type = filter.type || 'lowpass';
        f.frequency.value = filter.freq || 1500;
        f.Q.value = filter.q || 1.5;
        osc.connect(f);
        node = f;
    }
    node.connect(g);
    g.connect(Music.bus);
    if (opts.echo && Music.delaySend) {
        const send = Sound.ctx.createGain();
        send.gain.value = opts.echo;
        g.connect(send);
        send.connect(Music.delaySend);
    }
    if (opts.space && Music.spaceSend) {
        const send = Sound.ctx.createGain();
        send.gain.value = opts.space;
        g.connect(send);
        send.connect(Music.spaceSend);
    }
    osc.start(t); osc.stop(t + dur + 0.05);
    lfo.start(t); lfo.stop(t + dur + 0.05);
}

// --- Batterie "Oh Joy" : douce, ronde, avec leger shuffle ---
function musicKick(t0) {
    if (!Sound.ctx || !Music.bus) return;
    // Kick rond : sinus qui glisse doucement, PAS de click agressif.
    const osc = Sound.ctx.createOscillator();
    const g = Sound.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, t0);
    osc.frequency.exponentialRampToValueAtTime(43, t0 + 0.10);
    g.gain.setValueAtTime(0.55, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.20);
    osc.connect(g); g.connect(Music.drumBus || Music.bus);
    osc.start(t0); osc.stop(t0 + 0.24);
    osc.onended = () => { try { osc.disconnect(); } catch (e) {} };
    // V3.49 : memoire audio -- les noms connectes jamais deconnectes
    // s'accumulaient dans le graphe Web Audio (retour joueur : >1 Go).
    osc.onended = () => { try { osc.disconnect(); g.disconnect(); } catch (e) {} };
}

function musicHat(t0, open) {
    if (!Sound.ctx || !Music.bus) return;
    // Hi-hat METALLIQUE facon 808 : des oscillateurs carres inharmoniques
    // (rapports de frequences "faux", comme une cymbale reelle) au lieu du
    // bruit blanc filtre -- plus doux, plus feutre, plus disco. Le son
    // decroit exponentiellement : attaque discrete, queue chantante.
    const dur = open ? 0.28 : 0.06;
    const t = t0;
    const g = Sound.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(open ? 0.085 : 0.065, t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    g.connect(Music.drumBus || Music.bus);
    // Groupe metallique : 6 partiels inharmoniques (style CR-78/808).
    const freqs = [263, 400, 421, 474, 587, 845];
    freqs.forEach((f, k) => {
        const osc = Sound.ctx.createOscillator();
        osc.type = 'square';
        osc.frequency.value = f * (open ? 1.02 : 1);
        const og = Sound.ctx.createGain();
        og.gain.value = (k < 2 ? 0.30 : 0.18) / freqs.length;
        osc.connect(og); og.connect(g);
        osc.start(t); osc.stop(t + dur + 0.02);
    osc.onended = () => { try { osc.disconnect(); } catch (e) {} };
    });
    // Souffle doux par-dessus : la texture feutree, tres discrete.
    const buf = Sound.ctx.createBuffer(1, Math.ceil(Sound.ctx.sampleRate * dur), Sound.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let n = 0; n < data.length; n++) data[n] = (Math.random() * 2 - 1) * Math.pow(1 - n / data.length, open ? 2.2 : 3.5);
    const src = Sound.ctx.createBufferSource();
    src.buffer = buf;
    const f = Sound.ctx.createBiquadFilter();
    f.type = 'highpass'; f.frequency.value = 9000;
    const ng = Sound.ctx.createGain();
    ng.gain.value = open ? 0.05 : 0.035;
    src.connect(f); f.connect(ng); ng.connect(g);
    src.start(t);
}


// Clap disco : triple micro-retard de bruit -- l'identite "Oh Joy".
function musicClap(t0) {
    if (!Sound.ctx || !Music.bus) return;
    for (let k = 0; k < 3; k++) {
        const dt = k * 0.012;
        const buf = Sound.ctx.createBuffer(1, Math.ceil(Sound.ctx.sampleRate * 0.14), Sound.ctx.sampleRate);
        const data = buf.getChannelData(0);
        for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / data.length, 1.6);
        const src = Sound.ctx.createBufferSource();
        src.buffer = buf;
        const f = Sound.ctx.createBiquadFilter();
        f.type = 'bandpass'; f.frequency.value = 1600; f.Q.value = 1.2;
        const g = Sound.ctx.createGain();
        g.gain.value = 0.16 - k * 0.03;
        src.connect(f); f.connect(g); g.connect(Music.drumBus || Music.bus);
        src.start(t0 + dt);
    }
    // Corps doux.
    musicTone(190, 140, 0.09, 'triangle', 0.10, null, { at: t0 });
}

// --- Basse disco ronde : sub + saw chaleureuse, motif syncop\u00e9 ---
function musicBass(root, dur, at, glideEnd) {
    // Sub sinus : le fond chaleureux.
    musicTone(root / 2, glideEnd ? glideEnd / 2 : root / 2, dur, 'sine', 0.34, null, { at: at });
    // Saw : le corps, filtre doux qui s'ouvre l\u00e9g\u00e8rement.
    musicTone(root, glideEnd || root, dur * 0.92, 'sawtooth', 0.17,
        { type: 'lowpass', freq: 420, freqEnd: 640, q: 4 }, { at: at });
}

// Un pas du s\u00e9quenceur. t0 = temps AUDIO ABSOLU (scheduler).
function musicStep(t0) {
    if (t0 === undefined || !Sound.ctx) t0 = Sound.ctx ? Sound.ctx.currentTime : 0;
    const sec = Music.section();
    const ch = Music.chordForBar(Music.bar);
    const s = Music.step;
    const step16 = (60 / Music.bpm) / 4;
    const fill = Music.isFill();
    // SWING disco : les 16e impairs (contretemps) avancent un peu --
    // le groove "Oh Joy" respire, il n'est pas quantis\u00e9 raide.
    const sw = (s % 2 === 1) ? step16 * 0.22 : 0;
    const t = t0 + sw;

    // --- Batterie ---
    if (sec !== 3) {
        if (s % 4 === 0) musicKick(t0);                    // 4-on-the-floor doux
        if (s % 2 === 1) musicHat(t0, s === 15);           // hats sur les contretemps (swing\u00e9s)
        if (s === 4 || s === 12) musicClap(t0);             // clap sur 2 et 4
        if (fill && s >= 12 && s % 2 === 0) musicClap(t0);  // fill : claps qui densifient
    } else {
        if (s === 0 || s === 8) musicKick(t0);
        if (s === 4 || s === 12) musicClap(t0);
        if (s % 2 === 1) musicHat(t0, false);
    }

    // --- Basse disco : ROOT..octave..root..quinte, rond et chantant ---
    if (sec !== 3) {
        // Motif syncop\u00e9 : 1 . . & . . 1 . . & . . 1 . & .
        const bassPat = { 0: 1.0, 3: 2.0, 6: 1.0, 8: 1.5, 11: 1.0, 14: 2.0 };
        const mult = bassPat[s];
        if (mult) {
            const dur = mult === 2.0 ? 0.30 : 0.22;
            musicBass(ch.root * mult, dur, t);
        }
    } else if (s === 0) {
        // Breakdown : basse qui respire en rondes douces.
        musicBass(ch.root, step16 * 7, t);
    }

    // --- Stabs d'accords disco : sur les "&" de 2 et 4 --
    //     le geste signature : cuivres synth\u00e9tiques doux et joyeux.
    if ((sec === 2 || sec === 1) && (s === 3 || s === 7 || s === 11 || s === 15)) {
        ch.notes.forEach((n, i) => {
            musicTone(n * 2, n * 2, 0.14, 'sawtooth', 0.035,
                { type: 'lowpass', freq: 1600 + i * 250, q: 2 }, { at: t, detune: (i - 1.5) * 6, echo: 0.22, space: 0.3 });
        });
    }

    // --- Arp\u00e8ge cristallin : croches douces, motif monte/descend --
    //     la scintillance joyeuse qui court sous le lead.
    if (sec >= 1) {
        const eighth = Math.floor(s / 2);
        const arpSeq = [0, 1, 2, 3, 2, 1, 2, 3];   // mont\u00e9e-redescente fluide
        const f = ch.notes[arpSeq[eighth % 8]] * 4;
        musicTone(f, f, 0.16, 'square', 0.030,
            { type: 'lowpass', freq: 2400, q: 1.5 }, { at: t, detune: (Math.random() - 0.5) * 6, echo: 0.30, space: 0.35 });
        // Octave brillante tr\u00e8s discr\u00e8te sur les temps forts.
        if (s % 4 === 0) musicTone(f * 2, f * 2, 0.10, 'square', 0.011,
            { type: 'lowpass', freq: 4800, q: 1 }, { at: t, echo: 0.28, space: 0.5 });
    }

    // --- LEAD : les m\u00e9lodies compos\u00e9es, une phrase par mesure.
    //     Call & response : A / B / A' / C sur 4 mesures (2 par accord).
    if (sec === 2 || sec === 3) {
        // La phrase est celle de l'ACCORD courant (change toutes les 2 mesures).
        const noteIdx = Math.floor(s / 2);                 // une note / croche
        if (noteIdx < 8 && s % 2 === 0) {
            // Note = fondamentale de l'ACCORD (une octave au-dessus de
            // sa racine) + le degre de gamme de la phrase : la melodie
            // suit l'harmonie, juste sur chaque accord.
            // Note = indice DIRECT dans la gamme D majeur : diatonique
            // garanti, et la phrase est composee pour sonner sur son accord.
            const ci = Music.chordIndexForBar(Music.bar);
            const chordPhrase = Music.leadPhrases[ci];
            const semis = Music.dMajorScale[chordPhrase[noteIdx]];
            const base = 293.66 * Math.pow(2, semis / 12);   // D4
            // Phrase A : les notes longues chantent avec vibrato.
            const isLong = (noteIdx === 0 || noteIdx === 4 || noteIdx === 7);
            if (isLong) {
                musicVibrato(base, step16 * 3.2, 'sawtooth', 0.055,
                    { type: 'lowpass', freq: 2100, q: 1.6 }, { at: t, echo: 0.35, space: 0.5 });
            } else {
                // Notes courtes : plucks doux avec legere mont\u00e9e de pitch.
                musicTone(base * 0.99, base, 0.22, 'sawtooth', 0.045,
                    { type: 'lowpass', freq: 2400, q: 1.6 }, { at: t, detune: (Math.random() - 0.5) * 5, echo: 0.30, space: 0.45 });
            }
            // Doublage une octave en dessous : chaleur, facon chorus.
            musicTone(base / 2, base / 2, 0.18, 'sawtooth', 0.020,
                { type: 'lowpass', freq: 1500, q: 1 }, { at: t, detune: -7, echo: 0.25 });
        }
    }

    // --- Nappe de fond : accords tenus tr\u00e8s doux, touche finale ---
    if (s === 0 && (sec === 2 || sec === 3)) {
        ch.notes.slice(0, 3).forEach((n, i) => {
            musicTone(n, n, step16 * 15, 'sawtooth', 0.016,
                { type: 'lowpass', freq: 750, q: 1 }, { at: t0, attack: 0.8, space: 0.6 });
        });
    }

    // --- Toms de relance : fin du breakdown ---
    if (sec === 3 && Music.bar % Music.sectionLen === Music.sectionLen - 1) {
        if (s === 8 || s === 12) {
            musicTone(170, 95, 0.16, 'sine', 0.22, null, { at: t0 });
        }
    }

    // Avance le s\u00e9quenceur.
    Music.step = (Music.step + 1) % 16;
    if (Music.step === 0) Music.bar = (Music.bar + 1) % 128;   // boucle ~ 5 min
}

function startMusic() {
    if (Music.playing || !Music.enabled) return;
    musicInit();
    if (!Music.bus || !Sound.ctx) return;
    try {
        Music.bus.gain.cancelScheduledValues(Sound.ctx.currentTime);
        Music.bus.gain.setValueAtTime(0.85, Sound.ctx.currentTime);
    } catch (e) {}
    Music.playing = true;
    Music.step = 0;
    Music.bar = 0;
    // SCHEDULER LOOK-AHEAD : chaque pas est planifi\u00e9 ~200 ms en avance
    // sur l'horloge AUDIO -- le groove est au sample pr\u00e8s, la d\u00e9rive
    // de setInterval n'a aucun effet sur le tempo.
    const stepDur = (60 / Music.bpm) / 4;
    // Depart ALIGNe sur la grille : premier pas = prochaine frontiEre
    // de pas APRES maintenant (t + 0.1 s de marge), pas un multiple
    // absolu arbitraire qui dEcalait la phase de tout le morceau.
    Music.nextTime = Sound.ctx.currentTime + stepDur - ((Sound.ctx.currentTime + 0.1) % stepDur) + 0.1;
    Music.timer = setInterval(function () {
        if (!Sound.ctx || !Music.playing) return;
        try {
            let guard = 0;
            while (Music.nextTime < Sound.ctx.currentTime + 0.2 && guard++ < 8) {
                musicStep(Music.nextTime);
                Music.nextTime += stepDur;
            }
            if (Music.nextTime < Sound.ctx.currentTime - 0.5) {
                Music.nextTime = Sound.ctx.currentTime + 0.15;
            }
        } catch (e) {
            stopMusic();
        }
    }, 50);
}

function stopMusic() {
    if (Music.timer) { clearInterval(Music.timer); Music.timer = null; }
    Music.playing = false;
    if (Music.bus && Sound.ctx) {
        try {
            Music.bus.gain.cancelScheduledValues(Sound.ctx.currentTime);
            Music.bus.gain.setValueAtTime(Music.bus.gain.value, Sound.ctx.currentTime);
            Music.bus.gain.linearRampToValueAtTime(0.0001, Sound.ctx.currentTime + 0.08);
        } catch (e) {}
    }
}

const Sounds = {
    // Clic sur la médaille : tick doux, pitch légèrement aléatoire, anti-spam 30 ms
    click() {
        if (!ClickSound.enabled) return;
        // Vrai son de piece de monnaie, bien audible : le classique "coin
        // collect" (piece Zelda / rupee) — deux notes metalliques cristallines
        // en intervalle de quarte ascendante (Si grave puis Mi aigu), chaque
        // note = fondamentale forte + partiel metallique inharmonique +
        // petite attaque carree. Pitch legerement improvise a chaque clic.
        const now = performance.now();
        if (now - Sound._lastClick < 40) return;
        Sound._lastClick = now;
        const detune = 1 + (Math.random() - 0.5) * 0.04;
        const f1 = 988 * detune;   // Si5 : premiere note, cristalline
        const f2 = 1319 * detune;   // Mi6 : seconde note, claire et conclusive
        // Note 1 : attaque breve + fondamentale cristalline + partiel metal
        soundTone(f1, f1, 0.012, 'square', 0.1);
        soundTone(f1, f1 * 0.998, 0.11, 'sine', 0.3);
        soundTone(f1 * 2.76, f1 * 2.7, 0.07, 'sine', 0.07, 0.002);
        // Note 2 : la reponse, plus aigue, qui conclut le geste
        soundTone(f2, f2, 0.012, 'square', 0.1, 0.075);
        soundTone(f2, f2 * 0.998, 0.16, 'sine', 0.32, 0.075);
        soundTone(f2 * 2.76, f2 * 2.7, 0.08, 'sine', 0.06, 0.077);
    },
    // Achat : pop satisfaisant, deux notes montantes
    buy() {
        soundTone(360, 520, 0.09, 'sine', 0.4);
        soundTone(540, 720, 0.12, 'sine', 0.3, 0.06);
    },
    // Construction d'une piece de fusee : soudure metallique (souffle bref)
    // puis note claire qui "verrouille" la piece, comme un rivet pose.
    partBuilt() {
        soundNoise(0.12, 0.22, 2600, 900);
        soundTone(220, 90, 0.1, 'square', 0.12);
        soundTone(1245, 1245, 0.16, 'triangle', 0.3, 0.1);
        soundTone(1865, 1865, 0.22, 'sine', 0.18, 0.16);
    },
    // Fanfare de reussite du lancement : arpege majeur triomphal qui monte,
    // la recompense de plusieurs minutes de production.
    launchFanfare() {
        const notes = [523, 659, 784, 1047];
        notes.forEach((f, i) => {
            soundTone(f, f, 0.16, 'triangle', 0.32, i * 0.11);
        });
        soundTone(1047, 1047, 0.5, 'triangle', 0.36, 0.44);
        soundTone(1319, 1319, 0.5, 'sine', 0.26, 0.44);
        soundTone(523, 523, 0.55, 'sine', 0.2, 0.46);
        // Etincelles cristallines au-dessus de l'accord final
        soundTone(2093, 2093, 0.18, 'sine', 0.1, 0.55);
        soundTone(2637, 2637, 0.22, 'sine', 0.08, 0.62);
    },
    // Un bâtiment devient abordable : "ding-dong" feutré en registre
    // grave, timbre triangle + quinte descendante — timbre distinct de
    // l'achat (aigu) et du déblocage (arpège) pour être reconnaissable.
    affordable() {
        soundTone(660, 660, 0.12, 'triangle', 0.22);
        soundTone(440, 440, 0.22, 'triangle', 0.2, 0.13);
    },
    // Nouveau bâtiment débloqué : jingle 3 notes ascendantes
    unlock() {
        soundTone(523, 523, 0.14, 'triangle', 0.35);
        soundTone(659, 659, 0.14, 'triangle', 0.35, 0.12);
        soundTone(784, 784, 0.22, 'triangle', 0.4, 0.24);
    },
    // Amélioration (upgrade) : bip cristallin
    upgrade() {
        soundTone(880, 1320, 0.1, 'sine', 0.35);
    },
    // Coup critique (x3) : fanfare doree -- accord majeur brillant
    // monte en arpege (Do-Mi-Sol-Do) avec partiel metallique,
    // nettement distinct du "coin" standard du clic.
    critical() {
        // Regi par le meme toggle que le son de clic : le bouton
        // "Desactiver le son du clic" coupe AUSSI les fanfares de crit.
        if (!ClickSound.enabled) return;
        const detune = 1 + (Math.random() - 0.5) * 0.03;
        soundTone(523 * detune, 523 * detune, 0.09, 'triangle', 0.3, 0);
        soundTone(659 * detune, 659 * detune, 0.09, 'triangle', 0.3, 0.07);
        soundTone(784 * detune, 784 * detune, 0.1, 'triangle', 0.3, 0.14);
        soundTone(1047 * detune, 1047 * detune, 0.22, 'triangle', 0.34, 0.21);
        soundTone(2093 * detune, 2093 * detune, 0.12, 'square', 0.06, 0.21);
    },
    // Comète : whoosh du missile puis explosion
    missile() {
        // Sifflement de missile realiste : comme avant, le sifflement aigu
        // descendant (l'arme qui tombe, Doppler), mais avec plus de corps —
        // une couche grave ronde qui glisse avec et un souffle d'air autour,
        // plus vivant qu'un sinus pur. Realiste et reconnaissable.
        soundTone(2400, 400, 0.5, 'sine', 0.3);
        soundTone(480, 120, 0.5, 'sine', 0.12);
        soundNoise(0.45, 0.08, 1800, 500, 0.03);
    },
    explosion() {
        // Combo ultra satisfaisant : impact qui claque SEC (claquement +
        // punch grave profond), puis une recompense cristalline qui monte
        // (deux notes do->sol aiguEs, la pieces gagnee) — le "payoff" du
        // missile. Tout reste bref et rond, dans le style du jeu.
        // Claquement initial tres present
        soundNoise(0.05, 0.45, 9000, 3000);
        // Le punch grave du BOOM, profond et bref
        soundTone(100, 40, 0.15, 'sine', 0.5);
        // Souffle de frappe court pour l'assise
        soundNoise(0.2, 0.25, 900, 150);
        // Payoff : notes cristallines montantes qui recompensent le hit
        soundTone(1047, 1047, 0.12, 'sine', 0.2, 0.1);
        soundTone(1568, 1568, 0.2, 'sine', 0.24, 0.2);
    },
    // Contrat : accepté / rempli / échoué
    // Nouveau contrat disponible : carillon d'annonce, deux notes claires
    contractNew() {
        soundTone(880, 880, 0.09, 'sine', 0.32);
        soundTone(1175, 1175, 0.16, 'sine', 0.3, 0.1);
    },
    contractAccept() {
        soundTone(440, 440, 0.1, 'sine', 0.3);
        soundTone(587, 587, 0.14, 'sine', 0.3, 0.09);
    },
    contractDone() {
        soundTone(587, 587, 0.1, 'triangle', 0.35);
        soundTone(784, 784, 0.1, 'triangle', 0.35, 0.09);
        soundTone(988, 988, 0.2, 'triangle', 0.4, 0.18);
    },
    contractFail() {
        soundTone(330, 220, 0.3, 'sawtooth', 0.25);
        soundTone(196, 130, 0.4, 'sine', 0.25, 0.1);
    },
    // Perte generique (achat impossible, comete ratee, bonus expire) :
    // petit duo descendant bref, discret mais clairement negatif
    lose() {
        soundTone(311, 233, 0.14, 'sine', 0.22);
        soundTone(233, 165, 0.2, 'sine', 0.2, 0.09);
    },
    // Alerte pluie de cometes naturelle : trois notes montantes cristallines
    // suivies d'un souffle — previent l'oreille avant que l'oeil ne voie la pluie
    showerAlert() {
        soundTone(392, 392, 0.16, 'triangle', 0.3);
        soundTone(523, 523, 0.16, 'triangle', 0.3, 0.16);
        soundTone(659, 659, 0.22, 'triangle', 0.26, 0.32);
        soundNoise(0.5, 0.12, 2000, 6000, 0.34);
    },
    // Booster de cartes : ouverture mystique
    booster() {
        // Ouverture du booster : UNIQUEMENT le swell mysterieux qui monte depuis
        // le grave -- l'accord cristallin de revelation n'est plus joue ici mais
        // au retournement de la carte (Sounds.cardFlip), adapte a sa rarete.
        soundTone(110, 440, 0.35, 'sine', 0.26);
        soundTone(165, 660, 0.35, 'sine', 0.14);
        soundNoise(0.25, 0.18, 3000, 7000, 0.3);
    },
    // Retournement d'une carte de booster : accord cristallin dont la
    // couleur ET la richesse dependent de la rarete -- la commune reste
    // sobre (deux notes), chaque palier ajoute des notes plus lumineuses,
    // jusqu'a la fanfare complete de l'alternative.
    cardFlip(rarity) {
        const d = 0.05;
        if (rarity === 'rare') {
            soundTone(880, 880, 0.25, 'sine', 0.26, d);
            soundTone(1109, 1109, 0.25, 'sine', 0.2, d + 0.05);
            soundTone(1319, 1319, 0.4, 'sine', 0.24, d + 0.1);
        } else if (rarity === 'epic') {
            soundTone(784, 784, 0.2, 'triangle', 0.26, d);
            soundTone(988, 988, 0.2, 'triangle', 0.24, d + 0.06);
            soundTone(1175, 1175, 0.25, 'triangle', 0.24, d + 0.12);
            soundTone(1568, 1568, 0.45, 'sine', 0.26, d + 0.18);
        } else if (rarity === 'legendary') {
            soundTone(659, 659, 0.16, 'triangle', 0.3, d);
            soundTone(880, 880, 0.16, 'triangle', 0.3, d + 0.08);
            soundTone(1109, 1109, 0.16, 'triangle', 0.3, d + 0.16);
            soundTone(1319, 1319, 0.2, 'triangle', 0.32, d + 0.24);
            soundTone(1760, 1760, 0.55, 'sine', 0.3, d + 0.36);
            soundTone(2217, 2217, 0.5, 'sine', 0.14, d + 0.4);
        } else if (rarity === 'alternative') {
            soundTone(523, 523, 0.18, 'triangle', 0.3, d);
            soundTone(784, 784, 0.18, 'triangle', 0.3, d + 0.09);
            soundTone(1047, 1047, 0.18, 'triangle', 0.3, d + 0.18);
            soundTone(1319, 1319, 0.22, 'triangle', 0.32, d + 0.27);
            soundTone(1568, 1568, 0.22, 'triangle', 0.28, d + 0.36);
            soundTone(2093, 2093, 0.6, 'sine', 0.3, d + 0.45);
            soundTone(2637, 2637, 0.5, 'sine', 0.12, d + 0.5);
        } else {
            soundTone(880, 880, 0.3, 'sine', 0.26, d);
            soundTone(1109, 1109, 0.35, 'sine', 0.18, d + 0.05);
        }
    },
    // Booster pret a etre ouvert : annonce claire et festive, deux notes
    // cristallines montees puis accord lumineux tenu — un "fanfare courte"
    // distinct de l'ouverture mystique du paquet.
    boosterReady() {
        soundTone(659, 659, 0.14, 'triangle', 0.34);
        soundTone(988, 988, 0.16, 'triangle', 0.34, 0.12);
        soundTone(1319, 1319, 0.3, 'sine', 0.3, 0.24);
        soundTone(1976, 1976, 0.35, 'sine', 0.16, 0.28);
        soundTone(659, 659, 0.35, 'sine', 0.12, 0.3);
    },
    // Pièce de fusée qui s'empile : choc métallique + verrouillage
    partStack() {
        // Une pièce de fusée qui tombe à sa place : clac métallique grave
        // au contact (le choc), puis petit cliquetis de verrouillage (la
        // pièce qui se clipse), discret et satisfaisant, dans le style des
        // autres sons.
        soundTone(320, 180, 0.08, 'square', 0.14);
        soundTone(160, 90, 0.14, 'sine', 0.2);
        soundNoise(0.06, 0.14, 4000, 900);
        soundTone(1175, 1175, 0.05, 'square', 0.06, 0.09);
        soundTone(1568, 1568, 0.07, 'sine', 0.08, 0.1);
    },
    // Trophée : fanfare discrète
    trophy() {
        soundTone(659, 659, 0.1, 'triangle', 0.3);
        soundTone(784, 784, 0.1, 'triangle', 0.3, 0.1);
        soundTone(1047, 1047, 0.26, 'triangle', 0.38, 0.2);
    },
    // Lancement : la sequence complete est pilotee par launchSoundSequence()
    launch() {}
};
// ===== Boucles audio continues (moteurs, voyage) =====
const SoundLoops = {};
// Demarre une boucle de bruit rose filtrE, retourne un handle { stop() }
function soundStartNoiseLoop(freqStart, freqEnd, vol, rampSec) {
    if (!Sound.enabled) return null;
    soundResume();
    if (!Sound.ctx) return null;
    const ctx = Sound.ctx;
    const len = Math.floor(ctx.sampleRate * 2);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
        // Bruit rose approx : moyenne glissante du blanc
        const w = Math.random() * 2 - 1;
        last = (last + 0.03 * w) / 1.03;
        data[i] = last * 3.2;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.setValueAtTime(freqStart, ctx.currentTime);
    filt.frequency.linearRampToValueAtTime(freqEnd, ctx.currentTime + (rampSec || 1));
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, ctx.currentTime);
    g.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.15);
    src.connect(filt); filt.connect(g); g.connect(Sound.master);
    src.start();
    return {
        stop(fadeSec) {
            const t = ctx.currentTime;
            g.gain.cancelScheduledValues(t);
            g.gain.setValueAtTime(g.gain.value, t);
            g.gain.linearRampToValueAtTime(0, t + (fadeSec || 0.4));
            setTimeout(() => { try { src.stop(); } catch (e) {} }, ((fadeSec || 0.4) * 1000) + 80);
        }
    };
}
// Boucle de moteur : oscillateurs graves + modulations, handle { stop() }
function soundStartEngineLoop(baseFreq, vol) {
    if (!Sound.enabled) return null;
    soundResume();
    if (!Sound.ctx) return null;
    const ctx = Sound.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, ctx.currentTime);
    g.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.2);
    g.connect(Sound.master);
    const oscs = [];
    // Couche 1 : grondement fondamental (sawtooth tres grave, filtre passe-bas)
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = baseFreq;
    const f1 = ctx.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.value = 260;
    o1.connect(f1); f1.connect(g); o1.start(); oscs.push(o1);
    // Couche 2 : sub plus grave (sine) pour la poitrine
    const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = baseFreq * 0.5;
    o2.connect(g); o2.start(); oscs.push(o2);
    // Couche 3 : LFO de trEmblement sur la frequence (vibration moteur)
    const lfo = ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 11;
    const lfoG = ctx.createGain(); lfoG.gain.value = baseFreq * 0.12;
    lfo.connect(lfoG); lfoG.connect(o1.frequency); lfo.start(); oscs.push(lfo);
    return {
        stop(fadeSec) {
            const t = ctx.currentTime;
            g.gain.cancelScheduledValues(t);
            g.gain.setValueAtTime(g.gain.value, t);
            g.gain.linearRampToValueAtTime(0, t + (fadeSec || 0.5));
            oscs.forEach(o => { try { o.stop(t + (fadeSec || 0.5) + 0.1); } catch (e) {} });
        }
    };
}
// SEQUENCE sonore complete du lancement : compte a rebours (bips), ignition
// (moteurs + souffle), decollage (montee en puissance), puis extinction.
// THEME DE LANCEMENT EPIQUE : composition dediee au decollage (~6 s).
// Structure : nappe de tension du compte a rebours -> IGNITION : arpEge
// montant en croches + basse pompEe + timbales -> fanfare de decollage
// (accords majeurs) -> decroissance, l'ambiance de voyage prend le
// relais. Joue en parallele des bruitages moteur existants.
function playLaunchTheme() {
    if (!Sound.enabled || !Sound.ctx) return;
    soundResume();
    // Couper la musique de fond pendant le lancement.
    if (typeof stopMusic === 'function' && Music.playing) {
        stopMusic();
        playLaunchTheme._resumeBg = true;
    }
    const t0 = Sound.ctx.currentTime + 0.05;
    // Helper : note planifiee (temps absolu).
    const at = (dt) => t0 + dt;
    // --- Compte a rebours : nappe de tension (E mineur, basse drone).
    // Nappe : deux saw detunees filtrees qui montent doucement.
    const padNotes = [164.81, 196.00, 246.94];   // E3 G3 B3
    padNotes.forEach((f, i) => {
        const osc = Sound.ctx.createOscillator();
        const g = Sound.ctx.createGain();
        const filt = Sound.ctx.createBiquadFilter();
        osc.type = 'sawtooth';
        osc.frequency.value = f;
        osc.detune.value = (i - 1) * 8;
        filt.type = 'lowpass';
        filt.frequency.setValueAtTime(600, at(0));
        filt.frequency.linearRampToValueAtTime(1400, at(2.0));
        filt.Q.value = 2;
        g.gain.setValueAtTime(0.0001, at(0));
        g.gain.linearRampToValueAtTime(0.05, at(0.4));
        g.gain.setValueAtTime(0.05, at(1.9));
        g.gain.linearRampToValueAtTime(0.0001, at(2.4));
        osc.connect(filt); filt.connect(g);
        g.connect(Sound.master);
        osc.start(at(0)); osc.stop(at(2.5));
    });
    // Basse drone de tension.
    const droneOsc = Sound.ctx.createOscillator();
    const droneG = Sound.ctx.createGain();
    droneOsc.type = 'sawtooth';
    droneOsc.frequency.value = 82.41;   // E2
    droneG.gain.setValueAtTime(0.0001, at(0));
    droneG.gain.linearRampToValueAtTime(0.10, at(0.5));
    droneG.gain.setValueAtTime(0.10, at(1.9));
    droneG.gain.linearRampToValueAtTime(0.0001, at(2.4));
    droneOsc.connect(droneG);
    droneG.connect(Sound.master);
    droneOsc.start(at(0)); droneOsc.stop(at(2.5));

    // --- IGNITION (T+2.1 s) : arpege montant + timbales + basse pompEe.
    // Arpege : E mineur montant sur 2 octaves, croches, echo.
    const arpSeq = [164.81, 196.00, 246.94, 329.63, 392.00, 493.88, 659.26, 783.99];
    arpSeq.forEach((f, i) => {
        const dt = 2.1 + i * 0.14;
        const osc = Sound.ctx.createOscillator();
        const g = Sound.ctx.createGain();
        const filt = Sound.ctx.createBiquadFilter();
        osc.type = 'square';
        osc.frequency.value = f * 2;
        filt.type = 'lowpass';
        filt.frequency.value = 3200;
        filt.Q.value = 1.5;
        g.gain.setValueAtTime(0.0001, at(dt));
        g.gain.linearRampToValueAtTime(0.05, at(dt + 0.01));
        g.gain.exponentialRampToValueAtTime(0.0001, at(dt + 0.24));
        osc.connect(filt); filt.connect(g);
        g.connect(Sound.master);
        osc.start(at(dt)); osc.stop(at(dt + 0.3));
    });
    // Timbales : roulement 4 coups qui accelerent.
    [2.1, 2.45, 2.75, 3.0].forEach((dt, i) => {
        const osc = Sound.ctx.createOscillator();
        const g = Sound.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(160 - i * 10, at(dt));
        osc.frequency.exponentialRampToValueAtTime(60, at(dt) + 0.2);
        g.gain.setValueAtTime(0.5 - i * 0.08, at(dt));
        g.gain.exponentialRampToValueAtTime(0.0001, at(dt) + 0.35);
        osc.connect(g);
        g.connect(Sound.master);
        osc.start(at(dt)); osc.stop(at(dt) + 0.4);
    });
    // Basse pompEe post-ignition : E en doubles.
    [2.1, 2.35, 2.6, 2.85, 3.1, 3.35, 3.6, 3.85].forEach(dt => {
        const osc = Sound.ctx.createOscillator();
        const g = Sound.ctx.createGain();
        const filt = Sound.ctx.createBiquadFilter();
        osc.type = 'sawtooth';
        osc.frequency.value = 82.41;
        filt.type = 'lowpass';
        filt.frequency.value = 500;
        filt.Q.value = 4;
        g.gain.setValueAtTime(0.0001, at(dt));
        g.gain.linearRampToValueAtTime(0.16, at(dt + 0.01));
        g.gain.exponentialRampToValueAtTime(0.0001, at(dt + 0.2));
        osc.connect(filt); filt.connect(g);
        g.connect(Sound.master);
        osc.start(at(dt)); osc.stop(at(dt + 0.25));
    });

    // --- Fanfare de decollage (T+3.2 s) : accords majeurs montants.
    // E majeur -> A majeur -> B majeur : triomphant.
    const fanfareChords = [
        { t: 3.2, notes: [329.63, 415.30, 493.88] },   // E majeur
        { t: 3.7, notes: [440.00, 554.37, 659.26] },   // A majeur
        { t: 4.2, notes: [493.88, 622.25, 739.99] }    // B majeur
    ];
    fanfareChords.forEach(ch => {
        ch.notes.forEach((f, i) => {
            const osc = Sound.ctx.createOscillator();
            const g = Sound.ctx.createGain();
            const filt = Sound.ctx.createBiquadFilter();
            osc.type = 'sawtooth';
            osc.frequency.value = f;
            osc.detune.value = (i - 1) * 6;
            filt.type = 'lowpass';
            filt.frequency.value = 2600;
            filt.Q.value = 1.2;
            g.gain.setValueAtTime(0.0001, at(ch.t));
            g.gain.linearRampToValueAtTime(0.06, at(ch.t + 0.02));
            g.gain.exponentialRampToValueAtTime(0.0001, at(ch.t + 0.55));
            osc.connect(filt); filt.connect(g);
            g.connect(Sound.master);
            osc.start(at(ch.t)); osc.stop(at(ch.t + 0.6));
        });
    });
    // Note tenue finale (B) avec vibrato : le sommet.
    const leadOsc = Sound.ctx.createOscillator();
    const leadG = Sound.ctx.createGain();
    const lfo = Sound.ctx.createOscillator();
    const lfoG = Sound.ctx.createGain();
    leadOsc.type = 'sawtooth';
    leadOsc.frequency.value = 987.77;   // B5
    lfo.frequency.value = 5.5;
    lfoG.gain.value = 5;
    lfo.connect(lfoG); lfoG.connect(leadOsc.frequency);
    leadG.gain.setValueAtTime(0.0001, at(4.2));
    leadG.gain.linearRampToValueAtTime(0.07, at(4.35));
    leadG.gain.exponentialRampToValueAtTime(0.0001, at(5.8));
    const leadFilt = Sound.ctx.createBiquadFilter();
    leadFilt.type = 'lowpass';
    leadFilt.frequency.value = 3000;
    leadOsc.connect(leadFilt); leadFilt.connect(leadG);
    leadG.connect(Sound.master);
    leadOsc.start(at(4.2)); leadOsc.stop(at(5.9));
    lfo.start(at(4.2)); lfo.stop(at(5.9));

    // Reprise de la musique de fond apres le lancement (~7 s).
    setTimeout(() => {
        if (playLaunchTheme._resumeBg && Music.enabled && typeof startMusic === 'function') {
            startMusic();
        }
        playLaunchTheme._resumeBg = false;
    }, 7000);
}

function launchSoundSequence() {
    if (!Sound.enabled) return;
    soundResume();
    if (!Sound.ctx) return;
    // Bips du compte a rebours : 3.. 2.. 1 (bip grave) puis bip final aigu
    [0, 700, 1400].forEach(d => soundTone(440, 440, 0.12, 'square', 0.14, d / 1000));
    soundTone(880, 880, 0.25, 'square', 0.16, 2.1);
    // Ignition a T+2.1 s (compte a rebours ~2.1 s + marge d'allumage) :
    // grondement moteur + jet de souffle qui montent en puissance
    setTimeout(() => {
        SoundLoops.engine = soundStartEngineLoop(55, 0.5);
        SoundLoops.jet = soundStartNoiseLoop(400, 2400, 0.5, 1.2);
    }, 2050);
    // Extinction douce apres le decollage (la fusee est sortie de l'ecran)
    setTimeout(() => {
        if (SoundLoops.engine) { SoundLoops.engine.stop(1.2); SoundLoops.engine = null; }
        if (SoundLoops.jet) { SoundLoops.jet.stop(1.2); SoundLoops.jet = null; }
    }, 6500);
}
// AMBIANCE DE VOYAGE : moteur continu plus doux + vent spatial discret
function travelSoundStart() {
    if (!Sound.enabled) return;
    soundResume();
    if (!Sound.ctx) return;
    SoundLoops.travelEngine = soundStartEngineLoop(42, 0.22);
    SoundLoops.travelWind = soundStartNoiseLoop(900, 600, 0.1, 2);
}
function travelSoundStop() {
    if (SoundLoops.travelEngine) { SoundLoops.travelEngine.stop(0.6); SoundLoops.travelEngine = null; }
    if (SoundLoops.travelWind) { SoundLoops.travelWind.stop(0.6); SoundLoops.travelWind = null; }
}
function toggleMusic() {
    Music.enabled = !Music.enabled;
    localStorage.setItem('starcruiserMusic', Music.enabled ? '1' : '0');
    const btn = document.getElementById('music-toggle-btn');
    const btnLbl = btn ? btn.querySelector('#music-toggle-label') : null;
    if (btnLbl) btnLbl.textContent = Music.enabled ? t('Désactiver la musique de fond') : t('Activer la musique de fond');
    if (Music.enabled && Sound.enabled && typeof startMusic === 'function') startMusic();
    else if (typeof stopMusic === 'function') stopMusic();
}

function toggleSound() {
    Sound.enabled = !Sound.enabled;
    localStorage.setItem('starcruiserSound', Sound.enabled ? '1' : '0');
    const btn = document.getElementById('sound-toggle-btn');
    // V3.44bis : images dediees on/off (upload joueur) -- le bouton porte
    // une img unique dont la source suit l'etat, plus d'emoji.
    if (btn) {
        const icon = btn.querySelector('img') || document.getElementById('sound-toggle-icon');
        if (icon) icon.src = Sound.enabled ? 'images/SoundOn.webp' : 'images/SoundOff.webp';
    }
    if (Sound.enabled) {
        Sounds.click();
        if (typeof startMusic === 'function') startMusic();
    } else if (typeof stopMusic === 'function') {
        stopMusic();
    }
}
document.addEventListener('visibilitychange', () => {
    if (document.hidden && Sound.ctx && Sound.ctx.state === 'running') Sound.ctx.suspend();
    else if (!document.hidden && Sound.ctx && Sound.ctx.state === 'suspended' && Sound.enabled) Sound.ctx.resume();
});

// ============================================
// MAIN GAME LOOP
// ============================================

// ============================================
// PLUIE DE PIECES (panneau central)
// ============================================
// Densite liee aux Parts/s : 1 piece / 10 s a 1 Parts/s,
// 100 pieces / s a 1 000 000 Parts/s (progression racine, sans plafond).
const partsRain = {
    container: null,
    canvas: null,
    ctx: null,
    coinImg: null,
    sprite: null,
    parts: [],
    dpr: 1,
    spawnDebt: 0,
    lastTick: 0,
    lastFrame: 0,
    canvasClean: false
};
function getPartsRainRate() {
    // Mode basse config : pluie totalement coupee (l'animation la plus
    // couteuse du jeu) -- la production reste affichee via les compteurs.
    if (typeof lowConfigMode !== 'undefined' && lowConfigMode) return 0;
    if (partsPerSecond <= 0) return 0;
    // Mode degrade : debit divise par 3 -- les pieces restent presentes
    // (feedback de production conserve) mais le canvas coute 3x moins cher.
    // V3.31 (retour joueur : 'seule la pluie est ralentie, supprime tout ce
    // qui la limite') : PLUS AUCUN debit degrade -- la pluie defile a son
    // debit normal quel que soit le mode perf. Le mode low-perf ne coupe plus
    // que les effets CSS decoratifs.
    // (ancien: lowPerf -> 40 pieces/s)
    // 0.08 = 0.1 reduit de 20 % : moins de pieces visibles a debit egal.
    // Plafond dur a 100 pieces/s : au-dela, la densite visuelle n'ajoute
    // rien et la lecture du panneau central en souffre.
    // V3.30 (retour joueur) : MOINS de pieces mais PLUS GROSSES -- coefficient
    // 0.16 -> 0.11 (-30%) et taille +20% dans spawnRainPart : meme presence
    // visuelle, moins de draw calls par frame, moins de pression sur le FPS
    // (donc moins de passages en low-perf, donc moins d'arrets de pluie).
    return Math.min(0.11 * Math.sqrt(partsPerSecond), 140);
}
function resizeRainCanvas() {
    const canvas = partsRain.canvas;
    if (!canvas || !canvas.parentElement) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    // V3.49 : dpr plafonne a 1,25 (fluidite + memoire, retour joueur) : le
    // canvas etait rendu a 1,5x la resolution CSS -- sur un ecran 1080p le
    // buffer faisait ~50% de pixels en plus pour un gain de nettete
    // invisible sur des pieces de 6-26px.
    const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
    partsRain.dpr = dpr;
    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
}
// Pre-rend la piece dans un petit canvas offscreen (~48 px) : dessiner
// l'image 687x664 redimensionnee a 5-22 px pour chaque piece a chaque frame
// coutait tres cher et faisait decrocher le rendu sous les 60 fps.
function buildRainSprite() {
    const img = partsRain.coinImg;
    if (!img || !img.complete || !img.naturalWidth) return false;
    // V3.42 (retour joueur : 'la pluie ralentit, tourne pas en 60 fps alors
    // que tout le reste tourne a 60') : CAUSE -- le rendu canvas 2D passait
    // par setTransform (ecriture de matrice) + drawImage SCALE pour CHAQUE
    // piece et CHAQUE frame (jusqu'a 800 pieces = 800 changements de matrice
    // + 800 draw scalaires par frame, sur le CPU) alors que le reste du jeu
    // est compositE GPU (transitions CSS) et reste fluide meme quand le main
    // thread sature. FIX : PRE-RENDU de la piece a 12 pas de retournement
    // horizontal (l'effet 'piece qui virevolte' est un flip scaleX par le cos
    // de l'angle -- 12 quanta suffisent visuellement). Le rendu ne fait plus
    // QUE des drawImage BRUTS (aucune transformation par piece) : le canvas
    // defoule le GPU et tient 60 fps meme a 800 pieces.
    // 6 pas MONOTONES de face pleine a la tranche : sprite 0 = face (x1),
    // sprite 5 = tranche (x0.07). L'index au rendu est round((1-|cos|)*5) :
    // |cos|=1 -> 0 (face), |cos|=0 -> 5 (tranche), croissance monotone --
    // le virement de la piece parcourt les sprites 0->5->0 par demi-tour.
    const STEPS = 6;
    const spriteSize = 48;
    partsRain.sprites = [];
    for (let k = 0; k < STEPS; k++) {
        const sx = 1 - (k / (STEPS - 1)) * 0.93;
        const off = document.createElement('canvas');
        off.width = spriteSize;
        off.height = spriteSize;
        const octx = off.getContext('2d');
        octx.translate(spriteSize / 2, spriteSize / 2);
        octx.scale(sx, 1);
        octx.drawImage(img, -spriteSize / 2, -spriteSize / 2, spriteSize, spriteSize);
        partsRain.sprites.push(off);
    }
    partsRain.sprite = partsRain.sprites[0];
    return true;
}

function ensureRainCanvas() {
    if (partsRain.canvas) return true;
    const container = partsRain.container || document.getElementById('parts-rain');
    if (!container) return false;
    partsRain.container = container;
    const canvas = document.createElement('canvas');
    canvas.className = 'rain-canvas';
    container.appendChild(canvas);
    partsRain.canvas = canvas;
    partsRain.ctx = canvas.getContext('2d');
    const img = new Image();
    img.src = 'images/parts.webp';
    img.onload = buildRainSprite;
    partsRain.coinImg = img;
    window.addEventListener('resize', resizeRainCanvas);
    window.addEventListener('resize', refreshBonusBadgePosition);
    window.addEventListener('resize', fitCounterFontSize);
    resizeRainCanvas();
    partsRain.lastFrame = 0;
    requestAnimationFrame(rainFrame);
    return true;
}
const RAIN_RENDER_MIN_INTERVAL_MS = 0; // V3.3 : 60 fps natif (rAF), l'ancien plafond 16 ms bornait a ~30 fps
function rainFrame(now) {
    requestAnimationFrame(rainFrame);
    const canvas = partsRain.canvas;
    const ctx = partsRain.ctx;
    if (!canvas || !ctx) return;
    // V3.3 : rendu a CHAQUE frame rAF (60 fps) -- retour playtest : la pluie
    // paraissait saccadee a 30 fps. Le cout sera optimise plus tard.
    if (now - (partsRain.lastFrame || 0) < RAIN_RENDER_MIN_INTERVAL_MS) return;
    const dt = Math.min((now - partsRain.lastFrame) / 1000, 0.1);
    // Horloge murale distincte : les timestamps rAF comptent depuis le
    // chargement de la page, pas l'epoch — les comparer a Date.now()
    // cassait le garde-fou de tickPartsRain et purgait la pluie a chaque tick.
    partsRain.lastFrame = now;
    partsRain.lastFrameWall = Date.now();
    if (canvas.width <= 1) { resizeRainCanvas(); return; }
    // Idle quasi gratuit : si rien a dessiner, on ne clear meme pas le canvas
    // (il l'a deja EtE au dernier passage) — la boucle RAF devient no-op.
    if (partsRain.suspended || partsRain.parts.length === 0) {
        if (!partsRain.canvasClean) {
            // Reinitialiser la matrice avant le clear : la derniere piece
            // dessinee laisse un setTransform(cos(angle), ...) en place ; si
            // ce cos est proche de zero, clearRect ne nettoie qu'une bande
            // infime et les pieces restaient peintes, figees jusqu'au reload.
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            partsRain.canvasClean = true;
        }
        return;
    }
    partsRain.canvasClean = false;
    // Reinitialiser la matrice a l'identite : la frame precedente peut avoir
    // laisse une transformation piece en place, faussant clearRect.
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // V3.42 : les sprites pre-rendus sont obligatoires (le rendu brut les
    // consomme) -- si l'image n'est pas prete on ne dessine rien ce tick-ci.
    if ((!partsRain.sprites || partsRain.sprites.length === 0) && !buildRainSprite()) return;
    const sprite = partsRain.sprite;
    const parts = partsRain.parts;
    for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.angle += p.spinSpeed * dt;
        if (p.y - p.size > canvas.height) { parts.splice(i, 1); continue; }
        // V3.42 : sprite PRE-RENDU -- l'angle est quantifie sur les 12 pas
        // du virement (l'ancien cos continu etait indiscernable de 12 quanta
        // sur une piece de 6-26 px). Plus AUCUNE transformation par piece :
        // un drawImage brut par piece, la matrice reste a l'identite tout au
        // long de la frame -- c'est le chemin le moins cher que canvas 2D
        // connaisse et il passe sur le GPU.
        const c = Math.abs(Math.cos(p.angle));
        const step = Math.min(partsRain.sprites.length - 1, Math.round((1 - c) * (partsRain.sprites.length - 1)));
        const sp = partsRain.sprites[step] || sprite;
        ctx.drawImage(sp, p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
    }
}
function tickPartsRain(now) {
    if (gameplayPaused) { partsRain.lastTick = now; return; }
    if (!ensureRainCanvas()) return;
    if (partsRain.suspended) { partsRain.lastTick = now; partsRain.spawnDebt = 0; return; }
    const rate = getPartsRainRate();
    if (rate <= 0) { partsRain.lastTick = now; partsRain.spawnDebt = 0; return; }
    if (!partsRain.lastTick) partsRain.lastTick = now;
    // Garde anti-empilement : si requestAnimationFrame n'a pas rendu de frame
    // depuis longtemps (fenetre masquee sans visibilitychange, ecran veille,
    // throttling RAF du navigateur), le timer continuait a spawn des pieces
    // qui n'etaient ni animees ni supprimees — d'ou la pile qui tourne d'un
    // coup au retour. On purge tout tant que le rendu est fige.
    // V3.25 : seuil releve 1 s -> 2,5 s (retour joueur : un clic sur la piece
    // peut provoquer un gros reflow -- click-effect + shockwave + re-render ;
    // si UNE frame rAF prend > 1 s de retard sous pression, la pluie etait
    // purgee alors que le jeu tournait normalement : la pluie s'arretrait
    // 'quand je clique'. 2,5 s ne purge plus que les vrais gels).
    // V3.31 : la purge anti-empilement ne se fait PLUS pendant le jeu actif
    // (retour joueur : 'elle s arrete puis reprend ?!?!') -- meme apres un
    // gros ralentissement de frames, la pluie REPREND telle quelle : les
    // pieces hors-ecran sont evacuees par le rendu lui-meme. La purge n'a
    // lieu que si l'onglet est REELLEMENT cache (le rendu est alors fige a
    // coup sur, et la reprise repart proprement).
    if (partsRain.lastFrameWall && document.hidden && now - partsRain.lastFrameWall > 2500) {
        partsRain.parts.length = 0;
        partsRain.spawnDebt = 0;
        partsRain.lastTick = now;
        return;
    }
    // Accumulateur : autorise plusieurs spawns par tick aux debits eleves,
    // tout en gardant le rythme exact aux faibles debits. Plafonne a 0.5 s de
    // dette (au lieu de 1 x rate) : meme aux tres hauts debits, aucune rafale
    // ne peut vider un stock de pieces d'un seul coup au retour.
    partsRain.spawnDebt = Math.min(partsRain.spawnDebt + (rate * (now - partsRain.lastTick)) / 1000, rate * 0.5);
    partsRain.lastTick = now;
    // V3.49 : cap 800 -> 500 (retour joueur fluidite) : au debit max (140/s,
        // vie ~5-9 s) le cap tronquait deja ; 500 pieces a l'ecran restent
        // tres denses et le rendu fait ~36% de draw calls en moins au pic.
        while (partsRain.spawnDebt >= 1 && partsRain.parts.length < 500) {
        partsRain.spawnDebt -= 1;
        spawnRainPart();
    }
}
// Purge de la pluie quand la page est masquee : au rechargement ou au retour
// d'onglet, aucune piece stockee ne doit se mettre a tourner d'un coup.
// V3.3 : l'ancien gel visibilitychange (purge pluie + pause mobile) donnait
// l'impression d'un JEU PLANTE au retour d'onglet -- compteurs figes, cometes
// incli quables. Supprime : au retour, le jeu continue la ou il etait. La
// securite anti-abus reste assuree ailleurs (gameLoop plafonne les grands dt
// via applyOfflineEarnings ; le garde-fou RAF purge la pluie si le rendu a
// ete fige plus d'une seconde).
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        partsRain.suspended = true;
        partsRain.parts.length = 0;
        partsRain.spawnDebt = 0;
        // MOBILE : la page laissee en arriere-plan ne doit PAS produire a
        // l'infini -- un PC s'eteint et passe par le systeme hors-ligne
        // plafonne (applyOfflineEarnings a la reouverture), mais un onglet
        // mobile en arriere-plan reste ouvert indetermine : les timers,
        // meme throttles par le navigateur, continuaient a crediter des
        // Parts sans AUCUN plafond. On fige la boucle de jeu et on note
        // l'heure : au retour, le temps d'absence passe par le meme systeme
        // plafonne (modal "Bon retour" incluse), exactement comme si la
        // partie avait ete fermee puis rouverte.
        // saveDisabled : pendant une IMPORTATION (fenetre entre l'ecriture
        // de la save importee et le reload), AUCUN saveGame ne doit passer --
        // ce handler mobile sauvegardait l'etat ANCIEN (partie en cours en
        // memoire) par-dessus la save importee : au reload, le nom etait
        // restaure (cle dediee) mais la progression restait l'ANCIENNE --
        // exactement le bug "l'import reprend le nom mais pas le reste".
        if (typeof isMobileLayout === 'function' && isMobileLayout()
            && !gameplayPaused && !mobileBackgroundFrozenAt && !saveDisabled) {
            mobileBackgroundFrozenAt = Date.now();
            // Reutilise la pause de gameplay (purge ecran, gel boucle) et
            // surtout son decalage d'echeances au retour : les contrats et
            // rotations ne doivent pas expirer pendant l'arriere-plan.
            setGameplayPaused(true);
            try { saveGame(); } catch (e) {}
        }
        // DESKTOP : noter l'heure de masquage pour crediter la duree REELLE
        // au retour (la boucle est figee par le garde document.hidden). Le
        // plafond hors-ligne s'applique enfin a l'absence complete.
        if (!(typeof isMobileLayout === 'function' && isMobileLayout())
            && !gameplayPaused && !saveDisabled) {
            desktopHiddenAt = Date.now();
        }
    } else {
        // Retour sur desktop : credit hors-ligne plafonne sur la duree reelle.
        if (desktopHiddenAt) {
            const hiddenAt = desktopHiddenAt;
            desktopHiddenAt = 0;
            if (!gameplayPaused && !mobileBackgroundFrozenAt) {
                applyOfflineEarnings(hiddenAt);
            }
        }
        // Retour sur mobile : degeler via le chemin hors-ligne plafonne.
        if (mobileBackgroundFrozenAt) {
            const frozenAt = mobileBackgroundFrozenAt;
            mobileBackgroundFrozenAt = 0;
            // Depause AVANT le credit hors-ligne : setGameplayPaused(false)
            // decale les echeances du temps de pause, puis le temps
            // d'absence est credite par le systeme hors-ligne plafonne.
            setGameplayPaused(false);
            applyOfflineEarnings(frozenAt);
        }
        // Ne reactiver que si la vue affiche bien le panneau central :
        // sur mobile la navigation gere sa propre suspension.
        partsRain.suspended = (typeof isMobileLayout === 'function' && isMobileLayout() && mobileActiveView !== 'center');
        partsRain.lastTick = Date.now();
        // V3.90 (perf, retour proprietaire : visibilitychange 442 ms) : le
        // resize du canvas de pluie force un reflow de toute la page au
        // moment ou le navigateur REAFFICHE l onglet (moment deja charge :
        // reprise audio, credit hors-ligne, re-rendu complet). DIFFERE d
        // une frame rAF : le navigateur peint d abord la page revenue, le
        // resize passe ensuite en temps masque -- le retour parait
        // instantane.
        requestAnimationFrame(() => { try { resizeRainCanvas(); } catch (e) {} });
    }
});
function spawnRainPart() {
    const canvas = partsRain.canvas;
    if (!canvas || canvas.width <= 1) return;
    const dpr = partsRain.dpr;
    // V3.30 : tailles +20% (retour joueur) -- de 6px a 26px, petit plus frequent.
    const size = (6 + Math.random() * Math.random() * 20.4) * dpr;
    const duration = 5 + Math.random() * 4;
    // Deviation laterale : trajectoire en diagonale, jamais parfaitement droite.
    const drift = (Math.random() - 0.5) * 160 * dpr;
    // Rotation sur elle-meme : vitesse et sens aleatoires, restituee en canvas
    // par un retournement horizontal (cos de l'angle), meme effet piece qui virevolte.
    const spin = (Math.random() < 0.5 ? -1 : 1) * (180 + Math.random() * 540);
    partsRain.parts.push({
        x: Math.random() * canvas.width,
        y: -40 * dpr,
        size,
        vx: drift / duration,
        vy: (canvas.height + 80 * dpr) / duration,
        angle: Math.random() * Math.PI * 2,
        spinSpeed: (spin * Math.PI / 180) / duration
    });
}

let buildingGainsCache = null;
let cachedGainPerBuilding = new Map();

function invalidateBuildingGainsCache() {
    buildingGainsCache = null;
    basePartsPerSecondCache = null;
    buildingCostMemo = null;
}

function getBuildingGainsSnapshot() {
    if (buildingGainsCache === null) {
        let totalGain = 0;
        cachedGainPerBuilding = new Map();
        BUILDINGS.forEach(building => {
            const buildingGain = calculateBuildingGain(building);
            cachedGainPerBuilding.set(building.id, buildingGain);
            totalGain += buildingGain;
        });
        partsPerSecond = totalGain;
        if (partsPerSecond > maxPartsPerSecond) maxPartsPerSecond = partsPerSecond;
        buildingGainsCache = totalGain;
    }
    return buildingGainsCache;
}

// Purge des bonus temporaires expires : un bonus restaure depuis la
// sauvegarde (rechargement pendant un bonus) n'a PLUS son setTimeout
// d'expiration -- il restait dans activeRandomBonuses pour toujours et
// l'arc-en-ciel .bonus-active ne s'eteignait jamais apres le timer.
function expireRandomBonuses() {
    const now = Date.now();
    const before = activeRandomBonuses.length;
    activeRandomBonuses = activeRandomBonuses.filter(b => b.endTime > now);
    if (activeRandomBonuses.length !== before) {
        rebuildAutoMultipliers();
        updateDisplay();
    }
}

function gameLoop() {
    if (gameplayPaused) { lastGameTick = Date.now(); return; }
    // V3.35 (retour joueur : 'enleve la baisse d un cran toutes les 7 s,
    // garde le reset total apres la fin du bonus') : PLUS AUCUN decay --
    // pendant une cascade de x2, le malus ne redescend JAMAIS : chaque x2
    // octroye pese -10% jusqu'a la fin du bonus. Le malus ne se dissipe que
    // par le RESET TOTAL a l expiration du timer (updateBonusTimer) : hors
    // bonus, le joueur retrouve toutes ses cometes ; pendant une cascade,
    // atteindre x2048 devient vraiment dur (simulation : 49% -> 12%).
    // Onglet desktop CACHE : le navigateur throttle la boucle a ~1 tick/min
    // mais ne l'arrete PAS. Chaque tick en arriere-plan reinitialisait
    // lastGameTick apres un credit mini -- l'absence reelle etait creditee
    // minute par minute et le pop-up n'affichait jamais que "~1 minute",
    // le plafond hors-ligne (5 min a 6 h) ne s'appliquait a rien. On fige
    // le credit direct ici : la duree REELLE est creditee au retour via
    // desktopHiddenAt dans le handler visibilitychange (meme chemin que le
    // gel mobile), avec le plafond de l'atelier galactique applique.
    if (document.hidden && !mobileBackgroundFrozenAt) { lastGameTick = Date.now(); return; }
    // Arriere-plan mobile : la production en direct est FIGEE. Le temps
    // d'absence sera credite au retour par applyOfflineEarnings, avec le
    // plafond horaire du jeu (base 5 min, extensible a l'atelier galactique)
    // -- un onglet mobile oublie en arriere-plan ne produit pas a l'infini.
    if (mobileBackgroundFrozenAt) { lastGameTick = Date.now(); return; }
    getBuildingGainsSnapshot();
    tickPartsRain(Date.now());
    expireRandomBonuses();
    const now = Date.now();
    let dtSeconds = (now - lastGameTick) / 1000;
    if (dtSeconds > GAME_TICK_DIRECT_CREDIT_MAX_MS / 1000) {
        // Ecart anormal (arriere-plan desktop, veille) : crediter via le
        // systeme hors-ligne plafonne, pas au taux direct sans limite.
        applyOfflineEarnings(lastGameTick);
        dtSeconds = 0;
    }
    lastGameTick = now;
    // Records de la partie : captures a CHAQUE tick sur les valeurs
    // reelles (boosts temporaires inclus) -- le pps record echappait
    // avant aux pics de flare car seul le cache recalculait le record.
    if (partsPerSecond > maxPartsPerSecond) maxPartsPerSecond = partsPerSecond;
    const tickGain = partsPerSecond * dtSeconds;
    const naturalTickGain = getBasePartsPerSecond() * dtSeconds;
    // Bâtiment favori (V3) : +1% de production du favori par seconde de JEU
    // ACTIF -- uniquement ici : ni hors-ligne ni arrière-plan (les returns
    // au-dessus excluent pause, gel mobile et credit hors-ligne).
    if (favoriteBuildingId && dtSeconds > 0) {
        favoriteBuildingSeconds += dtSeconds;
        favoriteBuildingSecondsByBuilding.set(favoriteBuildingId,
            (favoriteBuildingSecondsByBuilding.get(favoriteBuildingId) || 0) + dtSeconds);
        // V3.22 (retour joueur : 'le pps ne se met pas a jour quand le favori
        // gagne en %') : le bonus du favori CROIT a chaque seconde (+1%/s
        // jouee), mais buildingGainsCache n'etait JAMAIS invalide par cette
        // croissance -- le pps affiche restait fige jusqu'au prochain achat.
        // Invalidation au fil de l'eau : le snapshot du tick suivant recalcule.
        invalidateBuildingGainsCache();
    }
    // V3.4 : temps reel -- meme regle que le favori, dtSeconds du tick actif
    // (les returns en haut de gameLoop excluent deja pauses et gels).
    if (dtSeconds > 0) {
        activePlaytimeSeconds += Math.min(dtSeconds, 5);
    }
    runAutoBuy(now);
    score += tickGain;
    partsSinceLaunch += tickGain;
    trackPartsEarned(tickGain);
    trackNaturalParts(naturalTickGain);
    // MODE TRICHEUR : detection CONTINUE a chaque tick (la fenetre
    // d'invisibilite etait de 30 s -- le check ne tournait qu'a
    // l'auto-submit ; un tricheur pouvait modifier, sauvegarder via
    // l'autosave de 10 s et recharger sans jamais etre vu). Maintenant
    // la detection est quasi instantanee.
    checkCodeIntegrity();
    // MODE TRICHEUR : en cas de detection, les Parts FONDENT en plus du
    // gameLoop normal (-2%/s, jamais sous 0) -- la production apparente
    // devient negative des que le pps du tricheur est < 2% du score/s.
    applyCheaterPenalty(dtSeconds);
    updateLaunchTimer();
    if (dtSeconds > 0) {
        BUILDINGS.forEach(building => {
            if (building.count > 0) {
                totalGeneratedByBuilding[building.id] = (totalGeneratedByBuilding[building.id] || 0) + (cachedGainPerBuilding.get(building.id) || 0) * dtSeconds;
            }
        });
    }
    if (now - lastBuildingsUpdate > BUILDING_UPDATE_INTERVAL_MS) {
        lastBuildingsUpdate = now;
        updateAllBuildingButtons();
        checkNewUpgrades();
    }
    // V3.4 : barre de la piece de fusee rafraichie a 100 ms -- retour playtest,
    // elle paraissait en retard sur le compteur de Parts. La fonction ne
    // reconstruit le DOM que si la piece affichee change : a 100 ms le cout
    // reste des mises a jour ciblees (width/label) quasi gratuites.
    if (now - lastRocketPartsUpdate > 100) {
        lastRocketPartsUpdate = now;
        renderRocketPartsShop();
    }
    if (now - lastDisplayUpdate > DISPLAY_UPDATE_INTERVAL_MS) {
        lastDisplayUpdate = now;
        updateDisplay();
    }
    if (now - lastSpaceProgressUpdate > SPACE_UPDATE_INTERVAL_MS) {
        lastSpaceProgressUpdate = now;
        updateSpaceProgress();
    }
    if (now - lastSlowUpdate > SLOW_UPDATE_INTERVAL_MS) {
        lastSlowUpdate = now;
        checkBuildingUnlocks();
        refreshStatsLive();
        checkTrophies();
        updateBuildingsScrollHints();
        // V3.41 (retour joueur : 'mets a jour les infos des hoovers 1x/s') :
        // le refresh du tooltip affiche passe au rythme LENT (1 s) -- il
        // etait accroche au rythme batiments (500 ms), trop rapide pour une
        // info de lecture. Les bulles stat-tiles ont deja leur propre timer
        // 1 s (startStatTileInfoRefresh), on ne double pas l'appel.
        refreshLiveTooltip();
    }
    // V3.85 CONSOLIDATION DES TIMERS (chantier perf n2) : les ticks
    // secondaires vivaient chacun dans son propre setInterval -- chaque
    // timer est un REVEIL du main thread, meme pour ne rien faire. Ils
    // sont desormais pilotes par le gameLoop (deja a 100 ms) via des
    // compteurs de temps : un seul reveil pour tout.
    tickConsolidatedTimers(now);
}

// Ticks secondaires consolides : contrats (100 ms), lecons contextuelles
// (1 s), fond jour/nuit (60 s). Chacun ne s execute que si son intervalle
// est ecoule -- le comportement est RIGOUREUSEMENT identique aux anciens
// setInterval, seul le nombre de reveils du main thread change.
let __consLastContractTick = 0;
let __consLastLessonTick = 0;
let __consLastDayNightTick = 0;
function tickConsolidatedTimers(now) {
    // Contrats : 100 ms (l ancien etait coupe en mobile gel -- garde).
    if (now - __consLastContractTick >= 100) {
        __consLastContractTick = now;
        if (!mobileBackgroundFrozenAt) tickContracts();
    }
    // Lecons contextuelles : 1 s.
    if (featureLessonTimer !== null && now - __consLastLessonTick >= 1000) {
        __consLastLessonTick = now;
        pollFeatureLessons();
    }
    // Fond jour/nuit : 60 s.
    if (now - __consLastDayNightTick >= 60000) {
        __consLastDayNightTick = now;
        updateDayNightBackground();
    }
}

// ============================================
// STATISTICS
// ============================================

function trackPartsEarned(amount) {
    if (!(amount > 0)) return;
    totalPartsEarnedAllTime += amount;
    totalPartsEarnedThisLaunch += amount;
}

// Parts "naturelles" gagnees depuis le debut du run : production de base (hors
// autoMultiplier) + Parts naturelles des clics. Les bonus instantanes (meteores)
// et les multiplicateurs temporaires sont exclus. Sert de base coherente au
// contrat de production, dont la cible est calculee sur le PPS naturel.
function trackNaturalParts(amount) {
    if (!(amount > 0)) return;
    naturalPartsThisLaunch += amount;
}
function calculateTotalGenerated() {
    let total = 0;
    for (const key in totalGeneratedByBuilding) {
        total += totalGeneratedByBuilding[key];
    }
    return total;
}
// Cumul des Parts generees depuis le dernier lancement : snapshot du total
// historique pris au moment du reset de la run (confirmPostTravelReset).
function calculateLaunchGenerated() {
    return Math.max(0, calculateTotalGenerated() - totalGeneratedAtLaunchStart);
}

function getClickPower() {
    const { baseCpC, buildingBonus, cpsBonus } = getClickComponents();
    return (baseCpC + buildingBonus + cpsBonus) * clickMultiplier * getClickPowerBonus();
}

function getTotalBuildingsOwned() {
    return BUILDINGS.reduce((total, building) => total + building.count, 0);
}

function getGameDuration() {
    if (!gameStartTime) return "N/A";
    
    const durationMs = Date.now() - gameStartTime;
    
    const totalSec = Math.floor(durationMs / 1000);
    const days = Math.floor(totalSec / 86400);
    if (days > 0) return days + t("jours") + ' ' + formatDurationHMS((totalSec % 86400) * 1000);
    return formatDurationHMS(durationMs);
}

// ============================================
// GESTION DES TROPH\u001aES
// ============================================

function getTotalStardustEarned() {
    return totalStardustEarned;
}
function getTotalBuildingUpgrades() {
    let count = 0;
    for (const buildingId in buildingUpgrades) {
        count += buildingUpgrades[buildingId].length;
    }
    return count;
}

function getUnlockedBuildingTypes() {
    return BUILDINGS.filter(b => b.count > 0).length;
}

function checkTrophies() {
    let changed = false;
    
    TROPHIES.forEach(trophy => {
        if (!unlockedTrophies.has(trophy.id)) {
            let unlocked = false;
            
            switch (trophy.type) {
                case 'pps':
                    // PPS de base uniquement : un bonus temporaire (flare)
                    // ne doit jamais debloquer un trophee.
                    unlocked = getBasePartsPerSecond() >= trophy.threshold;
                    break;
                case 'building-upgrade':
                    unlocked = getTotalBuildingUpgrades() >= trophy.threshold;
                    break;
                case 'click-upgrade':
                    unlocked = activatedClickUpgrades.length >= trophy.threshold;
                    break;
                case 'building':
                    unlocked = getTotalBuildingsOwned() >= trophy.threshold;
                    break;
                case 'score':
                    unlocked = score >= trophy.threshold;
                    break;
                case 'bonus':
                    unlocked = clickedBonusesCount >= trophy.threshold;
                    break;
                case 'building-types':
                    unlocked = getUnlockedBuildingTypes() >= trophy.threshold;
                    break;
                case 'planets':
                    unlocked = unlockedPlanets.size - (unlockedPlanets.has('earth') ? 1 : 0) >= trophy.threshold;
                    break;
                case 'launches':
                    unlocked = rocketsLaunched >= trophy.threshold;
                    break;
                case 'stardust':
                    unlocked = getTotalStardustEarned() >= trophy.threshold;
                    break;
                case 'cards':
                    unlocked = Object.keys(cardCollection).filter(id => cardCollection[id] > 0).length >= trophy.threshold;
                    break;
                case 'speed':
                    unlocked = calculateTravelSpeedKmSBase() >= trophy.threshold;
                    break;
                // V3.12 : trophees des nouvelles mecaniques infinies
                case 'record-doublings':
                    unlocked = recordDoublings >= trophy.threshold;
                    break;
                case 'cosmic-boost':
                    unlocked = getGalacticUpgradeLevel('inf-boost') >= trophy.threshold;
                    break;
                case 'contracts-completed':
                    unlocked = contractsCompleted >= trophy.threshold;
                    break;
                case 'fav-seconds': {
                    // Somme des banques de tous les batiments : le bonus
                    // acquis compte, meme sur d'anciens favoris (V3.8).
                    // ATTENTION : la banque du favori COURANT est deja
                    // incrementee en parallèle de favoriteBuildingSeconds
                    // (gameLoop) -- additionner les deux compterait deux fois
                    // le temps du favori actif. La somme des banques suffit.
                    let bank = 0;
                    favoriteBuildingSecondsByBuilding.forEach(v => { bank += v; });
                    unlocked = bank >= trophy.threshold;
                    break;
                }
                case 'temp-mult': {
                    // Produit des multiplicateurs temporaires ACTIFS.
                    const nowT = Date.now();
                    const prodAct = activeRandomBonuses.filter(b => (b.effect === 'multiplier' || b.effect === 'both' || b.id === 'flare') && b.endTime > nowT);
                    const prodT = prodAct.reduce((acc, b) => acc * (b.multiplier || 1), 1);
                    unlocked = prodT >= trophy.threshold;
                    break;
                }
            }
            
            if (unlocked) {
                unlockedTrophies.add(trophy.id);
                Sounds.trophy();
                changed = true;
                showToast(`${t("Troph\u00e9e d\u00e9bloqu\u00e9 :")} ${t(trophy.name)}!`, trophy.icon, 5000, { trophy: true, subtitle: t(trophy.description) });
            }
        }
    });

    // V3.43 : TOUS les trophees debloques -> ecran de fin ULTIME, une seule
    // fois par sauvegarde (le re-check au tick suivant ne re-affiche pas).
    if (!trophiesEndingShown && TROPHIES.length > 0 && unlockedTrophies.size >= TROPHIES.length) {
        trophiesEndingShown = true;
        saveGame();
        showTrophiesEnding();
    }

    return changed;
}

function renderTrophies() {
    const container = document.createElement('div');
    container.style.marginTop = '8px';
    
    const trophiesGrid = document.createElement('div');
    trophiesGrid.style.display = 'grid';
    trophiesGrid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(60px, 1fr))';
    trophiesGrid.style.gap = '8px';
    trophiesGrid.style.marginTop = '8px';
    
    const familyOrder = ['pps', 'speed', 'planets', 'launches', 'stardust', 'building-upgrade', 'click-upgrade', 'building', 'score', 'bonus', 'building-types', 'cards'];
    const trophiesByFamily = {};
    TROPHIES.forEach(trophy => {
        (trophiesByFamily[trophy.type] = trophiesByFamily[trophy.type] || []).push(trophy);
    });
    const orderedTrophies = [];
    familyOrder.forEach(family => {
        if (trophiesByFamily[family]) orderedTrophies.push(...trophiesByFamily[family]);
    });
    Object.keys(trophiesByFamily).forEach(family => {
        if (!familyOrder.includes(family)) orderedTrophies.push(...trophiesByFamily[family]);
    });

    const colorCounters = {};
    orderedTrophies.forEach(trophy => {
        const trophyElement = document.createElement('div');
        trophyElement.className = 'trophy-icon';
        trophyElement.style.width = '50px';
        trophyElement.style.height = '50px';
        trophyElement.style.borderRadius = '50%';
        trophyElement.style.display = 'flex';
        trophyElement.style.alignItems = 'center';
        trophyElement.style.justifyContent = 'center';
        trophyElement.style.fontSize = '1.5rem';
        trophyElement.style.cursor = 'pointer';
        trophyElement.style.position = 'relative';
        trophyElement.style.transition = 'all 0.2s';
        // Couleur du palier : uniquement sur le bord du cercle, fond neutre.
        // L'index est mappe sur la palette selon la taille REELLE de la
        // famille -- avant, toutes les familles longues ecrasaient leurs
        // paliers 10+ sur la derniere couleur (jaune).
        const family = trophiesByFamily[trophy.type] || [];
        const familyIndex = family.indexOf(trophy);
        // Meme echelle que les niveaux d'amelioration (15 paliers) : le
        // rang N d'une famille a EXACTEMENT la couleur du niveau N d'upgrade.
        // Les familles font toutes <= 15 trophees, la correspondance est directe.
        const tierColor = getUpgradeTierColor(familyIndex);
        if (unlockedTrophies.has(trophy.id)) {
            trophyElement.style.border = '2px solid ' + tierColor;
            trophyElement.style.background = 'var(--secondary-light)';
            trophyElement.style.boxShadow = 'var(--shadow)';
            trophyElement.style.opacity = '1';
        } else {
            trophyElement.style.border = '1px solid var(--border)';
            trophyElement.style.background = 'var(--secondary)';
            trophyElement.style.opacity = '0.35';
            trophyElement.style.filter = 'grayscale(100%)';
        }
        
        // V4.4 (retour propriétaire : toutes les icônes de trophées doivent
        // rentrer dans le rond et faire la MÊME taille visuelle) : les images
        // sources ont des ratios très variés (900x900 planète, 900x1581 fusée,
        // 784x1339 carte) -- un width/height 100% + contain rendait les
        // hautes minuscules et les carrées énormes. Une seule classe CSS
        // normalise : boîte carrée 82% du rond + contain dedans.
        // Trophée non débloqué : contenu masqué par un point d'interrogation.
        if (unlockedTrophies.has(trophy.id)) {
            trophyElement.innerHTML = trophy.icon.startsWith('images/')
                ? `<img src="${trophy.icon}" alt="${trophy.name}" class="trophy-icon-img">`
                : trophy.icon;
        } else {
            trophyElement.innerHTML = '?';
        }
        // Trophee verrouille : aucun tooltip, le contenu reste un mystere.
        if (unlockedTrophies.has(trophy.id)) {
            const showTrophyTooltip = (target) => {
                const rect = target.getBoundingClientRect();
                const name = t(trophy.name);
                const description = t(trophy.description);
                showTooltip(`${name}\n${description}\n${t('D\u00e9bloqu\u00e9')}`, rect.left + rect.width/2, rect.top, { anchorBottom: rect.bottom });
            };
            if (!IS_TOUCH) {
                trophyElement.addEventListener('mouseenter', (e) => showTrophyTooltip(e.target));
                trophyElement.addEventListener('mouseleave', hideTooltip);
            } else {
                trophyElement.addEventListener('click', (e) => {
                    if (touchTooltipElement === trophyElement) {
                        touchTooltipElement = null;
                        hideTooltip();
                    } else {
                        touchTooltipElement = trophyElement;
                        showTrophyTooltip(trophyElement);
                    }
                    e.stopPropagation();
                });
            }
        }
        
        trophiesGrid.appendChild(trophyElement);
    });
    
    container.appendChild(trophiesGrid);
    return container;
}

let lastStatsRender = 0;

function statsStructureKey() {
    return [
        gameLanguage,
        activatedClickUpgrades.join(','),
        Object.keys(buildingUpgrades).map(id => id + ':' + ((buildingUpgrades[id] || []).length)).join(','),
        unlockedTrophies.size,
        [...unlockedTrophies].join(',')
    ].join('|');
}

function refreshStatsLive() {
    const modal = document.getElementById('stats-modal');
    if (!modal || !modal.classList.contains('active')) return;
    const now = Date.now();
    const container = document.getElementById('stats-body');
    if (!container) return;
    const key = statsStructureKey();
    if (container.dataset.structureKey !== key) {
        const scrollTop = container.scrollTop;
        renderStats();
        container.dataset.structureKey = key;
        container.scrollTop = scrollTop;
        return;
    }
    if (now - lastStatsRender < 1000) return;
    lastStatsRender = now;
    updateStatsDynamicValues(container);
}

function updateStatsDynamicValues(container) {
    // DOIT rester synchronisee, ENTREE POUR ENTREE, avec la liste
    // globalStats de renderStats() -- les valeurs se mettent a jour par
    // index : un desynchro (ex : nouvelles stats inserees ici mais pas
    // la) faisait GLISSER chaque valeur vers la stat voisine.
    const values = [
        formatNumber(score, true),
        formatNumber(totalPartsEarnedThisLaunch),
        formatNumber(totalPartsEarnedAllTime),
        formatNumber(partsPerSecond),
        formatNumber(maxPartsPerSecond),
        formatMultiplier(getTotalProductionMultiplier()),
        formatNumber(getClickPower()),
        // Index 7 = "Multiplicateur critique" : STATIQUE (recalculee a la
        // re-render de structure) -- la liste doit rester alignee ENTREE POUR
        // ENTREE avec globalStats, un trou faisait glisser toutes les valeurs.
        undefined,
        formatNumber(totalClicksAllTime),
        formatNumber(totalPartsFromClicks, true),
        formatNumber(getTotalBuildingsOwned()),
        formatTravelSpeed(calculateTravelSpeedKmS()),
        formatTravelSpeed(maxTravelSpeed),
        getGameDuration(),
        formatDurationHMS(Math.max(0, Date.now() - (lastLaunchAt || expeditionStartTime || gameStartTime || Date.now()))),
        formatDurationHMS(activePlaytimeSeconds * 1000),
        String(clickedBonusesCount)
    ];
    container.querySelectorAll('[data-stat-value]').forEach(el => {
        const idx = parseInt(el.dataset.statValue, 10);
        if (!Number.isNaN(idx) && values[idx] !== undefined) el.textContent = values[idx];
    });
    const bonusTitle = container.querySelector('[data-trophies-bonus]');
    if (bonusTitle) bonusTitle.textContent = '(+' + (unlockedTrophies.size * 1) + '%)';
}

function renderStats() {
    const container = document.getElementById('stats-body');
    container.innerHTML = '';
    container.innerHTML += '<h4 style="margin: 0 0 8px; color: #2563eb; font-size: 1.3rem;">' + t('Statistiques Globales') + '</h4>';
    const globalStats = [
        { label: t("Parts actuelles"), value: formatNumber(score, true) },
        { label: t("Parts g\u00e9n\u00e9r\u00e9s pour ce lancement"), value: formatNumber(totalPartsEarnedThisLaunch) },
        { label: t("Total Parts g\u00e9n\u00e9r\u00e9s"), value: formatNumber(totalPartsEarnedAllTime) },
        { label: t("Parts par seconde"), value: formatNumber(partsPerSecond) },
        { label: t("Record de parts par seconde"), value: formatNumber(maxPartsPerSecond) },
        { label: t("Multiplicateur de production"), value: formatMultiplier(getTotalProductionMultiplier()) },
        { label: t("Parts par clic"), value: formatNumber(getClickPower()) },
        { label: t("Multiplicateur critique"), value: getCritChance() > 0 ? 'x' + ((getGalacticUpgradeLevel('click8') > 0 || getGalacticUpgradeLevel('inf-crit') > 0) ? 5 : 3) + ' (' + Math.round(getCritChance() * 100) + '%)' : t('Aucun') },
        { label: t("Clics effectu\u00e9s sur la pi\u00e8ce"), value: formatNumber(totalClicksAllTime) },
        { label: t("Parts gagn\u00e9es par les clics"), value: formatNumber(totalPartsFromClicks, true) },
        { label: t("B\u00e2timents poss\u00e9d\u00e9s au total"), value: formatNumber(getTotalBuildingsOwned()) },
        { label: t("Vitesse actuelle"), value: formatTravelSpeed(calculateTravelSpeedKmS()) },
        { label: t("Vitesse record"), value: formatTravelSpeed(maxTravelSpeed) },
        { label: t("Partie commenc\u00e9e"), value: getGameDuration() },
        { label: t("Exp\u00e9dition en cours"), value: formatDurationHMS(Math.max(0, Date.now() - (lastLaunchAt || expeditionStartTime || gameStartTime || Date.now()))) },
        { label: t("Temps de jeu r\u00e9el"), value: formatDurationHMS(activePlaytimeSeconds * 1000) },
        { label: t("Com\u00e8tes D\u00e9truites"), value: groupThousands(clickedBonusesCount) }
    ];

    globalStats.forEach(stat => {
        const idx = globalStats.indexOf(stat);
        const statElement = document.createElement('div');
        // V3.5 : zebra striping -- une ligne sur deux teintee pour la lisibilite.
        statElement.style.display = 'flex';
        statElement.style.justifyContent = 'space-between';
        statElement.style.padding = '8px 6px';
        statElement.style.borderBottom = '1px solid #e2e8f0';
        if (idx % 2 === 1) {
            statElement.style.background = 'rgba(100, 116, 139, 0.12)';
            statElement.style.borderRadius = '6px';
        }
        statElement.innerHTML = `
            <span style="color: #64748b; font-size: 1.05rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${stat.label}</span>
            <span style="color: #2563eb; font-weight: 600; font-size: 1.1rem; white-space: nowrap; flex-shrink: 0; margin-left: 14px; text-align: right;" data-stat-value="${idx}">${stat.value}</span>
        `;
        container.appendChild(statElement);
    });

    container.innerHTML += '<h4 style="margin: 16px 0 8px; color: #2563eb; font-size: 1.3rem;">' + t('Upgrades') + '</h4>';
    container.innerHTML += '<h5 style="margin: 8px 0 4px; color: #64748b; font-size: 1.05rem;">' + t('Améliorations de Clic:') + '</h5>';
    
    if (activatedClickUpgrades.length > 0) {
        const line = document.createElement('div');
        line.style.display = 'flex';
        line.style.flexWrap = 'wrap';
        line.style.gap = '6px';
        line.style.alignItems = 'center';
        line.style.padding = '4px 0';
        activatedClickUpgrades.forEach(threshold => {
            const upgrade = CLICK_UPGRADES.find(u => u.threshold === threshold);
            if (upgrade) {
                const upgradeIndex = CLICK_UPGRADES.indexOf(upgrade);
                const color = UPGRADE_COLORS[upgradeIndex % UPGRADE_COLORS.length];
                const badge = document.createElement('span');
                badge.style.display = 'inline-flex';
                badge.style.alignItems = 'center';
                badge.style.gap = '4px';
                badge.style.padding = '2px 8px';
                badge.style.borderRadius = '999px';
                badge.style.border = '1px solid ' + color;
                badge.style.background = 'rgba(255, 255, 255, 0.6)';
                badge.style.color = '#64748b';
                badge.style.fontSize = '0.95rem';
                badge.innerHTML = `<img src="images/cursor.svg" alt="" style="width: 14px; height: 14px;"> ${t(upgrade.name)}`;
                line.appendChild(badge);
            }
        });
        container.appendChild(line);
    } else {
        const statElement = document.createElement('div');
        statElement.style.padding = '4px 0';
        statElement.style.fontSize = '1rem';
        statElement.style.color = '#94a3b8';
        statElement.textContent = t('Aucune am\u00e9lioration de clic');
        container.appendChild(statElement);
    }

    container.innerHTML += '<h5 style="margin: 12px 0 4px; color: #64748b; font-size: 1.05rem;">' + t('Am\u00e9liorations de B\u00e2timents:') + '</h5>';
    
    let hasBuildingUpgrades = false;
    // V3.21 : TEMPS DE FAVORI par batiment (retour joueur) -- la banque de
    // secondes acquises (favoriteBuildingSecondsByBuilding) s'affiche sous
    // le batiment concerne, format h/min/s lisible.
    const favSecByBuilding = (typeof favoriteBuildingSecondsByBuilding !== 'undefined' && favoriteBuildingSecondsByBuilding)
        ? favoriteBuildingSecondsByBuilding : new Map();
    BUILDINGS.forEach(building => {
        const favSec = favSecByBuilding.get(building.id) || 0;
        if (favSec > 0) {
            hasBuildingUpgrades = true;
            const h = Math.floor(favSec / 3600);
            const m = Math.floor((favSec % 3600) / 60);
            const sec = Math.floor(favSec % 60);
            const favText = h > 0
                ? h + ' ' + t('h') + ' ' + m + ' ' + t('min')
                : (m > 0 ? m + ' ' + t('min') + ' ' + sec + ' ' + t('s') : sec + ' ' + t('s'));
            const favElement = document.createElement('div');
            favElement.style.display = 'flex';
            favElement.style.justifyContent = 'space-between';
            favElement.style.padding = '4px 0';
            favElement.style.fontSize = '0.95rem';
            favElement.style.color = '#a78bfa';
            const isCurrent = favoriteBuildingId === building.id;
            favElement.innerHTML = `<span>${t(building.name)}: <span style="color: #c4b5fd; font-weight: 700;">${favText}</span> ${t('en favori')}${isCurrent ? ' ★' : ''}</span>`;
            container.appendChild(favElement);
        }
        const upgrades = buildingUpgrades[building.id] || [];
        if (upgrades.length > 0) {
            hasBuildingUpgrades = true;
            const statElement = document.createElement('div');
            statElement.style.display = 'flex';
            statElement.style.justifyContent = 'space-between';
            statElement.style.padding = '4px 0';
            statElement.style.fontSize = '1rem';
            statElement.style.color = '#64748b';
            const levelColor = getUpgradeTierColor(upgrades.length - 1);
            statElement.innerHTML = `<span>${t(building.name)}: <span style="color: ${levelColor}; font-weight: 700;">${upgrades.length}</span> ${t('niveau(x)')}</span>`;
            container.appendChild(statElement);
        }
    });

    if (!hasBuildingUpgrades) {
        const statElement = document.createElement('div');
        statElement.style.padding = '4px 0';
        statElement.style.fontSize = '1rem';
        statElement.style.color = '#94a3b8';
        statElement.textContent = t('Aucune am\u00e9lioration de b\u00e2timent');
        container.appendChild(statElement);
    }

    container.innerHTML += '<h4 style="margin: 16px 0 8px; color: #2563eb; font-size: 1.3rem;">' + t('Troph\u00e9es') + ' <span style="color: #16a34a;" data-trophies-bonus>(+' + (unlockedTrophies.size * 1) + '%)</span>' + '</h4>';
    const trophiesSection = renderTrophies();
    container.appendChild(trophiesSection);
    container.dataset.structureKey = statsStructureKey();
}

// ============================================
// MODALS
// ============================================

const EXCLUSIVE_MODALS = ['stats-modal', 'settings-modal', 'contracts-modal', 'card-collection-modal', 'galactic-shop-modal', 'leaderboard-modal', 'chat-modal'];
// Focus trap des modaux exclusifs : la tabulation doit rester DANS le
// modal ouvert (accessibilite clavier). Au focus du premier element,
// Tab cyclable vers le dernier et inversement. Le focus est rendu a
// l'element qui avait ouvert le modal a la fermeture.
const modalFocusState = { active: null, opener: null, handler: null };
function trapModalFocus(modal) {
    releaseModalFocus();
    modalFocusState.active = modal;
    modalFocusState.opener = document.activeElement;
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    const focusables = modal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    if (focusables.length) focusables[0].focus({ preventScroll: true });
    modalFocusState.handler = (e) => {
        // Auto-liberation : certains flux ferment le modal directement via
        // classList (sans passer par showExclusiveModal) -- le trap se retire
        // alors tout seul pour ne jamais bloquer la tabulation d'une page
        // ou le modal n'est plus affiche.
        if (!modal.classList.contains('active')) { releaseModalFocus(); return; }
        if (e.key !== 'Tab') return;
        const items = modal.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
            e.preventDefault(); last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault(); first.focus();
        } else if (!modal.contains(document.activeElement)) {
            e.preventDefault(); first.focus();
        }
    };
    modal.addEventListener('keydown', modalFocusState.handler);
}
function releaseModalFocus() {
    if (modalFocusState.active) {
        modalFocusState.active.removeEventListener('keydown', modalFocusState.handler);
        modalFocusState.active.removeAttribute('role');
        modalFocusState.active.removeAttribute('aria-modal');
        modalFocusState.active = null;
    }
    if (modalFocusState.opener && document.contains(modalFocusState.opener)) {
        try { modalFocusState.opener.focus({ preventScroll: true }); } catch (e) {}
    }
    modalFocusState.opener = null;
    modalFocusState.handler = null;
}
function showExclusiveModal(modalId, onOpen) {
    const target = document.getElementById(modalId);
    const wasActive = target.classList.contains('active');
    EXCLUSIVE_MODALS.forEach(id => {
        if (id !== modalId) {
            const el = document.getElementById(id);
            // Ne jamais masquer l'atelier galactique pendant le blocage post-voyage
            if (id === 'galactic-shop-modal' && postTravelLock) return;
            if (el.classList.contains('active')) releaseModalFocus();
            el.classList.remove('active');
        }
    });
    if (wasActive) {
        target.classList.remove('active');
        releaseModalFocus();
    } else {
        target.classList.add('active');
        trapModalFocus(target);
        if (onOpen) onOpen();
    }
}
// ===== RAPPORT DE BUG =====
// Ouvre le client mail du joueur avec un rapport pre-rempli : sa
// description + un resume technique collecte automatiquement (navigateur,
// langue, version du jeu, contexte de partie). mailto: fonctionne partout,
// aucun serveur requis.
const CONTACT_EMAIL = 'contact@starcruiserclicker.com';

function openBugReport() {
    document.getElementById('bug-report-text').value = '';
    document.getElementById('bug-report-modal').classList.add('active');
}

function closeBugReport() {
    document.getElementById('bug-report-modal').classList.remove('active');
}

// Envoi DIRECT depuis le jeu via un service de formulaire (Formspree) :
// le joueur ne passe PAS par son client mail. Tant que BUG_FORM_ENDPOINT
// est vide (service non configure), on retombe sur mailto:.
// CONFIGURATION : creer un compte gratuit sur formspree.io, lier le
// formulaire a contact@starcruiserclicker.com, copier l'endpoint
// (https://formspree.io/f/XXXXXXXX) et le coller ci-dessous.
const BUG_FORM_ENDPOINT = 'https://formspree.io/f/mppqlogd';

function sendBugReport() {
    const desc = (document.getElementById('bug-report-text').value || '').trim();
    const subject = '[Starcruiser Clicker] Rapport de bug';
    // Resume technique : tout ce qui aide a reproduire sans exposer de
    // donnees personnelles (pas de nom d'entreprise, pas de contenu libre
    // de la sauvegarde).
    const tech = [
        '--- Rapport technique (auto-genere) ---',
        // Nom du joueur (nom d'entreprise) : sert a retrouver sa ligne dans
        // le classement / sa sauvegarde si besoin de creuser le bug.
        'Joueur: ' + (getCompanyName() || 'inconnu'),
        'URL: ' + location.href,
        'Navigateur: ' + navigator.userAgent,
        'Langue du jeu: ' + gameLanguage,
        'Ecran: ' + window.innerWidth + 'x' + window.innerHeight + (isMobileLayout() ? ' (mobile)' : ' (pc)'),
        'Lancements: ' + rocketsLaunched + ' | Record: ' + Math.round(maxDistance).toLocaleString('fr-FR') + ' km',
        'Parts/s: ' + formatNumber(partsPerSecond),
        'Version SW: ' + (typeof APP_CACHE_VERSION !== 'undefined' ? APP_CACHE_VERSION : 'n/a')
    ].join('\n');
    const body = (desc ? desc + '\n\n' : '') + tech;
    // Service configure : envoi direct (le joueur reste dans le jeu).
    if (BUG_FORM_ENDPOINT) {
        const btn = document.querySelector('#bug-report-modal .modal-button');
        if (btn) { btn.disabled = true; }
        fetch(BUG_FORM_ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ _subject: subject, description: body })
        }).then(res => {
            if (res.ok) {
                showToast('\u2705 ' + t('Rapport envoy\u00e9 ! Merci commandant.'));
            } else {
                showToast('\u26a0\ufe0f ' + t('Envoi impossible, ouverture de votre messagerie...'));
                window.location.href = 'mailto:' + CONTACT_EMAIL
                    + '?subject=' + encodeURIComponent(subject)
                    + '&body=' + encodeURIComponent(body);
            }
        }).catch(() => {
            showToast('\u26a0\ufe0f ' + t('Envoi impossible, ouverture de votre messagerie...'));
            window.location.href = 'mailto:' + CONTACT_EMAIL
                + '?subject=' + encodeURIComponent(subject)
                + '&body=' + encodeURIComponent(body);
        }).finally(() => {
            if (btn) { btn.disabled = false; }
            closeBugReport();
        });
        return;
    }
    // Service non configure : mailto: classique.
    window.location.href = 'mailto:' + CONTACT_EMAIL
        + '?subject=' + encodeURIComponent(subject)
        + '&body=' + encodeURIComponent(body);
    closeBugReport();
}

function toggleSettings() {
    showExclusiveModal('settings-modal');
}

function toggleStats() {
    showExclusiveModal('stats-modal', renderStats);
}

// ============================================
// CLASSEMENT DES PILOTES (record de vitesse km/s)
// ============================================
// Architecture en couches, pensee pour un site 100% statique (GitHub Pages) :
//  - Stockage LOCAL (localStorage) : fonctionne immediatement, sans serveur.
//  - Couche REMOTE : Supabase (leaderboard-config.js) -- le classement est
//    global entre tous les joueurs, sans compte. Le vieux backend PHP
//    (server/leaderboard.php) est supprime V3.38 : remplacé par Supabase.
//
// Identite : le NOM D'ENTREPRISE SPATIALE, saisi a la premiere partie dans
// l'ecran d'intro (ou la modale de rattrapage pour les vieilles saves),
// definitif -- jamais modifiable ensuite.
// Soumission : AUTOMATIQUE, toutes les 30 s, avec le record de vitesse
// courant (maxTravelSpeed). Le joueur n'a rien a faire.

// CLASSEMENT GLOBAL : Supabase (PostgreSQL, plan gratuit).
// SUPABASE_URL et SUPABASE_ANON_KEY sont definies en CONST dans
// leaderboard-config.js (charge avant ce script). ATTENTION : ne JAMAIS
// redeclarer ces identifiants ici (var/let/const) -- const global + var
// du meme nom = SyntaxError fatale qui tue tout script.js (bug reel
// corrige). On les lit simplement : elles existent deja.
// Chargement du module WASM starcruiser-core (constantes des records +
// detention des records dans la memoire du module). Echec non bloquant :
// sans le module, le jeu retombe sur les formules JS natives.
if (window.StarcruiserCore) {
    window.StarcruiserCore.load().then(exports => {
        if (exports) {
            wasmCoreReady = true;
            // Rejouer les records deja charges depuis la sauvegarde dans le
            // module (monotone par construction).
            try { if (maxTravelSpeed > 0) exports.set_record_speed(maxTravelSpeed); } catch (e) {}
            try { if (maxDistance > 0) exports.set_record_distance(maxDistance); } catch (e) {}
        }
    }).catch(() => {});
}
const LB_REMOTE_OK = (typeof SUPABASE_URL !== 'undefined' && typeof SUPABASE_ANON_KEY !== 'undefined');
const LEADERBOARD_LOCAL_KEY = 'starcruiserLeaderboard';
const LEADERBOARD_COMPANY_KEY = 'starcruiserCompanyName';

// --- INTEGRITE DU CODE (anti-triche couche 1, dissuasion client) ---
// Snapshot des fonctions critiques prises au chargement (via
// Function.prototype.toString) : toute redéfinition ultérieure en console
// (patch de calculDistance / calculateTravelSpeedKmS / multiplicative
// overrides) est détectée à chaque envoi. DETECTION LOCALE UNIQUEMENT :
// si le code ne matche plus, le jeu n'envoie PLUS rien au classement
// global (le jeu continue, seul l'envoi est coupé). Un tricheur motivé
// peut neutraliser ce check -- c'est un filet dissuasif, pas une barrière
// (la vraie barrière est serveur, dans submit_score : cohérence des
// métriques entre elles).
const INTEGRITY_SNAPSHOT = (function () {
    try {
        return [
            calculateTravelSpeedKmS,
            travelSpeedFromPps,
            calculateDistance,
            getLeaderboardScore,
            submitRemoteScore,
            autoSubmitLeaderboard,
            // V3.38 (P2 audit) : les GETTERS DES RECORDS surveilles aussi --
            // patcher getRecordMaxTravelSpeed/getRecordMaxDistance en console
            // n'etait pas detecte localement (seul le serveur attrapait la
            // soumission incoherente) : la modification du getter declenche
            // desormais le mode tricheur immediatement.
            getRecordMaxTravelSpeed,
            getRecordMaxDistance
        ].map(fn => String(fn));
    } catch (e) { return null; }
})();
let integrityCompromised = false;

// V4.5 : detection locale d'un auto-clicker "doux" (couche 1, dissuasion,
// comme le snapshot d'intégrité). Un bot clique à intervalles quasi constants
// (CV ~ 0) ; un humain varie (CV > ~0.4). Si 50+ clics avec CV < 0.15 et
// rythme > 4 clics/s -> integrityCompromised (le jeu cesse d'envoyer au classement).
const clickTimes = [];
function trackClickRhythm() {
    const now = Date.now();
    clickTimes.push(now);
    if (clickTimes.length > 60) clickTimes.shift();
    if (clickTimes.length < 50 || integrityCompromised) return;
    // V4.8 : le pattern doit persister AU MOINS 10 minutes (meme regle que le
    // serveur) — un joueur qui clique en rythme 30 s ne doit pas être flagué.
    if (clickTimes[clickTimes.length - 1] - clickTimes[0] < 600000) return;
    const intervals = [];
    for (let i = 1; i < clickTimes.length; i++) intervals.push(clickTimes[i] - clickTimes[i - 1]);
    const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    if (mean <= 0) return;
    const variance = intervals.reduce((a, b) => a + (b - mean) * (b - mean), 0) / intervals.length;
    const cv = Math.sqrt(variance) / mean;
    const rate = 1000 / mean; // clics/s
    if (rate > 4 && cv < 0.15) {
        integrityCompromised = true;
        console.warn('[Starcruiser] Rythme de clics non humain détecté (cv=' + cv.toFixed(3) + ', rate=' + rate.toFixed(1) + '/s) — envoi au classement coupé.');
    }
}

// ============================================================
// MODE TRICHEUR (couche 1, punishment) : quand une modification du
// code critique est detectee, le jeu ne se contente plus de couper
// l'envoi au classement -- il PUNIT. La production s'INVERSE (les
// Parts fondent a x1 par seconde, jamais sous 0), une modale plein
// ecran non fermable l'annonce, et le mode persiste jusqu'au reload.
// Le tricheur qui recharge retombe sur un code sain (nouveau snapshot),
// la detection reprendra a la moindre nouvelle modification.
// ============================================================
let cheaterModeActive = false;
// Penalite PROPORTIONNELLE : -2% du score courant par seconde. Le score
// fond de facon exponentielle (il est divise par ~1.9 chaque minute),
// quel que soit le niveau du tricheur -- un compte a 1e15 souffre autant
// qu'un compte a 1000. Plafonne a 0 : jamais de negatif.
const CHEATER_DRAIN_PERCENT_PER_SECOND = 0.02;

function activateCheaterMode() {
    if (cheaterModeActive) return;
    cheaterModeActive = true;
    integrityCompromised = true;
    const w = wasmCore();
    if (w) { try { w.mark_integrity_flag(); } catch (e) {} }
    // GROSSE MODALE non fermable, style "arrete de tricher"
    let modal = document.getElementById('cheater-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'cheater-modal';
        modal.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(20,0,0,0.88);backdrop-filter:blur(6px);';
        const box = document.createElement('div');
        box.style.cssText = 'max-width:520px;margin:16px;padding:40px 32px;text-align:center;background:linear-gradient(160deg,#2a0a0a,#1a0505);border:2px solid #ff3333;border-radius:16px;color:#ffd6d6;box-shadow:0 0 80px rgba(255,40,40,0.55);font-family:inherit;';
        box.innerHTML = '<div style="font-size:64px;line-height:1;margin-bottom:18px;">\ud83d\udcb1</div>'
            + '<h2 style="margin:0 0 14px;color:#ff5555;font-size:26px;">' + t('CODE MODIFI\u00c9 D\u00c9TECT\u00c9') + '</h2>'
            + '<p style="margin:0 0 10px;font-size:16px;line-height:1.5;">' + t('Notre service anti-triche a detecte une modification du code du jeu. Tant que vous trichez, vos Parts FONDENT et votre classement mondial est desactive.') + '</p>'
            + '<p style="margin:0 0 22px;font-size:14px;color:#ff9999;">' + t('Rechargez la page pour revenir a un jeu propre \u2014 et jouez honnetement, pilote.') + '</p>'
            + '<button onclick="window.location.reload()" style="padding:12px 28px;font-size:16px;border:none;border-radius:10px;background:#ff3333;color:#fff;cursor:pointer;font-family:inherit;">' + t('Recharger le jeu') + '</button>';
        modal.appendChild(box);
    }
    if (!modal.parentNode) document.body.appendChild(modal);
}

// Penalite prelevee a CHAQUE tick du gameLoop quand le mode est actif :
// les Parts baissent au lieu de monter. Jamais sous 0 : le tricheur
// ne doit pas declencher d'etats incoherents (prix negatifs etc.).
function applyCheaterPenalty(dtSeconds) {
    if (!cheaterModeActive) return;
    const drain = score * CHEATER_DRAIN_PERCENT_PER_SECOND * dtSeconds;
    score = Math.max(0, score - drain);
    partsSinceLaunch = Math.max(0, partsSinceLaunch - drain);
}
function checkCodeIntegrity() {
    if (!INTEGRITY_SNAPSHOT) return true;
    try {
        const current = [
            calculateTravelSpeedKmS,
            travelSpeedFromPps,
            calculateDistance,
            getLeaderboardScore,
            submitRemoteScore,
            autoSubmitLeaderboard,
            // V3.38 (P2 audit) : les DEUX getters de records font partie du
            // snapshot (8 entrees) -- ils DOIVENT etre collectes ici aussi,
            // sinon current[6]/current[7] valent undefined et la comparaison
            // avec le snapshot detectait une modification IMAGINAIRE : le mode
            // tricheur se declenchait pour TOUT joueur honnete des le 1er tick.
            getRecordMaxTravelSpeed,
            getRecordMaxDistance
        ].map(fn => String(fn));
        for (let i = 0; i < INTEGRITY_SNAPSHOT.length; i++) {
            if (INTEGRITY_SNAPSHOT[i] !== current[i]) {
                integrityCompromised = true;
                console.warn('[Starcruiser] Intégrité du code modifiée — mode tricheur activé.');
                activateCheaterMode();
                return !integrityCompromised;
            }
        }
        return !integrityCompromised;
    } catch (e) { return !integrityCompromised; }
}
// Toute detection d'integrite compromise declenche aussi le MODE TRICHEUR
// (modale + fond de Parts). Appelle depuis checkCodeIntegrity et depuis
// les autres points de detection (envoi de score).
function enforceAntiCheat() {
    if (integrityCompromised) activateCheaterMode();
}
// Helper unique d'appel REST Supabase : headers d'auth, timeout AbortController
// et neutralisation des erreurs (jamais bloquer le jeu sur le reseau du
// classement). Les trois consommateurs (lecture du top, soumission, verif
// de nom) partageaient le meme gabarit duplique -- un seul endroit pour le
// regler desormais.
async function supabaseFetch(path, options, timeoutMs) {
    if (!LB_REMOTE_OK) return null;
    try {
        const ctrl = new AbortController();
        const kill = setTimeout(() => ctrl.abort(), timeoutMs || 5000);
        // FUSION des headers : Object.assign remplacait l'objet headers du
        // gabarit par celui de l'appelant -- le POST (Content-Type seul)
        // partait SANS apikey/Authorization et Supabase repondait 401 :
        // les scores n'etaient plus envoyes, silencieusement.
        const opts = Object.assign({}, options || {});
        opts.headers = Object.assign({
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': 'Bearer ' + SUPABASE_ANON_KEY
        }, (options && options.headers) || {});
        if (!opts.signal) opts.signal = ctrl.signal;
        const res = await fetch(SUPABASE_URL + path, opts);
        clearTimeout(kill);
        return res;
    } catch (e) { return null; }
}
// Cloture stockage/affichage : on stocke et recupere le meme nombre
// d'entrees que ce qui est affiche. Avant : 100 stockees/fetch mais seules
// les 50 premieres etaient rendues -- 50 entrees mortes en localStorage
// et dans la reponse REST a chaque ouverture de modale.
const LEADERBOARD_MAX_ENTRIES = 200;

// Plafond anti-triche : 2e1000 depasse le max des doubles IEEE 754
// (~1.8e308) -> la constante vaut Infinity : AUCUN score fini n'est
// bloque cote client. La vraie barriere est serveur : anti-triche de
// croissance (rapport > x1000 entre deux soumissions d'un meme nom =
// rejet + journal) et rate-limit par IP. Cote client, le plafond est
// desactive : le jeu ne doit jamais cacher une soumission legitime.
const LEADERBOARD_SPEED_CEILING = 2e1000;
// Auto-soumission : toutes les 30 s, uniquement si le record a change.
const LEADERBOARD_AUTOSUBMIT_MS = 30000;

function sanitizeCompanyName(raw) {
    return String(raw || '')
        .replace(/[<>"'&]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 20);
}

function getCompanyName() {
    return sanitizeCompanyName(localStorage.getItem(LEADERBOARD_COMPANY_KEY));
}

// Verifier si le nom existe deja dans le classement mondial : retourne
// true si pris. Non bloquant : en cas d'erreur reseau, on autorise (le
// serveur gere les collisions par le meilleur score de toute facon).
async function isCompanyNameTakenRemote(name) {
    const res = await supabaseFetch('/rest/v1/leaderboard?select=name&name=eq.' + encodeURIComponent(name), null, 4000);
    if (!res || !res.ok) return false;
    try {
        const rows = await res.json();
        return Array.isArray(rows) && rows.length > 0;
    } catch (e) { return false; }
}

function confirmCompanyName() {
    const input = document.getElementById('company-required-input');
    const name = sanitizeCompanyName(input ? input.value : '');
    if (name.length < 3) {
        showToast('\u274c ' + t('Nom trop court : 3 caract\u00e8res minimum.'));
        if (input) input.focus();
        return;
    }
    localStorage.setItem(LEADERBOARD_COMPANY_KEY, name);
    document.getElementById('company-required-modal').classList.remove('active');
    // Reprise du jeu gele par ensureCompanyName (le nom est confirme :
    // la partie peut commencer).
    if (gameplayPaused) setGameplayPaused(false);
    showToast('\u2705 ' + t('Entreprise enregistr\u00e9e : {name} !').replace('{name}', name));
    // Le corps de fusee (deja achete ou achete plus tard) prend le nom.
    refreshRocketNameTag();
    // V3.70 (retour proprietaire : 'si je choisis un ban word il faut
    // que cote joueur ca le lui dise et que ca lui demande un autre nom')
    // : verification LOCALE des mots interdits -- le joueur est PREVENU
    // AVANT meme la confirmation, la modale reste ouverte pour changer.
    // (liste miroir de leaderboard_banned_words : la reference SERVEUR
    // reste la base, cette liste evite l'aller-retour reseau pour les
    // cas evidents ; insensible a la casse comme le serveur.)
    const LOCAL_BANNED_WORDS = ['connard', 'salope', 'pute', 'ntm', 'fuck',
                                'bitch', 'shit', 'nazi', 'hitler'];
    const lower = name.toLowerCase();
    const badWord = LOCAL_BANNED_WORDS.find(w => lower.includes(w));
    if (badWord) {
        if (input) { input.focus(); }
        showToast('\u274c ' + t('Ce pseudo contient un mot interdit \u2014 choisissez-en un autre.'));
        return;
    }
    // V3.59 (demande proprietaire : 'si le serveur detecte que le nom
    // est deja pris, celui qui le demande ne peut pas le prendre du
    // tout') : BLOCAGE. La verification remote est censee repondre avant
    // la confirmation (le nom vient d'etre tape) ; si elle ne repond pas
    // (reseau lent/HS), le garde-fou SERVEUR reste actif ('name already
    // taken' : refus de la soumission).
    isCompanyNameTakenRemote(name).then(taken => {
        if (taken) {
            localStorage.removeItem(LEADERBOARD_COMPANY_KEY);
            const modal = document.getElementById('company-required-modal');
            const input = document.getElementById('company-required-input');
            if (modal) {
                modal.classList.add('active');
                if (input) { input.value = ''; setTimeout(() => input.focus(), 80); }
            }
            showToast('\u274c ' + t('Ce nom est d\u00e9j\u00e0 utilis\u00e9 par un autre pilote \u2014 choisissez-en un autre.'));
            return;
        }
        // Nom libre : premiere soumission pour exister dans le top.
        autoSubmitLeaderboard(true);
    });
}

// Partie en cours sans nom d'entreprise : modale non fermable jusqu'a
// validation. Appelee a l'init, apres loadGame().
function ensureCompanyName() {
    if (getCompanyName().length >= 3) return;
    const modal = document.getElementById('company-required-modal');
    if (!modal) return;
    const input = document.getElementById('company-required-input');
    if (input) input.value = '';
    modal.classList.add('active');
    // PAUSE du jeu tant que le nom n'est pas confirme : le jeu ne doit pas
    // commencer (production, clics, contrats, cometes) avant que le joueur
    // ait donne son nom d'entreprise. La pause purge l'ecran et gele la
    // boucle ; la reprise se fait dans confirmCompanyName.
    setGameplayPaused(true);
    if (input) setTimeout(() => input.focus(), 80);
}

function getLocalLeaderboard() {
    try {
        const raw = localStorage.getItem(LEADERBOARD_LOCAL_KEY);
        const arr = raw ? JSON.parse(raw) : [];
        if (!Array.isArray(arr)) return [];
        return arr.filter(e => e && typeof e.name === 'string' && isFinite(e.speed))
            .map(e => ({
                name: String(e.name).slice(0, 20),
                speed: Number(e.speed) || 0,
                rockets: Number(e.rockets) || 0,
                clicks: Number(e.clicks) || 0,
                at: Number(e.at) || 0
            }));
    } catch (e) { return []; }
}

function saveLocalLeaderboard(entries) {
    try { localStorage.setItem(LEADERBOARD_LOCAL_KEY, JSON.stringify(entries.slice(0, LEADERBOARD_MAX_ENTRIES))); }
    catch (e) { /* quota : le classement local est un bonus, jamais bloquant */ }
}

function pushLocalScore(name, speed) {
    const entries = getLocalLeaderboard();
    // 1 entreprise = 1 entree : la meilleure vitesse l'emporte.
    const existing = entries.findIndex(e => e.name === name);
    if (existing !== -1) {
        if (entries[existing].speed >= speed) return;
        entries.splice(existing, 1);
    }
    entries.push({ name, speed, at: Date.now() });
    entries.sort((a, b) => b.speed - a.speed);
    saveLocalLeaderboard(entries);
}

// --- Couche remote : inactive tant que LEADERBOARD_ENDPOINT est vide ---
async function fetchRemoteLeaderboard() {
    const res = await supabaseFetch('/rest/v1/leaderboard?select=name,speed,distance,rockets,clicks,at&order=speed.desc&limit=' + LEADERBOARD_MAX_ENTRIES, { cache: 'no-store' });
    if (!res || !res.ok) return null;
    try {
        const rows = await res.json();
        if (!Array.isArray(rows)) return null;
        return rows
            .filter(e => e && typeof e.name === 'string' && isFinite(e.speed))
            .map(e => ({
                name: String(e.name).slice(0, 20),
                speed: Number(e.speed) || 0,
                distance: Number(e.distance) || 0,
                rockets: Number(e.rockets) || 0,
                clicks: Number(e.clicks) || 0,
                at: Number(e.at) || 0
            }));
    } catch (e) { return null; }
}
// Onglet actif du classement : 'speed' | 'rockets' | 'clicks'. Le rendu de
// la liste se re-trie selon cet onglet (chaque classement vit sa vie).
let leaderboardActiveTab = 'distance';
function setLeaderboardTab(tab) {
    leaderboardActiveTab = (['speed', 'distance', 'clicks'].includes(tab)) ? tab : 'distance';
    document.querySelectorAll('#leaderboard-tabs .lb-tab').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.lb === leaderboardActiveTab);
    });
    // Description dynamique : chaque onglet decrit SON record.
    const subtitle = document.getElementById('leaderboard-subtitle');
    if (subtitle) {
        if (leaderboardActiveTab === 'distance') {
            subtitle.textContent = t('Record de distance d\u2019un lancement (km)');
        } else if (leaderboardActiveTab === 'clicks') {
            subtitle.textContent = t('Record de clics sur la pi\u00e8ce');
        } else {
            subtitle.textContent = t('Record de vitesse de voyage (km/s)');
        }
    }
    renderLeaderboardList();
}

// ================= CHAT GLOBAL =================
let chatChannel = null;
function toggleChat() {
    const modal = document.getElementById('chat-modal');
    if (!modal) return;
    const willOpen = !modal.classList.contains('active');
    if (typeof showExclusiveModal === 'function') {
        // réutilise le mécanisme exclusif si la modale chat y est enregistrée, sinon toggle manuel
        if (EXCLUSIVE_MODALS.includes('chat-modal')) {
            if (willOpen) {
                const badge = document.getElementById('chat-badge');
                if (badge) { badge.style.display = 'none'; badge.textContent = ''; }
            }
            showExclusiveModal('chat-modal', willOpen ? loadChatHistory : null);
            return;
        }
    }
    modal.classList.toggle('active', willOpen);
    if (typeof trapModalFocus === 'function' && willOpen) trapModalFocus(modal);
    if (willOpen) {
        const badge = document.getElementById('chat-badge');
        if (badge) { badge.style.display = 'none'; badge.textContent = ''; }
        loadChatHistory();
    }
}
function openChat() { toggleChat(); }
bindChatInputKeyboard();
// S'abonner au chat dès le chargement (pour le badge) — retry tant que le CDN supabase-js n'est pas prêt
(function subscribeChatOnLoad() {
    if (typeof window.supabase === 'undefined') { setTimeout(subscribeChatOnLoad, 500); return; }
    subscribeChatRealtime();
})();
async function loadChatHistory() {
    const list = document.getElementById('chat-list');
    if (!list) return;
    if (!LB_REMOTE_OK) { list.innerHTML = '<div class="chat-empty">' + escapeLeaderboardHtml(t('Chat indisponible')) + '</div>'; return; }
    try {
        const res = await supabaseFetch('/rest/v1/chat_messages?select=name,msg,ts&order=ts.desc&limit=50', { cache: 'no-store' });
        if (!res || !res.ok) throw new Error('http ' + (res && res.status));
        const rows = (await res.json()).reverse();
        renderChatRows(rows);
        subscribeChatRealtime();
    } catch (e) {
        list.innerHTML = '<div class="chat-empty">' + escapeLeaderboardHtml(t('Chat indisponible')) + '</div>';
    }
}
function renderChatRows(rows) {
    const list = document.getElementById('chat-list');
    if (!list) return;
    list.innerHTML = rows.map(r => {
        const d = new Date(Number(r.ts));
        const hh = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
        return '<div class="chat-msg"><span class="chat-time">' + hh + '</span> <span class="chat-name">' + escapeLeaderboardHtml(r.name) + '</span> <span class="chat-text">' + escapeLeaderboardHtml(r.msg) + '</span></div>';
    }).join('');
    list.scrollTop = list.scrollHeight;
}
function subscribeChatRealtime() {
    if (chatChannel || !LB_REMOTE_OK || !window.supabase || !supabase.createClient) return;
    try {
        if (!window.supabaseClient) window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        chatChannel = window.supabaseClient
            .channel('chat-global')
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, (payload) => {
                const list = document.getElementById('chat-list');
                if (!list || !payload.new) return;
                const d = new Date(Number(payload.new.ts));
                const hh = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
                const div = document.createElement('div');
                div.className = 'chat-msg';
                div.innerHTML = '<span class="chat-time">' + hh + '</span> <span class="chat-name">' + escapeLeaderboardHtml(payload.new.name) + '</span> <span class="chat-text">' + escapeLeaderboardHtml(payload.new.msg) + '</span>';
                list.appendChild(div);
                while (list.children.length > 100) list.removeChild(list.firstChild);
                list.scrollTop = list.scrollHeight;
                // Badge de notification si la modale chat est fermée
                const modal = document.getElementById('chat-modal');
                if (!modal || !modal.classList.contains('active')) {
                    const badge = document.getElementById('chat-badge');
                    if (badge) {
                        const n = (parseInt(badge.textContent, 10) || 0) + 1;
                        badge.textContent = n > 99 ? '99+' : String(n);
                        badge.style.display = 'flex';
                    }
                }
            })
            .subscribe();
    } catch (e) {}
}
// Mobile : quand le clavier virtuel s'ouvre, remonter le champ de saisie
// pour qu'il reste visible au-dessus du clavier (visualViewport).
function bindChatInputKeyboard() {
    const input = document.getElementById('chat-input');
    if (!input) return;
    const keepVisible = () => {
        setTimeout(() => {
            const vv = window.visualViewport;
            const r = input.getBoundingClientRect();
            if (vv && r.bottom > vv.height) {
                const list = document.getElementById('chat-list');
                if (list) list.scrollTop = list.scrollHeight;
                input.scrollIntoView({ block: 'end', behavior: 'smooth' });
            }
        }, 250);
    };
    input.addEventListener('focus', keepVisible);
    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); sendChat(); }
    });
    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', () => {
            if (document.activeElement === input) keepVisible();
        });
    }
}

async function sendChat() {
    const input = document.getElementById('chat-input');
    if (!input) return;
    const msg = input.value.trim();
    if (!msg) return;
    if (msg.length > 200) { showToast(t('Message trop long (200 max)')); return; }
    const name = getCompanyName();
    if (!name || name.length < 3) { showToast(t("Nomme ton entreprise spatiale d'abord (classement)")); return; }
    input.value = '';
    try {
        const res = await supabaseFetch('/rest/v1/rpc/post_chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ p_name: name, p_msg: msg })
        }, 5000);
        if (!res || !res.ok) {
            showToast(t('Message non envoyé (trop rapide ?)'));
        }
    } catch (e) {
        showToast(t('Chat indisponible'));
    }
}

async function submitRemoteScore(name, speed, curDistance, curClicks) {
    // UPSERT par nom (cle primaire) : chaque record ne descend jamais
    // (cote SQL : greatest() par colonne). On envoie TOUT l'etat de records
    // du joueur : vitesse (avec boosts, decision 2024-10), distance de
    // lancement record, nombre de fusees, nombre de clics.
    // V3.23 : STATISTIQUES JOUEUR (info uniquement) -- les plus parlantes
    // sur un compte : PE gagnees, batiments, upgrades galactiques, trophees,
    // cometes interceptees, record pps, doublages du record, mode infini.
    let buildingsOwned = 0;
    try { BUILDINGS.forEach(b => { buildingsOwned += Math.max(0, b.count || 0); }); } catch (e) {}
    let upgradesGal = 0;
    try { Object.values(galacticUpgrades).forEach(l => { upgradesGal += Math.max(0, l || 0); }); } catch (e) {}
    let trophiesCount = 0;
    try { trophiesCount = unlockedTrophies ? unlockedTrophies.size : 0; } catch (e) {}
    const res = await supabaseFetch('/rest/v1/rpc/submit_score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            p_name: name,
            p_speed: speed,
            p_distance: Math.max(0, isFinite(curDistance) ? curDistance : 0),
            p_rockets: Math.max(0, rocketsLaunched || 0),
            p_clicks: Math.max(0, isFinite(curClicks) ? curClicks : 0),
            // V3.4 : temps de jeu reel (info uniquement, non affiche).
            p_playtime: Math.max(0, Math.floor(activePlaytimeSeconds)),
            // V3.99 : sessions distinctes (analyse de retention).
            p_sessions: Math.max(0, sessionsCount || 0),
            // V3.23 : stats joueur.
            p_stardust: Math.max(0, totalStardustEarned || 0),
            p_buildings: buildingsOwned,
            p_upgrades: upgradesGal,
            p_trophies: trophiesCount,
            p_comets: Math.max(0, clickedBonusesCount || 0),
            p_pps: Math.max(0, isFinite(maxPartsPerSecond) ? maxPartsPerSecond : 0),
            p_doublings: Math.max(0, recordDoublings || 0),
            p_infinite: !!gameFinished,
            // V5.2 : source du joueur (domaine + utm) pour le dashboard "d'où viennent les joueurs"
            p_source: (new URLSearchParams(location.search).get('utm_source') || location.hostname)
        })
    });
    return !!(res && res.ok);
}

// Suppression cote serveur de l'entree du classement (reset complet) :
// sans elle, l'ancienne progression resterait visible au classement mondial
// (upsert monotone greatest() : un record ne descend jamais). Le serveur
// verifie la propriete du nom par IP ('not owner' depuis une autre IP).
// Fire-and-forget : le reset local ne bloque jamais sur le reseau.
async function deleteRemoteScore(name) {
    if (!LB_REMOTE_OK) return;
    await supabaseFetch('/rest/v1/rpc/delete_my_score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ p_name: name })
    }, 4000);
}

// Score soumis : le record de vitesse de voyage (km/s), deja persiste
// dans les stats du jeu (maxTravelSpeed, mis a jour en continu par
// updateSpaceProgress).
function getLeaderboardScore() {
    return Math.max(0, isFinite(getRecordMaxTravelSpeed()) ? getRecordMaxTravelSpeed() : 0);
}

// Soumission PERIODIQUE : le timer de 30 s appelle autoSubmitLeaderboard
// et l'envoi part a CHAQUE tick, sans garde de progression -- les records
// de distance et de clics doivent remonter meme sans progression de la
// vitesse. Le serveur deduplique de toute facon (upsert greatest() par
// colonne : renvoyer la meme valeur est un no-op ; la vitesse ne monte
// que strictement). L'ancien garde "speed <= lastSubmittedSpeed" figeait
// distance et clics tant que la vitesse ne progressait pas.
let lastSubmitted = { speed: -1, distance: -1, clicks: -1 };
let autoSubmitIntegrityToastShown = false;
async function autoSubmitLeaderboard(force) {
    const name = getCompanyName();
    if (name.length < 3) return;
    // Mode test : les scores obtenus via CHEATMODE2 ne sont JAMAIS envoyes,
    // ni pendant la session ni apres (le flag n'est pas leve par 'Quitter
    // le mode test' -- les records falsises restent invalides).
    if (devModeTainted) return;
    const speed = getLeaderboardScore();
    // Anti-triche couche 1 : si le code critique a été modifié après le
    // chargement (console/debugger), on ne soumet PLUS rien au classement
    // global. Le classement local continue (aucune valeur, aucun serveur).
    const integrityOk = checkCodeIntegrity();
    enforceAntiCheat();
    if (!integrityOk && !autoSubmitIntegrityToastShown) {
        autoSubmitIntegrityToastShown = true;
        showToast('\u26a0\ufe0f ' + t('Code modifié — classement mondial désactivé.'));
    }
    if (!integrityOk) return;
    // Multi-records : la vitesse peut etre 0 (debut d'expedition, la vitesse
    // ne monte qu'en accumulant des Parts sur la fusee en cours) -- les
    // records de DISTANCE et de CLICS doivent continuer d'etre envoyes.
    // L'ancien garde "speed <= 0" coupait TOUT envoi en debut de run : un
    // joueur qui cliquait ne voyait jamais son record de clics remonter.
    // On ne bloque que si AUCUN record n'a de valeur a envoyer.
    if (speed > LEADERBOARD_SPEED_CEILING) return;
    const curDistance = Math.max(0, isFinite(getRecordMaxDistance()) ? getRecordMaxDistance() : 0);
    const curClicks = Math.max(0, totalClicksAllTime || 0);
    if (speed <= 0 && curDistance <= 0 && curClicks <= 0) return;
    pushLocalScore(name, speed);
    const ok = await submitRemoteScore(name, speed, curDistance, curClicks);
    // Echec reseau/serveur : ne PAS marquer le record comme soumis --
    // sinon il ne serait plus jamais retente (le test speed <= lastSubmitted
    // bloquerait toutes les soumissions futures tant que le record ne
    // progresse pas). On marque SEULEMENT si le serveur a accepte ; en cas
    // d'echec, la prochaine tentative repartira du meme record.
    if (ok) {
        lastSubmitted.speed = speed;
        lastSubmitted.distance = curDistance;
        lastSubmitted.clicks = curClicks;
    }
    // Rafraichir la modale si elle est ouverte.
    const modal = document.getElementById('leaderboard-modal');
    if (modal && modal.classList.contains('active')) renderLeaderboardList();
}

function escapeLeaderboardHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

async function refreshLeaderboard() {
    await renderLeaderboardList(true);
}

// Valeur "mon record" selon l'onglet actif du classement.
// V3.60 -> V3.61 : RANG MONDIAL du joueur, GENERALISE aux 3 onglets
// de la modale (distance, speed, clicks -- retour proprietaire : 'le
// rang affiche pour les 3 classements differents'). Le classement etant
// INFINI (plus de purge), le joueur hors top 50 voit sa place partout.
// Requete dediee : compte les joueurs au-dessus de SON record de la
// colonne demandee + 1. Index sur chaque colonne : ~1 ms quelle que soit
// la taille de la table. Retourne null si indisponible (reseau/erreur).
// Nombre total de joueurs inscrits au classement (par colonne), pour afficher
// le rang sous la forme "#12/560". Utilise le header Prefer: count=exact de
// PostgREST (content-range total), sans charger les lignes.
async function fetchLeaderboardTotal() {
    if (!LB_REMOTE_OK) return null;
    try {
        const res = await supabaseFetch('/rest/v1/leaderboard?select=name', {
            method: 'HEAD',
            headers: { 'Prefer': 'count=exact' }
        }, 4000);
        if (!res || !res.ok) return null;
        const cr = res.headers.get('content-range') || '';
        const m = cr.match(/\/(\d+)$/);
        return m ? Number(m[1]) : null;
    } catch (e) { return null; }
}

async function fetchMyGlobalRank(tab) {
    if (!LB_REMOTE_OK) return null;
    const name = getCompanyName();
    if (name.length < 3) return null;
    const column = tab === 'distance' ? 'distance' : (tab === 'clicks' ? 'clicks' : 'speed');
    // V3.77 : le rang est calcule PAR LE SERVEUR (fonction RPC my_rank) --
    // l'ancien comptage client (?column=gte.valeur dans l'URL) souffrait
    // d'un piege de parsing : le double 1.02e+31 faisait un aller-retour
    // JS -> URL -> PostgREST et le parse de la notation exponentielle
    // introduisait une micro-difference -- le vrai #1 etait affiche '#2'
    // (retour proprietaire, reproduit en direct : content-range '0-0/1'
    // pour le top 1, et le gte avec toPrecision(20) ne matchait toujours
    // pas sa propre ligne). La RPC compare les valeurs EN BASE entre
    // elles : aucun arrondi, aucun aller-retour. Fallback : si la RPC
    // n'existe pas encore (SQL pas re-execute), ancien comportement null.
    try {
        const res = await supabaseFetch('/rest/v1/rpc/my_rank', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ p_name: name, p_column: column })
        }, 4000);
        if (!res || !res.ok) return null;
        const data = await res.json();
        const rank = Array.isArray(data) ? Number(data[0] && data[0].rank) : Number(data && data.rank);
        if (!(rank > 0)) return null;
        return { rank: rank, total: null };
    } catch (e) { return null; }
}

function lbTabMyValue(tab) {
    if (tab === 'distance') return formatNumber(Math.max(0, isFinite(maxDistance) ? maxDistance : 0)) + ' km';
    if (tab === 'clicks') return formatNumber(Math.max(0, totalClicksAllTime || 0));
    return formatTravelSpeed(getLeaderboardScore());
}
// Partage du record du joueur (Web Share API, fallback copie dans le presse-papiers).
// Message pré-rempli avec le lien du jeu + UTM share pour mesurer la viralité.
async function shareMyRecord() {
    const name = getCompanyName();
    const tab = leaderboardActiveTab || 'distance';
    let recordTxt;
    if (tab === 'distance') recordTxt = formatNumber(Math.max(0, isFinite(maxDistance) ? maxDistance : 0)) + ' km';
    else if (tab === 'clicks') recordTxt = formatNumber(totalClicksAllTime || 0) + ' clics';
    else recordTxt = formatTravelSpeed(getLeaderboardScore());
    const label = tab === 'distance' ? t('km parcourus') : (tab === 'clicks' ? t('clics') : t('km/s'));
    const url = 'https://starcruiserclicker.com/?utm_source=share';
    const text = tf('🚀 Mon record sur Starcruiser Clicker : {record} ! {rank}Peux-tu me battre ? {url}', {
        record: recordTxt + (label ? ' (' + label + ')' : ''),
        rank: (myRankCache && myRankCache.rank ? t('Rang mondial') + ' #' + myRankCache.rank + '. ' : ''),
        name: name || 'Pilote',
        url: url
    });
    // Mobile tactile : feuille de partage native (texte + lien + record).
    // Partout ailleurs (PC) : on COPIE directement "record + lien" dans le
    // presse-papiers — pas de fenêtre système, le texte contient le record.
    if (IS_TOUCH && navigator.share) {
        try {
            await navigator.share({ title: 'Starcruiser Clicker', text: text, url: url });
            return;
        } catch (e) { /* annulé -> on tombe sur la copie */ }
    }
    try {
        await navigator.clipboard.writeText(text);
        showToast(t('Record + lien copiés ! Colle-les à tes amis 🚀'));
    } catch (e) {
        // Dernier recours : sélection manuelle via prompt
        window.prompt(t('Copie ce texte :'), text);
    }
}
let myRankCache = null;

async function renderLeaderboardList() {
    const listEl = document.getElementById('leaderboard-list');
    if (!listEl) return;
    const footnote = document.getElementById('leaderboard-footnote');
    const selfEl = document.getElementById('leaderboard-self');
    const myName = getCompanyName();
    const tab = leaderboardActiveTab;

    // Ligne "mon record" au-dessus du classement -- V3.60 : place
    // GLOBALE affichee (#5623) que le joueur soit dans le top 50 ou non
    // (retour proprietaire : 's'il est hors top 50 il voit sa place a
    // cote de son record').
    let myRank = null;
    myRank = await fetchMyGlobalRank(tab);
    myRankCache = myRank;
    const remote0 = await fetchRemoteLeaderboard();
    const lbTotal = (remote0 !== null) ? await fetchLeaderboardTotal() : null;
    if (selfEl) {
        if (myName.length >= 3) {
            selfEl.innerHTML = '<span class="leaderboard-self-name">' + escapeLeaderboardHtml(myName) + '</span>'
                + '<span class="leaderboard-self-share"><button class="lb-share-btn" onclick="shareMyRecord()" title="' + escapeLeaderboardHtml(t('Partager mon record')) + '">🔗 <span>' + escapeLeaderboardHtml(t('Partager')) + '</span></button></span>'
                + '<span class="leaderboard-self-speed">' + lbTabMyValue(tab)
                + (myRank ? ' <span class="leaderboard-self-rank">#' + myRank.rank + (lbTotal ? '/' + lbTotal : '') + '</span>' : '') + '</span>';
        } else {
            selfEl.innerHTML = '<span class="leaderboard-self-none">' + t('Aucune entreprise nomm\u00e9e.') + '</span>';
        }
    }

    const remote = remote0;
    const entries = (remote !== null) ? remote : getLocalLeaderboard();
    const source = remote !== null ? 'global' : 'local';
    if (!entries.length) {
        listEl.innerHTML = '<div class="leaderboard-empty">' + t('Aucun record pour l\'instant. Sois le premier pilote !') + '</div>';
    } else {
        const MEDALS = ['\ud83e\udd47', '\ud83e\udd48', '\ud83e\udd49'];
        // Tri selon l'onglet actif : chaque classement vit sur sa colonne.
        const sorted = entries.slice().sort((a, b) => {
            if (tab === 'distance') return (b.distance || 0) - (a.distance || 0);
            if (tab === 'clicks') return (b.clicks || 0) - (a.clicks || 0);
            return (b.speed || 0) - (a.speed || 0);
        });
        let html = '';
        const now = Date.now();
        sorted.slice(0, LEADERBOARD_MAX_ENTRIES).forEach((e, i) => {
            const isMe = myName && e.name === myName;
            const rank = i < 3 ? MEDALS[i] : String(i + 1);
            // Rond vert : score soumis il y a 5 minutes ou moins (colonne "at", ms)
            const online = e.at && (now - Number(e.at)) <= 5 * 60 * 1000;
            const dot = online ? ' <span class="lb-online-dot" title="' + t('En ligne (score envoyé il y a moins de 5 min)') + '"></span>' : '';
            let value;
            if (tab === 'distance') value = formatNumber(e.distance || 0) + ' km';
            else if (tab === 'clicks') value = formatNumber(e.clicks || 0) + ' \u{1F5B1}\ufe0f';
            else value = formatTravelSpeed(e.speed || 0);
            html += '<div class="leaderboard-row' + (isMe ? ' me' : '') + '">'
                + '<span class="leaderboard-rank">' + rank + '</span>'
                + '<span class="leaderboard-name">' + escapeLeaderboardHtml(e.name) + dot + '</span>'
                + '<span class="leaderboard-speed">' + value + '</span>'
                + '</div>';
        });
        listEl.innerHTML = html;
    }
    if (footnote) {
        footnote.textContent = source === 'global'
            ? t('Classement global (tous les joueurs). Ton record est envoy\u00e9 automatiquement.')
            : t('Classement local (ce navigateur).');
    }
}

// Zone pub topbar : largeur pilotee en JS -- l'espace REEL entre le logo
// et les controles (timer + boutons) varie selon l'ecran, le scaling
// Windows/Mac et les traductions. Les paliers CSS etaient faux sur
// certains ecrans (banniere trop petite). Ici on MESURE : slot = espace
// libre moins marges, plafonne a 960px, masque sous 400px.
function fitTopbarAdSlot() {
    const slot = document.getElementById('ad-slot-topbar');
    const bar = document.querySelector('.top-bar');
    if (!slot || !bar) return;
    const logo = document.querySelector('.top-bar-logo');
    const controls = document.querySelector('.top-bar-controls');
    if (!logo || !controls) { slot.style.display = 'none'; return; }
    const barRect = bar.getBoundingClientRect();
    const logoRect = logo.getBoundingClientRect();
    const ctrlRect = controls.getBoundingClientRect();
    // Marge de securite : quand l'ecran retrecit, la banniere doit se
    // retraiter encore un peu (demande : -20px de largeur de reference
    // supplementaire) -- gap 54 -> 74px de chaque cote.
    const gap = 74;
    const available = ctrlRect.left - logoRect.right - gap * 2;
    const width = Math.min(960, available);
    if (width < 400) {
        slot.style.display = 'none';
    } else {
        slot.style.display = '';
        slot.style.width = width + 'px';
    }
}
window.addEventListener('resize', fitTopbarAdSlot);
// V3.76 : DEFERE d'une frame -- le 'load' tombe juste apres que le boot a
// ecrit tout le DOM (batiments, fusee, HUD) : les 3 getBoundingClientRect
// de la mesure forcaient un reflow de TOUTE la page en pleine initialisation
// ('Forced reflow 87 ms', retour proprietaire). En rAF, la lecture s'exécute
// dans la frame de layout naturelle du navigateur -- mesure gratuite.
window.addEventListener('load', () => requestAnimationFrame(fitTopbarAdSlot));

function toggleLeaderboard() {
    showExclusiveModal('leaderboard-modal', () => {
        renderLeaderboardList();
    });
}

// Timer d'auto-soumission : toutes les 30 s.
setInterval(() => { autoSubmitLeaderboard(false); }, LEADERBOARD_AUTOSUBMIT_MS);
// Premiere soumission des qu'un nom existe et qu'un record est fait.
setTimeout(() => { autoSubmitLeaderboard(false); }, 4000);

// ============================================
// DISPLAY
// ============================================

let displayElementsCache = null;

function getDisplayElements() {
    if (displayElementsCache === null) {
        displayElementsCache = {
            scoreValue: document.getElementById('score-value'),
            gainValue: document.getElementById('gain-value'),
            modalPartsValues: Array.from(document.querySelectorAll('.modal-parts-value')),
            modalPartsGains: Array.from(document.querySelectorAll('.modal-parts-gain')),
            stardustValues: Array.from(document.querySelectorAll('#stardust-value, #stardust-value-2')),
            bonusTimer: document.getElementById('bonus-timer')
        };
    }
    return displayElementsCache;
}

function updateDisplay() {
    getBuildingGainsSnapshot();
    const els = getDisplayElements();
    if (els.gainValue) els.gainValue.textContent = formatNumber(partsPerSecond);
    updateModalPartsCounter();
    updateStardustDisplay();
    // Apercu PE du BOUTON atelier (V3.3) : throttle a 100 ms -- retour playtest,
    // la barre paraissait en retard sur le chiffre a 500 ms.
    const nowMs = Date.now();
    if (typeof updateDisplay.__lastPreview === 'undefined' || nowMs - updateDisplay.__lastPreview >= 100) {
        updateDisplay.__lastPreview = nowMs;
        updateStardustPreview();
    }
    updateBonusTimer();
}

// Compteur fluide : la valeur affichee rattrape le score reel en douceur,
// et chaque chiffre qui change deroule comme une machine a sous.
let animatedScore = null;
// Ruban vertical type odometre : chaque colonne contient les 10 chiffres
// empiles ; changer de chiffre deplace le ruban (transition CSS douce).
// L'effet reste fluide meme si la valeur change a chaque frame.
function splitCounterText(text) {
    const segs = [];
    let i = 0;
    while (i < text.length) {
        const isDigit = /\d/.test(text[i]);
        let j = i;
        while (j < text.length && /\d/.test(text[j]) === isDigit) j++;
        segs.push({ digits: isDigit, str: text.slice(i, j) });
        i = j;
    }
    return segs;
}
// Hauteur de colonne en pixels entiers : une hauteur fractionnaire fait
// reposer le ruban sur un sous-pixel different selon le chiffre affiche
// (rendu de police legerement variable d'une ligne a l'autre). On snappe
// donc la hauteur sur un entier et on deplace le ruban en px entiers.
function syncCchHeight(el) {
    if (!el) return;
    // V3.75 : CACHE de la lecture getComputedStyle -- le compteur tourne a
    // 10 Hz et getComputedStyle est une LECTURE DE LAYOUT : apres une
    // ecriture DOM (le rendu odometer lui-meme), chaque lecture forcait un
    // reflow complet du HUD ('Forced reflow 67 ms' en console, retour
    // proprietaire -- sur mobile le layout etant plus lourd, le reflow y
    // etait 3-5x plus long). La police ne change QUE via fitCounterFontSize
    // (resize) : on ne relit la taille CALCULEE que quand ce dernier leve
    // le drapeau de changement (window.__fontSigChanged), et on met la
    // hauteur en cache entre deux changements.
    if (el.__cchH && !window.__fontSigChanged) return;
    let h = Math.round(parseFloat(getComputedStyle(el).fontSize) * 1.5);
    if (!Number.isFinite(h) || h <= 0) h = 20;
    if (el.__cchH !== h) {
        el.__cchH = h;
        el.style.setProperty('--cch-h', h + 'px');
        el.__segs = null;
    }
}
function makeDigitCol() {
    const col = document.createElement('span');
    col.className = 'cch';
    const reel = document.createElement('span');
    reel.className = 'cch-reel';
    for (let d = 0; d < 10; d++) {
        const dn = document.createElement('span');
        dn.className = 'digit';
        dn.textContent = String(d);
        reel.appendChild(dn);
    }
    col.appendChild(reel);
    return { col, reel };
}
function renderCounterChars(el, text) {
    if (!el) return;
    syncCchHeight(el);
    const segs = splitCounterText(text);
    const prev = el.__segs;
    const sameShape = prev
        && prev.length === segs.length
        && prev.every((p, k) => p.digits === segs[k].digits);
    if (!sameShape) {
        while (el.firstChild) el.removeChild(el.firstChild);
        const nodes = [];
        segs.forEach(seg => {
            if (!seg.digits) {
                const tn = document.createElement('span');
                tn.className = 'cch-sep';
                tn.textContent = seg.str;
                el.appendChild(tn);
                nodes.push(tn);
            } else {
                const wrap = document.createElement('span');
                wrap.className = 'cch-group';
                const cols = [];
                for (const ch of seg.str) {
                    const c = makeDigitCol();
                    c.reel.style.transform = 'translateY(-' + (ch * el.__cchH) + 'px)';
                    wrap.appendChild(c.col);
                    cols.push(c.reel);
                }
                el.appendChild(wrap);
                nodes.push(cols);
            }
        });
        el.__segs = segs.map(sg => ({ digits: sg.digits, len: sg.str.length }));
        el.__nodes = nodes;
        return;
    }
    const nodes = el.__nodes;
    segs.forEach((seg, k) => {
        if (!seg.digits) {
            if (nodes[k] && nodes[k].textContent !== seg.str) nodes[k].textContent = seg.str;
            return;
        }
        const cols = nodes[k];
        const oldLen = el.__segs[k].len;
        const newLen = seg.str.length;
        if (newLen === oldLen) {
            for (let c = 0; c < newLen; c++) {
                const target = 'translateY(-' + (seg.str[c] * el.__cchH) + 'px)';
                if (cols[c].style.transform !== target) cols[c].style.transform = target;
            }
        } else {
            const wrap = cols[0].closest('.cch-group');
            if (newLen === oldLen + 1) {
                const c = makeDigitCol();
                c.reel.style.transform = 'translateY(-' + (seg.str[0] * el.__cchH) + 'px)';
                wrap.insertBefore(c.col, wrap.firstChild);
                cols.unshift(c.reel);
                for (let ci = 1; ci < newLen; ci++) {
                    const target = 'translateY(-' + (seg.str[ci] * el.__cchH) + 'px)';
                    if (cols[ci].style.transform !== target) cols[ci].style.transform = target;
                }
            } else {
                while (wrap.firstChild) wrap.removeChild(wrap.firstChild);
                const newCols = [];
                for (const ch of seg.str) {
                    const c = makeDigitCol();
                    c.reel.style.transform = 'translateY(-' + (ch * el.__cchH) + 'px)';
                    wrap.appendChild(c.col);
                    newCols.push(c.reel);
                }
                nodes[k] = newCols;
            }
            el.__segs[k].len = newLen;
        }
    });
}
// Auto-ajustement de la police du compteur : si les chiffres debordent de
// leur boite (petits ecrans PC / tablette paysage avec grands nombres),
// on reduit la font-size du .counter conteneur jusqu'a ce que tout rentre.
// Reaugmente progressivement quand l'espace redevient suffisant.
let fitCounterLastSig = '';
function fitCounterFontSize() {
    // V3.75 : OPTIMISATION REFLOW -- l'ancienne version tournait via
    // setInterval(500) et lisait offsetWidth/clientWidth a chaque passe :
    // lecture de layout APRES ecriture = forced reflow 2x/seconde meme quand
    // RIEN ne changeait (le garde-fou sig ne levait qu'apres les lectures).
    // Nouveau gardien PREALABLE : on lit window.innerWidth (lecture de
    // fenetre, PAS de layout DOM -- gratuit) AVANT de toucher le DOM, et on
    // ne poursuit que si la largeur a reellement change.
    const boxes = Array.from(document.querySelectorAll('.hud-top-row .counter'));
    if (!boxes.length) return;
    const sig = window.innerWidth + '|' + boxes.length;
    if (sig === fitCounterLastSig) return;
    fitCounterLastSig = sig;
    // Leve le drapeau pour que syncCchHeight rafraichisse son cache UNE fois.
    window.__fontSigChanged = true;
    const rootPx = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    // Gabarit MAX : 14 glyphes chiffre + separateurs, assez pour '999,99 Qi'.
    const MAX_GLYPHS = 14;
    boxes.forEach(box => {
        box.style.fontSize = '';
        void box.offsetWidth;
    });
    const basePx = parseFloat(getComputedStyle(boxes[0]).fontSize) || rootPx * 1.6;
    // Mesurer la largeur d'un glyphe numerique au gabarit, via un span temoin.
    let glyphW = basePx * 0.6;
    try {
        const probe = document.createElement('span');
        probe.style.cssText = 'position:absolute;visibility:hidden;white-space:pre;font-size:' + basePx + 'px;font-weight:bold;';
        probe.textContent = '0000000000';
        document.body.appendChild(probe);
        glyphW = probe.getBoundingClientRect().width / 10;
        probe.remove();
    } catch (e) {}
    // Police calee pour que MAX_GLYPHS glyphes tiennent dans la moitie du cadre.
    let common = basePx;
    boxes.forEach(box => {
        const avail = box.clientWidth - 16; // padding
        if (avail > 0 && glyphW > 0) {
            const fs = Math.max(rootPx * 0.6, Math.min(basePx, (avail / (MAX_GLYPHS * glyphW)) * basePx));
            common = Math.min(common, fs);
        }
    });
    common = Math.floor(common * 100) / 100;
    boxes.forEach(box => { box.style.fontSize = common + 'px'; });
    // Laisser passer UNE frame pour que syncCchHeight relise la nouvelle
    // police, puis rebaisser le drapeau.
    requestAnimationFrame(() => { requestAnimationFrame(() => { window.__fontSigChanged = false; }); });
}
// V3.75 : PLUS de setInterval aveugle -- la police ne change qu'au RESIZE
// (window.innerWidth) : l'ancien interval 500 ms lisait clientWidth 2x/s
// pour rien apres la stabilisation = reflows permanents (retour : 'j ai
// peur que ca lag encore pas mal, notamment telephones et tablettes').
window.addEventListener('resize', () => requestAnimationFrame(fitCounterFontSize));
window.addEventListener('orientationchange', () => setTimeout(refreshBonusBadgePosition, 250));
document.addEventListener('visibilitychange', () => { if (!document.hidden) requestAnimationFrame(fitCounterFontSize); });
function counterAnimLoop() {
    const el = getDisplayElements().scoreValue;
    if (el) {
        // Afficher la valeur reelle au moment du tick, meme si elle a evolue
        // plusieurs fois entre deux ticks : pas de rattrapage progressif.
        const shown = score < 1000
            ? Math.round(score * 10) / 10
            : Math.round(score);
        const text = shown < 1000 ? shown.toFixed(1) : formatNumber(shown, true);        renderCounterChars(el, text);
    }
    setTimeout(counterAnimLoop, 100);
}
setTimeout(counterAnimLoop, 100);

function rollCounterText(el, text) {
    renderCounterChars(el, text);
}

function updateModalPartsCounter() {
    const els = getDisplayElements();
    const hasOpenModal = document.querySelector('.modal.active') !== null;
    if (!hasOpenModal) return;
    // Meme odometer que le compteur principal : le rendu anime est conserve
    // dans les modales atelier et collection.
    els.modalPartsValues.forEach(el => { rollCounterText(el, formatNumber(score, true)); });
    els.modalPartsGains.forEach(el => { rollCounterText(el, formatNumber(partsPerSecond)); });
}

function updateStardustDisplay() {
    const els = getDisplayElements();
    const text = formatNumber(starDust);
    els.stardustValues.forEach(el => { rollCounterText(el, text); });
}

function updateStardustPreview() {
    const previewValue = document.getElementById('stardust-preview-value');
    const previewBar = document.getElementById('stardust-preview-bar');
    if (!previewValue || !previewBar) return;

    const reachableDistance = calculateDistance();
    const safeDistance = (isNaN(reachableDistance) || reachableDistance < 0) ? 0 : reachableDistance;
    const potentialDust = calculateStardustGainExact(safeDistance);
    const intPart = Math.floor(potentialDust);
    const fracPart = potentialDust - intPart;

    // PE fractionnaires (V3) : affiche 0,4 PE au lieu de 0 quand le vol
    // vaut moins d'un PE entier -- la barre continue de montrer la fraction.
    previewValue.textContent = intPart > 0
        ? formatNumber(intPart)
        : (potentialDust > 0 ? potentialDust.toFixed(1).replace('.', ',') : '0');
    previewBar.style.width = (fracPart * 100) + '%';
}

// Re-evalue la position du badge de bonus (a cote ou sous le compteur)
// apres un redimensionnement de la fenetre.
function refreshBonusBadgePosition() {
    const badge = document.getElementById('bonus-timer');
    if (!badge || badge.style.display === 'none') return;
    const badgeRow = badge.closest('.hud-counters-row');
    // Parent contraignant : .hud-top-row (max-width calc(100cqw - 24cqw)),
    // PAS .center-panel : sur tablette paysage le badge pouvait sembler
    // tenir dans le panneau central alors qu'il debordait de la zone HUD.
    const panel = badgeRow?.parentElement;
    if (!badgeRow || !panel) return;
    const rowRect = badgeRow.getBoundingClientRect();
    const panelRect = panel.getBoundingClientRect();
    const badgeW = badge.getBoundingClientRect().width;
    const fitsRight = rowRect.right + 8 + badgeW <= panelRect.right - 8;
    const fitsLeft = rowRect.left - 8 - badgeW >= panelRect.left + 8;
    badge.classList.toggle('bonus-below', !(fitsRight || fitsLeft));
}

function updateBonusTimer() {
    const els = getDisplayElements();
    if (els.bonusTimer) {
        const repositionBadge = () => {
            const badgeRow = els.bonusTimer.closest('.hud-counters-row');
            const panel = badgeRow ? badgeRow.parentElement : null;
            if (!badgeRow || !panel) return;
            const rowRect = badgeRow.getBoundingClientRect();
            const panelRect = panel.getBoundingClientRect();
            const badgeW = els.bonusTimer.getBoundingClientRect().width;
            const fitsRight = rowRect.right + 8 + badgeW <= panelRect.right - 8;
            const fitsLeft = rowRect.left - 8 - badgeW >= panelRect.left + 8;
            els.bonusTimer.classList.toggle('bonus-below', !(fitsRight || fitsLeft));
        };
        // Affiche le multiplicateur temporaire actif et le temps restant
        // (ex: "×4 · 12 s") a cote du compteur tant que le bonus dure.
        // Tous les bonus temporaires actifs se cumulent : le badge montre
        // le multiplicateur TOTAL (produit) et le temps restant le plus long.
        const now = Date.now();
        const prodActive = activeRandomBonuses.filter(b => (b.effect === 'multiplier' || b.effect === 'both' || b.id === 'flare') && b.endTime > now);
        const clickActive = activeRandomBonuses.filter(b => (b.effect === 'click' || b.effect === 'both') && b.endTime > now);
        // V3.11 : affichage coherent avec le plafond doux -- la partie
        // cometes est ecretee a 2048, les contrats s'ajoutent ensuite.
        const cometProd = prodActive.filter(b => !isContractBonus(b)).reduce((acc, b) => acc * (b.multiplier || 1), 1);
        const contractProd = prodActive.filter(b => isContractBonus(b)).reduce((acc, b) => acc * (b.multiplier || 1), 1);
        const prodMult = Math.min(TEMP_MULT_CAP(), cometProd) * contractProd;
        const cometClick = clickActive.filter(b => !isContractBonus(b)).reduce((acc, b) => acc * (b.multiplier || 1), 1);
        const contractClick = clickActive.filter(b => isContractBonus(b)).reduce((acc, b) => acc * (b.multiplier || 1), 1);
        const clickMult = Math.min(TEMP_MULT_CAP(), cometClick) * contractClick;
        const latestEnd = Math.max(0, ...prodActive.map(b => b.endTime), ...clickActive.map(b => b.endTime));
        if ((prodActive.length || clickActive.length) && (prodMult > 1 || clickMult > 1)) {
            const secLeft = Math.ceil((latestEnd - now) / 1000);
            const parts = [];
            // V3.5 : meme formatage que partout ailleurs (formatMultiplier) --
            // l'ancien '×' + prodMult affichait des nombres bruts peu lisibles.
            // V3.35 (retour joueur : 'le badge du x2 affiche +100%, regle ca')
            // : le badge des bonus TEMPORAIRES reste en MULTIPLICATEUR (x2,
            // x4...) -- les % de la V3.33 s'appliquent aux bonus PERMANENTS
            // (planetes, atelier, collection), pas aux multiplicateurs
            // d'evenement ponctuels : le joueur voit 'x2' pendant une flare,
            // pas '+100%'.
            if (prodMult > 1) parts.push('x' + Math.round(prodMult));
            if (clickMult > 1) parts.push(t('Clic') + ' x' + Math.round(clickMult));
            const label = parts.join(' + ');
            const text = label + ' · ' + secLeft + ' s';
            // 'block' explicite : le CSS de .bonus-timer est display:none,
            // style.display='' retirerait le style inline et le cacherait.
            const wasHidden = els.bonusTimer.style.display === 'none' || !els.bonusTimer.style.display;
            els.bonusTimer.textContent = text;
            els.bonusTimer.style.display = 'block';
            // Le repositionnement (3 getBoundingClientRect + reflow force)
            // ne sert que quand le badge apparait ou quand la largeur du
            // texte change : le decompte des secondes garde une largeur
            // stable, inutile de le refaire a chaque tick de 500 ms.
            if (wasHidden || text.length !== (els.bonusTimer.dataset.lastLen | 0)) {
                void els.bonusTimer.offsetWidth;
                repositionBadge();
                els.bonusTimer.dataset.lastLen = text.length;
            }
        } else {
            els.bonusTimer.textContent = '';
            els.bonusTimer.style.display = 'none';
            els.bonusTimer.classList.remove('bonus-below');
            delete els.bonusTimer.dataset.lastLen;
            // V3.31/V3.35 (retour joueur) : UNIQUE chemin de dissipation du
            // malus -- RESET TOTAL quand le timer de bonus disparaît (cette
            // branche ne s'exécute QUE sans aucun bonus actif : une comète
            // qui relance un x2 maintient le badge vivant et le malus en
            // place). Hors bonus : toutes les chances reviennent ; pendant
            // une cascade : le malus ne baisse plus jamais cran par cran,
            // x2048 redevient rare (12% par tentative, simulation).
            cometsInterceptedWindow.count = 0;
        }
    }
    const countersEl = document.querySelector('.counters');
    if (!countersEl) return;
    // V3.25 : les bonus EXPIRES mais pas encore filtres (expireRandomBonuses
    // tourne au tick suivant) ne comptent plus -- le pulse s'eteignait avec
    // jusqu'a 100 ms de retard apres l'expiration, et pire : un bonus expire
    // present dans le tableau gardait le badge timer affiche avec un temps
    // negatif plaque a 0 ('juste 2 secondes' puis fige, retour joueur).
    const nowMs2 = Date.now();
    const hasBonus = activeRandomBonuses.some(b => (b.effect === 'multiplier' || b.id === 'flare') && b.endTime > nowMs2);
    // Synchronisation des pulses blancs : si l'une des deux cases a deja
    // la classe et pas l'autre (element recre'e, bonus prolonge, ordre
    // d'update imprevisible), les animations ::after partaient decalees.
    // On retire puis repose la classe sur les DEUX dans la meme frame pour
    // que les keyframes bonus-rainbow-pulse demarrent exactement ensemble.
    const speedTileEl = document.getElementById('sidebar-speed');
    const speedTile = speedTileEl ? speedTileEl.closest('.stat-tile') : null;
    const hadCounters = countersEl.classList.contains('bonus-active');
    const hadSpeed = speedTile ? speedTile.classList.contains('bonus-active') : false;
    if (hadCounters !== hasBonus || hadSpeed !== hasBonus || (hasBonus && hadCounters !== hadSpeed)) {
        countersEl.classList.remove('bonus-active');
        if (speedTile) speedTile.classList.remove('bonus-active');
        void countersEl.offsetWidth;
        if (hasBonus) {
            countersEl.classList.add('bonus-active');
            if (speedTile) speedTile.classList.add('bonus-active');
        }
    }
}

// ============================================
// CONTRATS DE FABRICATION (mini-jeu)
// Contrats INTERACTIFS de 30 secondes : le joueur doit realiser une
// action pendant la duree (cliquer, intercepter des cometes, produire)
// pour gagner des Parts instantanees ou des bonus temporaires.
// 5 types de contrats, chacun en 3 difficultes (prix et gains croissants).
// Rotation des offres toutes les 2 minutes ; un contrat a la fois.
// ============================================
const CONTRACT_ROTATION_MS = 2 * 60 * 1000;
const CONTRACT_DURATION_MS = 30 * 1000;
const CONTRACT_UNLOCK_BUILDING_TYPES = 2;
const CARD_COLLECTION_UNLOCK_BUILDING_TYPES = 4;

// Definitions des types de contrats interactifs.
// objective     : cle d'i18n decrivant l'objectif (avec {target})
// track         : comment la progression est mesurEe
// rewardType    : 'instant' (Parts instantanees) | 'mult' (multiplicateur temporaire) | 'click' (multiplicateur de clic temporaire)
function getContractTypes() {
    const pps = Math.max(1, getBasePartsPerSecond());
    // V3.34 (retour joueur : 'les contrats doivent prendre en compte les
    // bonus pendant que je les fais') : la cible clickParts est desormais
    // calibree sur le clic COMPLET -- puissance (getClickPowerBonus), crit
    // en esperance (chance x mult), et cpsBonus sur le PPS REEL (avec les
    // multiplicateurs permanents), comme le gain reellement affiche a
    // l'ecran. L'ancienne cible comptait le clic 'naturel' (PPS de base)
    // alors que la progression comptait le cpsBonus du PPS complet --
    // cible et mesure desynchronisees, contrat impossible ou trivial selon
    // les bonus du moment.
    // getClickPower inclut clickMultiplier (temporaires type 'Clic x2') : on
    // les EXCLUT de la cible (l'offre est generee hors boost), sinon un boost
    // de clic actif au moment de la rotation gonflerait la cible.
    // V3.43 (retour joueur : 'les calculs des objectifs ne doivent PAS
    // prendre en compte les bonus temporaires') : le cpsBonus est RECALCULE
    // sur le PPS HORS BOOST (getBasePartsPerSecond, sans autoMultiplier) --
    // getClickComponents() le lit sur partsPerSecond QUI INCLUT le boost
    // temporaire actif : une offre generee pendant un flare x2 etait ciblee
    // sur une production doublee. La cible parle des PERMANENTS uniquement ;
    // la PROGRESSION compte toujours le gain reel, boost compris (V3.34).
    const critChance = Math.min(getCritChance(), 1);
    const critMult = (getGalacticUpgradeLevel('click8') > 0 || getGalacticUpgradeLevel('inf-crit') > 0) ? 5 : 3;
    const { baseCpC, buildingBonus } = getClickComponents();
    const cpsBonus = activatedClickUpgrades.length * 0.01 * getBasePartsPerSecond();
    const clickParts = Math.max(1, (baseCpC + buildingBonus + cpsBonus) * getClickPowerBonus() * (1 + critChance * (critMult - 1)));
    return [
        {
            id: 'clicks',
            icon: 'images/parts.webp',
            // Objectif : nombre de clics sur la piece pendant 30 s
            objective: 'Cliquez {target} fois sur la piece',
            track: 'clicks',
            diffs: [
                { target: 60,  price: Math.max(5, pps * 5),  rewardMult: 3,   rewardType: 'instant', instantSec: 15 },
                { target: 90, price: Math.max(50, pps * 13), rewardMult: 4,   rewardType: 'instant', instantSec: 30 },
                { target: 180, price: Math.max(200, pps * 25), rewardMult: 7,   rewardType: 'instant', instantSec: 45 }
            ]
        },
        {
            id: 'clickParts',
            icon: 'images/cursor.svg',
            // Objectif : Parts produites en cliquant pendant 30 s
            objective: 'Produisez {target} Parts en cliquant',
            track: 'clickParts',
            diffs: [
                { target: Math.max(60, clickParts * 60), price: Math.max(5, pps * 5),  rewardMult: 2, rewardType: 'mult', mult: 2, duration: 12 },
                { target: Math.max(90, clickParts * 90), price: Math.max(50, pps * 13), rewardMult: 3, rewardType: 'mult', mult: 3, duration: 16 },
                { target: Math.max(180, clickParts * 180), price: Math.max(200, pps * 25), rewardMult: 5, rewardType: 'mult', mult: 4, duration: 20 }
            ]
        },
        {
            id: 'comets',
            icon: 'images/effects/missile.webp',
            // Objectif : intercepter des cometes pour proteger la fusee
            objective: 'Defense parfaite : aucune comete ne doit toucher la fusee ({target} cometes)',
            track: 'comets',
            diffs: [
                { target: 4, price: Math.max(5, pps * 5),  rewardMult: 3, rewardType: 'instant', instantSec: 15 },
                { target: 7, price: Math.max(50, pps * 13), rewardMult: 5, rewardType: 'instant', instantSec: 30 },
                { target: 11, price: Math.max(200, pps * 25), rewardMult: 8, rewardType: 'instant', instantSec: 45 }
            ]
        },
        {
            id: 'production',
            icon: 'images/buildings/factory.webp',
            // Objectif : produire un quota de Parts (toute production confondue)
            objective: 'Produisez {target} Parts (toutes sources)',
            track: 'parts',
            diffs: [
                // V3.34 : cible sur le PPS REEL (retour joueur : 'les contrats
                // doivent prendre en compte les bonus') -- l'ancienne cible
                // comptait le PPS de base et la progression les Parts
                // naturelles : les bonus permanents (planetes, collection...)
                // n'etaient JAMAIS comptes, le contrat paraissait absurde face
                // a la production affichee. Cible et progression prennent
                // desormais TOUT : production reelle + clics reels.
                // pps*30 sur 30 s = faisable en passif, les paliers
                // demandent un apport actif (clics, cometes).
                // V3.43 : la CIBLE est sur le PPS HORS BOOST TEMPORAIRE
                // (getBasePartsPerSecond) -- partsPerSecond inclut le
                // autoMultiplier d'un flare actif et gonflait la cible des
                // offres generees pendant un bonus. Les bonus PERMANENTS
                // (planetes, collection, suite infinie) restent comptes ;
                // la PROGRESSION compte la production reelle, boost inclus.
                { target: Math.max(1, getBasePartsPerSecond()) * 30,  price: Math.max(5, pps * 5),  rewardMult: 2, rewardType: 'click', clickMult: 2, duration: 12 },
                { target: Math.max(1, getBasePartsPerSecond()) * 35, price: Math.max(50, pps * 13), rewardMult: 3, rewardType: 'click', clickMult: 3, duration: 16 },
                { target: Math.max(1, getBasePartsPerSecond()) * 40, price: Math.max(200, pps * 25), rewardMult: 5, rewardType: 'click', clickMult: 4, duration: 20 }
            ]
        },
        {
            id: 'shower',
            icon: 'images/effects/comete.webp',
            // Objectif : attraper les cometes d'une pluie provoquee pour le contrat
            objective: 'Survivez a la pluie : attrapez {target} cometes',
            track: 'comets',
            diffs: [
                { target: 5, price: Math.max(5, pps * 5),  rewardMult: 4, rewardType: 'instant', instantSec: 20, shower: 6 },
                { target: 8, price: Math.max(50, pps * 13), rewardMult: 6, rewardType: 'instant', instantSec: 40, shower: 9 },
                { target: 12, price: Math.max(200, pps * 25), rewardMult: 9, rewardType: 'instant', instantSec: 60, shower: 14 }
            ]
        }
    ];
}

let contractState = {
    offers: [],
    nextRotationAt: 0,
    active: null,
    unlockedSeen: false,
    offersSeenIds: []
};

// Deblocage PERMANENT des mini-jeux : une fois le seuil de types de
// batiments atteint (2 pour les contrats, 4 pour la collection), le
// joueur y a acces pour toujours, meme apres un lancement qui remet
// les batiments a zero. Persiste dans la sauvegarde.
let contractsEverUnlocked = false;
let cardsEverUnlocked = false;

// Visibilite des mini-jeux : caches tant que le seuil de types de
// batiments n'a jamais ete atteint. Une fois atteint, le deblocage est
// PERMANENT (contractsEverUnlocked / cardsEverUnlocked) : les cartes
// restent affichees apres un lancement et ses resets de batiments.
function updateMiniGamesVisibility() {
    refreshMiniGamesEverUnlocked();
    // Carte par carte : les Contrats apparaissent des 2 types de batiments,
    // la Collection des 4 (memes conditions que le deblocage des mini-jeux).
    // Avant, le joueur ne les voit pas du tout.
    const contractsCard = document.getElementById('contracts-mini-card');
    if (contractsCard) contractsCard.style.display = areContractsUnlocked() ? '' : 'none';
    const cardsCard = document.getElementById('card-collection-mini-card');
    if (cardsCard) cardsCard.style.display = areCardsUnlocked() ? '' : 'none';
    const section = document.querySelector('.mini-games-section');
    if (section) section.style.display = (areContractsUnlocked() || areCardsUnlocked()) ? '' : 'none';
    // Premier mini-jeu debloque : l'attenuation du tuto sur la colonne
    // gauche (Progression Spatiale) se leve -- le panneau redevient net
    // et cliquable des qu'une vraie mecanique y vit.
    if (areContractsUnlocked() || areCardsUnlocked()) {
        const lp = document.querySelector('.left-panel');
        if (lp) lp.classList.remove('tutorial-muted');
    }
}

function areCardsUnlocked() {
    return cardsEverUnlocked || getUnlockedBuildingTypes() >= CARD_COLLECTION_UNLOCK_BUILDING_TYPES;
}
function areContractsUnlocked() {
    return contractsEverUnlocked || getUnlockedBuildingTypes() >= CONTRACT_UNLOCK_BUILDING_TYPES;
}
// Memorise le deblocage permanent des le premier franchissement du seuil.
function refreshMiniGamesEverUnlocked() {
    if (!contractsEverUnlocked && getUnlockedBuildingTypes() >= CONTRACT_UNLOCK_BUILDING_TYPES) {
        contractsEverUnlocked = true;
    }
    if (!cardsEverUnlocked && getUnlockedBuildingTypes() >= CARD_COLLECTION_UNLOCK_BUILDING_TYPES) {
        cardsEverUnlocked = true;
    }
}

// Genere 2 a 3 offres aleatoires parmi les 5 types, difficultes variees.
function generateContractOffers() {
    const now = Date.now();
    const types = getContractTypes();
    const picked = [];
    const pool = types.slice();
    const n = Math.min(3, pool.length);
    for (let i = 0; i < n; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        const type = pool.splice(idx, 1)[0];
        // Difficulte ponderee vers le milieu : 40% normal, 35% facile, 25% difficile.
        const roll = Math.random();
        const diffIdx = roll < 0.35 ? 0 : (roll < 0.75 ? 1 : 2);
        const diff = type.diffs[diffIdx];
        picked.push({
            id: 'contract-' + type.id + '-' + diffIdx + '-' + now + '-' + Math.floor(Math.random() * 1e6),
            typeId: type.id,
            diffIdx: diffIdx,
            target: Math.max(1, Math.floor(diff.target)),
            price: Math.floor(diff.price),
            rewardMult: diff.rewardMult || 2,
            rewardType: diff.rewardType,
            instantSec: diff.instantSec || 0,
            clickMult: diff.clickMult || 0,
            mult: diff.mult || 0,
            duration: diff.duration || 0,
            shower: diff.shower || 0,
            expiresAt: now + CONTRACT_ROTATION_MS
        });
    }
    contractState.offers = picked;
    contractState.nextRotationAt = now + CONTRACT_ROTATION_MS;
    if (typeof renderContracts === 'function' && document.getElementById('contracts-modal').classList.contains('active')) {
        renderContracts();
    }
}

function findContractType(typeId) {
    return getContractTypes().find(tp => tp.id === typeId) || null;
}
// Icone de contrat : image du jeu (piece, curseur, missile, usine, comete).
function contractIconHtml(type, cls) {
    if (!type) return '';
    return '<img src="' + type.icon + '" class="' + (cls || 'contract-icon') + '" alt="">';
}

function getContractPrice() {
    return Math.max(50, Math.floor(getBasePartsPerSecond() * 20));
}

function contractObjectiveText(offer) {
    const type = findContractType(offer.typeId);
    if (!type) return '';
    return tf(type.objective, { target: formatNumber(offer.target) });
}

function contractRewardText(offer) {
    if (offer.rewardType === 'instant') {
        // Meme calcul que completeContract : DOUBLE du prix paye. L'ancien
        // "pps * instantSec" ici divergeait du reel credite (deux affichages
        // de gains coexistaient : le rewardLabel du bouton etait correct,
        // cette ligne montrait l'ancien barreme dependant du pps).
        return tf('Gains : +{parts} Parts instantanees', { parts: formatNumber(Math.floor(offer.price * (offer.rewardMult || 2))) });
    }
    if (offer.rewardType === 'mult') {
        return tf('Gains : production x{mult} pendant {sec} s', { mult: offer.mult, sec: offer.duration });
    }
    if (offer.rewardType === 'click') {
        return tf('Gains : clic x{mult} pendant {sec} s', { mult: offer.clickMult, sec: offer.duration });
    }
    return '';
}

function openContracts() {
    // Tuto etape contrats : le joueur les a ouverts -> valider l'etape.
    try { markLessonSeen('tutorial-contracts-opened'); } catch (e) {}
    if (!areContractsUnlocked()) {
        showToast('\uD83D\uDD12 ' + tf('Debloque {count} types de batiments pour les contrats', { count: CONTRACT_UNLOCK_BUILDING_TYPES }));
        return;
    }
    // Le joueur a vu les contrats : le pulse d'attention s'eteint.
    clearPulseHint(document.getElementById('contracts-card-status')?.closest('.mini-game-card'));
    showExclusiveModal('contracts-modal', renderContracts);
}
function closeContracts() {
    document.getElementById('contracts-modal').classList.remove('active');
}

function acceptContract(offerId) {
    Sounds.contractAccept();
    const offer = contractState.offers.find(o => o.id === offerId);
    if (!offer) return;
    if (contractState.active) {
        showToast('\u26A0\uFE0F ' + t('Un contrat a la fois !'));
        return;
    }
    if (score < offer.price) {
        Sounds.lose();
        showToast('\u274C ' + t('Pas assez de Parts'));
        return;
    }
    score -= offer.price;
    // partsSinceLaunch (le compteur qui alimente la portee de la fusee) ne
    // doit JAMAIS diminuer : les achats de batiments, de pieces et
    // d'ameliorations ne le retirent pas. Le retirer ici faisait reculer
    // la portee actuelle -- le "retour en arriere du score" observe sur la
    // progression de la prochaine destination.
    contractState.active = {
        offerId: offer.id,
        typeId: offer.typeId,
        target: offer.target,
        progress: 0,
        price: offer.price,
        rewardMult: offer.rewardMult || 2,
        rewardType: offer.rewardType,
        instantSec: offer.instantSec,
        clickMult: offer.clickMult,
        mult: offer.mult,
        duration: offer.duration,
        shower: offer.shower,
        startTotal: totalPartsEarnedThisLaunch,
        naturalStartTotal: naturalPartsThisLaunch,
        startClickParts: totalPartsFromClicks,
        acceptedAt: Date.now(),
        expiresAt: Date.now() + CONTRACT_DURATION_MS
    };
    contractState.offers = contractState.offers.filter(o => o.id !== offer.id);
    const type = findContractType(offer.typeId);
    showToast('\u2705 ' + t('Contrat accepte !'), type ? type.icon : null);
    // Contrat "pluie" : on declenche SA pluie immediatement, les cometes
    // a attraper sont celles du contrat.
    if (offer.shower) {
        triggerContractShower(offer.shower);
    }
    // Contrat "cometes" : on fait tomber les cometes a intercepter.
    if (offer.typeId === 'comets' && !offer.shower) {
        // Defense parfaite : on lance exactement la cible — le joueur doit
        // toutes les intercepter, rater UNE seule fait echouer le contrat.
        triggerContractShower(offer.target);
    }
    if (offer.typeId === 'comets' || offer.shower) {
        showToast('\u2604\uFE0F ' + t('Des cometes arrivent ! Interception !'), null);
    }
    // La modale se ferme : le contrat se joue en direct sur la scene,
    // le joueur doit voir la fusee, la piece, les cometes. Sur mobile,
    // on ramene AUSSI la vue sur l'onglet Fusee -- sinon le joueur reste
    // sur le panneau des contrats et ne voit rien du jeu.
    closeContracts();
    if (typeof isMobileLayout === 'function' && isMobileLayout()) {
        setMobileView('center');
    }
    clearPulseHint(document.getElementById('contracts-card-status')?.closest('.mini-game-card'));
    saveGame();
}

// Pluie dediee au contrat : meme mecanique que startCometShower mais sans
// verrou cometShowerActive (les pluies de contrat sont independantes).
function triggerContractShower(count) {
    // Les cometes lancees ici sont des cometes de CONTRAT (aucun bonus direct
    // de parts), a distinguer des pluies naturelles qui, elles, en donnent.
    // Les cometes sont lancees UNE PAR UNE avec un intervalle fixe de
    // 0,33 seconde entre chaque : le rythme reste soutenu sans decomployer
    // la pluie d'un seul coup.
    // Sur mobile on MAINTIENT le nombre de cometes prevues : la reduction
    // a 60% rendait les contrats IMPOSSIBLES (defense parfaite facile :
    // cible 4, seulement 3 cometes lancees). Le contrat doit toujours etre
    // gagnable, on garde donc le compte exact.
    const COUNT = count;
    // Ecart de 0,5 s entre chaque comete (valeur validee par le jeu).
    const COMET_INTERVAL_MS = (wasmCore() ? wasmCore().contract_comet_interval_ms() : 330);
    // Suivi de la pluie du contrat : le total prevu, combien sont lancees
    // et combien sont encore en vol. Sert a echouer DES la derniere comete
    // passe si la cible n'est plus atteignable (plus de cometes a venir).
    if (contractState.active) {
        contractState.active.showerTotal = COUNT;
        contractState.active.showerLaunched = 0;
        contractState.active.showerInFlight = 0;
    }
    for (let k = 0; k < COUNT; k++) {
        launchContractComet(k * COMET_INTERVAL_MS);
    }
}
// Lancement d'UNE comete de contrat, tolerant aux pauses : si le jeu est
// en pause au moment du lancement (cinematique de depart, atelier post-vol,
// arriere-plan mobile...), l'ancien code perdait la comete -- elle etait
// comptee "lancee" mais spawnRandomBonus refusait de l'afficher. Le contrat
// devenait IMPOSSIBLE (cible 5, seulement 3 cometes visibles). On REPOUSSE
// donc le lancement jusqu'a la reprise, dans la limite du chrono du contrat.
// SPAWN CONTRACT AUTONOME : ne passe PAS par spawnRandomBonus (les regles
// du monde -- bande centrale, mode mobile, position -- ont deja provoque
// des cometes invisibles sur certains PC). Ici tout est calcule
// explicitement dans la bande CENTRALE VISIBLE, quel que soit le layout.
// Lancement des cometes de contrat -- MODELE D'ORIGINE (pre-V1, commit
// 1cb2a1b) remis a l'identique : c'est cette mecanique qui fonctionnait.
// Une comete toutes les 330 ms, comptes sur le contrat actif, spawn par
// le chemin unique spawnRandomBonus(true). La duree de vol y est FIXE
// (4 s), pas calculee -- aucune dependance a la geometrie de l'ecran.
function launchContractComet(delayMs) {
    setTimeout(() => {
        if (!contractState.active) return;
        // Pause pendant la fenetre de planification : les cometes non
        // lancees sont re-creees par la reprise (pausedRelaunch dans
        // setGameplayPaused) -- ne pas les spawn ici, sinon elles
        // apparaissaient pendant ou juste apres le gel.
        if (gameplayPaused) return;
        contractState.active.showerLaunched += 1;
        contractState.active.showerInFlight += 1;
        // 2e argument isContract = true : sans lui, la comete de contrat
        // n'etait pas marquee dataset.contractComet et creditait le bonus
        // de meteore (+parts) comme une comete naturelle au lieu de servir
        // uniquement l'objectif du contrat.
        spawnRandomBonus(true, true);
    }, delayMs);
}

// Hook appele depuis addScore (clics sur la piece) : alimente les contrats
// de type 'clicks' et 'clickParts'.
function notifyContractClick(points) {
    const c = contractState.active;
    if (!c) return;
    if (c.typeId === 'clicks') {
        c.progress += 1;
    } else if (c.typeId === 'clickParts') {
        c.progress += points;
    }
    updateContractHud();
}

// Hook appele quand une comete est interceptee/attrapee (clickedBonusesCount
// vient d'incrementer) : alimente les contrats 'comets' et 'shower'.
function notifyContractComet() {
    const c = contractState.active;
    if (!c) return;
    if (c.typeId === 'comets' || c.typeId === 'shower') {
        c.progress += 1;
        updateContractHud();
    }
}

function updateContractProgress() {
    const c = contractState.active;
    if (!c) return;
    // Contrat "production" : Parts naturelles gagnees toutes sources confondues
    if (c.typeId === 'production') {
        // V3.34 : le contrat production compte les Parts REELLES gagnees
        // (toutes sources, multiplicateurs permanents et temporaires inclus) --
        // coherent avec la cible calculee sur le PPS reel et avec ce que le
        // joueur VOIT s'accumuler. startTotal = totalPartsEarnedThisLaunch
        // a l'acceptation du contrat (snapshot existant).
        c.progress = Math.max(0, totalPartsEarnedThisLaunch - (c.startTotal || 0));
    }
    // clicks / clickParts / comets : progression incrementee par les hooks.
    if (c.progress >= c.target) {
        completeContract();
    }
}

function completeContract() {
    // EFFACER D'ABORD : la recompense (sons, toasts, multiplicateurs, DOM)
    // peut jeter -- si l'exception remontait avant l'effacement, le tick de
    // 100 ms re-detectait progress >= target et re-creditait la recompense
    // A CHAQUE TICK (gain + son en boucle, pps exponentiel). Le contrat est
    // retire de l'etat AVANT toute action secondaire : une erreur ne peut
    // plus jamais rejouer la complétion.
    const c = contractState.active;
    contractState.active = null;
    contractState.offers = [];
    contractState.nextRotationAt = Date.now() + CONTRACT_ROTATION_MS;
    if (!c) return;
    Sounds.contractDone();
    const pps = Math.max(1, getBasePartsPerSecond());
    if (c.rewardType === 'instant') {
        // Gain = DOUBLE du prix paye : recompense stable et previsible,
        // independante du pps du moment de la completion (le calcul
        // pps*instantSec variait selon la production au moment precis
        // du remplissage, et n'etait pas aligne sur le prix du bareme).
        const gain = Math.floor((c.price || 0) * (c.rewardMult || 2));
        score += gain;
        partsSinceLaunch += gain;
        trackPartsEarned(gain);
        showBonusPopup('+' + formatNumber(gain) + ' ' + t('Parts'), 'instant');
        showToast(tf('Contrat rempli ! +{parts} Parts', { parts: formatNumber(gain) }), 'images/parts.webp');
    } else if (c.rewardType === 'mult') {
        activateContractTempMultiplier(c.mult, c.duration * 1000);
        showToast(tf('Contrat rempli ! Production x{mult} pendant {sec} s', { mult: c.mult, sec: c.duration }), null);
    } else if (c.rewardType === 'click') {
        activateContractTempClickMultiplier(c.clickMult, c.duration * 1000);
        showToast(tf('Contrat rempli ! Clic x{mult} pendant {sec} s', { mult: c.clickMult, sec: c.duration }), null);
    }
    // V3.29 : compteur de contrats reussis (trophees).
    contractsCompleted++;
    updateDisplay();
    updateContractHud();
    checkTrophies();
    saveGame();
}

// Multiplicateur de production temporaire accorde par un contrat : passe
// par le meme canal que la flare (activeRandomBonuses) pour profiter du
// rainbow et du timer existants, avec un id distinct.
function activateContractTempMultiplier(mult, durationMs) {
    // Pas de setTimeout : expiration par endTime dans expireRandomBonuses
    // (gameLoop) -- unique source de verite, coherente avec les pauses.
    activeRandomBonuses.push({
        id: 'contract-mult',
        effect: 'multiplier',
        multiplier: mult,
        endTime: Date.now() + durationMs
    });
    rebuildAutoMultipliers();
    updateDisplay();
}

// Multiplicateur de clic temporaire accorde par un contrat.
function activateContractTempClickMultiplier(mult, durationMs) {
    // Pas de setTimeout : expiration par endTime dans expireRandomBonuses.
    activeRandomBonuses.push({
        id: 'contract-click',
        effect: 'click',
        multiplier: mult,
        endTime: Date.now() + durationMs
    });
    rebuildAutoMultipliers();
    updateDisplay();
}

function failContract() {
    Sounds.contractFail();
    const c = contractState.active;
    if (!c) return;
    // Defense parfaite : echec cause par UNE comete ratee, pas par le temps.
    // Message distinct pour que le joueur comprenne pourquoi il a perdu.
    const missedComet = c.failed && c.typeId === 'comets';
    const failMsg = missedComet
        ? t('Defense parfaite echouee : une comete a frappe la fusee !')
        : (c.typeId === 'shower' && c.failed
            ? t('Trop de cometes ratees... Le contrat est perdu.')
            : t('Contrat echoue... Le temps est ecoule.'));
    showToast('\u274C ' + failMsg, null, undefined, { failure: true });
    console.warn('[contrat] ECHEC type=' + c.typeId + ' cible=' + c.target
        + ' lancees=' + (c.showerLaunched || 0) + '/' + (c.showerTotal || 0)
        + ' enVol=' + (c.showerInFlight || 0) + ' progress=' + c.progress);
    contractState.active = null;
    contractState.offers = [];
    contractState.nextRotationAt = Date.now() + CONTRACT_ROTATION_MS;
    updateContractHud();
    saveGame();
}

let boosterReadyNotified = { standard: false, premium: false, legendary: false };
function tickBoosterTimers() {
    maybeStartBoosterTimers();
    const modalOpen = document.getElementById('card-collection-modal')?.classList.contains('active');
    if (modalOpen) updateBoosterTimers();
    for (const key in BOOSTERS) {
        if (isBoosterReady(key) && !boosterReadyNotified[key]) {
            boosterReadyNotified[key] = true;
            // Pas de toast au lancement : les boosters partent "prets"
            // (boosterReadyAt = 0) avant le deblocage de la collection,
            // et on ne notifie qu'un cycle DEJA reclame au moins une fois.
            if (!modalOpen && areCardsUnlocked() && boosterReadyAt[key] > 0) {
                showToast('\ud83c\udf81 ' + t('Booster') + ' ' + t(BOOSTERS[key].name) + ' ' + t('est prêt !'));
                showBoosterReadyBanner(key);
                Sounds.boosterReady();
            }
        } else if (!isBoosterReady(key)) {
            boosterReadyNotified[key] = false;
        }
    }
}
let boosterReadyBannerTimer = null;
function showBoosterReadyBanner(key) {
    const banner = document.createElement('div');
    banner.id = 'booster-ready-banner';
    banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:12000;display:flex;align-items:center;justify-content:center;gap:14px;padding:22px 18px;background:linear-gradient(135deg,rgba(88,28,135,0.97),rgba(2,6,23,0.97));border-bottom:3px solid var(--accent, #fbbf24);box-shadow:0 8px 30px rgba(0,0,0,0.6);cursor:pointer;transform:translateY(-100%);transition:transform 0.45s cubic-bezier(0.22,1,0.36,1);';
    const icon = document.createElement('span');
    icon.textContent = '\ud83c\udf81';
    icon.style.cssText = 'font-size:2.4rem;filter:drop-shadow(0 0 10px rgba(251,191,36,0.8));';
    banner.appendChild(icon);
    const text = document.createElement('div');
    text.style.cssText = 'display:flex;flex-direction:column;gap:4px;text-align:center;';
    const title = document.createElement('strong');
    title.textContent = t('Booster') + ' ' + t(BOOSTERS[key].name) + ' ' + t('est pr\u00eat !');
    title.style.cssText = 'font-size:1.35rem;font-weight:800;color:#fbbf24;text-shadow:0 0 12px rgba(251,191,36,0.5);letter-spacing:0.5px;';
    text.appendChild(title);
    const sub = document.createElement('span');
    sub.textContent = t('Clique pour ouvrir la collection');
    sub.style.cssText = 'font-size:0.9rem;color:rgba(226,232,240,0.85);';
    text.appendChild(sub);
    banner.appendChild(text);
    banner.addEventListener('click', () => {
        dismissBoosterReadyBanner(banner);
        openCardCollection();
    });
    document.body.appendChild(banner);
    requestAnimationFrame(() => { banner.style.transform = 'translateY(0)'; });
    if (boosterReadyBannerTimer) clearTimeout(boosterReadyBannerTimer);
    boosterReadyBannerTimer = setTimeout(() => dismissBoosterReadyBanner(banner), 6000);
}
function dismissBoosterReadyBanner(banner) {
    if (!banner || !banner.isConnected) return;
    if (boosterReadyBannerTimer) { clearTimeout(boosterReadyBannerTimer); boosterReadyBannerTimer = null; }
    banner.style.transform = 'translateY(-100%)';
    setTimeout(() => { if (banner.isConnected) banner.remove(); }, 500);
}
function tickContracts() {
    if (gameplayPaused) return;
    tickBoosterTimers();
    const now = Date.now();
    if (areContractsUnlocked() && !contractState.unlockedSeen) {
        contractState.unlockedSeen = true;
        if (contractState.offers.length === 0 && !contractState.active) {
            generateContractOffers();
        }
    }
    const rotationPaused = !!contractState.active;
    if (!rotationPaused && areContractsUnlocked()
        && (contractState.nextRotationAt === 0 || now >= contractState.nextRotationAt)) {
        generateContractOffers();
    }
    if (contractState.active) {
        updateContractProgress();
        if (contractState.active && now >= contractState.active.expiresAt) {
            failContract();
        }
    }
    if (document.getElementById('contracts-modal').classList.contains('active')) {
        renderContracts();
    }
    renderContractsCardStatus();
    renderCollectionCardStatus();
    updateContractHud();
}
// V3.83 (perf, retour proprietaire : 'setTimeout handler took 104ms,
// ca recharge h24') : tickContracts tourne a 100 ms et ces deux rendus de
// statut reecrivaient className/textContent a CHAQUE tick meme quand
// RIEN ne changeait -- une mutation de texte invalide le layout, x2
// fonctions x10/s = reflows permanents des le deblocage des mini-jeux.
// Desormais le DOM n est ecrit QUE si la signature (etat affiche) change.
let __collStatusSig = null;
function renderCollectionCardStatus() {
    const statusEl = document.getElementById('collection-card-status');
    if (!statusEl) return;
    // Signature : tout ce qui influence l affiche, en une seule string.
    const collectedCount = Object.keys(cardCollection).filter(id => cardCollection[id] > 0).length;
    const mult = areCardsUnlocked() ? getCollectionMultiplier().toFixed(2) : '';
    const sig = (areCardsUnlocked() ? 'u:' : 'l:') + collectedCount + ':' + COLLECTIBLE_CARDS.length + ':' + mult;
    if (sig === __collStatusSig) return;
    __collStatusSig = sig;
    // Badge informatif dans la case du mini-jeu : cartes / total + bonus,
    // visible des le deblocage de la collection.
    const ccbOwned = document.getElementById('ccb-owned');
    if (ccbOwned) {
        ccbOwned.textContent = collectedCount;
        document.getElementById('ccb-total').textContent = COLLECTIBLE_CARDS.length;
        document.getElementById('ccb-bonus').textContent = '\u00d7' + mult;
    }
    if (!areCardsUnlocked()) {
        statusEl.className = 'game-status visible';
        statusEl.textContent = '\uD83D\uDD12 ' + tf('{count} batiments requis', { count: CARD_COLLECTION_UNLOCK_BUILDING_TYPES });
        return;
    }
    statusEl.className = 'game-status';
    statusEl.textContent = '';
}
let __contrStatusSig = null;
function renderContractsCardStatus() {
    const statusEl = document.getElementById('contracts-card-status');
    if (!statusEl) return;
    const now = Date.now();
    // V3.83 : signature SECONDE-granularite -- le compte a rebours change
    // 1x/s, pas 10x/s : le tick de 100 ms ne doit ecrire le DOM qu une
    // fois par changement EFFECTIF de la valeur affichee.
    const sec = Math.ceil(Math.max(0, contractState.nextRotationAt - now) / 1000);
    const sig = (areContractsUnlocked() ? 'u:' : 'l:')
        + (contractState.active ? 'a:' + contractState.active.offerId
            : 'o:' + contractState.offers.map(o => o.id).join(','))
        + ':' + sec;
    if (sig === __contrStatusSig) return;
    __contrStatusSig = sig;
    if (!areContractsUnlocked()) {
        statusEl.className = 'game-status visible';
        statusEl.textContent = '\uD83D\uDD12 ' + tf('{count} batiments requis', { count: CONTRACT_UNLOCK_BUILDING_TYPES });
        return;
    }
    if (contractState.active) {
        // Le rappel du contrat actif vit desormais dans le badge HUD sous le
        // compteur : la case des contrats n'affiche plus le doublon.
        statusEl.className = 'game-status';
        statusEl.textContent = '';
    } else if (contractState.offers.length > 0) {
        const nextIn = Math.max(0, contractState.nextRotationAt - now);
        statusEl.className = 'game-status visible';
        statusEl.innerHTML = '<span class="status-offers">' + contractState.offers.length + ' ' + t('contrat(s) propose(s)') + '</span>'
            + ' \u00b7 ' + tf('nouveaux contrats dans {time}', { time: formatContractTime(nextIn) });
        // Nouveaux contrats disponibles : pulse sur la case pour attirer l'oeil,
        // uniquement pour des offres jamais annoncees.
        const seen = contractState.offersSeenIds || [];
        const hasNew = contractState.offers.some(o => !seen.includes(o.id));
        if (hasNew) {
            contractState.offersSeenIds = contractState.offers.map(o => o.id);
            pulseHint(statusEl.closest('.mini-game-card'));
            showToast('\ud83d\udcc4 ' + t('Nouveau contrat disponible !'));
            Sounds.contractNew();
        }
    } else {
        // Permanence : meme sans offre active, la case affiche TOUJOURS
        // quand arrive la prochaine rotation de contrats.
        const nextIn = Math.max(0, contractState.nextRotationAt - now);
        statusEl.className = 'game-status visible';
        statusEl.textContent = '\u23F3 ' + tf('prochain contrat dans {time}', { time: formatContractTime(nextIn) });
    }
}
function contractsStructureKey() {
    if (contractState.active) return 'active:' + contractState.active.offerId;
    return 'offers:' + contractState.offers.map(o => o.id).join(',');
}
// Panneau flottant du contrat actif (HUD central) : objectif court,
// progression cible et chrono restant, mis a jour par tickContracts
// et par les hooks de progression pour rester reactif entre deux ticks.
function getContractHudShortLabel(c) {
    // Toujours juste "Contrat" : le type complet ne tenait jamais dans la
    // largeur du HUD, le reste de la ligne (progression + chrono) etait rogne.
    return t('Contrat');
}
let __contrHudSig = null;
function updateContractHud() {
    const hud = document.getElementById('contract-hud');
    if (!hud) return;
    const c = contractState.active;
    if (!c) {
        // V3.83 : pas de re-ecriture a chaque tick -- la ligne etait
        // reassignee (meme valeur) 10x/s en permanence hors contrat.
        if (__contrHudSig !== null) {
            hud.style.display = 'none';
            __contrHudSig = null;
        }
        return;
    }
    const secLeft = Math.max(0, Math.ceil((c.expiresAt - Date.now()) / 1000));
    const current = c.typeId === 'production'
        ? Math.max(0, totalPartsEarnedThisLaunch - (c.startTotal || 0))
        : Math.max(0, c.progress);
    // Signature : le label ne change que par contrat, la progression et
    // le chrono SECONDE par seconde, la barre au % pres (barre fluide sans
    // reflow inutile : 100 ecritures/s remplacees par ~10).
    // V3.85 FIX (retour proprietaire : 'la barre n avance pas pendant un
    // contrat de comete') : le clamp etait a 100 mais la valeur en
    // POUR-MILLE -- des 10% de progression le plafond mordait et la barre
    // restait FIGEE a 10% jusqu a la completion. Clamp a 1000.
    const pct = Math.min(1000, Math.floor((current / c.target) * 1000));
    const sig = c.offerId + ':' + Math.floor(current) + ':' + secLeft + ':' + pct;
    if (sig === __contrHudSig) return;
    __contrHudSig = sig;
    const labelEl = document.getElementById('contract-hud-label');
    const progressEl = document.getElementById('contract-hud-progress');
    const timeEl = document.getElementById('contract-hud-time');
    const barEl = document.getElementById('contract-hud-bar-fill');
    if (labelEl) labelEl.textContent = getContractHudShortLabel(c);
    if (progressEl) progressEl.textContent = formatNumber(Math.min(current, c.target)) + ' / ' + formatNumber(c.target);
    if (timeEl) timeEl.textContent = secLeft + ' s';
    if (barEl) barEl.style.width = (pct / 10) + '%';
    hud.style.display = 'block';
}
function renderContracts() {
    const modal = document.getElementById('contracts-modal');
    if (!modal.classList.contains('active')) return;
    const listEl = document.getElementById('contracts-list');
    if (!listEl) return;
    const now = Date.now();
    const key = contractsStructureKey();
    // Reconstruire le DOM seulement si la structure change (nouvelles offres,
    // contrat actif/termine). Sinon mise a jour ciblee des valeurs dynamiques.
    if (listEl.dataset.structureKey !== key) {
        listEl.dataset.structureKey = key;
        listEl.innerHTML = buildContractsHtml();
    }
    updateContractsDynamicValues(listEl, now);
}
function contractDifficultyLabel(diffIdx) {
    return diffIdx === 0 ? t('Facile') : (diffIdx === 1 ? t('Normal') : t('Difficile'));
}
// Couleur du label de difficulte : vert = facile, gris-bleu = normal, rouge = difficile.
function contractDifficultyClass(diffIdx) {
    return diffIdx === 0 ? 'diff-easy' : (diffIdx === 1 ? 'diff-normal' : 'diff-hard');
}
function buildContractsHtml() {
    let html = '<div class="contract-rotation">\u23f3 ' + tf('nouveaux contrats dans {time}', { time: '<span class="contract-rotation-timer">' + formatContractTime(Math.max(0, contractState.nextRotationAt - Date.now())) + '</span>' }) + '</div>';
    if (contractState.active) {
        const c = contractState.active;
        const type = findContractType(c.typeId);
        html += '<div class="contract-card active">'
            + '<div class="contract-head">' + contractIconHtml(type) + '<div><div class="contract-title">' + tf(type ? type.objective : '', { target: formatNumber(c.target) }) + '</div>'
            + '<div class="contract-sub">' + t('Contrat en cours') + '</div></div></div>'
            + '<div class="contract-progress"><div class="contract-progress-fill" style="width:0%"></div></div>'
            + '<div class="contract-meta"><span class="contract-progress-text"></span>'
            + '<span class="contract-timer"></span></div>'
            + '</div>';
    } else if (contractState.offers.length === 0) {
        html += '<div class="contract-empty">' + t('Aucun contrat disponible') + '</div>';
    } else {
        contractState.offers.forEach(offer => {
            const type = findContractType(offer.typeId);
            // Aperçu aligne sur le gain reel (completeContract) : 2x le prix paye.
            const rewardLabel = offer.rewardType === 'instant'
                ? tf('+{parts} Parts', { parts: formatNumber(Math.floor(offer.price * (offer.rewardMult || 2))) })
                : (offer.rewardType === 'mult'
                    ? 'x' + offer.mult + ' ' + t('production') + ' (' + offer.duration + ' s)'
                    : 'x' + offer.clickMult + ' ' + t('clic') + ' (' + offer.duration + ' s)');
            html += '<div class="contract-card">'
                + '<div class="contract-head">' + contractIconHtml(type) + '<div>'
                + '<div class="contract-title">' + contractObjectiveText(offer) + '</div>'
                + '<div class="contract-sub">' + t('30 secondes') + ' \u00b7 <span class="' + contractDifficultyClass(offer.diffIdx) + '">' + contractDifficultyLabel(offer.diffIdx) + '</span></div></div></div>'
                + '<div class="contract-reward">' + contractRewardText(offer) + '</div>'
                + '<button class="contract-buy-btn" data-offer-id="' + offer.id + '" onclick="acceptContract(\'' + offer.id + '\')">'
                + '<img src="images/parts.webp" class="coin-icon" alt=""> ' + formatNumber(offer.price) + ' ' + t('Parts') + '</button>'
                + '</div>';
        });
    }
    return html;
}
function updateContractsDynamicValues(listEl, now) {
    const rotationEl = listEl.querySelector('.contract-rotation-timer');
    if (rotationEl) rotationEl.textContent = formatContractTime(Math.max(0, contractState.nextRotationAt - now));
    if (contractState.active) {
        const c = contractState.active;
        const remaining = Math.max(0, c.expiresAt - now);
        const pct = Math.min(100, (c.progress / c.target) * 100);
        const fill = listEl.querySelector('.contract-progress-fill');
        if (fill) fill.style.width = pct + '%';
        const text = listEl.querySelector('.contract-progress-text');
        if (text) {
            if (c.typeId === 'clickParts' || c.typeId === 'production') {
                text.textContent = formatNumber(Math.floor(c.progress)) + ' / ' + formatNumber(c.target) + ' ' + t('Parts');
            } else {
                text.textContent = Math.floor(c.progress) + ' / ' + c.target;
            }
        }
        const timer = listEl.querySelector('.contract-timer');
        if (timer) timer.textContent = formatContractTime(remaining);
    } else {
        contractState.offers.forEach(offer => {
            const btn = listEl.querySelector('.contract-buy-btn[data-offer-id="' + offer.id + '"]');
            if (btn) btn.disabled = score < offer.price;
        });
    }
}
function formatContractTime(ms) {
    const s = Math.max(0, Math.ceil(ms / 1000));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const r = s % 60;
    const mm = (m < 10 ? '0' : '') + m;
    const rr = (r < 10 ? '0' : '') + r;
    return (h > 0 ? h + ':' : '') + mm + ':' + rr;
}
function resetContractState() {
    contractState.offers = [];
    contractState.active = null;
    contractState.nextRotationAt = 0;
    // unlockedSeen est conserve volontairement : il marque le deblocage
    // PERMANENT des contrats (types de batiments requis), pas l'etat de la
    // run. Le remettre a zero a chaque expedition masquerait la case
    // jusqu'au seuil de nouveau atteint, contrairement au deblocage acquis.
}


// ============================================
// CARD COLLECTION MINI-GAME
// ============================================

const CARD_RARITIES = {
    common:     { name: 'Commune',     color: '#94a3b8', glow: 'rgba(148,163,184,0.4)', bonusMult: 0.01 },
    rare:       { name: 'Rare',        color: '#3b82f6', glow: 'rgba(59,130,246,0.5)',  bonusMult: 0.03 },
    epic:       { name: 'Épique',     color: '#a78bfa', glow: 'rgba(167,139,250,0.6)',  bonusMult: 0.08 },
    legendary:  { name: 'Légendaire',  color: '#fbbf24', glow: 'rgba(251,191,36,0.7)', bonusMult: 0.20 },
    alternative:{ name: 'Alternative', color: '#f43f5e', glow: 'rgba(244,63,94,0.8)',  bonusMult: 0.50 }
};

const COLLECTIBLE_CARDS = [    { id: 'earth-card',     name: 'Terre',                 rarity: 'common',     icon: '', imgPath: 'images/cards/collection/earth-card.webp' },    { id: 'moon-card',      name: 'Lune',                  rarity: 'common',     icon: '', imgPath: 'images/cards/collection/moon-card.webp' },    { id: 'mars-card',      name: 'Mars',                  rarity: 'common',     icon: '', imgPath: 'images/cards/collection/mars-card.webp' },    { id: 'wrench-card',    name: 'Atelier',               rarity: 'common',     icon: '', imgPath: 'images/cards/collection/workshop-card.webp' },    { id: 'factory-card',   name: 'Usine',                 rarity: 'common',     icon: '', imgPath: 'images/cards/collection/factory-card.webp' },    { id: 'mining-card',    name: 'Mine stellaire',        rarity: 'common',     icon: '', imgPath: 'images/cards/collection/stellar-mine-card.webp' },    { id: 'solar-card',     name: 'Centrale solaire',      rarity: 'common',     icon: '', imgPath: 'images/cards/collection/solar-factory-card.webp' },    { id: 'comet-card',     name: 'Comète',                rarity: 'common',     icon: '', imgPath: 'images/cards/collection/comet-card.webp' },    { id: 'neptune-card',   name: 'Neptune',               rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/neptune-card.webp' },    { id: 'pluto-card',     name: 'Pluton',                rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/pluto-card.webp' },    { id: 'proxima-card',   name: 'Proxima Centauri',      rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/proxima-centauri-card.webp' },    { id: 'foundry-card',   name: 'Autofab orbitale',      rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/orbital-autofab-card.webp' },    { id: 'station-card',   name: 'Essaim de sondes',      rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/probe-swarm-card.webp' },    { id: 'quasar-card',    name: 'Moteur à quasar',       rarity: 'rare',       icon: '', imgPath: 'images/cards/collection/quasar-engine-card.webp' },    { id: 'sirius-card',    name: 'Sirius',                rarity: 'epic',       icon: '', imgPath: 'images/cards/collection/sirius-card.webp' },    { id: 'oort-card',      name: "Nuage d'Oort",           rarity: 'epic',       icon: '', imgPath: 'images/cards/collection/oort-cloud-card.webp' },    { id: 'pulsar-card',    name: 'Horloger de pulsar',    rarity: 'epic',       icon: '', imgPath: 'images/cards/collection/pulsar-clock-card.webp' },    { id: 'milkyway-card',  name: 'Centre Voie lactée',  rarity: 'legendary',  icon: '', imgPath: 'images/cards/collection/milky-way-center-card.webp' },    { id: 'missile-card', name: 'Missile',               rarity: 'legendary',  icon: '', imgPath: 'images/cards/collection/missile-card.webp' },    { id: 'andromeda-card', name: 'Andromède',            rarity: 'alternative', icon: '', imgPath: 'images/cards/collection/andromeda-card.webp' }];

const BOOSTERS = {
    standard:  { name: 'Standard',   cardCount: 1, cooldownMs: 5 * 60 * 1000,      rarities: { common: 0.80, rare: 0.18, epic: 0.02 } },
    premium:   { name: 'Premium',    cardCount: 1, cooldownMs: 20 * 60 * 1000,    rarities: { common: 0.50, rare: 0.30, epic: 0.15, legendary: 0.05 } },
    legendary: { name: 'Légendaire', cardCount: 1, cooldownMs: 60 * 60 * 1000,    rarities: { common: 0.20, rare: 0.35, epic: 0.25, legendary: 0.15, alternative: 0.05 } }
};
// Timestamps (Date.now()) de disponibilite de chaque booster : le timer tourne
// jeu ferme (timestamp absolu). Un booster pret ne s'empile pas : son cycle
// ne redemarre qu'a la reclamation. Premiere fois : countdown complet (pose dans init).
let boosterReadyAt = { standard: 0, premium: 0, legendary: 0 };
// Nombre de boosters OUVERTS par type (stat demandee, affichee a cote du timer).
let boostersOpened = { standard: 0, premium: 0, legendary: 0 };
// Les countdowns des boosters ne demarrent qu'au PREMIER deblocage de la
// collection de cartes -- pas des le debut d'une nouvelle partie : le joueur
// qui n'a pas encore acces a la collection ne voit pas ses timers tourner.
// false = jamais demarres (indisponibles) ; true = cycles normaux.
let boosterTimersStarted = false;
function maybeStartBoosterTimers() {
    if (boosterTimersStarted || !areCardsUnlocked()) return;
    boosterTimersStarted = true;
    // Ne pas ecraser des deadlines deja connues d'une sauvegarde anterieure
    // dont le flag manquait (les timers y avaient deja commence a l'init).
    if (boosterReadyAt.standard > 0 || boosterReadyAt.premium > 0 || boosterReadyAt.legendary > 0) return;
    boosterReadyAt = {
        // Premier booster standard PRET des le deblocage : le joueur ouvre
        // la collection et recompense immediatement sa premiere carte.
        standard: Date.now(),
        premium: Date.now() + BOOSTERS.premium.cooldownMs * getBoosterCooldownFactor(),
        legendary: Date.now() + BOOSTERS.legendary.cooldownMs * getBoosterCooldownFactor()
    };
}
function isBoosterReady(type) {
    if (!boosterTimersStarted) return false;
    return Date.now() >= (boosterReadyAt[type] || 0);
}
function getBoosterRemainingMs(type) {
    // Timers pas encore demarres (collection non debloquee) : le countdown
    // complet est montre a titre indicatif, il ne tourne pas encore.
    if (!boosterTimersStarted) return BOOSTERS[type].cooldownMs * getBoosterCooldownFactor();
    return Math.max(0, (boosterReadyAt[type] || 0) - Date.now());
}
function getBoosterCooldownFactor() {
    return Math.max(0.40, 1 - getBoosterTimeDiscount());
}

// ============================================
// ATELIER GALACTIQUE - 23 upgrades uniques en 4 branches
// Ne se reset jamais. Progression meta entre les runs.
// ============================================
const GALACTIC_BRANCHES = [
    // V3.89 (retour proprietaire : 'remplace les emojis des titres des
    // ameliorations galactiques par des images du jeu -- batiments, clic
    // etc... sauf l infini') : les branches ont une IMAGE du jeu en icone
    // (piece pour la production, atelier pour les batiments, carte pour
    // la collection, curseur pour le clic, Lune pour le hors-ligne).
    // L infini garde son symbole (demande explicite).
    { id: 'production',   name: 'Production',    icon: 'images/parts.webp',  color: '#3b82f6' },
    { id: 'rocket',       name: 'B\u00e2timent',       icon: 'images/buildings/workshop.webp', color: '#f59e0b' },
    { id: 'collection',   name: 'Collection',     icon: 'images/cards/collection/earth-card.webp', color: '#ec4899' },
    { id: 'click',        name: 'Clic',            icon: 'images/cursor.svg', color: '#10b981' },
    { id: 'offline',      name: 'Hors-ligne',      icon: 'images/planets/moon.webp', color: '#64748b' },
    { id: 'infinite',     name: 'Infini',          icon: '\u221e',  color: '#8b5cf6' }
];

const GALACTIC_UPGRADES = [
    // === BRANCHE PRODUCTION (8) - un upgrade par planete ===
    { id: 'prod1',  branch: 'production', tier: 1, name: 'R\u00e9acteur \u00e0 fusion',        desc: '+25% production globale.',        baseCost: 1,    costMult: 1.0, maxLevel: 1, effectPerLevel: 0.25 },
    { id: 'prod2',  branch: 'production', tier: 2, name: 'Optimisation \u00e9nerg\u00e9tique',  desc: '+35% production globale.',        baseCost: 2,    costMult: 1.0, maxLevel: 1, effectPerLevel: 0.35, requires: ['prod1'] },
    { id: 'prod3',  branch: 'production', tier: 3, name: 'Surcharge industrielle',   desc: '+45% production globale.',        baseCost: 4,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.45, requires: ['prod2'] },
    { id: 'prod4',  branch: 'production', tier: 4, name: 'Automatisation avanc\u00e9e',    desc: '+55% production globale.',       baseCost: 7,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.55, requires: ['prod3'] },
    { id: 'prod5',  branch: 'production', tier: 5, name: 'Nanotechnologie',          desc: '+65% production globale.',       baseCost: 11,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.65, requires: ['prod4'] },
    { id: 'prod6',  branch: 'production', tier: 6, name: 'Synth\u00e8se de mati\u00e8re noire', desc: '+75% production globale.',      baseCost: 17,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.75, requires: ['prod5'] },
    { id: 'prod7',  branch: 'production', tier: 7, name: 'Singularit\u00e9 technologique', desc: '+85% production globale.',      baseCost: 26, costMult: 1.0, maxLevel: 1, effectPerLevel: 0.85, requires: ['prod6'] },
    { id: 'prod8',  branch: 'production', tier: 8, name: 'Forge stellaire',          desc: '+100% production globale.',       baseCost: 40, costMult: 1.0, maxLevel: 1, effectPerLevel: 1.0, requires: ['prod7'] },

    // === BRANCHE BÂTIMENT (8) - batiments gratuits au demarrage ===
    // Un batiment DIFFERENT a chaque palier : la chaine complete se construit
    // au fil des achats (Atelier, Usine, Mine, Centrale, Autofab, Sondes,
    // Nanoforge, Imprimeur), 1 exemplaire de chaque.
    { id: 'rock1',  branch: 'rocket', tier: 1, name: 'Premier atelier',          desc: '+8 Ateliers gratuits au début de chaque run.',              baseCost: 1,    costMult: 1.0, maxLevel: 1, effectPerLevel: 8, effectBuilding: 'workshop' },
    { id: 'rock2',  branch: 'rocket', tier: 2, name: 'Plans d\u2019usine',           desc: '+7 Usines gratuites au début de chaque run.',                baseCost: 2,    costMult: 1.0, maxLevel: 1, effectPerLevel: 7, effectBuilding: 'factory', requires: ['rock1'] },
    { id: 'rock3',  branch: 'rocket', tier: 3, name: 'Concession mini\u00e8re',      desc: '+6 Mines stellaires gratuites au début de chaque run.',      baseCost: 4,   costMult: 1.0, maxLevel: 1, effectPerLevel: 6, effectBuilding: 'mine', requires: ['rock2'] },
    { id: 'rock4',  branch: 'rocket', tier: 4, name: 'Contrat solaire',          desc: '+5 Centrales solaires gratuites au début de chaque run.',    baseCost: 7,   costMult: 1.0, maxLevel: 1, effectPerLevel: 5, effectBuilding: 'solar', requires: ['rock3'] },
    { id: 'rock5',  branch: 'rocket', tier: 5, name: ' Autofab pr\u00e9fabriqu\u00e9e', desc: '+4 Autofabs orbitales gratuites au début de chaque run.',   baseCost: 11,  costMult: 1.0, maxLevel: 1, effectPerLevel: 4, effectBuilding: 'foundry', requires: ['rock4'] },
    { id: 'rock6',  branch: 'rocket', tier: 6, name: 'Sondes de reconnaissance', desc: '+3 Essaims de sondes gratuits au début de chaque run.',     baseCost: 17,  costMult: 1.0, maxLevel: 1, effectPerLevel: 3, effectBuilding: 'station', requires: ['rock5'] },
    { id: 'rock7',  branch: 'rocket', tier: 7, name: 'Nanoforge de parade',     desc: '+2 Nanoforges gratuites au début de chaque run.',           baseCost: 26,  costMult: 1.0, maxLevel: 1, effectPerLevel: 2, effectBuilding: 'nanoforge', requires: ['rock6'] },
    { id: 'rock8',  branch: 'rocket', tier: 8, name: 'Imprimeur de secours',     desc: '+1 Imprimeur quantique gratuit au début de chaque run.',  baseCost: 40, costMult: 1.0, maxLevel: 1, effectPerLevel: 1, effectBuilding: 'synth', requires: ['rock7'] },
    // === BRANCHE COLLECTION    // === BRANCHE COLLECTION (5) - upgrades uniques ===
    { id: 'coll1',  branch: 'collection', tier: 1, name: 'Carte de commerçant',     desc: '-10% temps d\'attente des boosters.', baseCost: 1,    costMult: 1.0, maxLevel: 1, effectPerLevel: 0.10 },
    { id: 'coll2',  branch: 'collection', tier: 2, name: 'Chance de collection',   desc: '+15% chance de rareté supérieure dans le booster Standard.',  baseCost: 2,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.15, requires: ['coll1'] },
    { id: 'coll3',  branch: 'collection', tier: 3, name: 'Marché noir',           desc: '-10% temps d\'attente des boosters.', baseCost: 4,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.10, requires: ['coll2'] },
    { id: 'coll4',  branch: 'collection', tier: 4, name: 'Boosters renforcés',      desc: '+20% au bonus des cartes possédées.',              baseCost: 7,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.20, requires: ['coll3'] },
    { id: 'coll5',  branch: 'collection', tier: 5, name: 'Réseau de contrebande',  desc: '-15% temps d\'attente des boosters.', baseCost: 12,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.15, requires: ['coll4'] },
    { id: 'coll6',  branch: 'collection', tier: 6, name: 'Album cosmique',          desc: '+1 carte dans tous les boosters.',     baseCost: 19,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1, requires: ['coll5'] },
    { id: 'coll7',  branch: 'collection', tier: 7, name: 'Archives stellaires',      desc: 'Les doublons de cartes comptent double.', baseCost: 29, costMult: 1.0, maxLevel: 1, effectPerLevel: 1, requires: ['coll6'] },
    { id: 'coll8',  branch: 'collection', tier: 8, name: 'Sextant stellaire',         desc: 'La chance de rareté supérieure s’applique à tous les boosters.', baseCost: 45, costMult: 1.0, maxLevel: 1, effectPerLevel: 1, requires: ['coll7'] },

    // === BRANCHE CLIC (5) - upgrades uniques ===
    { id: 'click1', branch: 'click', tier: 1, name: 'Gants renforc\u00e9s',      desc: 'x1.5 puissance de clic.',              baseCost: 1,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1.5 },
    { id: 'click2', branch: 'click', tier: 2, name: 'Frappe critique',       desc: '+2.5% chance de coup critique (x3).',   baseCost: 2,   costMult: 1.0, maxLevel: 1, effectPerLevel: 0.025, requires: ['click1'] },
    { id: 'click3', branch: 'click', tier: 3, name: 'Main cybern\u00e9tique',     desc: 'x1.75 puissance de clic.',             baseCost: 4,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1.75, requires: ['click2'] },
    { id: 'click4', branch: 'click', tier: 4, name: 'Surcharge neuronale',    desc: '+10% chance de coup critique (x3).',    baseCost: 7,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.10, requires: ['click3'] },
    { id: 'click5', branch: 'click', tier: 5, name: 'Main de l\'univers',      desc: 'x2 puissance de clic.',                baseCost: 12, costMult: 1.0, maxLevel: 1, effectPerLevel: 2, requires: ['click4'] },
    { id: 'click6', branch: 'click', tier: 6, name: 'Appel cosmique',         desc: '5% de chance de d\u00e9clencher une com\u00e8te \u00e0 chaque clic.', baseCost: 19, costMult: 1.0, maxLevel: 1, effectPerLevel: 0.05, requires: ['click5'] },
    { id: 'click7', branch: 'click', tier: 7, name: 'Horizon des \u00e9v\u00e9nements', desc: 'x2.5 puissance de clic.',            baseCost: 29, costMult: 1.0, maxLevel: 1, effectPerLevel: 2.5, requires: ['click6'] },
    { id: 'click8', branch: 'click', tier: 8, name: 'Cœur de supernova',       desc: 'Les coups critiques passent de x3 à x5.', baseCost: 45, costMult: 1.0, maxLevel: 1, effectPerLevel: 1, requires: ['click7'] },
    // === BRANCHE HORS-LIGNE (8) - production pendant l'absence ===
    // 5min gratuit (BASE_OFFLINE_CAP_HOURS), puis 8 paliers de 10min a 6h.
    // Les derniers sont extremement chers : vises pour les chasseurs de records.
    { id: 'off1', branch: 'offline', tier: 1, name: 'Pilote automatique',    desc: "Production continue jusqu'à 10min après fermeture du jeu.",  baseCost: 1,     costMult: 1.0, maxLevel: 1, effectPerLevel: 10/60, requires: undefined },
    { id: 'off2', branch: 'offline', tier: 2, name: 'Drone de maintenance',   desc: "Production continue jusqu'à 15min après fermeture du jeu.",  baseCost: 2,     costMult: 1.0, maxLevel: 1, effectPerLevel: 15/60, requires: ['off1'] },
    { id: 'off3', branch: 'offline', tier: 3, name: 'IA de bord',             desc: "Production continue jusqu'à 20min après fermeture du jeu.",  baseCost: 3,     costMult: 1.0, maxLevel: 1, effectPerLevel: 20/60, requires: ['off2'] },
    { id: 'off4', branch: 'offline', tier: 4, name: 'Colonie autonome',       desc: "Production continue jusqu'à 25min après fermeture du jeu.",  baseCost: 5,    costMult: 1.0, maxLevel: 1, effectPerLevel: 25/60, requires: ['off3'] },
    { id: 'off5', branch: 'offline', tier: 5, name: 'Civilisation robotisée',  desc: "Production continue jusqu'à 30min après fermeture du jeu.",  baseCost: 8,    costMult: 1.0, maxLevel: 1, effectPerLevel: 30/60, requires: ['off4'] },
    { id: 'off6', branch: 'offline', tier: 6, name: 'Flotte autonome',         desc: "Production continue jusqu'à 1h après fermeture du jeu.",     baseCost: 13,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1,     requires: ['off5'] },
    { id: 'off7', branch: 'offline', tier: 7, name: 'Essaim de drones',        desc: "Production continue jusqu'à 2h après fermeture du jeu.",     baseCost: 21,   costMult: 1.0, maxLevel: 1, effectPerLevel: 2,     requires: ['off6'] },
    { id: 'off8', branch: 'offline', tier: 8, name: 'Empire intersidéral',   desc: "Production continue jusqu'à 6h après fermeture du jeu.",     baseCost: 34,  costMult: 1.0, maxLevel: 1, effectPerLevel: 6,     requires: ['off7'] },
    // === BRANCHE INFINI (V3) - debloquee a l'Amas de Virgo ===
    // 16 upgrades UNIQUES et puissantes, orientees records et confort de fin
    // de partie. La croissance infinie est portee par le +1%/PE automatique
    // (postVirgoStardust) -- l'atelier vend les OUTILS du chasseur de records.
    // Total ~100 000 PE : essentiel en ~10 cycles post-Virgo.
    { id: 'inf-fav',   branch: 'infinite', order: 4, tier: 1,  name: 'B\u00e2timent favori',        desc: 'Choisis un b\u00e2timent favori : il gagne +1% de production par seconde de jeu jou\u00e9e (jamais hors-ligne).', baseCost: 4000, costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-herit', branch: 'infinite', order: 10, tier: 2,  name: 'H\u00e9ritage industriel',    desc: 'Les b\u00e2timents pionniers rattrapent une fraction de la production des plus r\u00e9cents (power-law, jusqu\u2019\u00e0 x780 M pour l\u2019Atelier) \u2014 sans jamais les d\u00e9passer.', baseCost: 250000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-auto1', branch: 'infinite', order: 2, tier: 3,  name: 'Auto-Atelier I',           desc: 'Ach\u00e8te automatiquement le b\u00e2timent le moins cher d\u00e8s que tu peux le payer.', baseCost: 1000,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-auto2', branch: 'infinite', order: 12, tier: 4,  name: 'Auto-Atelier II',          desc: 'Ach\u00e8te automatiquement au meilleur ratio gain/prix.', baseCost: 1000000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1, requires: ['inf-auto1'] },
    { id: 'inf-parts', branch: 'infinite', order: 6, tier: 5,  name: 'Auto-Pi\u00e8ces',              desc: 'Ach\u00e8te automatiquement les pi\u00e8ces de fus\u00e9e d\u00e8s que tu peux les payer.', baseCost: 15000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-comet', branch: 'infinite', order: 7, tier: 6,  name: 'Com\u00e8te dor\u00e9e',           desc: 'x2 sur les gains instantan\u00e9s des com\u00e8tes intercept\u00e9es.', baseCost: 30000,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-sky',   branch: 'infinite', order: 5, tier: 7,  name: 'Ciel fr\u00e9quent\u00e9',        desc: '10% de chances d\u2019avoir une 2e com\u00e8te simultan\u00e9e \u00e0 l\u2019\u00e9cran (dor\u00e9e).', baseCost: 8000,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-choice',branch: 'infinite', order: 8, tier: 8,  name: 'Choix de r\u00e9compense',     desc: 'Neutre : 50/50 Parts ou x2. Choisis Parts (+15%) ou x2 production (+15%) -- le hasard reste, changeable \u00e0 tout moment.', baseCost: 60000,   costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-surs1', branch: 'infinite', order: 9, tier: 9,  name: 'Sursaut prolong\u00e9 I',      desc: '+10% de dur\u00e9e sur les bonus temporaires.', baseCost: 120000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.10 },
    { id: 'inf-surs2', branch: 'infinite', order: 15, tier: 10, name: 'Sursaut prolong\u00e9 II',     desc: '+10% de dur\u00e9e suppl\u00e9mentaires (cumul\u00e9s ~+20%).', baseCost: 4100000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 0.10, requires: ['inf-surs1'] },
    { id: 'inf-eclip', branch: 'infinite', order: 16, tier: 11, name: '\u00c9clipse totale',           desc: '+25% de fr\u00e9quence pour les com\u00e8tes isol\u00e9es ET les pluies de com\u00e8tes.', baseCost: 5000000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-crit',  branch: 'infinite', order: 13, tier: 12, name: 'Main c\u00e9leste',            desc: 'Les coups critiques passent de x3 \u00e0 x5.', baseCost: 2000000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-call',  branch: 'infinite', order: 11, tier: 13, name: 'Appel cosmique II',        desc: '10% de chance de d\u00e9clencher une com\u00e8te \u00e0 chaque clic.', baseCost: 500000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-market',branch: 'infinite', order: 14, tier: 14, name: 'March\u00e9 aux cartes',       desc: 'Les doublons de cartes des boosters sont convertis en grosse r\u00e9compense de Parts.', baseCost: 3200000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    { id: 'inf-chrono',branch: 'infinite', order: 1, tier: 15, name: 'Chronom\u00e8tre stellaire',     desc: 'Affiche le temps restant avant la prochaine plan\u00e8te et avant le doublement de ton record.', baseCost: 500,    costMult: 1.0, maxLevel: 1, effectPerLevel: 1 },
    // V3.9 : ENDGAME -- quand toutes les upgrades infinies sont achetees, le
    // Renforcement cosmique (REPETABLE, niveau infini) offre un puits de PE :
    // +5% de production permanente par niveau, cout doublant a chaque achat.
    // Debloque seulement apres les 16 autres (requires les toutes ? non --
    // verrou conditionnel ci-dessous pour rester lisible).
    { id: 'inf-boost', branch: 'infinite', tier: 17, name: 'Renforcement cosmique',   desc: '+20% de production permanente par niveau. Le prix double a chaque achat.', baseCost: 1000, costMult: 2.0, maxLevel: Infinity, effectPerLevel: 0.20 },
    { id: 'inf-radar', branch: 'infinite', order: 3, tier: 16, name: 'Radar de pilote',          desc: 'Affiche le pilote juste au-dessus de toi au classement (distance record) et le temps estim\u00e9 pour le d\u00e9passer.', baseCost: 2000,  costMult: 1.0, maxLevel: 1, effectPerLevel: 1 }];

let galacticUpgrades = {};

let cardCollection = {};

function openCardCollection() {
    if (!areCardsUnlocked()) {
        showToast('\uD83D\uDD12 ' + tf('Debloque {count} types de batiments pour la collection', { count: CARD_COLLECTION_UNLOCK_BUILDING_TYPES }));
        return;
    }
    showExclusiveModal('card-collection-modal', () => {
        updateCardCollectionDisplay();
        showCardShop();
    });
}

function closeCardCollection() {
    document.getElementById('card-collection-modal').classList.remove('active');
}

function showCardShop() {
    document.getElementById('cc-booster-screen').style.display = 'block';
    document.getElementById('cc-reveal-screen').style.display = 'none';
    document.getElementById('cc-album-screen').style.display = 'none';
    document.getElementById('cc-back-btn').style.display = 'none';
    updateBoosterPrices();
}

function showCardAlbum() {
    document.getElementById('cc-booster-screen').style.display = 'none';
    document.getElementById('cc-reveal-screen').style.display = 'none';
    document.getElementById('cc-album-screen').style.display = 'block';
    document.getElementById('cc-back-btn').style.display = 'inline-flex';
    renderCardAlbum();
}

function showCardReveal() {
    document.getElementById('cc-booster-screen').style.display = 'none';
    document.getElementById('cc-reveal-screen').style.display = 'flex';
    document.getElementById('cc-album-screen').style.display = 'none';
    document.getElementById('cc-back-btn').style.display = 'inline-flex';
}

function updateBoosterPrices() {
    updateBoosterTimers();
    updateBoosterOdds();
}

// Affiche les VRAIES probabilites de chaque booster, ajustees par les
// upgrades galactiques (Chance de collection + Sextant stellaire) --
// avant, les pourcentages affiches etaient statiques et faux des qu'un
// upgrade de rarete etait achete.
function updateBoosterOdds() {
    for (const key in BOOSTERS) {
        const btn = document.querySelector('.cc-booster-btn[data-booster="' + key + '"]');
        if (!btn) continue;
        const infoEl = btn.querySelector('.cc-booster-info');
        if (!infoEl) continue;
        const rarities = BOOSTERS[key].rarities;
        const isStandard = key === 'standard';
        let boost = getRarityBoost();
        if (getGalacticUpgradeLevel('coll8') === 0) {
            boost = isStandard ? boost : 0;
        }
        const order = Object.keys(rarities);
        const adjusted = {};
        let total = 0;
        for (const r of order) { adjusted[r] = rarities[r]; total += rarities[r]; }
        if (boost > 0) {
            const boosted = adjusted['common'] * boost;
            adjusted['common'] -= boosted;
            for (let i = 1; i < order.length; i++) {
                adjusted[order[i]] += boosted / (order.length - 1);
            }
        }
        const names = { common: t('commune'), rare: t('rare'), epic: t('épique'), legendary: t('légendaire'), alternative: t('alternative') };
        const parts = order.map(r => Math.round((adjusted[r] / total) * 100) + '% ' + names[r]);
        const nCards = BOOSTERS[key].cardCount + getGalacticUpgradeLevel('coll6');
        infoEl.textContent = nCards + (nCards > 1 ? ' cartes — ' : ' carte — ') + parts.join(' / ');
    }
}
function updateBoosterTimers() {
    for (const key in BOOSTERS) {
        const el = document.getElementById('cc-cost-' + key);
        if (!el) continue;
        const btn = el.closest('.cc-booster-btn');
        // Stat demandee : nombre de boosters DEJA OUVERTS, a cote du timer.
        let openedBadge = btn.querySelector('.cc-booster-opened');
        if (!openedBadge) {
            openedBadge = document.createElement('div');
            openedBadge.className = 'cc-booster-opened';
            btn.appendChild(openedBadge);
        }
        openedBadge.textContent = '\u{1F381} ' + t('Ouverts') + ' : ' + (boostersOpened[key] || 0);
        if (isBoosterReady(key)) {
            el.textContent = t('Prêt !');
            if (btn) btn.disabled = false;
        } else {
            el.textContent = '\u23f3 ' + formatContractTime(getBoosterRemainingMs(key));
            if (btn) btn.disabled = true;
        }
    }
}

function updateCardCollectionDisplay() {
    const collected = Object.keys(cardCollection).filter(id => cardCollection[id] > 0);
    document.getElementById('cc-collected-count').textContent = collected.length;
    document.getElementById('cc-total-count').textContent = COLLECTIBLE_CARDS.length;
    document.getElementById('cc-bonus-display').textContent = formatBonusPct(getCollectionMultiplier());
    // Cartes TOTALES possedees, doublons comptes : somme des exemplaires.
    const totalAll = Object.values(cardCollection).reduce((a, b) => a + (b || 0), 0);
    const totalAllEl = document.getElementById('cc-cards-total-all');
    if (totalAllEl) totalAllEl.textContent = totalAll;
}

function isCollectionComplete() {
    return COLLECTIBLE_CARDS.every(c => cardCollection[c.id] > 0);
}

function getCollectionBonus() {
    // Les doublons s'additionnent : chaque exemplaire d'une carte ajoute
    // son bonus (bonus par carte reduits en consequence, minimum 1%).
    let bonus = 0;
    const dbl = getGalacticUpgradeLevel('coll7') > 0;
    for (const card of COLLECTIBLE_CARDS) {
        const count = cardCollection[card.id] || 0;
        if (count > 0) {
            bonus += wasmCardBonusMult(card.rarity) * count * (dbl ? 2 : 1);
        }
    }
    if (isCollectionComplete()) {
        bonus += (wasmCore() ? (wasmCore().collection_complete_bonus ? wasmCore().collection_complete_bonus() : 0.20) : 0.20);
    }
    return bonus;
}

// Bonus du bâtiment favori (V3) : +1% par seconde de jeu jouée, compose
// au fil du temps. Appliqué UNIQUEMENT au bâtiment favori choisi.
function getFavoriteBuildingBonus(buildingId) {
    if (!favoriteBuildingId || buildingId !== favoriteBuildingId || favoriteBuildingSeconds <= 0) return 1;
    return 1 + wasmConst('favorite_per_second_percent', 0.01) * favoriteBuildingSeconds;
}

// Héritage industriel (V3) : les bâtiments anciens rattrapent leur retard.
// Chaque bâtiment gagne un bonus proportionnel a l'ecart entre SON ratio
// gain-effectif/prix unitaire et celui du meilleur bâtiment actuel --
// recalculé a chaque appel, donc jamais périmé. Le meilleur bâtiment ne
// gagne rien, les plus désuets jusqu'à x3.
// V3.41 (retour joueur : 'l'héritage industriel n'est pas bien fait, la c'est
// cassé') : REFONTE COMPLETE -- l'ancien partage LITTERAL de la production du
// MEILLEUR bâtiment (20% de son total pour l'Atelier...) avait deux defauts
// mortels : (1) le bonus dependait des COMPTE du meilleur (avec l'auto-buy,
// quelques achats de Trou noir faisaient varier l'héritage de tous les
// anciens a chaque tick -- et le % de prod totale des tooltips, calculé sur
// un snapshot figé 100 ms avant, divergeait du gain réaffiché : le % était
// bugé, retour joueur) ; (2) le partage par total rendait l'Atelier (des
// MILLIONS d'unités avec l'auto-buy) le bâtiment le plus puissant d'un coup.
// V3.41bis (choix joueur : 'ce n'est pas assez fort' -- l'ecart nominal
// Atelier/Trou noir est de 2,9e10 en gain unitaire, un x5 etait 10 ordres
// de grandeur trop faible) : POWER-LAW D'ANCIENNETE. Le multiplicateur de
// chaque batiment vaut (gain du MEILLEUR / gain du batiment)^alpha avec
// alpha = 0.85 (constante WASM heritage_alpha) : l'ancien rattrape une
// FRACTION de l'ecart de production avec le meilleur, jamais 100% -- le
// gain equivalent par unite (gain x heritage) reste STRICTEMENT CROISSANT
// de l'ancien au meilleur (alpha < 1), la hierarchie est garantis
// mathematiquement : l'Atelier equivaut ~4-5% d'une unite de Trou noir,
// il ne peut JAMAIS la depasser. Le bonus ne depend QUE des gains NOMINAUX
// (jamais des comptes ni des achats) : deterministe, le % du tooltip reste
// coherent. Avec l'auto-buy (des millions d'Ateliers contre quelques
// Trous noirs), les anciens retrouvent quelques % de la prod totale.
function getHeritageBonus(buildingId) {
    if (getGalacticUpgradeLevel('inf-herit') === 0) return 1;
    const b = findBuildingByIdFast(buildingId);
    if (!b || !(b.gain > 0)) return 1;
    const best = BUILDINGS[BUILDINGS.length - 1];
    if (!best || !(best.gain > 0) || best.id === buildingId) return 1;
    const alpha = wasmConst('heritage_alpha', 0.85);
    // Gains nominaux via le WASM (source de verite -- patcher building.gain
    // en console n'a aucun effet) ; power-law borne a 1 pour le meilleur.
    const bestGain = wasmBuildingGain(best.id);
    const myGain = wasmBuildingGain(buildingId);
    if (!(myGain > 0) || !(bestGain > myGain)) return 1;
    return Math.pow(bestGain / myGain, alpha);
}
// Gain unitaire du meilleur batiment SANS heritage/favori -- plus utilise
// depuis la refonte V3.41 de l'heritage (multiplicateur d'anciennete),
// supprime avec l'ancien modele de partage.

function getCollectionMultiplier() {
    return 1 + getCollectionBonus() * (1 + getCollectionUpgradeBonus());
}

function buyBooster(type) {
    const booster = BOOSTERS[type];
    if (!booster) return;
    if (!isBoosterReady(type)) {
        showToast('\u23f3 ' + tf('Booster disponible dans {time} !', { time: formatContractTime(getBoosterRemainingMs(type)) }));
        return;
    }
    // Le cycle redemarre SEULEMENT a la reclamation : pas d'empilement,
    // un booster pret reste pret indefinement jusqu'a ouverture.
    boosterReadyAt[type] = Date.now() + booster.cooldownMs * getBoosterCooldownFactor();
    boostersOpened[type] = (boostersOpened[type] || 0) + 1;
    boosterReadyNotified[type] = false;
    Sounds.booster();
    updateBoosterTimers();

    const drawn = [];
    let cardCount = booster.cardCount;
    cardCount += getGalacticUpgradeLevel('coll6');
    for (let i = 0; i < cardCount; i++) {
        drawn.push(drawCard(booster.rarities));
    }

    // Badge "NOUVELLE !" : decision prise AVANT l'increment de la
    // collection. renderRevealCards est appele APRES la mise a jour et
    // testait (cardCollection[card.id] || 0) <= 1 -- le 2e exemplaire
    // (count=2) n'etait jamais marque alors qu'une carte possedee 1 fois
    // avant le tirage pouvait l'etre. La nouveaute appartient au tirage,
    // pas a l'etat post-increment.
    const isNewByCard = new Map();
    drawn.forEach(card => {
        if (!isNewByCard.has(card.id)) {
            isNewByCard.set(card.id, (cardCollection[card.id] || 0) === 0);
        }
    });

    let marketTotal = 0;
    // V3.49 (retour joueur) : gain PROPORTIONNEL A LA RARETE du doublon --
    // un doublon commun valait autant qu'un legendaire. Bareme :
    // common x50, rare x150, epic x400, legendary x1200, alternative x2500
    // (multiplicateurs de pps ; l'ancien fixe x100 etait independent de la
    // carte). Garde-fou : seules les cartes EXISTANTES comptent (une carte
    // possedee fantome -- id retire du jeu -- ne rendait chaque tirage
    // 'doublon' fictif, retour joueur : 'des gains alors que je n'avais pas
    // les cartes').
    // V3.50 (retour joueur : 'divise par 5 les gains en pps') : bareme
    // divise par 5 -- commune x10, rare x30, epique x80, legendaire x240,
    // alternative x500 (multiplicateurs de pps par doublon).
    const MARKET_RARITY_MULT = { common: 10, rare: 30, epic: 80, legendary: 240, alternative: 500 };
    const knownIds = new Set(COLLECTIBLE_CARDS.map(c => c.id));
    for (const card of drawn) {
        const wasDuplicate = knownIds.has(card.id) && (cardCollection[card.id] || 0) > 0;
        cardCollection[card.id] = (cardCollection[card.id] || 0) + 1;
        // Marché aux cartes (V3, inf-market) : chaque doublon est converti
        // en récompense de Parts proportionnelle a sa rareté.
        if (wasDuplicate && getGalacticUpgradeLevel('inf-market') > 0 && partsPerSecond > 0) {
            marketTotal += partsPerSecond * (MARKET_RARITY_MULT[card.rarity] || 50);
        }
        invalidateBuildingGainsCache();
    }
    if (marketTotal > 0) {
        score += marketTotal;
        partsSinceLaunch += marketTotal;
        trackPartsEarned(marketTotal);
        // V3.44 : le total du marche vit AUSSI dans le recap de revelation
        // (ligne persistante) -- le toast seul etait ephemerE (3 s) et la
        // pile de toasts plafonnee a 3 : en ouvrant plusieurs boosters
        // d'affilee, les toasts s'ecrasaient et le joueur croyait que
        // l'upgrade ne marchait que sur le premier (retour joueur). Le
        // credit etait bien passe a CHAQUE booster -- c'est l'affichage
        // qui manquait.
        // V3.49 : PLUS DE TOAST -- l'unique affichage est la ligne du recap
        // de revelation ('doublons convertis'), au-dessus des cartes (retour
        // joueur : 'une seule ligne au-dessus des cartes' ; le toast suivi
        // de la ligne donnait l'impression d'un DOUBLE credit).
        lastMarketTotal = marketTotal;
    } else {
        lastMarketTotal = 0;
    }

    renderRevealCards(drawn, isNewByCard);
    showCardReveal();
    updateCardCollectionDisplay();
    saveGame();
}

function drawCard(rarities) {
    // coll8 (Sextant stellaire) : sans lui, le boost de rarete ne
    // s'applique qu'au booster Standard ; avec lui, a TOUS les boosters.
    const isStandard = !rarities.alternative && (rarities.epic || 0) <= 0.15 && !rarities.legendary;
    let boost = getRarityBoost();
    if (getGalacticUpgradeLevel('coll8') === 0) {
        boost = isStandard ? boost : 0;
    }
    const adjusted = {};
    let total = 0;
    const order = Object.keys(rarities);
    for (const r of order) { adjusted[r] = rarities[r]; total += rarities[r]; }
    if (boost > 0) {
        const boosted = adjusted['common'] * boost;
        adjusted['common'] -= boosted;
        for (let i = 1; i < order.length; i++) {
            adjusted[order[i]] += boosted / (order.length - 1);
        }
    }
    const roll = Math.random() * total;
    let cumul = 0;
    let chosenRarity = 'common';
    for (const rarity of order) {
        cumul += adjusted[rarity];
        if (roll < cumul) { chosenRarity = rarity; break; }
    }
    const pool = COLLECTIBLE_CARDS.filter(c => c.rarity === chosenRarity);
    if (pool.length === 0) {
        const fallback = COLLECTIBLE_CARDS.filter(c => c.rarity === 'common');
        return fallback[Math.floor(Math.random() * fallback.length)];
    }
    return pool[Math.floor(Math.random() * pool.length)];
}

// V3.44 : total MarchE aux cartes du DERNIER booster ouvert -- affiche dans
// le recap de revelation (persistant, contrairement au toast de 3 s).
let lastMarketTotal = 0;
function renderRevealCards(cards, isNewByCard) {
    const container = document.getElementById('cc-reveal-cards');
    container.innerHTML = '';
    // Masquer le titre du recap pendant la revelation sequentielle :
    // il n'apparait qu'avec le bilan final.
    const prevTitle = document.getElementById('cc-reveal-summary-title');
    if (prevTitle) prevTitle.style.display = 'none';
    const intro = document.getElementById('cc-reveal-intro');
    if (intro) {
        intro.textContent = cards.length > 1
            ? tf('Retourne les cartes ({n})', { n: cards.length })
            : t('Carte obtenue');
        intro.style.display = '';
    }
    container.style.setProperty('--card-count', cards.length);
    document.getElementById('cc-reveal-shop-btn').style.display = 'none';
    document.getElementById('cc-reveal-album-btn').style.display = 'none';
    const total = cards.length;
    let revealed = 0;
    const checkAllRevealed = function () {
        if (revealed >= total) {
            document.getElementById('cc-reveal-shop-btn').style.display = 'inline-flex';
            document.getElementById('cc-reveal-album-btn').style.display = 'inline-flex';
        }
    };

    // Paquet sequential : une seule carte visible a la fois, comme un
    // vrai booster. Le joueur retourne la carte, la decouvre un instant,
    // puis elle s'envole et la suivante arrive a sa place.
    let idx = 0;
    const revealedCards = [];
    const showSummary = function () {
        container.innerHTML = '';
        // Titre du recap AU-DESSUS des cartes : insere avant le
        // conteneur flex (frere precedent), les cartes centrees
        // en dessous. Distingue le bilan de la carte retournee
        // juste avant -- c'etait la confusion "2 cartes ?".
        let title = document.getElementById('cc-reveal-summary-title');
        if (!title) {
            title = document.createElement('div');
            title.id = 'cc-reveal-summary-title';
            title.className = 'cc-reveal-summary-title';
            container.parentElement.insertBefore(title, container);
        }
        title.textContent = cards.length > 1
            ? tf('Cartes obtenues ({n})', { n: cards.length })
            : t('Carte obtenue');
        // V3.44 : recap du MarchE aux cartes -- DOUBLONS convertis, total
        // persistant sous le titre : le joueur voit la conversion meme en
        // ouvrant plusieurs boosters d'affilee.
        // V3.50 : la ligne du MARCHE est par BOOSTER et disparait avec lui
        // -- l'ancienne ligne restait collee quand un nouveau booster etait
        // ouvert (retour joueur) ; on purge toute ligne existante avant
        // d'en poser une nouvelle (et seulement si CE booster a eu des
        // doublons).
        container.parentElement.querySelectorAll('.cc-reveal-market').forEach(el => el.remove());
        if (lastMarketTotal > 0) {
            const marketLine = document.createElement('div');
            marketLine.className = 'cc-reveal-market';
            marketLine.innerHTML = '<img src="images/Stardust.webp" alt="" class="control-icon-stardust"> ' + t('March\u00e9 aux cartes') + ' : +' + formatNumber(lastMarketTotal) + ' ' + t('Parts') + ' (' + t('doublons convertis') + ')';
            title.insertAdjacentElement('afterend', marketLine);
        }
        title.style.display = '';
        const summaryIntro = document.getElementById('cc-reveal-intro');
        if (summaryIntro) summaryIntro.style.display = 'none';
        revealedCards.forEach(function (rc, i) {
            const el = document.createElement('div');
            el.className = 'cc-reveal-card summary rarity-' + rc.card.rarity;
            el.style.animationDelay = (i * 0.08) + 's';
            el.innerHTML =
                '<div class="cc-reveal-inner flipped">' +
                    '<div class="cc-reveal-front"><img src="images/cards/backs/card-back.webp" class="cc-card-img" alt="Dos de carte"></div>' +
                    '<div class="cc-reveal-back">' +
                        '<img src="' + rc.card.imgPath + '" class="cc-card-img" alt="' + rc.card.name + '">' +
                        (rc.isNew ? '<div class="cc-card-new">' + t('NOUVELLE !') + '</div>' : '') +
                    '</div>' +
                '</div>';
            container.appendChild(el);
        });
        checkAllRevealed();
    };
    const showCard = function () {
        if (idx >= total) { showSummary(); return; }
        const card = cards[idx];
        // Nouveaute decidee au TIRAGE (buyBooster, avant increment) :
        // isNewByCard est fourni par l'appelant ; fallback historique si
        // un ancien appel ne passe pas la map.
        const isNew = isNewByCard ? (isNewByCard.get(card.id) === true) : (cardCollection[card.id] || 0) <= 1;
        const el = document.createElement('div');
        // Les cartes suivantes arrivent deja retournees (face visible), comme
        // si le booster montrait la carte gagnee avant de passer a la suivante.
        el.className = 'cc-reveal-card pack rarity-' + card.rarity + (idx > 0 ? ' flipped' : '');
        el.innerHTML =
            '<div class="cc-reveal-inner">' +
                '<div class="cc-reveal-front"><img src="images/cards/backs/card-back.webp" class="cc-card-img" alt="Dos de carte"></div>' +
                '<div class="cc-reveal-back">' +
                    '<img src="' + card.imgPath + '" class="cc-card-img" alt="' + card.name + '">' +
                    (isNew ? '<div class="cc-card-new">' + t('NOUVELLE !') + '</div>' : '') +
                '</div>' +
            '</div>';
        let discovered = false;
        // Les cartes suivantes (idx > 0) arrivent deja retournees : leur
        // accord de revelation est joue des l'arrivee, pas au clic -- sinon
        // seule la premiere carte du booster avait un son.
        if (idx > 0) {
            Sounds.cardFlip(card.rarity);
            discovered = true;
            revealed++;
            revealedCards.push({ card, isNew });
        }
        el.addEventListener('click', function () {
            if (!discovered) {
                // Premier clic : retourner la carte, elle reste affichee.
                // L'accord de revelation est joue ICI et sa couleur depend
                // de la rarete de la carte.
                discovered = true;
                const wasFlipped = el.classList.contains('flipped');
                if (!wasFlipped) Sounds.cardFlip(card.rarity);
                if (!wasFlipped) el.classList.add('flipped');
                revealed++;
                revealedCards.push({ card, isNew });
                return;
            }
            // Second clic : elle s'envole et la suivante arrive (ou le recap)
            el.classList.add('pack-out');
            setTimeout(function () {
                el.remove();
                idx++;
                showCard();
            }, 320);
        });
        container.appendChild(el);
    };
    showCard();
}

function renderCardAlbum() {
    const grid = document.getElementById('cc-album-grid');
    grid.innerHTML = '';

    const complete = isCollectionComplete();
    if (complete) {
        const banner = document.createElement('div');
        banner.className = 'cc-set-complete';
        banner.textContent = t('Collection complète ! +20% prod');
        grid.appendChild(banner);
    }
    COLLECTIBLE_CARDS.forEach(card => {
        const owned = cardCollection[card.id] > 0;
        const el = document.createElement('div');
        el.className = 'cc-album-card' + (owned ? '' : ' locked') + ' rarity-' + card.rarity;
        el.innerHTML =
            (owned
                ? '<img src="' + card.imgPath + '" class="cc-card-img" alt="' + card.name + '"><div class="cc-card-count">\u00d7' + cardCollection[card.id] + '</div>'
                : '<div class="cc-card-icon">?</div>');
        if (owned) {
            el.addEventListener('click', function () { openCardLightbox(card); });
        }
        grid.appendChild(el);
    });
}

function openCardLightbox(card) {
    const lightbox = document.getElementById('cc-lightbox');
    const img = document.getElementById('cc-lightbox-img');
    img.src = card.imgPath;
    img.alt = card.name;
    document.getElementById('cc-lightbox-name').textContent = t(card.name);
    const rarity = CARD_RARITIES[card.rarity];
    const perCopy = Math.round(CARD_RARITIES[card.rarity].bonusMult * 100);
    const count = cardCollection[card.id] || 0;
    const total = perCopy * count;
    document.getElementById('cc-lightbox-sub').textContent = t(rarity.name) + ' \u00b7 +' + perCopy + '% ' + t('production') + ' \u00d7' + count + ' = +' + total + '%';
    document.getElementById('cc-lightbox-name').style.color = rarity.color;
    lightbox.classList.add('open');
    lightbox.dataset.cardId = card.id;
}

function closeCardLightbox() {
    const lightbox = document.getElementById('cc-lightbox');
    lightbox.classList.remove('open');
    lightbox.dataset.cardId = '';
}

// ============================================
// MOBILE / RESPONSIVE
// ============================================
// Vue active sur mobile : 'center' (fusée), 'right' (bâtiments), 'left' (espace)
let mobileActiveView = 'center';
// Arriere-plan mobile : heure de gel de la production (visibilitychange).
// 0 = jeu actif ; >0 = page masquee, la boucle de jeu est figee et le
// temps d'absence sera credite au retour via applyOfflineEarnings
// (systeme hors-ligne PLAFONNE -- jamais de production illimitee).
let mobileBackgroundFrozenAt = 0;
// Desktop : heure de masquage de l'onglet (0 = visible). Sert au credit
// hors-ligne de la duree REELLE d'absence au retour (gameLoop est figee
// pendant le masquage, sinon le throttling navigateur creditait minute par
// minute et le pop-up "Bon retour" n'affichait jamais que ~1 minute).
let desktopHiddenAt = 0;

function isMobileLayout() {
    return window.matchMedia('(max-width: 1024px) and (pointer: coarse)').matches;
}

// ===== BADGE DE DIAGNOSTIC =====
// Petit indicateur discret en bas a droite du jeu : clique dessus pour
// voir ce que le jeu detecte (layout, pointer, viewport, version SW).
// Sert a diagnostiquer a l'ecran, sans console F12, les cas ou le PC est
// mal classe "mobile/tablette" (ecran tactile, zoom Windows, etc.).
function initLayoutDebugBadge() {
    const badge = document.createElement('div');
    badge.id = 'layout-debug-badge';
    badge.textContent = 'i';
    badge.title = 'Infos de detection';
    badge.onclick = function () {
        const mq = window.matchMedia('(max-width: 1024px) and (pointer: coarse)');
        const coarse = window.matchMedia('(pointer: coarse)').matches;
        const fine = window.matchMedia('(pointer: fine)').matches;
        const info =
            'Layout mobile : ' + (mq.matches ? 'OUI' : 'non') + '\n' +
            'Pointer coarse : ' + (coarse ? 'OUI' : 'non') + '\n' +
            'Pointer fine : ' + (fine ? 'OUI' : 'non') + '\n' +
            'Viewport : ' + window.innerWidth + ' x ' + window.innerHeight + '\n' +
            'DPR : ' + window.devicePixelRatio + '\n' +
            'Version du jeu : ' + (window.APP_CACHE_VERSION || 'inconnue');
        alert(info);
    };
    document.body.appendChild(badge);
}

function closeAllModalsForMobileNav() {
    document.querySelectorAll('.modal.active').forEach(m => {
        if (m.classList.contains('post-travel')) return;
        // La modale du nom d'entreprise est NON FERMABLE : elle doit survivre
        // a la navigation entre onglets (sinon le joueur pouvait y echapper
        // en changeant de page, et la saisie etait perdue).
        if (m.id === 'company-required-modal') return;
        m.classList.remove('active');
    });
}

function setMobileView(view) {
    mobileActiveView = view;
    const grid = document.querySelector('.main-grid');
    const nav = document.getElementById('mobile-nav');
    if (!grid) return;
    // Panneau central masque : les animations de pluie de pieces sont figees
    // par display:none et s'accumulent. On purge et suspend la pluie.
    if (typeof partsRain !== 'undefined' && partsRain) {
        if (view === 'center') {
            partsRain.suspended = false;
            resizeRainCanvas();
        } else {
            partsRain.suspended = true;
            partsRain.parts.length = 0;
        }
    }
    const viewClass = 'mobile-view-' + view;
    if (!grid.classList.contains(viewClass)) {
        grid.classList.remove('mobile-view-left', 'mobile-view-center', 'mobile-view-right');
        grid.classList.add(viewClass);
    }
    if (nav) {
        nav.querySelectorAll('button').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
            // Le joueur a ouvert l'onglet vise par la lecon : le pulse
            // a rempli son role, on l'eteint.
            btn.classList.toggle('nav-pulse', false);
        });
    }
    if (view === 'center') applySceneScale();
}

// Mise à l'échelle de la scène de construction : la fusée fait ~700px
// de haut en taille réelle (pièces positionnées en pixels fixes). On applique
// un transform: scale() pour qu'elle tienne toujours dans l'écran.
function applyUiScale() {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (isMobileLayout()) {
        // Reference visuelle mobile : iPhone 13 (390x844). Le master layout
        // mobile etait regle a la main avec --ui-scale = 0.8 (plancher
        // desktop) : on le preserve et on applique partout la meme echelle
        // uniforme (px via --mscale, rem via --ui-scale).
        const wScale = vw / 390;
        const hScale = vh / 844;
        const mscale = Math.max(0.85, Math.min(1.35, Math.min(wScale, hScale)));
        document.documentElement.style.setProperty('--mscale', mscale.toFixed(3));
        // 0.95 : texte mobile tres lisible (base 15.2px sur iPhone 13)
        document.documentElement.style.setProperty('--ui-scale', (1.1 * mscale).toFixed(3));
        return;
    }
    document.documentElement.style.removeProperty('--mscale');
    // Echelle pilotee surtout par la hauteur : c'est elle qui manque sur
    // les fenetres desktop compactes. La largeur ne compte que sous 1150px.
    const wScale = Math.min(1, vw / 1150);
    const hScale = Math.min(1, vh / 820);
    // Plancher 0.8 : sous cette taille le texte deviendrait illisible ;
    // les panneaux lateraux scrollent deja en interne.
    let scale = Math.max(0.8, Math.min(wScale, hScale));
    // GRANDS ECRANS (ex. 2560x1440) : la grille du jeu est bornee
    // (--game-max-width) et l'ui-scale plafonne a 1 -- l'ecran gagnait
    // tout son surplus en HAUTEUR seule : memes elements, mais poses
    // differemment qu'en 1920x1080. Au-dela du Full HD, l'echelle monte
    // avec l'ecran (plafond 1.33 = 1440/1080) : la disposition reste
    // EXACTEMENT celle du 1920x1080, agrandie uniformement comme un
    // zoom systeme -- textes, panneaux et scene grandissent ensemble.
    // La borne de largeur du jeu suit la meme echelle (rem agrandi =
    // panneaux agrandis) pour que la grille occupe la place du 1080p
    // mise a l'echelle, sans deborder.
    const bigW = vw / 1920, bigH = vh / 1080;
    const bigScale = Math.max(bigW, bigH);
    if (bigScale > 1) {
        scale = Math.min(scale * bigScale, 1.33);
        document.documentElement.style.setProperty('--game-max-width', Math.round(1720 * scale) + 'px');
    } else {
        document.documentElement.style.removeProperty('--game-max-width');
    }
    document.documentElement.style.setProperty('--ui-scale', scale.toFixed(3));
}
// Fond de scene jour/nuit : la vallee passe en version nocturne quand le
// joueur joue entre 20h et 6h (heure locale). Reverifie chaque minute pour
// basculer proprement si la partie reste ouverte pendant le changement d'heure.
function updateDayNightBackground() {
    const hour = new Date().getHours();
    const night = hour >= 20 || hour < 6;
    document.body.classList.toggle('night-mode', night);
}
// V3.85 : consolide dans le gameLoop (tickConsolidatedTimers).

function applySceneScale() {
    // Le monde scene-world (1024x744, dimensions natives du fond) contient le
    // decor ET la fusée dans le meme repere : une seule echelle uniforme,
    // jamais de desynchronisation au redimensionnement.
    const world = document.getElementById('scene-world');
    if (!world || launchSequenceActive) return;
    const scene = world.parentElement;
    if (!scene) return;
    const sceneHeight = scene.clientHeight;
    const sceneWidth = scene.clientWidth;
    if (!sceneHeight || !sceneWidth) return;
    const WORLD_WIDTH = 1024;
    const WORLD_HEIGHT = 744;
    // Le monde reste TOUJOURS ancre au bas du panneau central (bottom: 0),
    // comme a l'origine : le decor ne bouge jamais, quelle que soit la
    // hauteur de la barre d'achat des pieces en dessous. C'est la hauteur
    // de la barre qu'on gerera pour ne pas cacher le pas de tir.
    // Sommet de la fusée dans le repere monde (piece la plus haute : pas de tir).
    const ROCKET_TOP_Y = 205;
    const rocketAboveGround = WORLD_HEIGHT - ROCKET_TOP_Y;
    const MARGIN = 24;
    // 1) Echelle "cover" : le decor remplit toujours la scene (ancré bas-centre,
    //    le debordement part vers le ciel).
    let scale = Math.max(sceneWidth / WORLD_WIDTH, sceneHeight / WORLD_HEIGHT);
    // 2) Garde-fou : le sommet de la fusée reste toujours visible avec une
    //    marge, même sur des ecrans tres larges et bas.
    scale = Math.min(scale, (sceneHeight - MARGIN) / rocketAboveGround);
    world.style.transformOrigin = '50% 100%';
    world.style.transform = 'translateX(-50%) scale(' + scale + ')';
    // Prolongation du sol : le decor a sa ligne de sol vers y=480 (sur 744).
    // On aligne le remplissage sur cette ligne pour une jonction invisible.
    const GROUND_LINE_Y = 480;
    const groundFill = document.getElementById('scene-ground-fill');
    if (groundFill) groundFill.style.height = (scale * (WORLD_HEIGHT - GROUND_LINE_Y)) + 'px';
}

function initMobileNav() {
    const nav = document.getElementById('mobile-nav');
    if (!nav) return;
    nav.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
            closeAllModalsForMobileNav();
            setMobileView(btn.dataset.view);
        });
    });
    if (isMobileLayout()) setMobileView(mobileActiveView);
    let resizeTimer = null;
    let lastResizeW = window.innerWidth;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            relocateBuildingProductions();
            // Barre d'URL mobile : un resize de hauteur seul (scroll masque la
            // barre) ne doit pas rescaler l'UI en plein scroll, sinon la
            // hauteur du contenu change et le scrollTop est reclampe.
            if (window.innerWidth !== lastResizeW) applyUiScale();
            // Sur mobile, scroller masque/affiche la barre d'URL du navigateur :
            // un changement de hauteur seul ne doit pas reinitialiser la vue,
            // sinon le scroll du panneau batiments remonte de force.
            const widthChanged = window.innerWidth !== lastResizeW;
            if (isMobileLayout() && widthChanged) {
                setMobileView(mobileActiveView);
            }
            lastResizeW = window.innerWidth;
            // La scène se recale à toutes les tailles d'écran (desktop inclus)
            applySceneScale();
        }, 150);
    });
    window.addEventListener('orientationchange', () => {
        applyUiScale();
        setTimeout(applySceneScale, 250);
    });
    applyUiScale();
}

// --- Chronometre depuis le dernier lancement ---
// Format de duree complet : toutes les unites non nulles sont affichees,
// avec zero non significatif quand une unite superieure est presente.
// 3h45m50s / 45m50s / 50s / jamais une seule unite tronquee.
function formatDurationHMS(ms) {
    if (ms < 0) ms = 0;
    const totalSec = Math.floor(ms / 1000);
    const d = Math.floor(totalSec / 86400);
    const h = Math.floor((totalSec % 86400) / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (d > 0) return d + 'j' + String(h).padStart(2, '0') + 'h' + String(m).padStart(2, '0') + 'm';
    if (h > 0) return h + 'h' + String(m).padStart(2, '0') + 'm' + String(s).padStart(2, '0') + 's';
    if (m > 0) return m + 'm' + String(s).padStart(2, '0') + 's';
    return s + 's';
}
function formatLaunchTimer(ms) {
    return formatDurationHMS(ms);
}

function updateLaunchTimer() {
    const el = document.getElementById('launch-timer');
    if (!el) return;
    // Avant le premier lancement, le chrono court depuis le debut de la partie
    const start = lastLaunchAt || expeditionStartTime || gameStartTime || 0;
    if (!start) return;
    setTextIfChanged(el, formatLaunchTimer(Date.now() - start));
    el.classList.toggle('has-launch', !!lastLaunchAt);
}
// Ecriture DOM dEdoublonnEe : ne toucher el que si le texte change vraiment.
function setTextIfChanged(el, text) {
    if (el.textContent !== text) el.textContent = text;
}

// ============================================
// INITIALIZATION
// ============================================

// ============================================
// ============================================
// TUTORIEL DEBUT DE PARTIE
// Coach proactif : au lieu d'une presentation que le joueur subit,
// un guide flottant suit ses premiers gestes (clic, achat, construction)
// et passe a l'etape suivante QUAND l'action est faite. Le jeu reste
// jouable a chaque instant (pas d'overlay bloquant).
// Persiste dans la save (tutorialSeen).
// ============================================
const TUTORIAL_STEPS = [
    {
        img: 'images/parts.webp',
        titleKey: 'Clique sur la pièce',
        textKey: 'Chaque clic te rapporte des Parts. Clique 15 fois pour t’entraîner !',
        done: () => totalPartsFromClicks >= 15,
        target: '#medal',
    },
    {
        img: 'images/buildings/workshop.webp',
        titleKey: 'Achète ton premier bâtiment !',
        textKey: 'Les bâtiments produisent des Parts tout seuls. Achète un Atelier dans le panneau Bâtiments.',
        done: () => (findBuildingById('workshop')?.count || 0) >= 1,
        target: '#building-workshop',
    },
    {
        img: 'images/parts.webp',
        titleKey: 'Achète ta première amélioration',
        textKey: 'La barre Améliorations en haut propose des bonus qui te permettent de doubler ta puissance de clic et doubler la production sur chaque bâtiment. Achète-en une pour progresser plus vite !',
        done: () => activatedClickUpgrades.length >= 1 || Object.values(buildingUpgrades).some(list => list.length > 0),
        target: '.counters',
        prefer: 'below',
    },
    {
        img: 'images/rocket/Fusée3.webp',
        titleKey: 'Construis ta première pièce de fusée',
        textKey: 'Achète les pièces de fusée une par une afin de construire la fusée entièrement et pouvoir lancer l\'expédition !',
        done: () => ROCKET_PARTS.some(p => p.purchased),
        target: '#rocket-parts-shop',
        prefer: 'below',
    },
    {
        img: 'images/buildings/factory.webp',
        titleKey: 'Nouveau bâtiment : Usine',
        textKey: 'Clique pour acheter l’Usine ! Elle produit bien plus qu’un Atelier et accélérera ta production.',
        done: () => (findBuildingById('factory')?.count || 0) >= 1,
        target: '#building-factory',
    },
    {
        img: 'images/effects/comete.webp',
        titleKey: 'Les Contrats sont disponibles',
        textKey: 'Les contrats sont des mini-défis de 30 secondes : cliquer, intercepter des comètes, produire… contre des récompenses.',
        done: () => getSeenLessons().includes('tutorial-contracts-opened'),
        target: '#contracts-mini-card',
    },
    {
        img: 'images/planets/moon.webp',
        titleKey: 'Progression Spatiale',
        textKey: 'La colonne de gauche résume ton expédition : Portée actuelle (jusqu’où ta fusée peut aller maintenant), Vitesse (km de portée gagnés par seconde), Distance record et Bonus planètes. Clique sur chaque case pour une explication détaillée !',
        done: () => getSeenLessons().includes('tutorial-space-stats-seen'),
        target: '#space-stats-sidebar',
        prefer: 'right',
        // V3.38bis : passe toute seule apres 15 s (retour joueur : le
        // joueur qui ne clique pas sur les cases restait bloque ici pour
        // toujours). Les autres etapes exigent un vrai geste du joueur.
        autoAfterMs: 15000,
    },
];
let tutorialStep = 0;
let tutorialActive = false;
let tutorialPollTimer = null;

function isTutorialSeen() {
    return !!tutorialSeen;
}

// Ecran d'accueil plein ecran (premiere visite) : les etapes principales du
// jeu en une page, affiche UNE SEULE FOIS par navigateur (localStorage),
// independamment de la sauvegarde. Le coach pas-a-pas prend ensuite le relais.
function showIntroScreen() {
    const overlay = document.getElementById('intro-overlay');
    if (!overlay) return false;
    if (localStorage.getItem('starcruiser-intro-seen') === '1') return false;
    localStorage.setItem('starcruiser-intro-seen', '1');
    overlay.classList.add('active');
    return true;
}
function closeIntroScreen(startCoach) {
    const overlay = document.getElementById('intro-overlay');
    if (overlay) overlay.classList.remove('active');
    if (startCoach) startTutorial(false);
}
// Choix de la langue a la premiere visite : affiche le sélecteur
// au-dessus de tout (z-index 14500) et differe le tutoriel.
function shouldAskLanguage() {
    return localStorage.getItem('starcruiser-language') === null;
}

function showLanguagePicker() {
    const overlay = document.getElementById('lang-picker-overlay');
    if (!overlay) return;
    overlay.classList.add('active');
}

function closeLanguagePicker() {
    const overlay = document.getElementById('lang-picker-overlay');
    if (overlay) overlay.classList.remove('active');
}

function chooseGameLanguage(lang) {
    setGameLanguage(lang);
    closeLanguagePicker();
    // Le tutoriel attend que la langue soit choisie pour demarrer :
    // d'abord l'ecran d'accueil, puis le coach pas-a-pas.
    if (!tutorialActive && !isTutorialSeen()) showIntroScreen();
}

function startTutorial(force) {
    if (tutorialActive) return;
    if (!force && isTutorialSeen()) return;
    // Deja de la progression sauvegardee : le coach n'a plus lieu d'etre.
    const workshop = findBuildingById('workshop');
    if (!force && (workshop?.count > 0 || ROCKET_PARTS.some(p => p.purchased))) {
        tutorialSeen = true;
        return;
    }
    tutorialActive = true;
    tutorialStep = 0;
    renderTutorialStep();
    if (tutorialPollTimer) clearInterval(tutorialPollTimer);
    tutorialPollTimer = setInterval(pollTutorialProgress, 400);
}

// Place le coach flottant a cote de l'element concerne par la lecon : sous lui
// si la place suffit, au-dessus sinon, toujours borne dans le viewport. Si la
// cible est absente ou masquee (ex. panneau non ouvert), le coach reste en bas
// au centre (position CSS par defaut).
function positionCoachNear(coach, selector, prefer) {
    coach.style.left = '';
    coach.style.top = '';
    coach.style.bottom = '';
    coach.style.transform = '';
    coach.style.width = '';
    if (!selector) return;
    let targetEl = null;
    try { targetEl = document.querySelector(selector); } catch (e) { targetEl = null; }
    if (!targetEl || !targetEl.isConnected) return;
    const rect = targetEl.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    // Largeur adaptative : la carte complete (420px) sur grand ecran, plus
    // etroite sur petit ecran PC pour liberer de la place autour de la cible.
    let cw = Math.min(vw * 0.92, 420);
    if (vw < 1000) cw = Math.min(vw * 0.7, 340);
    if (vw < 700) cw = Math.min(vw * 0.88, 300);
    coach.style.width = cw + 'px';
    const ch = coach.offsetHeight || 170;
    const margin = 12;
    // La piece a cliquer ne doit JAMAIS etre recouverte : le joueur en a
    // besoin pendant tout le tutoriel (gagner des Parts pour acheter).
    const medalEl = document.getElementById('medal');
    const medalRect = medalEl ? medalEl.getBoundingClientRect() : null;
    const pad = 10;
    const overlapsMedal = (l, t) => {
        if (!medalRect) return false;
        const r = l + cw, b = t + ch;
        return !(r < medalRect.left - pad || l > medalRect.right + pad || b < medalRect.top - pad || t > medalRect.bottom + pad);
    };
    // V4.0bis (retour proprietaire : 'sur ecran plus petit que 1920x1080,
    // le tuto 3 cache la barre des ameliorations et la piece') : le coach
    // ne doit pas NON PLUS recouvrir la CIBLE elle-meme -- le joueur doit
    // voir l element qu on lui explique (la barre d ameliorations pour le
    // tuto 3). Sur petit ecran vertical, le coach 340-420px pose sous la
    // cible remontait parfois dessus. La cible rejoint la piece dans les
    // zones interdites du placement.
    const overlapsTarget = (l, t) => {
        const r = l + cw, b = t + ch;
        return !(r < rect.left - pad || l > rect.right + pad || b < rect.top - pad || t > rect.bottom + pad);
    };
    // Placements candidats, du plus naturel au repli : sous la cible,
    // au-dessus, a droite, a gauche. On garde le premier qui ne couvre ni
    // la piece ni ne sort de l'ecran ; sinon le moins penalise.
    // MOBILE : la barre de navigation du bas (+ le bouton LANCER fixe et
    // la barre des pieces) occupent tout le bas de l'ecran. Le coach ne
    // doit JAMAIS s'y poser : on borne les placements candidats pour que
    // le BAS du coach reste au-dessus de la navbar. Les lecons 2, 3, 5, 6
    // et les lecons contextuelles (contrats, progression) ciblent des
    // elements bas -- sans ce garde, le coach recouvrait la navbar ou
    // passait dessous.
    const isMobileCoach = typeof isMobileLayout === 'function' && isMobileLayout();
    const navEl = document.getElementById('mobile-nav');
    const navTop = isMobileCoach && navEl ? navEl.getBoundingClientRect().top : vh;
    const maxY = isMobileCoach ? (navTop - margin - ch) : (vh - ch - 8);
    const candidates = [
        { x: rect.left + rect.width / 2 - cw / 2, y: rect.bottom + margin },
        // Variante 'below' decalee : si le centrage sous la cible couvre
        // la piece, un petit decalage lateral suffit souvent a la liberer
        // tout en restant sous la cible -- mieux qu'un rebasculement
        // au-dessus qui cache le contexte.
        { x: rect.left + rect.width / 2 - cw / 2 - Math.min(160, cw * 0.5), y: rect.bottom + margin },
        { x: rect.left + rect.width / 2 - cw / 2, y: rect.top - margin - ch },
        { x: rect.right + margin, y: rect.top + rect.height / 2 - ch / 2 },
        { x: rect.left - margin - cw, y: rect.top + rect.height / 2 - ch / 2 },
    ];
    // Preference de placement demandee par la lecon : ce cote est teste en
    // premier, les autres restent en repli si jamais il couvre la piece.
    // 'below' est le sens par defaut : la cible reste visible AU-DESSUS du
    // coach, ce qui se lit mieux (fleche du contexte vers l'explication).
    if (prefer === 'above') {
        const above = candidates.splice(1, 1)[0];
        candidates.unshift(above);
    } else if (prefer === 'right') {
        const right = candidates.splice(2, 1)[0];
        candidates.unshift(right);
    } else if (prefer === 'left') {
        const left = candidates.splice(3, 1)[0];
        candidates.unshift(left);
    }
    let best = null, bestScore = Infinity;
    for (const c of candidates) {
        const clipped = Math.max(8, Math.min(c.x, vw - cw - 8)) !== c.x || Math.max(8, Math.min(c.y, vh - ch - 8)) !== c.y;
        const cx0 = Math.max(8, Math.min(c.x, vw - cw - 8));
        const cy0 = Math.max(8, Math.min(c.y, vh - ch - 8));
        let score = (overlapsMedal(cx0, cy0) || overlapsTarget(cx0, cy0) ? 1000 : 0) + (clipped ? 5 : 0);
        if (score < bestScore) { bestScore = score; best = c; }
        if (score === 0) break;
    }
    if (bestScore >= 1000) {
        // V4.0bis : le repli bas-centre reste le filet, mais il doit a son
        // tour eviter la cible si possible : essayer les positions bas
        // decalees gauche/droite avant le centre pur.
        // (Le centre est garde en dernier recours absolu.)
        // Tous les placements couvrent la piece (ecran tres petit) : repli
        // en bas au centre. Sur mobile, le repli est place AU-DESSUS de la
        // navbar (le CSS par defaut bottom:18px passerait dessous).
        coach.style.bottom = '';
        coach.style.left = '50%';
        coach.style.transform = 'translateX(-50%)';
        if (isMobileCoach && navEl) {
            const navH = vh - navTop;
            coach.style.bottom = Math.round(navH + margin) + 'px';
        }
        return;
    }
    const x = Math.max(8, Math.min(best.x, vw - cw - 8));
    const y = Math.max(8, Math.min(best.y, maxY));
    coach.style.left = Math.round(x) + 'px';
    coach.style.top = Math.round(y) + 'px';
    coach.style.bottom = 'auto';
    coach.style.transform = 'none';
}
// Pulse tuto sur la nav mobile : quand la lecon courante concerne le
// panneau Progression Spatiale (gauche) ou Batiments (droite), l'onglet
// correspondant pulse pour attirer le regard -- sur mobile le coach flottant
// designe un element parfois invisible (panneau non affiche).
function updateTutorialNavPulse(targetSelector) {
    const nav = document.getElementById('mobile-nav');
    if (!nav) return;
    // Chaque cible de lecon appartient a une des trois vues mobiles.
    // CENTER (page Fusee) : piece, compteurs, boutique de pieces, bouton
    // lancer -- toutes les etapes qui se jouent sur la scene centrale.
    const CENTER_TARGETS = ['#medal', '.counters', '#rocket-parts-shop', '#launch-button'];
    const LEFT_TARGETS = ['#space-stats-sidebar', '.mini-space-map', '.galactic-shop-btn',
        '#contracts-mini-card', '#card-collection-mini-card'];
    const RIGHT_TARGETS = ['#building-workshop', '#building-factory', '.buildings'];
    let pulseView = null;
    if (targetSelector) {
        if (CENTER_TARGETS.some(sel => targetSelector.startsWith(sel))) pulseView = 'center';
        else if (LEFT_TARGETS.some(sel => targetSelector.startsWith(sel))) pulseView = 'left';
        else if (RIGHT_TARGETS.some(sel => targetSelector.startsWith(sel))) pulseView = 'right';
    }
    nav.querySelectorAll('button').forEach(btn => {
        btn.classList.toggle('nav-pulse', btn.dataset.view === pulseView);
    });
}

function renderTutorialStep() {
    const step = TUTORIAL_STEPS[tutorialStep];
    // Panneau gauche : le PANNEAU reste visible (fond, bordure -- pas de
    // disparition brutale), seuls les ELEMENTS pas encore debloques se
    // masquent avec un fondu. Les mini-jeux (contrats, collection) restent
    // visibles des leur deblocage, independamment du tuto.
    const leftPanel = document.querySelector('.left-panel');
    if (leftPanel) {
        // Voile leve des l'etape Contrats (index 5) : la lecon cible
        // #contracts-mini-card dans CE panneau -- le voile ne doit pas
        // masquer la cible de la lecon en cours (avant : leve seulement
        // a l'etape 7, la lecon contrats tombait sur un panneau voile).
        const spaceStatsUnlocked = !tutorialActive || tutorialStep >= 5;
        leftPanel.classList.toggle('tutorial-muted', !spaceStatsUnlocked);
    }
    if (!step) { endTutorial(); return; }
    const coach = document.getElementById('tutorial-coach');
    if (!coach) return;
    coach.classList.add('active');
    // Etape obligatoire : le bouton fermer est masque, impossible de la passer.
    const closeBtn = coach.querySelector('.tutorial-close-btn');
    if (closeBtn) closeBtn.style.display = step.mandatory ? 'none' : '';
    const stepEl = coach.querySelector('.tutorial-coach-step');
    const imgEl = coach.querySelector('.tutorial-coach-visual');
    const titleEl = coach.querySelector('.tutorial-coach-title');
    const textEl = coach.querySelector('.tutorial-coach-text');
    if (stepEl) stepEl.textContent = (tutorialStep + 1) + '/' + TUTORIAL_STEPS.length;
    if (imgEl) imgEl.src = step.img;
    if (titleEl) titleEl.textContent = t(step.titleKey);
    if (textEl) textEl.textContent = t(step.textKey);
    positionCoachNear(coach, step.target, step.prefer);
    updateTutorialNavPulse(step.target);
    // Etape a duree limitee (autoAfterMs) : arme un minuteur qui force
    // le passage a l'etape suivante -- utile pour les lecons de lecture
    // (rien a faire) qu'un joueur attentif ne validerait jamais.
    startTutorialAutoTimer(step);
}

let tutorialStepAutoTimer = null;
// Arme (ou desarme) le minuteur de passage automatique de l'etape en
// cours. Nettoye au changement d'etape, en fin de tuto et au skip : le
// timer ne doit jamais faire avancer un tuto termine ou une autre etape.
function startTutorialAutoTimer(step) {
    if (tutorialStepAutoTimer) { clearTimeout(tutorialStepAutoTimer); tutorialStepAutoTimer = null; }
    if (!step || !step.autoAfterMs) return;
    tutorialStepAutoTimer = setTimeout(() => {
        tutorialStepAutoTimer = null;
        if (!tutorialActive || tutorialStep >= TUTORIAL_STEPS.length) return;
        const current = TUTORIAL_STEPS[tutorialStep];
        if (current !== step) return;
        tutorialStep++;
        if (tutorialStep >= TUTORIAL_STEPS.length) endTutorial();
        else renderTutorialStep();
    }, step.autoAfterMs);
}
function stopTutorialAutoTimer() {
    if (tutorialStepAutoTimer) { clearTimeout(tutorialStepAutoTimer); tutorialStepAutoTimer = null; }
}

// Le joueur fait l'action (clic, achat...) : on verifie regulierement
// si l'etape courante est accomplie et on avance automatiquement.
function pollTutorialProgress() {
    if (!tutorialActive) return;
    const step = TUTORIAL_STEPS[tutorialStep];
    if (!step) { endTutorial(); return; }
    // Etapes a condition : attendre que la mecanique existe vraiment
    // (contrats debloques par l'Usine, fusête completee) -- sinon le
    // coach sauterait des etapes sans que le joueur voie quoi que ce soit.
    if (tutorialStep === 5 && !isBuildingUnlocked(findBuildingById('factory'))) return;
    if (tutorialStep === 7 && !ROCKET_PARTS.every(pr => pr.purchased)) return;
    if (step.done && step.done()) {
        tutorialStep++;
        if (tutorialStep >= TUTORIAL_STEPS.length) {
            endTutorial();
        } else {
            renderTutorialStep();
        }
    }
}

// Compatible avec les anciens appels : passer une etape a la main reste
// possible, mais le coach avance surtout tout seul.
function nextTutorialStep() {
    if (!tutorialActive) return;
    tutorialStep++;
    if (tutorialStep >= TUTORIAL_STEPS.length) endTutorial();
    else renderTutorialStep();
}

function skipTutorial() {
    // Fermeture manuelle pendant une lecon contextuelle : liberer le coach
    // pour la lecon suivante (le tuto de base etant deja vu).
    if (featureLessonVisible) {
        dismissFeatureLesson();
        return;
    }
    endTutorial();
}

function endTutorial() {
    updateTutorialNavPulse(null);
    const lp = document.querySelector('.left-panel');
    if (lp) lp.classList.remove('tutorial-muted');
    tutorialActive = false;
    tutorialSeen = true;
    stopTutorialAutoTimer();
    if (tutorialPollTimer) { clearInterval(tutorialPollTimer); tutorialPollTimer = null; }
    saveGame();
    const coach = document.getElementById('tutorial-coach');
    if (coach) {
        coach.classList.remove('active');
        const endCloseBtn = coach.querySelector('.tutorial-close-btn');
        if (endCloseBtn) endCloseBtn.style.display = '';
        positionCoachNear(coach, null);
    }
    // Le coach de base est fini : les lecons contextuelles prennent le
    // relais (un deblocage = une explication, une seule fois).
    startFeatureLessons();
}

// ============================================
// LECONS CONTEXTUELLES : chaque mecanique est expliquee au moment ou
// le joueur la debloque, pas avant. Chaque lecon a une condition de
// declenchement et une cle d'historisation (jamais reaffichee).
// ============================================
function markLessonSeen(key) {
    const seen = getSeenLessons();
    if (!seen.includes(key)) {
        seen.push(key);
        localStorage.setItem('starcruiser-lessons-seen', JSON.stringify(seen));
    }
}

let featureLessonTimer = null;
let featureLessonVisible = false;

const FEATURE_LESSONS = [
    {
        key: 'card-collection-unlocked',
        titleKey: 'La Collection de Cartes est disponible',
        textKey: 'Ouvre des boosters, complète ton album : chaque carte améliore ta production de Parts pour toujours !',
        img: 'images/cards/collection/booster1.webp',
        trigger: () => areCardsUnlocked(),
        target: '#card-collection-mini-card',
    },
    {
        key: 'rocket-complete',
        titleKey: 'Fusée prête !',
        textKey: 'Toutes les pièces sont construites ! Appuie sur LANCER LA FUSÉE lorsque tu voudras lancer l\'expédition ! Petit conseil, lance une expédition quand tu es sûr d\'atteindre une nouvelle planète ou de gagner de nouvelles poussières d\'étoiles !',
        img: 'images/rocket/Fusée3.webp',
        trigger: () => ROCKET_PARTS.every(p => p.purchased),
        target: '#launch-button',
    },
    {
        key: 'galactic-shop',
        titleKey: 'Atelier Galactique',
        textKey: 'L’Atelier Galactique (bouton violet sous la mini-carte) propose des améliorations PERMANENTES achetées avec la Poussière d’Étoiles gagnée à chaque lancement : production, fusée, collection, clics… Elles survivent aux nouvelles expéditions. Ouvre-le quand tu as des PE !',
        img: 'images/rocket/astronaut.webp',
        trigger: () => starDust >= 2,
        target: '.galactic-shop-btn',
        prefer: 'right',
    },
    {
        key: 'first-launch',
        titleKey: 'Bon voyage !',
        textKey: 'Chaque lancement termine une expédition : ta nouvelle fusée repart de la Terre, mais tes planètes débloquées, ta distance record et tes bonus permanents sont conservés. Vas de plus en plus loin !',
        img: 'images/planets/moon.webp',
        trigger: () => rocketsLaunched >= 1,
    },
];

// Premiere comete : le coach ne peut pas la deviner, on arme un timer au
// demarrage et la lecon tombe apres le delai naturel d'apparition.
let cometLessonReadyAt = 0;

function startFeatureLessons() {
    // V3.85 : plus de setInterval -- le poll est pilote par le gameLoop
    // (tickConsolidatedTimers, 1 s). featureLessonTimer reste le drapeau
    // d activation (null = arrete) pour ne pas casser les autres usages.
    featureLessonTimer = 1;
    pollFeatureLessons();
}

function pollFeatureLessons() {
    // Les lecons contextuelles ne demarrent qu'apres le coach de base
    // (les 4 etapes : clic, Atelier, piece de fusee, amelioration).
    if (tutorialActive || !isTutorialSeen()) return;
    // Une seule lecon a la fois : on attend la fermeture de la lecon
    // courante (auto apres 12 s ou clic) avant d'en montrer une autre.
    if (featureLessonVisible) return;
    const seen = getSeenLessons();
    const next = FEATURE_LESSONS.find(l => !seen.includes(l.key) && l.trigger && l.trigger());
    if (next) showFeatureLesson(next);
}

function getSeenLessons() {
    try { return JSON.parse(localStorage.getItem('starcruiser-lessons-seen') || '[]'); }
    catch (e) { return []; }
}

function showFeatureLesson(lesson) {
    if (featureLessonVisible) return;
    featureLessonVisible = true;
    const seen = getSeenLessons();
    if (!seen.includes(lesson.key)) {
        seen.push(lesson.key);
        localStorage.setItem('starcruiser-lessons-seen', JSON.stringify(seen));
    }
    const coach = document.getElementById('tutorial-coach');
    if (!coach) return;
    coach.classList.add('active');
    const stepEl = coach.querySelector('.tutorial-coach-step');
    const imgEl = coach.querySelector('.tutorial-coach-visual');
    const titleEl = coach.querySelector('.tutorial-coach-title');
    const textEl = coach.querySelector('.tutorial-coach-text');
    if (stepEl) stepEl.textContent = '';
    if (imgEl) imgEl.src = lesson.img;
    if (titleEl) titleEl.textContent = t(lesson.titleKey);
    if (textEl) textEl.textContent = t(lesson.textKey);
    positionCoachNear(coach, lesson.target, lesson.prefer);
    updateTutorialNavPulse(lesson.target);
    // Fermeture UNIQUEMENT par la croix : la lecon reste affichee tant que
    // le joueur ne la ferme pas lui-meme (plus de disparition automatique).
    clearTimeout(showFeatureLesson.hideTimer);
}

function dismissFeatureLesson() {
    updateTutorialNavPulse(null);
    // Tuto etape Progression Spatiale : fermer le coach la valide.
    try { markLessonSeen('tutorial-space-stats-seen'); } catch (e) {}
    clearTimeout(showFeatureLesson.hideTimer);
    featureLessonVisible = false;
    const coach = document.getElementById('tutorial-coach');
    if (coach && !tutorialActive) {
        coach.classList.remove('active');
        positionCoachNear(coach, null);
    }
}

function init() {
    // L'ecran de chargement disparait en toute premiere action : aucune erreur
    // runtime ulterieure ne peut plus le laisser bloque jusqu'au filet des 8 s.
    hideLoadingScreen();
    initGlobals();
    const introStartBtn = document.getElementById('intro-start-btn');
    // Le bouton ferme l'intro ; la modale de nom d'entreprise s'affiche
    // juste APRES l'intro (demande unique, dans cet ordre).
    if (introStartBtn) introStartBtn.addEventListener('click', () => {
        closeIntroScreen(true);
        ensureCompanyName();
    });
    const npnLaunchBtn = document.getElementById('npn-launch-btn');
    if (npnLaunchBtn) {
        npnLaunchBtn.addEventListener('click', () => {
            closeNextPlanetNotification();
            launchRocket();
        });
    }
    const npnOverlay = document.getElementById('next-planet-notification');
    if (npnOverlay) {
        npnOverlay.addEventListener('click', (e) => {
            if (e.target === npnOverlay) closeNextPlanetNotification();
        });
    }
    loadGame();
    initLayoutDebugBadge();
    // Nouvelle partie (aucune sauvegarde) : les boosters ne sont PAS dispo
    // des le debut -- leurs countdowns demarrent au PREMIER deblocage de
    // la collection de cartes (voir maybeStartBoosterTimers).
    if (!hasSaveData) {
        boosterTimersStarted = false;
    }
    // Refleter le multiplicateur d'achat restaure (bouton actif de la sidebar).
    if (typeof setBuyMultiplier === 'function') setBuyMultiplier(buyMultiplier);
    applyStartupBonus();
    // P8 : rechargement pendant l'atelier post-voyage -> le rouvrir en mode
    // bloquant (recompenses deja creditees, pas de double gain ; le reset
    // doit passer par le bouton Continuer, impossible de le sauter par F5).
    if (atelierAfterTravel) {
        setGameplayPaused(true);
        showPostTravelShop(lastLaunchDistance);
    }

    updateDisplay();
    renderBuildings();
    renderUpgrades();
    renderRocketPartsShop();
    updateConstructionScene();
    checkBuildingUnlocks();
    updateMiniGamesVisibility();
    checkTrophies();
    initMobileNav();
    const ccLightbox = document.getElementById('cc-lightbox');
    if (ccLightbox) {
        ccLightbox.addEventListener('click', function (e) { if (e.target !== document.getElementById('cc-lightbox-img')) closeCardLightbox(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeCardLightbox(); });
    }
    if (isMobileLayout()) {
        setMobileView(mobileActiveView);
    }
    // Recalage systematique de la scene (desktop aussi) : la mise a l'echelle
    // depend de la hauteur rendue de la scene, fausse tant que le CSS et les
    // polices ne sont pas appliques.
    applySceneScale();
    updateDayNightBackground();
    // Bouton musique des parametres : refleter l'etat persiste.
    const musicBtn0 = document.getElementById('music-toggle-btn');
    if (musicBtn0) { const l = musicBtn0.querySelector('#music-toggle-label'); if (l) l.textContent = Music.enabled ? t('Désactiver la musique de fond') : t('Activer la musique de fond'); }
    const clickSndBtn0 = document.getElementById('clicksound-toggle-btn');
    if (clickSndBtn0) { const l = clickSndBtn0.querySelector('span'); if (l) l.textContent = ClickSound.enabled ? t('Désactiver le son du clic') : t('Activer le son du clic'); }
    // V3.96 (retour proprietaire : 'a chaque rechargement je vois le tuto
    // apparaitre une demi-seconde puis disparaitre') : quand une SAUVEGARDE
    // SIGNEE est en attente du module WASM, la partie demarre vierge le
    // temps du chargement -- startTutorial voyait 'aucun bâtiment, tuto non
    // vu' et DEMARRAIT le coach, que le rejeu de la V3.82 tuait juste
    // apres : le flash. La decision du tuto est DIFFEREE jusqu'a la
    // restauration : si la save a de la vraie progression, le coach ne
    // sera jamais demarre ; une vraie nouvelle partie (pas d'attente
    // WASM) garde son tuto immediat.
    if (saveLockedWaitingWasm) {
        // La restauration passera par replayAfterRestore : NE RIEN
        // decider ici (ni intro, ni coach) tant que la save n'est pas
        // relue -- startFeatureLessons reste lui aussi differe.
    } else if (shouldAskLanguage()) {
        showLanguagePicker();
    } else if (!tutorialActive && !isTutorialSeen() && showIntroScreen()) {
        // Le coach demarrera a la fermeture de l'ecran d'accueil ; ne pas
        // retourner ici : hideLoadingScreen() doit toujours etre appele.
    } else {
        startTutorial(false);
    }
    // Nom d'entreprise spatiale OBLIGATOIRE : APRES la logique d'accueil.
    // L'ecran d'intro et le selecteur de langue contiennent deja le champ
    // de saisie -- on ne demande le nom via la modale QUE si aucun des deux
    // n'est affiche. Avant, l'appel etait AVANT l'intro : le joueur subissait
    // la modale PUIS l'intro qui redemandait le nom -> double demande.
    const introShown = document.getElementById('intro-overlay')
        && document.getElementById('intro-overlay').classList.contains('active');
    const langPickerShown = document.getElementById('lang-picker-overlay')
        && document.getElementById('lang-picker-overlay').classList.contains('active');
    if (!introShown && !langPickerShown && !saveLockedWaitingWasm) {
        ensureCompanyName();
    }
    // Joueur qui a deja fini le tutoriel : les lecons contextuelles
    // (debut d'un nouveau run inclus) tournent quand meme, chaque lecon
    // n'est montree qu'une fois via starcruiser-lessons-seen.
    // V3.96 : differe aussi pendant l attente WASM (la save dira si le
    // tuto est vu -- eviter de demarrer les lecons sur une partie vierge
    // qui n en sera pas une).
    if (isTutorialSeen() && !tutorialActive && !saveLockedWaitingWasm) startFeatureLessons();
}

// Masque l'ecran de chargement des que le jeu est initialise (pas de duree
// minimum forcee) : on attend juste le logo pour eviter un flash.
function hideLoadingScreen() {
    const overlay = document.getElementById('loading-screen');
    if (!overlay) return;
    const logo = overlay.querySelector('.loading-logo');
    const hide = () => {
        overlay.classList.add('hidden');
        setTimeout(() => overlay.remove(), 500);
    };
    if (logo && !logo.complete) {
        logo.addEventListener('load', hide, { once: true });
        logo.addEventListener('error', hide, { once: true });
    } else {
        hide();
    }
}

// Pieces de fusee deja construites : initialise ICI, avant startGame qui
// recharge la sauvegarde (loadGame y ajoute les pieces achetees) — la
// declaration etait avant plus bas dans le fichier, apres l'IIFE d'init,
// ce qui levait une ReferenceError (TDZ) au chargement d'une sauvegarde.
let constructedParts = new Set();


// ============================================
// TIMERS
// ============================================

let bonusSpawnTimer = null;
function scheduleBonusSpawn() {
    const bonus = getCometFrequencyBonus();
    const delay = Math.max(800, BONUS_SPAWN_INTERVAL_MS / (1 + bonus));
    clearTimeout(bonusSpawnTimer);
    bonusSpawnTimer = setTimeout(() => {
        if (!gameplayPaused && !cometShowerActive) {
            // Ciel frequente (V3.10, inf-sky) : jusqu'a 2 cometes isolees
            // simultanees, mais la supplementaire n'a QUE 10% de chances
            // d'apparaitre a chaque cycle (retour playtest : 100% etait
            // trop fort avec les x4).
            const hasSky = getGalacticUpgradeLevel('inf-sky') > 0;
            const maxSolo = hasSky && Math.random() < wasmConst('sky_second_comet_chance', 0.10) ? 2 : 1;
            const beforeCount = document.querySelectorAll('#random-bonuses .random-bonus').length;
            for (let i = beforeCount; i < maxSolo; i++) spawnRandomBonus();
            // La comete SUPPLEMENTAIRE (celle de l'upgrade, la 2e a l'ecran)
            // porte la classe .comet-gold : trainee jaune doree, la distingue
            // de l'ordinaire. Jamais la premiere comete (idx 0).
            const afterAll = document.querySelectorAll('#random-bonuses .random-bonus');
            afterAll.forEach((el, idx) => {
                if (idx >= 1 && idx >= beforeCount) el.classList.add('comet-gold');
            });
        }
        scheduleBonusSpawn();
    }, delay);
}
scheduleBonusSpawn();
// Etat du bouton son au chargement (icône cohérente avec le réglage sauvegardé)
(() => { const b = document.getElementById('sound-toggle-btn'); if (b) { const icon = b.querySelector('img') || document.getElementById('sound-toggle-icon'); if (icon) icon.src = Sound.enabled ? 'images/SoundOn.webp' : 'images/SoundOff.webp'; } })();
// Prechargement du sprite du missile : il n'est insere dans le DOM qu'au
// premier tir, sans ce prechargement le premier missile vole sans image
// le temps du premier telechargement.
(() => { const preload = new Image(); preload.src = 'images/effects/missile.webp'; })();

// ============================================
// PLUIE DE COMÈTES (événement régulier)
// ============================================
// Toutes les 6 minutes PILE (délai fixe, pas d'aléatoire), une cascade
// de comètes dorées traverse l'écran : chacune ne donne que du bonus
// instantané (jamais de flare), pour éviter tout cumul de multiplicateurs.
// Le décompte commence des le premier chargement du jeu : la premiere
// pluie tombe donc elle aussi a 6 minutes, jamais avant.
let cometShowerActive = false;
let firstCometShower = true;
function scheduleCometShower() {
    // Delai FIXE de 6 minutes, identique pour la premiere pluie et les
    // suivantes : le timer tourne des le chargement du jeu.
    // Eclipse totale (V3.5) : pluies 25% plus frequentes (x2 etait trop fort).
    const eclip = getGalacticUpgradeLevel('inf-eclip') > 0 ? 0.8 : 1;
    const delay = (wasmCore() ? wasmCore().comet_shower_interval_ms() : COMET_SHOWER_INTERVAL_MS) * eclip;
    if (firstCometShower) {
        // Lecon comete : armee pour tomber juste apres la premiere pluie,
        // quand le joueur a vraiment vu une comete a l'ecran.
        cometLessonReadyAt = Date.now() + delay;
    }
    firstCometShower = false;
    setTimeout(() => {
        if (gameplayPaused) { scheduleCometShower(); return; }
        startCometShower();
        scheduleCometShower();
    }, delay);
}
function startCometShower() {
    if (cometShowerActive) return;
    cometShowerActive = true;
    Sounds.showerAlert();
    showToast('\ud83c\udf20 ' + t('Pluie de com\u00e8tes ! Attrapez-les !'));
    // Nombre de cometes identique sur mobile et desktop.
    const COUNT = (wasmCore() ? wasmCore().comet_shower_count() : 12);
    const SPREAD_MS = (wasmCore() ? wasmCore().comet_shower_spread_ms() : 8000);
    // Les spawns individuels sont planifies ici par setTimeout : une pause
    // declenchee pendant la pluie purge l'ecran (setGameplayPaused) mais ces
    // spawns deja planifies passaient quand meme au retour. Chacun re-verifie
    // la pause : une comete non spawnee pendant la pause est simplement
    // annulee (comme attrapee-purgee par le gel), pas cumulee apres le gel.
    for (let i = 0; i < COUNT; i++) {
        setTimeout(() => { if (!gameplayPaused) spawnRandomBonus(true); }, (i / COUNT) * SPREAD_MS + Math.random() * 400);
    }
    setTimeout(() => { cometShowerActive = false; }, SPREAD_MS + 8000);
}
scheduleCometShower();
let lastGameTick = Date.now();

// ============================================
// MONITEUR DE PERFORMANCE : mode degrade automatique
// ============================================
// Mesure le taux de rendu reel via rAF. Sous un seuil prolonge (FPS < 30
// pendant 4 s), la classe body.low-perf est posee : les effets decoratifs
// couteux (trainees de cometes, ombres/pulses CSS, pluie de parts densifiee)
// sont reduits ou coupes via CSS + flags JS. Retour au mode normal apres
// 12 s de FPS sains -- l'entree/sortie est volontairement LENTE pour ne
// jamais clignoter en bord de seuil (hysteresis large).
const PerfMonitor = {
    lowPerf: false,
    frames: 0,
    windowStart: 0,
    lowSince: 0,
    goodSince: 0
};
const PERF_FPS_WINDOW_MS = 2000;
// V3.30 : seuil abaisse 28 -> 22 fps -- un jeu tournant a 30 fps sur une
// machine modeste entrait en low-perf par intermittence (chutes ponctuelles
// sous 28), coupant la pluie et l arc-en-ciel pour rien (retours joueur :
// pluie qui s arrete 'de temps en temps', orange qui remplace l arc-en-ciel).
const PERF_FPS_MIN = 22;
const PERF_ENTER_AFTER_MS = 4000;
const PERF_EXIT_AFTER_MS = 12000;
function setLowPerf(on) {
    if (PerfMonitor.lowPerf === on) return;
    PerfMonitor.lowPerf = on;
    document.body.classList.toggle('low-perf', on);
}
// ============================================
// MODE BASSE CONFIG (manuel, persistant) : coupe TOUTES les animations --
// pluie de pieces, trainees de cometes, halos, pulses CSS -- mais garde
// le gameplay intact (production, cometes interceptables, contrats).
// Pose la classe body.low-config (en plus de low-perf) : le joueur garde
// l'option meme apres un redemarrage, et le jeu la lui PROPOSE quand le
// moniteur FPS detecte un navigateur qui rame de facon prolongee.
let lowConfigMode = (localStorage.getItem('starcruiserLowConfig') === '1');
let lowConfigPromptShown = false;
function applyLowConfig() {
    document.body.classList.toggle('low-config', lowConfigMode);
    // En mode basse config, la pluie de pieces est totalement coupee :
    // purge immediate des pieces existantes et plus aucun spawn.
    if (lowConfigMode && typeof partsRain !== 'undefined' && partsRain) {
        partsRain.parts.length = 0;
        partsRain.spawnDebt = 0;
    }
    const btnLbl = document.querySelector('#lowconfig-toggle-label');
    if (btnLbl) btnLbl.textContent = lowConfigMode ? t('Mode basse configuration activé') : t('Mode basse configuration');
}
function toggleLowConfig() {
    lowConfigMode = !lowConfigMode;
    localStorage.setItem('starcruiserLowConfig', lowConfigMode ? '1' : '0');
    applyLowConfig();
}
// Proposition automatique : apres 3 entrees distinctes du moniteur FPS en
// low-perf prolonge, un toast suggere le mode une seule fois par session
// (jamais de spam) -- le joueur clique le bouton des Parametres pour activer.
function maybeSuggestLowConfig() {
    if (lowConfigMode || lowConfigPromptShown) return;
    lowConfigPromptShown = true;
    showToast(t('Votre appareil semble ramer — activez le Mode basse configuration dans les Paramètres pour retirer toutes les animations.'));
}
function perfFrame(now) {
    requestAnimationFrame(perfFrame);
    if (!PerfMonitor.windowStart) PerfMonitor.windowStart = now;
    PerfMonitor.frames++;
    if (now - PerfMonitor.windowStart >= PERF_FPS_WINDOW_MS) {
        const fps = (PerfMonitor.frames * 1000) / (now - PerfMonitor.windowStart);
        PerfMonitor.frames = 0;
        PerfMonitor.windowStart = now;
        if (fps < PERF_FPS_MIN) {
            if (!PerfMonitor.lowSince) PerfMonitor.lowSince = now;
            PerfMonitor.goodSince = 0;
            if (now - PerfMonitor.lowSince >= PERF_ENTER_AFTER_MS) {
                setLowPerf(true);
                // Mode basse config : suggere l'option une fois si le
                // navigateur rame de facon repetee (compteur de triggers).
                PerfMonitor.lowEnterCount = (PerfMonitor.lowEnterCount || 0) + 1;
                if (PerfMonitor.lowEnterCount >= 3) maybeSuggestLowConfig();
            }
        } else {
            PerfMonitor.lowSince = 0;
            if (PerfMonitor.goodSince) {
                if (now - PerfMonitor.goodSince >= PERF_EXIT_AFTER_MS) setLowPerf(false);
            } else {
                PerfMonitor.goodSince = now;
            }
        }
    }
}
requestAnimationFrame(perfFrame);

// V3.85 (chantier perf n3) : GAME LOOP SUR requestAnimationFrame +
// ACCUMULATEUR FIXED TIMESTEP. L economie reste a PAS FIXE 100 ms (les
// gains dependent de dtSeconds calcule dans gameLoop -- comportement
// RIGOUREUSEMENT identique), mais le pilotage change :
//  - setInterval n est PAS synchronise avec le rafraichissement ecran :
//    il arrive entre deux frames, le rendu saute des ticks, et le timer
//    derive (les timers JS ne descendent pas sous ~4-10 ms) ;
//  - rAF s aligne sur le vsync (60/120 Hz), se met EN PAUSE tout seul
//    quand l onglet est cache (batterie mobile : plus de tick en
//    arriere-plan du tout, le credit hors-ligne existe deja) et offre
//    un timestamp fiable.
// L accumulateur : on accumule le temps ecoule, et on joue au PLUS UN
// pas fixe de 100 ms par frame rAF -- le pas reste exact, jamais de
// double-credit si une frame saute (le rattrapage est plafonne par le
// garde hors-ligne existant de gameLoop).
let __rafAccumLast = null;
let __rafAccum = 0;
function rafGameLoop(timestamp) {
    if (__rafAccumLast === null) __rafAccumLast = timestamp;
    // Plafond anti-rattrapage : une frame sautee (onglet cache, lag)
    // ne doit pas empiler des pas -- le credit des grandes absences
    // passe par le chemin hors-ligne existant.
    const elapsed = Math.min(timestamp - __rafAccumLast, 1000);
    __rafAccumLast = timestamp;
    __rafAccum += elapsed;
    if (__rafAccum >= GAME_LOOP_INTERVAL_MS) {
        __rafAccum = 0;
        gameLoop();
    }
    requestAnimationFrame(rafGameLoop);
}
requestAnimationFrame(rafGameLoop);
// V3.85 : le tick contrats a 100 ms ne vit PLUS dans son propre
// setInterval -- il est pilote par le gameLoop (tickConsolidatedTimers).
// Un timer de moins, un reveil de main thread de moins.
setInterval(() => {
    if (!saveDisabled && Date.now() - lastSaveTime > SAVE_INTERVAL_MS) {
        // P7 : l'autosave ne doit pas lever d'erreur non geree (quota
        // localStorage plein, navigation privee) -- un toast unique previent
        // le joueur sans spammer a chaque tick de 10 s.
        try {
            saveGame();
        } catch (e) {
            console.error('Echec de la sauvegarde automatique :', e);
            if (!window.__saveFailToastShown) {
                window.__saveFailToastShown = true;
                try { showToast("\u26a0\ufe0f " + t("Sauvegarde impossible. Lib\u00e8re de l'espace de stockage.")); } catch (e2) {}
            }
        }
    }
}, 10000);

// Sauvegarde immédiate à la fermeture de l'onglet / navigation :
// l'autosave tourne toutes les 30s, sans ce hook le joueur pouvait
// perdre jusqu'a SAVE_INTERVAL_MS de progression en fermant vite.
window.addEventListener('beforeunload', () => {
    if (saveDisabled) return;
    try { saveGame(); } catch (e) { /* dernier recours : ne pas bloquer la fermeture */ }
});
// Idem sur mobile : l'onglet passe en arriere-plan sans beforeunload fiable.
document.addEventListener('visibilitychange', () => {
    if (document.hidden && !saveDisabled) {
        try { saveGame(); } catch (e) {}
    }
});

// ============================================
// GESTION D'ERREURS GLOBALE
// ============================================
// Objectif : un joueur qui rencontre un bug doit (1) garder sa
// sauvegarde (save avant tout), (2) voir un message plutot qu'un jeu
// fige en silence. Les erreurs de chargement des ressources non
// critiques (images) sont ignorees.
let errorToastShown = false;
window.addEventListener('error', (event) => {
    if (event.target && event.target.tagName === 'IMG') return;
    try { saveGame(); } catch (e) {}
    if (!errorToastShown) {
        errorToastShown = true;
        if (typeof showToast === 'function' && typeof t === 'function') {
            showToast('\u26a0\ufe0f ' + t("Une erreur inattendue est survenue. Votre progression est sauvegard\u00e9e."));
        }
    }
});
window.addEventListener('unhandledrejection', (event) => {
    try { saveGame(); } catch (e) {}
    if (!errorToastShown) {
        errorToastShown = true;
        if (typeof showToast === 'function' && typeof t === 'function') {
            showToast('\u26a0\ufe0f ' + t("Une erreur inattendue est survenue. Votre progression est sauvegard\u00e9e."));
        }
    }
});

// Initialisation des que le script s'execute (il est charge en fin de body,
// le DOM est deja parse) : NE PAS attendre window.onload — il ne se declenche
// qu'une fois TOUTES les ressources chargees (polices Google, images), et
// sur une premiere visite vierge une ressource lente/bloquee figeait
// l'ecran de chargement indéfiniment.
(function startGame() {
    if (typeof initLanguage === 'function') initLanguage();
    init();
    if (!gameStartTime) {
        gameStartTime = Date.now();
    }
    // Recalage de la scene une fois le layout stabilise : polices, images,
    // et dimensions finales de la scene. Plusieurs passes car le premier
    // rendu a lieu avant l'application complete du CSS.
    requestAnimationFrame(applySceneScale);
    setTimeout(applySceneScale, 100);
    setTimeout(applySceneScale, 400);
    window.addEventListener('load', applySceneScale);
    if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(applySceneScale);
    }
})();






// ============================================
// ROCKET PARTS SHOP (achats uniques)
// ============================================

function getRocketPartCost(part) {
    const discount = Math.min(0.5, getRocketPartDiscount());
    // Les prix montent avec le multiplicateur de production general FIGE
    // au dernier reset : chaque expedition rend la fusee suivante plus
    // puissante (prestige, planetes, collection...), les pieces coutent
    // d'autant plus cher -- mais le calcul se fait UNE fois par expedition,
    // pas en continu, pour ignorer bonus temporaires et achats en cours.
    return Math.floor(part.cost * Math.pow(rocketPartCostGrowth(rocketsLaunched), rocketsLaunched) * partCostMultiplier * (1 - discount));
}

function buyRocketPart(partId) {
    const part = ROCKET_PARTS.find(p => p.id === partId);
    if (!part || part.purchased) return;
    const cost = getRocketPartCost(part);
    if (score < cost) {
        showToast(t("Pas assez de Parts pour") + " " + t(part.name));
        return;
    }
    score -= cost;
    Sounds.partBuilt();
    part.purchased = true;
    // Sans invalidation du cache des gains, le +4% de production de la piece
    // ne s'appliquait pas immediatement (pps fige jusqu'au prochain achat
    // de batiment) — le bonus semblait ne jamais s'appliquer.
    invalidateBuildingGainsCache();
    showBuyFeedback(document.getElementById('rocket-parts-shop'), '-' + formatNumber(cost) + ' ' + t('Parts'), '+4% ' + t('production'));
    updateDisplay();
    updateConstructionScene();
    const builtCard = document.querySelector('#rocket-parts-shop .rocket-part-frame');
    if (builtCard) { builtCard.classList.remove('part-built-flash'); void builtCard.offsetWidth; builtCard.classList.add('part-built-flash'); }
    renderRocketPartsShop();
    checkBuildingUnlocks();
    saveGame();
    // Plus de toast de confirmation d'achat de piece : l'animation de chute
    // sur la scene EST le feedback, le toast spam a chaque piece etait
    // inutile (demande explicite).
    checkTrophies();
}

// Auto-ajustement de la police du label de la barre de progression des
// pieces de fusee : le texte long (Construire -- 1.23K / 45.6K Parts)
// passait sur DEUX lignes sur mobile, cassant la hauteur de la case.
// Meme approche que fitCounterFontSize : on reduit d'un cran jusqu'a ce
// que le label tienne sur UNE ligne.
function fitRocketPartProgressLabels() {
    document.querySelectorAll('.rocket-part-progress-label').forEach(el => {
        if (el.style.fontSize) { el.style.fontSize = ''; void el.offsetWidth; }
        let fs = parseFloat(getComputedStyle(el).fontSize) || 14;
        const minFs = 9;
        let guard = 0;
        // scrollHeight > ~1.4 ligne = retour a la ligne detecte
        while (el.scrollWidth > el.clientWidth + 1 && fs > minFs && guard < 10) {
            fs = Math.max(minFs, fs * 0.88);
            el.style.fontSize = fs.toFixed(1) + 'px';
            guard++;
        }
    });
}

function renderRocketPartsShop() {
    const container = document.getElementById('rocket-parts-shop');
    if (!container) return;
    updateLaunchButtonVisibility();
    const nextPart = ROCKET_PARTS.find(p => !p.purchased);
    if (!nextPart) {
        // Toutes les pieces sont achetees : la boutique est masquee par la
        // classe .shop-done (posee par updateLaunchButtonVisibility) -- la
        // carte "Pieces completes" n'existe plus, seul le bouton LANCER,
        // agrandi, occupe le bas du panneau central. On vide juste le DOM.
        clearPulseHint(container);
        if (container.dataset.partId !== '__complete__') {
            container.dataset.partId = '__complete__';
            container.innerHTML = '';
        }
        return;
    }
    const cost = getRocketPartCost(nextPart);
    const isAffordable = score >= cost;
    // Calcule au niveau de la fonction : la branche de mise a jour (else)
    // en a besoin aussi, sinon ReferenceError au changement de langue.
    const purchasedCount = ROCKET_PARTS.filter(p => p.purchased).length;
    // Ne recreer le DOM que si la piece affichee change. Sinon, mettre a jour
    // uniquement la barre et les textes pour eviter le clignotement du hover.
    if (container.dataset.partId !== nextPart.id) {
        container.dataset.partId = nextPart.id;
        const imageUrl = nextPart.imgPath || '';
        const imageHtml = imageUrl
            ? '<img src="' + imageUrl + '" class="rocket-part-icon" alt="' + nextPart.name + '">'
            : '<span class="rocket-part-icon-placeholder"></span>';
        // Deux parties : image a gauche, informations a droite.
        container.innerHTML =
            '<div class="rocket-part-frame' + (!isAffordable ? ' locked' : '') + '" onclick="buyRocketPart(' + String.fromCharCode(39) + nextPart.id + String.fromCharCode(39) + ')">' +
                '<div class="rocket-part-img">' + imageHtml + '</div>' +
                '<div class="rocket-part-info">' +
                    '<div class="rocket-part-headline">' +
                        '<span class="rocket-part-name">' + t(nextPart.name) + '</span>' +
                        '<span class="rocket-part-mult">\u00d7' + (1 + 0.04 * (purchasedCount + 1)).toFixed(2) + ' ' + t('production') + '</span>' +
                    '</div>' +
                    '<div class="rocket-part-progress">' +
                        '<div class="rocket-part-progress-fill"></div>' +
                        '<span class="rocket-part-progress-label">' + formatNumber(Math.floor(score)) + ' / ' + formatNumber(cost) + ' ' + t('Parts') + '</span>' +
                    '</div>' +
                '</div>' +
            '</div>';
    } else {
        const fillEl = container.querySelector('.rocket-part-progress-fill');
        const labelEl = container.querySelector('.rocket-part-progress-label');
        if (fillEl) fillEl.style.width = Math.min(100, (score / cost) * 100) + '%';
        if (labelEl) labelEl.textContent = t('Construire') + ' \u2014 ' + formatNumber(Math.floor(score)) + ' / ' + formatNumber(cost) + ' ' + t('Parts');
        const nameEl = container.querySelector('.rocket-part-name');
        if (nameEl) nameEl.textContent = t(nextPart.name);
        const multEl = container.querySelector('.rocket-part-mult');
        if (multEl) multEl.textContent = '\u00d7' + (1 + 0.04 * (purchasedCount + 1)).toFixed(2) + ' ' + t('production');
        fitRocketPartProgressLabels();
        const frame = container.querySelector('.rocket-part-frame');
        if (frame) {
            if (isAffordable) frame.classList.remove('locked');
            else frame.classList.add('locked');
        }
    }
    // Piece de fusee abordable : pulse pour attirer l'oeil (10 s max).
    const fillEl0 = container.querySelector('.rocket-part-progress-fill');
    const labelEl0 = container.querySelector('.rocket-part-progress-label');
    if (fillEl0) fillEl0.style.width = Math.min(100, (score / cost) * 100) + '%';
    if (labelEl0) labelEl0.textContent = t('Construire') + ' \u2014 ' + formatNumber(Math.floor(score)) + ' / ' + formatNumber(cost) + ' ' + t('Parts');
    const partCard = container.querySelector('.rocket-part-frame');
    if (partCard) {
        if (isAffordable) pulseHint(partCard);
        else clearPulseHint(partCard);
    }
    fitRocketPartProgressLabels();
}

// ============================================
// ROCKET CONSTRUCTION SCENE
// ============================================
function updateConstructionScene() {
    const container = document.getElementById('rocket-parts-container');
    if (!container) return;

    // Ne pas vider le conteneur, on va juste ajouter les nouvelles pièces
    // container.innerHTML = '';

    ROCKET_PARTS.forEach(part => {
        // Les pièces de fusée s'affichent une fois achetées
        const shouldDisplay = part.purchased;
        
        // Vérifier si la pièce existe déjà dans le DOM
        const existingPiece = container.querySelector(`.rocket-piece.${part.id}`);
        
        if (shouldDisplay && !existingPiece) {
            // La pièce n'existe pas encore, la créer
            const piece = document.createElement('div');
            piece.className = `rocket-piece ${part.id}`;
            piece.title = t(part.name);
            
            // Positionnement en pixels pour empilement parfait
            const x = part.x || 50;
            const y = part.y || 0;
            const width = part.width || 150;
            const height = part.height || 150;
            
            // Appliquer les styles de position
            piece.style.left = x + '%';
            piece.style.top = y + 'px';
            piece.style.width = width + 'px';
            piece.style.height = height + 'px';
            piece.style.zIndex = '3';
            applySceneScale();
            
            // Use image if available, fallback to emoji
            if (part.imgPath) {
                const img = document.createElement('img');
                img.src = part.imgPath;
                img.alt = part.name;
                img.loading = 'lazy';
                piece.appendChild(img);
                // Le CORPS de la fusee porte le nom de l'entreprise :
                // lettres verticales (haut en bas), taille auto-ajustee
                // a la longueur du nom pour toujours rester dans la piece.
                if (part.id === 'rocket-body') {
                    const nameTag = document.createElement('div');
                    nameTag.className = 'rocket-name-tag';
                    const nm = getCompanyName();
                    nameTag.textContent = nm || 'STARCruiser';
                    piece.appendChild(nameTag);
                }
            } else {
                piece.textContent = part.image;
            }
            

            // Animation de chute depuis le haut
            piece.style.opacity = '0';
            piece.style.transform = 'translate(-50%, -200px) scale(0.8)';
            
            requestAnimationFrame(() => {
                piece.style.transition = 'all 0.6s ease-out';
                piece.style.opacity = '1';
                piece.style.transform = 'translate(-50%, 0) scale(1)';
            });
            
            // Marquer comme construite
            if (!constructedParts.has(part.id)) {
                constructedParts.add(part.id);
                piece.classList.add('new', 'unlocked');
                spawnBuildDust(container, part);
                // Bruit d'empilement au moment où la pièce touche la fusée
                // (0.55 s ≈ fin de l'animation de chute de 0.6 s)
                setTimeout(() => Sounds.partStack(), 550);
                setTimeout(() => {
                    piece.classList.remove('new');
                }, 600);
            } else {
                piece.classList.add('unlocked');
            }
            
            container.appendChild(piece);
            // Nom sur le corps : ajuster la taille a la longueur du mot.
            const tag = piece.querySelector('.rocket-name-tag');
            if (tag) fitRocketNameTag(tag);
        }
    });
    
    // Check if rocket is complete
    checkRocketComplete();
}

// Effet de poussiere de construction : quand une piece atterrit, des particules
// jaillissent aux points ou elle touche les pieces deja en place (ou le sol
// pour la premiere piece posee). Les coordonnees des pieces sont en px dans le
// repere 100x100 du conteneur (part.x %, part.y px, ancrage haut-centre).
function spawnBuildDust(container, newPart) {
    const contacts = [];
    const newLeft = (newPart.x || 50) / 100 * 100;
    const newWidth = newPart.width || 150;
    const newTop = newPart.y || 0;
    const newBottom = newTop + (newPart.height || 150);
    ROCKET_PARTS.forEach(other => {
        if (other.id === newPart.id || !other.purchased) return;
        const oTop = other.y || 0;
        const oBottom = oTop + (other.height || 150);
        const oLeftPct = other.x || 50;
        const oWidth = other.width || 150;
        // Piece posee sur le dessus d'une autre : le bas de la nouvelle
        // touche le haut de l'existante.
        if (Math.abs(newBottom - oTop) <= 6) {
            contacts.push({ x: oLeftPct, y: oTop });
        } else if (Math.abs(newTop - oBottom) <= 6) {
            // Piece glissee sous une autre (ex. tuyeres sous moteurs).
            contacts.push({ x: oLeftPct, y: newTop });
        } else if (newTop < oBottom && newBottom > oTop && Math.abs(oLeftPct - (newPart.x || 50)) < 12) {
            // Pieces collees lateralement (ex. boosters) : poussiere sur
            // toute la zone de contact vertical commun.
            const overlapTop = Math.max(newTop, oTop);
            const overlapBottom = Math.min(newBottom, oBottom);
            const steps = Math.max(2, Math.min(5, Math.floor((overlapBottom - overlapTop) / 80)));
            for (let i = 0; i <= steps; i++) {
                contacts.push({ x: ((newPart.x || 50) + oLeftPct) / 2, y: overlapTop + (overlapBottom - overlapTop) * i / steps });
            }
        }
    });
    if (!contacts.length) return;
    // Maximum 3 points de contact par piece : au-dela la poussiere fait un nuage opaque.
    while (contacts.length > 3) {
        contacts.splice(Math.floor(Math.random() * contacts.length), 1);
    }
    // Delai = duree de l'animation de chute : la poussiere jaillit a l'impact.
    setTimeout(() => {
        if (!container.isConnected) return;
        contacts.forEach(c => {
            const count = 7;
            for (let i = 0; i < count; i++) {
                const dust = document.createElement('div');
                dust.className = 'build-dust';
                const angle = (Math.PI * (0.15 + Math.random() * 0.7)) * (Math.random() < 0.5 ? 1 : -1);
                const dist = 18 + Math.random() * 34;
                dust.style.left = c.x + '%';
                dust.style.top = c.y + 'px';
                dust.style.setProperty('--dx', (Math.cos(angle) * dist).toFixed(1) + 'px');
                dust.style.setProperty('--dy', (-Math.abs(Math.sin(angle)) * dist - 12).toFixed(1) + 'px');
                dust.style.animationDelay = (Math.random() * 0.12).toFixed(2) + 's';
                container.appendChild(dust);
                dust.addEventListener('animationend', () => dust.remove());
            }
        });
    }, 600);
}

// Ajuste la taille du nom vertical pour qu'il tienne dans le corps de
// la fusee : police proportionnelle a la hauteur dispo / nb de lettres.
function fitRocketNameTag(tag) {
    const len = Math.max(1, (tag.textContent || '').length);
    // CORPS : y=337, height=200 -> hauteur utile 200px, on occupe 94%
    // soit 188px. Orbitron UPPERCASE est large : budget 1.45 par lettre
    // (glyphe + interlettrage) pour ne JAMAIS etre coupe, meme a 20 car.
    // ANCRAGE BAS DU RESERVOIR : le nom part de ~595 (bas du reservoir)
    // et monte -- hauteur utile ~250px (reservoir 58 + corps 200), avec
    // marge de securite -> 235px budget.
    const availH = 235;
    const size = Math.max(8, Math.min(30, Math.floor(availH / (len * 1.5))));
    tag.style.fontSize = size + 'px';
    tag.style.letterSpacing = Math.max(0, Math.min(2, 12 / len)) + 'px';
}

// Rafraichir le nom affiche sur la fusee (appele apres validation du nom).
function refreshRocketNameTag() {
    const tag = document.querySelector('.rocket-piece.rocket-body .rocket-name-tag');
    if (!tag) return;
    tag.textContent = getCompanyName() || 'STARCruiser';
    fitRocketNameTag(tag);
}

function checkRocketComplete() {
    const allConstructed = ROCKET_PARTS.every(p => p.purchased && constructedParts.has(p.id));
    
    const scene = document.getElementById('construction-scene');
    if (allConstructed && scene) {
        scene.classList.add('rocket-complete');
    } else if (scene) {
        scene.classList.remove('rocket-complete');
    }
    checkNextPlanetNotification();
}
function checkNextPlanetNotification() {
    if (nextPlanetNotified) return;
    const allConstructed = ROCKET_PARTS.every(p => p.purchased && constructedParts.has(p.id));
    if (!allConstructed) return;
    // Suite infinie (Amas de Virgo depasse) : plus d'objectif planetaire,
    // le pop-up "fusee complete / derniere destination" n'a plus de sens.
    if (postVirgoStardust > 0) { nextPlanetNotified = true; return; }
    // COHERENCE (v2) : le pop-up s'active quand la portée COURANTE
    // dépasse la PREMIÈRE PLANÈTE NON DÉBLOQUÉE -- exactement l'objectif
    // affiché dans la colonne « Prochaine destination ». La v1 du fix
    // comparait la portée à la planète SUIVANT la portée (trop tard) ;
    // l'original comparait au record (trop tôt et menteur). Les trois
    // références (test, pop-up, colonne) sont alignées sur l'objectif réel.
    const reachable = calculateDistance();
    const firstLocked = PLANETS.find(pl => pl.id !== 'earth' && !unlockedPlanets.has(pl.id));
    const kmReached = !firstLocked || reachable >= firstLocked.distanceRequired;
    if (kmReached) {
        nextPlanetNotified = true;
        showNextPlanetNotification();
    }
}
function showNextPlanetNotification() {
    const notif = document.getElementById('next-planet-notification');
    if (!notif) return;
    // Meme coherence v2 : la planete affichee est la premiere planete
    // NON DEBLOQUEE (l'objectif reel), identique au test d'activation.
    const planet = PLANETS.find(pl => pl.id !== 'earth' && !unlockedPlanets.has(pl.id)) || null;
    const imgEl = document.getElementById('npn-planet-img');
    const nameEl = document.getElementById('npn-planet-name');
    const distEl = document.getElementById('npn-planet-distance');
    if (planet) {
        imgEl.src = planet.imgPath;
        nameEl.textContent = t(planet.name);
        distEl.textContent = formatNumber(planet.distanceRequired) + ' km';
    } else {
        imgEl.src = 'images/rocket/Fusée3.webp';
        nameEl.textContent = t('Dernière destination atteinte !');
        distEl.textContent = '';
    }
    notif.classList.add('active');
}
function closeNextPlanetNotification() {
    const notif = document.getElementById('next-planet-notification');
    if (notif) notif.classList.remove('active');
}
