// Service worker Starcruiser Clicker.
//
// Strategie : NETWORK-FIRST sur tout le site. Chaque requete va d'abord au
// reseau ; le cache n'est qu'un fallback hors-ligne. Un simple F5 recupere
// donc TOUJOURS la derniere version deployee, meme apres un depot GitHub
// Pages sous un sous-chemin (/Starcruiser-Clicker/).
//
// Mise a jour du SW lui-meme : pas de skipWaiting a l'install. Le nouveau SW
// reste en etat "waiting" ; la page le detecte, affiche le bouton
// "Recharger", lui envoie SKIP_WAITING au clic, puis recharge la page quand
// il prend le controle (controllerchange).
const CACHE_NAME = 'starcruiser-clicker-vccb0c755a';;;;;;;;;;;;;

self.addEventListener('install', (event) => {
    // Precache minimal (fallback hors-ligne). Les echecs individuels sont
    // ignores : une image manquante ne doit pas bloquer l'installation.
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache =>
            Promise.allSettled([
                './',
                './index.html',
                './game.html',
                './legal.html',
                './records.html',
                './actualites.html',
                './style.css',
                './leaderboard-config.js',
                './leaderboard-shared.js',
                './script.js',
                './i18n.js',
                './manifest.json',
                './wasm/wasm-core-loader.js',
                './wasm/build/starcruiser_core.js',
                './wasm/build/starcruiser_core_bg.wasm'
            ].map(url => cache.add(url)))
        )
    );
});

self.addEventListener('activate', (event) => {
    // Supprime tous les caches obsoletes, prend le controle des clients
    // ouverts, puis annonce sa version (la page compare avec la sienne).
    event.waitUntil(
        caches.keys().then(keys => Promise.all(
            keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
        )).then(() => self.clients.claim()).then(() => self.clients.matchAll()).then(clients => {
            clients.forEach(client => client.postMessage({ type: 'SW_VERSION', version: CACHE_NAME }));
        })
    );
});

// Activation demandee par la page (bouton "Recharger").
self.addEventListener('message', (event) => {
    if (event.data === 'SKIP_WAITING') self.skipWaiting();
    // PING de version : la page demande la version du SW ACTIF a chaque
    // chargement. Sans lui, la comparaison n'avait lieu qu'a l'activation
    // d'un nouveau SW -- si aucun updatefound ne survenait dans la session
    // (cache HTTP, reg.update sans changement), le joueur restait sur une
    // vieille version SANS jamais voir le pop-up de mise a jour.
    if (event.data === 'SW_PING') {
        event.source.postMessage({ type: 'SW_VERSION', version: CACHE_NAME });
    }
});

self.addEventListener('fetch', (event) => {
    const request = event.request;
    if (request.method !== 'GET') return;

    const url = new URL(request.url);

    // Google Fonts : reseau direct, jamais de stale.
    if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') return;

    // Hors origine : reseau direct.
    if (url.origin !== self.location.origin) return;

    // IMAGES : STALE-WHILE-REVALIDATE. Elles sont immuables entre deux
    // deploiements (le bump de version SW gere les vrais changements) et le
    // jeu les recree sans arret (re-render des tuiles batiments/upgrades
    // apres chaque achat). Le network-first avec cache:'no-cache' les
    // faisait RECHARGER depuis le reseau a chaque re-render -- tres visible
    // sur mobile (scintillement + latence). Desormais : reponse IMMEDIATE
    // du cache SW si presente, revalidation discrete en arriere-plan.
    if (request.destination === 'image' || /\.(webp|png|jpe?g|gif|svg|ico)$/i.test(url.pathname)) {
        event.respondWith(
            caches.open(CACHE_NAME).then(cache =>
                cache.match(request).then(cached => {
                    // Revalidation arriere-plan dans les DEUX cas : le cache
                    // SW reste synchronise avec le serveur.
                    const refresh = fetch(request, { cache: 'no-cache' }).then(response => {
                        if (response && response.ok) cache.put(request, response.clone());
                        return response;
                    }).catch(() => null);
                    if (cached) return cached;
                    return refresh.then(r => r || Response.error());
                })
            )
        );
        return;
    }

    // NETWORK-FIRST + BYPASS DU CACHE HTTP : fetch(request) respectait le
    // cache HTTP de GitHub Pages (max-age 10 min) -- le SW recevait donc
    // les VIEUX fichiers meme en network-first, et les changements de
    // police/taille n'arrivaient jamais sans Ctrl+Shift+R. cache:'no-cache'
    // force la revalidation reseau a CHAQUE requete : toujours frais.
    // Le cache SW ne reste qu'un fallback hors-ligne.
    event.respondWith(
        fetch(request, { cache: 'no-cache' }).then(response => {
            if (response && response.ok) {
                const copy = response.clone();
                caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
            }
            return response;
        }).catch(() =>
            caches.match(request).then(cached => cached
                // Fallback HTML UNIQUEMENT pour les navigations de page :
                // une ressource manquante (JS/CSS) ne doit JAMAIS recevoir
                // du HTML a sa place -- cela corrompt le chargement du jeu.
                || (request.mode === 'navigate' ? caches.match('./index.html') : undefined))
        )
    );
});
