// Umami analytics — file d'attente : les evenements sont mis en memoire
// tant que le script Umami n'est pas charge (chargement async sur CDN).
// Configuration via les attributs data-umami-* de la balise script.
(function () {
    'use strict';
    var queue = [];
    var UMI = {
        ready: false,
        track: function (name, props) {
            if (typeof window.umami === 'undefined') {
                queue.push([name, props || {}]);
                return;
            }
            try {
                window.umami.track(name, props || {});
            } catch (e) { /* analytics ne doit jamais casser le jeu */ }
        },
        flush: function () {
            while (queue.length) {
                var ev = queue.shift();
                UMI.track(ev[0], ev[1]);
            }
        }
    };
    // Poll leger : si le script charge apres le premier evenement,
    // la file est videe des qu'il est dispo.
    var pollCount = 0;
    var poll = setInterval(function () {
        if (typeof window.umami !== 'undefined') {
            clearInterval(poll);
            UMI.ready = true;
            UMI.flush();
        } else if (++pollCount > 60) {
            clearInterval(poll); // ~30s : abandon silencieux
        }
    }, 500);
    window.UMI = UMI;
})();
