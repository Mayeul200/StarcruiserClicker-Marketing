// Lib PARTAGEE classement : consommee par records.html (page publique) et
// prete pour toute future page. Regle la divergence historique jeu/page :
// le limit=100 vs 50 et le formatage des nombres differaient entre
// script.js et records.html -- une seule source desormais.
//
// Doit etre chargee APRES leaderboard-config.js (SUPABASE_URL/KEY).

// Plafond d'entrees identique au jeu (LEADERBOARD_MAX_ENTRIES de script.js).
var LB_SHARED_MAX_ENTRIES = 50;

// Timeout d'un appel reseau : jamais bloquer une page sur le classement.
var LB_SHARED_TIMEOUT_MS = 5000;

// Lecture du classement : global (Supabase) si configure, sinon fallback
// localStorage (starcruiserLeaderboard). Retourne { entries, source } avec
// source = 'global' | 'local'. Les entrees sont normalisees : nom coupe a
// 20 caracteres, vitesse/at numeriques.
function lbSharedFetchLeaderboard() {
    return new Promise(function (resolve) {
        var result = { entries: [], source: 'local' };
        var supabaseOk = typeof SUPABASE_URL !== 'undefined' && SUPABASE_URL
            && typeof SUPABASE_ANON_KEY !== 'undefined' && SUPABASE_ANON_KEY;
        if (!supabaseOk) { resolve(result); return; }
        var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var kill = setTimeout(function () { if (ctrl) ctrl.abort(); }, LB_SHARED_TIMEOUT_MS);
        fetch(SUPABASE_URL + '/rest/v1/leaderboard?select=name,speed,distance,rockets,clicks,at&order=speed.desc&limit=' + LB_SHARED_MAX_ENTRIES, {
            headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': 'Bearer ' + SUPABASE_ANON_KEY },
            signal: ctrl ? ctrl.signal : undefined
        }).then(function (res) {
            clearTimeout(kill);
            if (!res.ok) throw new Error('http ' + res.status);
            return res.json();
        }).then(function (rows) {
            if (Array.isArray(rows) && rows.length) {
                result.entries = lbSharedNormalize(rows);
                result.source = 'global';
            }
            resolve(result);
        }).catch(function () {
            clearTimeout(kill);
            resolve(result);
        });
    });
}

// Fallback local : le classement du navigateur uniquement si le global n'a
// rien donne. Retourne { entries, source } normalise.
function lbSharedLocalLeaderboard() {
    var entries = [];
    try {
        var raw = localStorage.getItem('starcruiserLeaderboard');
        var arr = raw ? JSON.parse(raw) : [];
        if (Array.isArray(arr)) entries = lbSharedNormalize(arr);
    } catch (e) {}
    return { entries: entries, source: 'local' };
}

// Normalisation commune des entrees (global comme local).
function lbSharedNormalize(rows) {
    return rows
        .filter(function (e) { return e && typeof e.name === 'string' && isFinite(e.speed); })
        .map(function (e) {
            return {
                name: String(e.name).slice(0, 20),
                speed: Number(e.speed) || 0,
                distance: Number(e.distance) || 0,
                rockets: Number(e.rockets) || 0,
                clicks: Number(e.clicks) || 0,
                at: Number(e.at) || 0
            };
        });
}

// Formatage ALIGNE sur formatNumber de script.js (suffixes, virgule
// decimale) -- version autonome sans dependance au jeu. Les suffixes
// couvrent le meme domaine que le jeu ; au-dela : notation scientifique.
function lbSharedFormatNumber(num) {
    if (num === 0) return '0';
    var absNum = Math.abs(num);
    if (absNum < 1000) {
        return num % 1 === 0 ? Math.round(num).toString() : num.toFixed(1);
    }
    var suffixes = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi', 'Sx', 'Sp', 'Oc', 'No', 'De', 'Ud', 'Dd', 'Td', 'Qad', 'Qid', 'Sxd', 'Spd', 'Ocd', 'Nod', 'Vg', 'Uvg', 'Dvg', 'Tvg', 'Qavg', 'Qivg', 'Sxvg', 'Spvg', 'Ocvg', 'Novg', 'Tg', 'Utg', 'Dtg', 'Qtg'];
    var tier = Math.floor(Math.log10(absNum) / 3);
    if (tier >= suffixes.length) {
        var exp = Math.floor(Math.log10(absNum));
        return (num / Math.pow(10, exp)).toFixed(2).replace('.', ',') + ' x 10^' + exp;
    }
    var scaled = num / Math.pow(10, tier * 3);
    var scaledAbs = Math.abs(scaled);
    var decimals = scaledAbs >= 100 ? 2 : 3;
    return scaled.toFixed(decimals).replace('.', ',') + (suffixes[tier] ? ' ' + suffixes[tier] : '');
}

// Echappement HTML commun (noms du classement affiches dans le DOM).
function lbSharedEscapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
}
