// Configuration du classement mondial (Supabase).
// Charge par game.html (jeu) et records.html (page des records) :
// un seul endroit a renseigner.
//
// RENSEIGNER les deux valeurs ci-dessous depuis le Dashboard Supabase
// (Settings > API) :
//   SUPABASE_URL      : "https://xxxx.supabase.co"
//   SUPABASE_ANON_KEY : la cle "anon public" (publique par design,
//                        protegee par les policies RLS du fichier
//                        server/supabase-leaderboard.sql)
const SUPABASE_URL = 'https://wcuvrcfypivazubokuxa.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjdXZyY2Z5cGl2YXp1Ym9rdXhhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE3NTI2MTQsImV4cCI6MjEwNzMyODYxNH0.r6LmXgwyZPmClQlGskVxd4PrgzGK7kgH7N8i5bbKflA';
