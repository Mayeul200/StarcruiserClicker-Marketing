use std::cell::Cell;
use wasm_bindgen::prelude::*;

thread_local! {
    static MAX_TRAVEL_SPEED: Cell<f64> = Cell::new(0.0);
    static MAX_DISTANCE: Cell<f64> = Cell::new(0.0);
}

// ============================================================
// DISTANCE / VITESSE (formules des records)
// ============================================================
#[wasm_bindgen]
pub fn k_distance() -> f64 { 384400.0 / 2.5e7 }

#[wasm_bindgen]
pub fn dist(parts: f64, parts_mult: f64, distance_bonus: f64) -> f64 {
    if parts <= 0.0 { return 0.0; }
    let k = 384400.0 / 2.5e7;
    let score_factor = if parts <= 2.5e7 {
        parts * k
    } else {
        384400.0 * (parts / 2.5e7)
    };
    score_factor * parts_mult * distance_bonus
}

#[wasm_bindgen]
pub fn speed(parts: f64, pps: f64, parts_mult: f64, distance_bonus: f64) -> f64 {
    if parts <= 0.0 || pps <= 0.0 { return 0.0; }
    let k = 384400.0 / 2.5e7;
    let d_factor = if parts <= 2.5e7 {
        k
    } else {
        384400.0 / 2.5e7
    };
    pps * parts_mult * d_factor * distance_bonus
}

#[wasm_bindgen]
pub fn set_record_speed(v: f64) {
    if v.is_finite() && v > 0.0 {
        MAX_TRAVEL_SPEED.with(|m| if v > m.get() { m.set(v); });
    }
}

#[wasm_bindgen]
pub fn get_record_speed() -> f64 { MAX_TRAVEL_SPEED.with(|m| m.get()) }

#[wasm_bindgen]
pub fn set_record_distance(v: f64) {
    if v.is_finite() && v > 0.0 {
        MAX_DISTANCE.with(|m| if v > m.get() { m.set(v); });
    }
}

#[wasm_bindgen]
pub fn get_record_distance() -> f64 { MAX_DISTANCE.with(|m| m.get()) }

// ============================================================
// CONSTANTES DES RECORDS : COMETES / FLARE / METEORES
// ============================================================
#[wasm_bindgen]
pub fn comet_shower_interval_ms() -> f64 { 6.0 * 60.0 * 1000.0 }

#[wasm_bindgen]
pub fn comet_shower_count() -> u32 { 12 }

#[wasm_bindgen]
pub fn comet_shower_spread_ms() -> f64 { 8000.0 }

#[wasm_bindgen]
pub fn contract_comet_interval_ms() -> f64 { 330.0 }

#[wasm_bindgen]
pub fn flare_multiplier() -> f64 { 2.0 }

#[wasm_bindgen]
pub fn flare_duration_ms() -> f64 { 15000.0 }

#[wasm_bindgen]
pub fn meteor_gain_shower() -> f64 { 30.0 }

#[wasm_bindgen]
pub fn meteor_gain_solo() -> f64 { 10.0 }

// ============================================================
// CARTES DE COLLECTION : bonus par rarete (5 valeurs)
// Appel type : card_bonus_mult(rarity) avec rarity en 0..=4
// (0=common, 1=rare, 2=epic, 3=legendary, 4=alternative)
// ============================================================
#[wasm_bindgen]
pub fn card_bonus_mult(rarity: u32) -> f64 {
    match rarity {
        0 => 0.01,
        1 => 0.03,
        2 => 0.08,
        3 => 0.20,
        4 => 0.50,
        _ => 0.0,
    }
}

// Bonus de collection complet : +0.20 quand l'album est complet
#[wasm_bindgen]
pub fn collection_complete_bonus() -> f64 { 0.20 }

// Chance de rarete superieure dans les boosters (par type, 0=standard,
// 1=premium, 2=legendary) : probabilites cumulees par rarete.
// Retourne la probabilite de la rarete r dans le booster b.
#[wasm_bindgen]
pub fn booster_rarity_prob(booster: u32, rarity: u32) -> f64 {
    match (booster, rarity) {
        (0, 0) => 0.80, (0, 1) => 0.18, (0, 2) => 0.02,
        (1, 0) => 0.50, (1, 1) => 0.30, (1, 2) => 0.15, (1, 3) => 0.05,
        (2, 0) => 0.20, (2, 1) => 0.35, (2, 2) => 0.25, (2, 3) => 0.15, (2, 4) => 0.05,
        _ => 0.0,
    }
}

// ============================================================
// UPGRADES GALACTIQUES : effectPerLevel de chaque upgrade qui
// impacte la production, les clics ou la collection.
// L'ID est passe en index ; l'ordre correspond a l'inventaire JS
// documente dans wasm/README.md (l'application JS fait la traduction).
// ============================================================
#[wasm_bindgen]
pub fn upgrade_effect_per_level(id: u32) -> f64 {
    match id {
        0 => 0.25,   // prod1
        1 => 0.35,   // prod2
        2 => 0.45,   // prod3
        3 => 0.55,   // prod4
        4 => 0.65,   // prod5
        5 => 0.75,   // prod6
        6 => 0.85,   // prod7
        7 => 1.00,   // prod8
        10 => 1.5,   // click1
        11 => 0.025, // click2 (crit chance)
        12 => 1.75,  // click3
        13 => 0.10,  // click4 (crit chance)
        14 => 2.0,   // click5
        15 => 0.05,  // click6 (crit chance)
        16 => 2.5,   // click7
        17 => 1.0,   // click8
        20 => 0.20,  // coll4 (boost des cartes possedees)
        30 => 0.20,  // inf-boost (Renforcement cosmique endgame)
        _ => 0.0,
    }
}

// Chance critique max (garde-fou du jeu : cap 50%)
#[wasm_bindgen]
pub fn crit_chance_cap() -> f64 { 0.50 }

// ============================================================
// BATIMENTS : gain par bâtiment (production de base par unite)
// index 0..=13 dans l'ordre du jeu
// ============================================================
#[wasm_bindgen]
pub fn building_gain(index: u32) -> f64 {
    match index {
        0 => 0.1,        // workshop
        1 => 1.0,        // factory
        2 => 8.0,        // mine
        3 => 47.0,       // solar
        4 => 260.0,      // foundry
        5 => 1400.0,     // station
        6 => 7800.0,     // nanoforge
        7 => 44000.0,    // synth
        8 => 260000.0,   // antimatter
        9 => 1600000.0,  // voidrig
        10 => 10000000.0, // quasar
        11 => 65000000.0, // nebula
        12 => 430000000.0, // pulsar
        13 => 2900000000.0, // blackhole
        _ => 0.0,
    }
}

// Multiplicateur d'upgrade de batiment : x2 par palier (style Cookie Clicker)
#[wasm_bindgen]
pub fn building_upgrade_multiplier(nb_upgrades: u32) -> f64 {
    (nb_upgrades as f64).exp2()
}

// ============================================================
// BONUS PLANETES : bonusPercent par planete (index = ordre PLANETS)
// ============================================================
#[wasm_bindgen]
pub fn planet_bonus_percent(index: u32) -> f64 {
    match index {
        0 => 0.0,   // earth
        1 => 25.0,  // moon
        2 => 30.0,  // mars
        3 => 35.0,  // neptune
        4 => 40.0,  // pluto
        5 => 45.0,  // oort
        6 => 50.0,  // proxima
        7 => 55.0,  // sirius
        8 => 60.0,
        9 => 70.0,  // andromeda
        10 => 85.0,
        _ => 0.0,
    }
}

// Bonus de production par trophee debloque : +1% chacun
#[wasm_bindgen]
pub fn trophy_production_percent() -> f64 { 0.01 }

// Suite infinie : +1% de production par PE post-Virgo
#[wasm_bindgen]
pub fn infinite_stardust_percent(stardust: f64) -> f64 {
    if stardust < 0.0 { 0.0 } else { stardust * 1.0 }
}

// Bonus de production par piece de fusee possedee : +4% chacune
#[wasm_bindgen]
pub fn rocket_part_production_percent(parts_owned: u32) -> f64 {
    0.04 * parts_owned as f64
}

// Bonus des pieces de fusee sur la DISTANCE : multiplicateur par piece
// (PIECE_DISTANCE_MULT, actuellement 1.0 -- mais central dans la
// formule de distance, donc detenue ici)
#[wasm_bindgen]
pub fn piece_distance_mult() -> f64 { 1.0 }

// Puissance de clic : base x2 par upgrade de clic possede
#[wasm_bindgen]
pub fn click_base_power(nb_upgrades: u32) -> f64 {
    (nb_upgrades as f64).exp2()
}

// Bonus par batiment possede equivalent Thousand Fingers
#[wasm_bindgen]
pub fn click_finger_multiplier(nb_upgrades: u32) -> f64 {
    if nb_upgrades >= 2 { 1.0 + (nb_upgrades as f64 - 1.0) * 0.5 } else { 0.0 }
}

#[wasm_bindgen]
pub fn click_finger_unit_bonus() -> f64 { 0.1 }

// Bonus de production par upgrade de clic : 1% des Parts/s par upgrade
#[wasm_bindgen]
pub fn click_cps_percent() -> f64 { 0.01 }

// Croissance du cout des pieces de fusee entre lancements
#[wasm_bindgen]
pub fn rocket_part_cost_growth() -> f64 { 1.4 }

// Reduction du temps d'attente des boosters (garde-fou : max -60%)
#[wasm_bindgen]
pub fn booster_time_discount_floor() -> f64 { 0.40 }

// ============================================================
// V3.12 : CONSTANTES CRITIQUES additionnelles -- avant patchables
// en console (retour audit : "toutes les donnees sensibles dans
// le WASM").
// ============================================================

// Plafond du produit des multiplicateurs temporaires d'origine cometes
#[wasm_bindgen]
pub fn temp_mult_cap() -> f64 { 2048.0 }

// Bonus de production permanent par doublement du record : +50%
#[wasm_bindgen]
pub fn record_doubling_percent() -> f64 { 0.50 }

// Bonus du batiment favori : +1% de production par seconde de jeu jouee
#[wasm_bindgen]
pub fn favorite_per_second_percent() -> f64 { 0.01 }

// Bonus d'heritage industriel (V3.41bis) : POWER-LAW d'anciennete.
// heritage(b) = (gainBest / gainB)^alpha avec alpha = 0.85 : chaque batiment
// ancien rattrape une fraction de l'eccart de production avec le meilleur --
// la hierarchie est garantis mathematiquement (alpha < 1 : le gain equivalent
// par unite reste strictement croissant de l'ancien au meilleur).
#[wasm_bindgen]
pub fn heritage_alpha() -> f64 { 0.85 }

// Bonus de la suite infinie : +1% de production par PE post-Virgo
#[wasm_bindgen]
pub fn infinite_stardust_base_percent() -> f64 { 1.0 }

// Renforcement cosmique (inf-boost, endgame) : +5% par niveau
#[wasm_bindgen]
pub fn cosmic_boost_percent_per_level() -> f64 { 0.20 }

// Chance de comete par clic : 5% base / 10% avec Appel cosmique II
#[wasm_bindgen]
pub fn click_comet_chance_base() -> f64 { 0.05 }
#[wasm_bindgen]
pub fn click_comet_chance_upgraded() -> f64 { 0.10 }

// Penalite de chance de spawn par comete x2 interceptee : -15% du restant
// (V3.47bis : passage demande 10% -> 15%)
#[wasm_bindgen]
pub fn comet_chance_penalty_per_intercept() -> f64 { 0.15 }

// Choix de recompense : neutre 50/50, choix +/-15%
#[wasm_bindgen]
pub fn comet_reward_neutral_chance() -> f64 { 0.50 }
#[wasm_bindgen]
pub fn comet_reward_choice_bonus() -> f64 { 0.15 }

// Ciel frequente : chance d'une 2e comete simultanee
#[wasm_bindgen]
pub fn sky_second_comet_chance() -> f64 { 0.10 }

// ============================================================
// V3.15 : SIGNATURE DE SAUVEGARDE (anti-save-editee)
// La cle HMAC vit dans le binaire WASM : un joueur qui edite le
// JSON de sa save ne peut pas recalculer la signature valide.
// - save_sign(json) : HMAC-SHA256(cle, json) -> hex
// - save_verify(json, sig_hex) : 1 si valide, 0 sinon
// Le JS signe a chaque saveGame et verifie a chaque loadGame.
// ============================================================

// Cle secrete de signature (compilee dans le binaire). Si elle
// fuite un jour, la changer invalide TOUTES les saves -- les
// joueurs doivent alors repartir d'une save non signee (acceptee
// par le jeu avec les garde-fous de clamp).
const SIG_KEY: &[u8] = b"Starcruiser-Save-Sign-v1-4f7a9c2e";

// HMAC-SHA256 implemente a la main (pas de dependance externe,
// le binaire reste minimal et la cle reste privee au module).
fn sha256(data: &[u8]) -> [u8; 32] {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ];
    let mut h: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    ];
    let mut msg = data.to_vec();
    let bit_len = (data.len() as u64) * 8;
    msg.push(0x80);
    while msg.len() % 64 != 56 { msg.push(0); }
    msg.extend_from_slice(&bit_len.to_be_bytes());

    for chunk in msg.chunks(64) {
        let mut w = [0u32; 64];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([chunk[i*4], chunk[i*4+1], chunk[i*4+2], chunk[i*4+3]]);
        }
        for i in 16..64 {
            let s0 = w[i-15].rotate_right(7) ^ w[i-15].rotate_right(18) ^ (w[i-15] >> 3);
            let s1 = w[i-2].rotate_right(17) ^ w[i-2].rotate_right(19) ^ (w[i-2] >> 10);
            w[i] = w[i-16].wrapping_add(s0).wrapping_add(w[i-7]).wrapping_add(s1);
        }
        let (mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh) =
            (h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7]);
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let temp1 = hh.wrapping_add(s1).wrapping_add(ch).wrapping_add(K[i]).wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let temp2 = s0.wrapping_add(maj);
            hh = g; g = f; f = e; e = d.wrapping_add(temp1);
            d = c; c = b; b = a; a = temp1.wrapping_add(temp2);
        }
        h[0] = h[0].wrapping_add(a); h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c); h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e); h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g); h[7] = h[7].wrapping_add(hh);
    }
    let mut out = [0u8; 32];
    for (i, v) in h.iter().enumerate() {
        out[i*4..i*4+4].copy_from_slice(&v.to_be_bytes());
    }
    out
}

fn hmac_sha256(key: &[u8], data: &[u8]) -> [u8; 32] {
    // HMAC = H((K ^ opad) || H((K ^ ipad) || m)), blocs de 64 octets.
    let mut k = [0u8; 64];
    if key.len() > 64 {
        k[..32].copy_from_slice(&sha256(key));
    } else {
        k[..key.len()].copy_from_slice(key);
    }
    let mut ipad = [0x36u8; 64];
    let mut opad = [0x5cu8; 64];
    for i in 0..64 {
        ipad[i] ^= k[i];
        opad[i] ^= k[i];
    }
    let mut inner = ipad.to_vec();
    inner.extend_from_slice(data);
    let inner_hash = sha256(&inner);
    let mut outer = opad.to_vec();
    outer.extend_from_slice(&inner_hash);
    sha256(&outer)
}

fn to_hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{:02x}", b));
    }
    s
}

// V3.15 (revu) : le JS construit le JSON canonique (delete _sig puis
// JSON.stringify -- l'ordre des clés de JSON.parse suit l'ordre du JSON,
// _sig etant toujours ajoute en DERNIER par saveGame, sa suppression
// restitue exactement le JSON signe). Le module ne fait que le HMAC :
// c'est la que reside le secret, le parsing reste cote JS (robuste aux
// echappements, Unicode, etc.).
#[wasm_bindgen]
pub fn save_sign(canonical_json: &str) -> String {
    to_hex(&hmac_sha256(SIG_KEY, canonical_json.as_bytes()))
}

#[wasm_bindgen]
pub fn save_verify(canonical_json: &str, sig_hex: &str) -> u32 {
    let expected = save_sign(canonical_json);
    if expected == sig_hex { 1 } else { 0 }
}
// FLAG D'INTEGRITE : marque qu'une modification de code a ete
// detectee cote client. Vit dans la memoire du module -- le JS
// ne peut pas le REINITIALISER une fois pose.
// ============================================================
thread_local! {
    static INTEGRITY_FLAG: Cell<u32> = Cell::new(0);
}

#[wasm_bindgen]
pub fn mark_integrity_flag() {
    INTEGRITY_FLAG.with(|f| f.set(1));
}

#[wasm_bindgen]
pub fn get_integrity_flag() -> u32 {
    INTEGRITY_FLAG.with(|f| f.get())
}
