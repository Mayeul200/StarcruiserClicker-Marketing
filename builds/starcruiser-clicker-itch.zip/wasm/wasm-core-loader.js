// Chargeur du module WASM starcruiser-core (anti-triche couche 1bis).
// Le binaire (wasm/build/starcruiser_core_bg.wasm) detient :
//  - les constantes des records (cometes, flare, distance, vitesse)
//  - les records eux-memes (maxTravelSpeed, maxDistance) dans la memoire
//    lineaire du module : inaccessibles depuis la console JS.
// V3.15 : SIGNATURE DE SAUVEGARDE. Le HMAC-SHA256 (cle dans le binaire)
// est calcule par le module ; le JSON canonique est construit cote JS
// (suppression du champ _sig puis re-serialisation -- l'ordre des cles
// de JSON.parse suit celui du JSON source, _sig etant toujours ajoute
// en DERNIER par saveGame). Les fonctions a arguments String passent par
// le glue wasm-bindgen genere (import dynamique, ESM).
window.StarcruiserCore = (function () {
    let moduleInstance = null;
    let glue = null;
    let loading = null;
    async function load(url) {
        if (moduleInstance) return moduleInstance;
        if (loading) return loading;
        loading = (async () => {
            try {
                const glueMod = await import('./build/starcruiser_core.js');
                const init = glueMod.default;
                // V3.45 : FIX SyntaxError -- ce fichier est charge par une
                // balise <script src> CLASSIQUE (game.html) : 'import.meta'
                // n'y est legal nulle part et tuait le parse du script
                // ENTIER depuis la V3.15 (le module WASM ne chargeait
                // jamais, silencieusement, fallback JS partout). Resolution
                // par document.currentScript (URL du loader, les chemins
                // etant relatifs a lui), fallback sur location si absent.
                // V3.70 FIX : le chemin relatif 'build/...' resolvait contre
                // l'URL du loader -- MAIS servit par le Service Worker,
                // document.currentScript est parfois absent et le fallback
                // (location = racine) donnait /build/... qui repond 200 en
                // HTML (SPA fallback de l hebergeur) -> magic word '<!DO'.
                // Chemin ABSOLU depuis l'origine : insensible au context
                // (SW, racine, sous-dossier). Le param url (explicite) reste
                // prioritaire pour les tests.
                // Plateforme embarquée (GameJolt & co servent le wasm avec un mauvais
                // content-type / statut 400) : on saute carrément le WASM, le jeu
                // retombe en JS natif (mêmes mécaniques, un peu moins rapide).
                var h0 = location.hostname;
                if (/itch\.zone$/.test(h0) || /(^|\.)itch\.io$/.test(h0) || /(^|\.)crazygames\.com$/.test(h0)
                    || /(^|\.)poki\.(com|games)$/.test(h0) || /(^|\.)gamejolt\.com$/.test(h0)
                    || /serve\.gamejolt\.net$/.test(h0) || /(^|\.)newgrounds\.com$/.test(h0)) {
                    throw new Error('WASM désactivé sur plateforme embarquée (' + h0 + '), fallback JS natif.');
                }
                const origin = (location.origin || '');
                const wasmUrl = url || (origin + '/wasm/build/starcruiser_core_bg.wasm');
                // V3.45bis : API wasm-bindgen actuelle -- init attend un OBJET
                // { module_or_path } (l'appel avec une string brute declenchait
                // le warning 'deprecated parameters'). Garde-fou : si le
                // serveur renvoie du HTML (404 SPA au lieu du binaire), on
                // detecte le mauvais magic word AVANT instantiate et on log
                // une erreur claire au lieu du cryptique 'expected magic word'.
                // Garde-fou magic word : un serveur mal configure (ou un
                // deployment sans le binaire) renvoie une page HTML -- on le
                // detecte avant instantiate pour un message CLAIR.
                const probe = await fetch(wasmUrl);
                if (!probe.ok) throw new Error('WASM HTTP ' + probe.status + ' pour ' + wasmUrl);
                const headBuf = new Uint8Array(await probe.clone().arrayBuffer()).slice(0, 4);
                if (headBuf[0] !== 0x00 || headBuf[1] !== 0x61 || headBuf[2] !== 0x73 || headBuf[3] !== 0x6d) {
                    throw new Error('Le serveur ne renvoie pas le binaire WASM a ' + wasmUrl + ' (HTML/404 ?)');
                }
                const wasmObj = await init({ module_or_path: wasmUrl });
                glue = glueMod;
                moduleInstance = wasmObj;
                return moduleInstance;
            } catch (e) {
                console.warn('[Starcruiser] Module WASM indisponible, fallback JS natif.', e);
                moduleInstance = null;
                return null;
            }
        })();
        return loading;
    }
    // JSON canonique : la save SANS son champ de signature.
    function canonicalSaveJson(saveJsonString) {
        const obj = JSON.parse(saveJsonString);
        if (obj && typeof obj === 'object' && '_sig' in obj) delete obj._sig;
        return JSON.stringify(obj);
    }
    return {
        load,
        get exports() { return moduleInstance; },
        // V3.81 : ATTENTE MODULE -- script.js testait 'loading !== undefined'
        // mais la variable etait PRIVEE : la garde d'attente V3.21 etait
        // MORTE, loadGame verifiait la signature AVANT que le module soit
        // pret (saveVerify -> null) et le warning 'Signature non verifiee'
        // revenait a CHAQUE rechargement, meme sur une save parfaitement
        // valide. Expose l'etat reel du chargement.
        get loading() { return loading; },
        get ready() { return !!glue; },
        // Signe le JSON CANONIQUE d'une sauvegarde (sans le champ _sig).
        saveSign: function (saveJsonString) {
            if (!glue) return null;
            return glue.save_sign(canonicalSaveJson(saveJsonString));
        },
        // Verifie une sauvegarde COMPLETE (le champ _sig est retire
        // par le canonique avant la comparaison).
        saveVerify: function (saveJsonString, sigHex) {
            if (!glue) return null;
            return glue.save_verify(canonicalSaveJson(saveJsonString), sigHex);
        }
    };
})();
